# [Orchestrator Name] — Architecture

---

## System Overview

```
You
  │
  ▼
[Orchestrator]  ← you talk to ONE agent
  │
  ├── Agent Registry (who exists, what they do)
  ├── External context source (wiki / Notion / docs — always-current)
  ├── Memory (cross-session learning)
  │
  ├── agent-builder/     ← builds new agents via the build pipeline
  ├── agent-security/    ← the bouncer — PASS/WARN/BLOCK on anything external
  ├── agent-self-improve/ ← the weekly report card — see self-improve-loop-real-example.md
  └── [new agents created as needed]
```

---

## Agent Repository Standard Structure — THE 8-DOC STRUCTURE

Every agent follows this exact shape. Same shape, every time, means a fresh AI session can orient itself in seconds regardless of which agent it's looking at.

```
agent-[name]/
├── CLAUDE.md            # This agent's own boot sequence and rules
├── README.md            # What this agent does and how to invoke it
├── agent-memory.md       # This agent's own cross-session memory
├── docs/
│   ├── PRD.md            # What it is and does
│   ├── ARCHITECTURE.md   # How it's built
│   ├── SOUL.md           # Its identity/personality (if user-facing)
│   ├── SECURITY.md       # Hard rules — highest priority
│   ├── ROADMAP.md        # What's being built and when
│   ├── DECISIONS.md      # Log of key technical decisions
│   └── SPRINT_LOG.md     # Session-by-session progress log
├── skills/               # Agent-specific skill/playbook files
└── [wiki/ or equivalent]  # Raw captures / structured knowledge / outputs
```

**Why this matters more than it looks:** the `agent-memory.md` + `SPRINT_LOG.md` + `DECISIONS.md` combination IS the "output file" that gets reviewed weekly against the PRD (see self-improve-loop-real-example.md). Without a standard shape, that review can't be automated at all — a human or judge model would need bespoke logic per agent. With it, the same review process works on every agent in the fleet, no matter how different their actual job is.

---

## Architectural Principles

1. **File-native** — all memory, docs, and skills live in version-controlled, human-and-AI-readable files. Nothing important lives only in a chat window.
2. **Confirmation-gated** — nothing executes without explicit human go-ahead.
3. **Compound learning** — outputs become inputs; the system is designed to get smarter every week, not just every model upgrade.
4. **Portable** — no proprietary platform lock-in. The whole system can be rebuilt anywhere from these docs alone.
