# [Orchestrator Name] — Roadmap

What's being built, and when. Kept short on purpose — this is a living doc, not a planning archive (that's what DECISIONS.md and SPRINT_LOG.md are for).

---

## Now

- [What's actively being built this week]

## Next

- [What's queued once "Now" ships]

## Later / Ideas

- [Things worth doing eventually, not yet scoped]

---

Update this file at the end of every session where priorities shifted. If it's stale, the next session inherits a stale plan — that's the whole failure mode this file exists to prevent.
