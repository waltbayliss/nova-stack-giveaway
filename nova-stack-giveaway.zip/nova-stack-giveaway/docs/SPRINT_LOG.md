# [Orchestrator Name] — Sprint Log

Session-by-session progress log. This is the "output file" — what the weekly self-improve review actually reads. See `skills/self-improve-loop-real-example.md`.

---

## Session [N] — [DATE]

**Status:** Complete / In progress

### Done
- [What actually got built/fixed/shipped this session, in plain English]

### Broke / learned
- [Anything that went wrong, and the lesson extracted — this is what feeds lessons.md]

### Open / next
- [What's unresolved, what the next session should pick up first]

---

*(Newest session at the top. Every session gets an entry, even short ones — this is what makes "start a new session, pick up exactly where the last one stopped" actually work.)*
