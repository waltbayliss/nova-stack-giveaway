# [Orchestrator Name] — Product Requirements Document

**Version:** 1.0
**Owner:** [Your Name]
**Status:** Active

---

## Overview

[One paragraph: what is this system, who is it for, what does it replace or improve on.]

---

## Target User

[Who you're building this for. Be specific — role, context, working style, what they need that they don't currently have.]

---

## Core Problem

[What's actually broken or missing without this system. Not "AI could help with X" — the specific, felt problem.]

---

## MVP Feature Set

### Feature 1: [Name]
- [What it does]
- [How it's triggered]
- [What "done" looks like]

### Feature 2: [Name]
...

---

## Future Agents / Capabilities (planned, not yet built)

| Agent/Feature | Purpose | Priority |
|---|---|---|
| | | |

---

## Out of Scope

- [Things this system deliberately does NOT do — as important as what it does do]
