# [Orchestrator Name] — Decisions Log

A running record of key technical/product decisions and WHY they were made — not just what. The "why" is the part that saves you from re-litigating the same debate three months later.

---

## [DATE] — [Decision title]

**Decision:** [What was decided]
**Alternatives considered:** [What else was on the table]
**Why this one:** [The actual reasoning]
**Revisit if:** [The condition that would make this decision wrong]

---

*(Newest entries at the top. Never delete an old entry — if a decision gets reversed, log the reversal as a new entry that references the old one.)*
