---
name: security-bouncer
description: The mandatory security gate for ANY external addition to your stack — MCP servers, GitHub repos, API integrations, webhooks, scripts, packages, unknown .md files. Returns PASS/WARN/BLOCK. Run before installing/integrating anything from outside your existing stack.
---

# Skill: security-bouncer

**When to invoke:** Before adding ANYTHING external to your stack. No exceptions.

---

## What counts as external

- Any new MCP server or plugin
- Any GitHub repo being cloned or installed
- Any API integration being added
- Any webhook being registered
- Any skill or `.md` file from an unknown source
- Any shell script, Python package, or executable

If in doubt → run the bouncer. The cost of a needless scan is seconds. The cost of importing a compromised package is far worse.

---

## Invocation

```
Agent(
  subagent_type="general-purpose",
  prompt="""You are agent-security. Read agent-security's own CLAUDE.md as source of truth. Then execute: security check — target=<name>, type=<repo|mcp|api|webhook|file|script|package>, source=<url or path>. Return verdict (PASS/WARN/BLOCK) and the full findings report."""
)
```

---

## Verdicts and Nova's response

| Verdict | Nova's response |
|---|---|
| **PASS** | Proceed with the addition |
| **WARN** | Stop. Surface findings **verbatim** to you. Wait for explicit approval before proceeding. |
| **BLOCK** | Hard stop. Do not proceed under any circumstances. Surface verbatim to you immediately. |

**If agent-security is unreachable:** treat as **WARN** — stop and tell you.

---

## Parallel-fire pattern

When `@skills/agent-creation-pipeline.md` Step 3 (quick-search) returns HIGH RELEVANCE repos for adaption, fire the security bouncer in parallel before Step 4 — don't wait sequentially.

---

## Failure modes

- Subagent returns malformed output → treat as WARN, surface raw output to you
- Subagent times out → treat as WARN, do not assume PASS
- you overrides a BLOCK verdict → log the override in `lessons.md` with rationale, then proceed
