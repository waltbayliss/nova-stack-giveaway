# Build Quality Pipeline — Skill

A portable, self-contained Claude Code skill that runs a four-stage quality gate on any software build:

1. **Prior Art Research** — discovers what already exists, surfaces a Feature Menu of ideas to incorporate
2. **PRD Review** — 9-point spec check before a single line of code is written
3. **Security Pre-Check** — verifies repos/packages are real, flags credential and injection risks
4. **Code Review** — 6-dimension, 2-pass post-build review with mechanical verification steps

No external API keys required. No Python, no repos to clone beyond this one. Works on any machine with Claude Code installed.

---

## Install

```bash
# One command — run from anywhere
curl -fsSL https://raw.githubusercontent.com/waltbayliss/skill-build-pipeline/main/install.sh | bash
```

Or manually:
```bash
git clone https://github.com/waltbayliss/skill-build-pipeline.git /tmp/skill-build-pipeline
bash /tmp/skill-build-pipeline/install.sh
```

Then restart Claude Code (or start a new session) for the skill to be available.

---

## Usage

```
/build-pipeline                          → full pipeline (will prompt for brief)
/build-pipeline [brief text]             → full pipeline with brief inline
/build-pipeline --research [brief]       → Stage 1 only: prior art research
/build-pipeline --prd [brief or path]    → Stage 2 only: PRD review
/build-pipeline --security [url|path]    → Stage 3 only: security scan
/build-pipeline --review [path]          → Stage 4 only: post-build code review
/build-pipeline --review [path] --pass2  → Stage 4 Pass 2 after fixes applied
```

---

## What you get

- **Before writing code:** Stages 1–3 tell you what exists, what's wrong with your spec, and whether your dependencies are safe.
- **After writing code:** Stage 4 gives you a structured review across structure, security, code quality, spec alignment, documentation, and runtime correctness.
- **Clear gates:** BLOCKED in Stage 2 = don't write code yet. BLOCK in Stage 3 = don't write code yet. Two-pass cap on code review with a hard escalation if Pass 2 still fails.

---

## Requirements

- Claude Code (any version)
- No additional tools required — uses WebSearch, WebFetch, Read, Bash (standard Claude Code tools)
- Optional: if reviewing code, the code must be locally accessible (Read tool)

---

## What it does NOT do

- Does not write to Notion, GitHub, or any external system
- Does not install packages or clone repos
- Does not make decisions for you — it surfaces findings and verdicts, you decide what to do

---

## Source

Part of the Nova AI agent stack — waltbayliss.com
