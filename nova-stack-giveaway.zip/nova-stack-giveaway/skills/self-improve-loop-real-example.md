# The Self-Improve Loop — A Real Working Example

This is a redacted but structurally faithful copy of the operating instructions for the agent that runs the weekly self-improvement loop across a live 98-agent fleet. Paths, credential names, and internal IDs have been genericised — the actual mechanism is presented as it really runs.

---

## WHAT THIS AGENT DOES

Runs three scheduled components plus a retrofit tool:

1. **Daily judge** — reads structured run logs from every agent, verifies they haven't been tampered with, scores each agent's output via an adversarial LLM ensemble, fires an alert on hard failures.
2. **Weekly analyser** — reads 7 days of assessments, updates ELO-style rankings across the whole fleet, promotes cross-fleet patterns to a shared lessons file, writes improvement proposals to a review queue.
3. **Approval poller** — polls the review queue for human-approved proposals, dispatches them to the agent-builder pipeline sequentially.
4. **Post-verifier** (triggered by the poller) — monitors the agent for a window of runs after any change ships, auto-reverts on regression.

Every agent in the fleet writes structured, tamper-evident log entries. This agent reads those logs — it never has to guess what happened, because every run leaves a verifiable trail.

---

## THE ADVERSARIAL JUDGE RULE

**The judge model must be a different model family from the agent being judged.** An agent built on one model family gets judged by a different one. Same-family judging is forbidden by hard rule.

This is the single most important design decision in the whole loop: a model grading its own homework will rate itself generously. A model from a different lineage, with no stake in the outcome, catches what self-assessment misses.

---

## SCHEDULING

| Component | Cadence |
|---|---|
| Daily judge | nightly |
| Weekly analyser | weekly |
| Approval poller | every 15 minutes |
| Log cleanup | nightly |

---

## SECURITY RULES

- Never log secrets — logging goes through a sanitiser that strips anything credential-shaped before it's written.
- All improvement proposals are treated as untrusted text until a human approves them.
- The builder pipeline is never invoked without explicit human approval on the specific proposal. Automation writes the report card; a human still signs the improvement.

---

## THE FULL LOOP, END TO END

```
Every agent run
  → writes a tamper-evident log entry
      ↓
Daily judge
  → scores every agent's output (different-model-family judge)
  → hard failures alert immediately
      ↓
Weekly analyser
  → updates fleet-wide ELO rankings
  → promotes cross-fleet lessons to a shared file
  → writes improvement PROPOSALS (not changes) to a review queue
      ↓
YOU approve or reject each proposal
      ↓
Approval poller
  → dispatches approved proposals to the build pipeline
      ↓
Post-verifier
  → watches the change for N runs post-deployment
  → regression detected → automatic revert, no ticket, no drama
```

Nothing in this loop ever bypasses the human approval gate. The system finds the patterns and drafts the fix. A person still decides whether the fix ships. That's the difference between "self-improving" and "self-modifying without oversight" — and it's the difference that makes this safe to run unattended on a live fleet.
