# SELF-IMPROVEMENT LOOP — Skill Protocol

This skill executes at the end of EVERY agent run, regardless of trigger (Nova routing, timer, Telegram, CLI, webhook). It is non-negotiable. A run is not complete until this protocol has fired.

---

## STEP 1 — Write Raw Capture

Create file: `wiki/Raw/{YYYY-MM-DD}-{task-slug}-raw.md`

Use this format:

```
# Raw Capture — {task-slug} — {YYYY-MM-DD}

**Trigger:** [how this run was initiated — Nova routing / timer / CLI / webhook]
**Input:** [what was asked, or what data arrived]
**Actions taken:** [tools called, APIs hit, decisions made — brief bullet list]
**Output:** [what was produced or delivered]
**Errors / surprises:** [anything unexpected, any retry, any fallback]
**Duration:** [approximate]
**Notes:** [anything else worth capturing]
```

---

## STEP 2 — Reflect

Read the raw capture you just wrote. Then read your PURPOSE from your CLAUDE.md (the one-line "what this agent does").

Answer these 5 questions:

1. **Alignment** — Was this run aligned with my stated purpose?
2. **Efficiency** — Was this the most direct path? Is there a shorter route?
3. **Prior pattern?** — Have I done something similar before? Check agent-memory.md. Did I do it the same way or differently?
4. **Prevention** — Did anything go wrong that a rule could prevent next time?
5. **Feedback** — Did I receive any explicit or implicit feedback from you or Nova that changes how I should operate?

---

## STEP 3 — Act on Reflection

**Nothing significant surfaced:** done. No further writes required.

**New observation, unconfirmed:**
→ Note it in the raw capture only. Add: `[WATCH] {observation}` at the bottom of the raw file.
→ Do not update memory yet.

**Pattern confirmed 3+ times** (check Raw/ for prior `[WATCH]` entries on the same topic):
→ Update `agent-memory.md` with a permanent entry:
```
[{DATE}] PATTERN: {what was observed} | RULE: {what this agent now does differently} | CONFIRMED: {N} occurrences
```

**you gave explicit feedback this run:**
→ Update `agent-memory.md` immediately. No 3x threshold required.
```
[{DATE}] WALT FEEDBACK: {what he said or corrected} | RULE: {permanent behavioral change applied}
```

**Hard rule change warranted** (a pattern that should govern every future run, not just influence behaviour):
→ DO NOT write to CLAUDE.md directly — ever.
→ Write a proposal to `pending-rules.md` in this agent's folder:
```
## [{DATE}] Proposed Rule Change

**Pattern observed:** {what happened}
**Occurrences:** {N}
**Proposed CLAUDE.md addition:** {exact text of the rule}
**Reason this should be a hard rule:** {why memory-level guidance is not sufficient}
```
→ Also write an identical entry to `nova-assistant/pending-agent-rules/{agent-name}.md` (central inbox) so Nova sees it at next session boot.
→ Nova reviews and actions all proposals. Agent never self-modifies CLAUDE.md under any circumstances.

---

## STEP 4 — Wiki Synthesis Check

Count `.md` files in `wiki/Raw/` that do NOT contain the tag `[SYNTHESISED]`.

**If 10 or more unprocessed files exist:**
→ Add to `pending-rules.md`:
```
## [{DATE}] Wiki Synthesis Due
{N} raw captures are unprocessed. Request Nova to run wiki synthesis for this agent.
```
→ Also add to `nova-assistant/pending-agent-rules/{agent-name}.md`

**Wiki synthesis** (run by Nova on request — not by the agent autonomously):
- Read all unprocessed Raw/ files
- Extract confirmed patterns, reference facts, process learnings
- Write or update topical articles in `wiki/Wiki/`
- Regenerate `wiki/Master/master-context.md` as a synthesised summary
- Add `[SYNTHESISED]` tag to each processed Raw/ file

---

## HARD RULES

1. This skill fires after EVERY run. No exceptions. No "this run was too short to bother."
2. Raw captures are append-only. Never edit a prior Raw/ file — only add `[SYNTHESISED]` tag when processed.
3. Agent never writes to its own CLAUDE.md. Proposals go to pending-rules.md only.
4. `nova-assistant/pending-agent-rules/` is the central inbox. Always write there when flagging Nova.
5. Memory graduation path: Raw/ → agent-memory.md → pending-rules.md (proposal) → CLAUDE.md (Nova only).
6. The reflection step uses the agent's current model — keep it lightweight. Answer the 5 questions, act on results, move on. This is not a deep analysis session.
