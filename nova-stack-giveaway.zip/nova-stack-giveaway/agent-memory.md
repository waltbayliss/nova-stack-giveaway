# Agent Memory

Cross-session memory — read at every session start, updated at session close. This is different from SPRINT_LOG.md (that's the narrative log) — this file holds distilled, confirmed patterns only.

Graduation path: a raw observation → confirmed 3 times, or explicit correction from you → gets written here as a permanent entry. Nothing goes straight from "noticed once" to "permanent rule."

---

## Confirmed Patterns

[DATE] PATTERN: {what was observed} | RULE: {what changed as a result} | CONFIRMED: {N} occurrences

[DATE] FEEDBACK: {what you said or corrected} | RULE: {permanent behavioral change applied — logged immediately, no threshold required for direct feedback}

---

*(This file is written by you, or by the self-improve loop after confirmation — never by an agent silently rewriting its own rules.)*
