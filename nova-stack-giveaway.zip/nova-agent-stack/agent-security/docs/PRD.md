# agent-security — PRD

## What This Agent Is

The Security Bouncer is Nova's mandatory security gate. It intercepts every external input entering Walt's AI team system and blocks anything with harm potential before it can execute, be read, or influence any agent.

This is not optional middleware. It is the first call Nova makes whenever anything external is introduced.

---

## Problem It Solves

As Nova's team grows — more agents, more MCP servers, more skills, more repos, more external tools — the attack surface grows with it. Without a dedicated gate:

- Malicious code in a GitHub repo could execute on Walt's machine
- Prompt injection in a skill file could redirect Nova's behaviour
- A rogue MCP server could intercept all tool calls
- Hardcoded credentials in imported code could be exfiltrated
- AI config tampering could silently change how agents behave

The Security Bouncer prevents all of this with a structured, tiered scan before anything touches the system.

---

## Core Capabilities

### 1. Universal Interception
Scans all external inputs without exception:
- GitHub repos (new or updated)
- Skill files (.md)
- MCP server configs
- Python, JS, YAML, shell scripts
- CLAUDE.md files from external sources
- Any file imported from outside the system

### 2. Three-Tier Scan Protocol
- **Tier 1 (Quick):** Pattern matching, prompt injection detection, obvious secret exposure — Ollama local model, <10 seconds
- **Tier 2 (Static):** Full Semgrep OWASP scan + Gitleaks secrets scan + custom Nova ruleset — <60 seconds
- **Tier 3 (Deep):** Docker sandbox isolation, behaviour analysis, network call detection — minutes, used for flagged items

### 3. Structured Verdict
Every scan returns: `PASS / WARN / BLOCK` with risk score, findings, and action instruction for Nova.

### 4. Memory of Threats
Logs all findings to `agent-memory.md`. Builds a knowledge base of known threat patterns specific to Nova's environment.

### 5. Manual Scan Mode
Nova or Walt can trigger a direct scan of any file or repo at any time.

---

## Inputs

- File path or GitHub repo URL
- Content (raw text, code, YAML, markdown)
- Scan type override (optional — defaults to auto-tier)

## Outputs

- Structured verdict (PASS/WARN/BLOCK)
- Risk score 1–10
- Findings list
- Action instruction for Nova

---

## Non-Goals

- The bouncer does not fix vulnerabilities — it detects and reports them
- The bouncer does not make install decisions — Nova and Walt do
- The bouncer does not scan Walt's own committed code (only external inputs)
