# agent-security — Roadmap

## Phase 1 — Core Gate (Current)

- [x] Repo created and structured
- [x] CLAUDE.md, 8 docs, skills, wiki
- [ ] Semgrep installed and configured locally
- [ ] Gitleaks installed and configured locally
- [ ] Ollama integration wired (Tier 1 scans)
- [ ] `src/scanner.py` functional for static scans
- [ ] Custom Nova rules (`nova-rules.yml`) — initial ruleset
- [ ] Nova wired to call bouncer before any external read
- [ ] Verdict format tested end-to-end

## Phase 2 — Sandbox

- [ ] Docker sandbox environment configured
- [ ] Tier 3 deep scan working for Python/JS
- [ ] Network egress monitoring in sandbox
- [ ] Automated sandbox teardown after scan

## Phase 3 — Intelligence

- [ ] Threat memory — known bad patterns logged and reused
- [ ] Reputation scoring for GitHub repos/authors
- [ ] Incremental scanning (only scan changed files in a repo)
- [ ] Scan results cached for unchanged files (avoid re-scanning known-clean sources)

## Phase 4 — Integration

- [ ] Nova Telegram alert for BLOCK verdicts (immediate push to Walt)
- [ ] Daily digest of all scans (PASS summary + any WARNs/BLOCKs)
- [ ] Integration with agent-builder (auto-scan before any new agent is installed)
- [ ] MCP server scanning protocol (dedicated scan type for `.json` MCP configs)

## Stretch

- [ ] GitHub webhook — auto-scan on push to any connected repo
- [ ] YARA rules for binary/obfuscated file detection
- [ ] VirusTotal API integration for file hash checks
