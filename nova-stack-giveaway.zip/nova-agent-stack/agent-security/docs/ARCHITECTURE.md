# agent-security — Architecture

## Stack

| Layer | Tool | Role |
|-------|------|------|
| Orchestration | Nova (claude-sonnet-4-6) | Routes all external inputs through bouncer |
| Primary scan model | Ollama (local) | Tier 1 quick scans — free, no token cost |
| Escalation model | Claude Haiku 4.5 | Tier 2 complex analysis |
| Deep analysis | Claude Sonnet 4.6 | Tier 3 multi-vector threats |
| Static analysis | Semgrep | OWASP ruleset + custom Nova rules |
| Secret scanning | Gitleaks | Credential and API key detection |
| Sandbox execution | Docker | Isolated runtime for suspicious code |
| Repo access | GitHub MCP | Fetch files and inspect commits |
| Source | Python 3.11+ | Core scanner logic |

---

## Directory Structure

```
agent-security/
├── CLAUDE.md                    ← Boot sequence and operating rules
├── agent-memory.md              ← Session learnings and known threat log
├── .env.example                 ← Required environment variables
├── docs/
│   ├── PRD.md                   ← Capabilities and scan protocol
│   ├── ARCHITECTURE.md          ← This file
│   ├── SOUL.md                  ← Agent identity and purpose
│   ├── SECURITY.md              ← Hard rules (highest priority)
│   ├── ROADMAP.md               ← Planned features
│   ├── DECISIONS.md             ← Key decisions log
│   └── SPRINT_LOG.md            ← Session-by-session build log
├── skills/
│   ├── scan-quick.md            ← Tier 1 quick scan skill
│   └── scan-deep.md             ← Tier 3 sandbox deep scan skill
├── src/
│   ├── scanner.py               ← Main scan orchestrator
│   ├── verdict.py               ← Verdict formatting and reporting
│   └── rules/
│       └── nova-rules.yml       ← Custom Semgrep ruleset for Nova environment
└── wiki/
    ├── Raw/                     ← Raw session outputs
    ├── Wiki/                    ← Processed knowledge
    ├── Output/                  ← Deliverables
    └── Master/                  ← Master context
```

---

## Scan Flow

```
External Input
      ↓
Nova receives request (repo, skill, file, code)
      ↓
Nova calls Security Bouncer BEFORE any other action
      ↓
Tier 1: Ollama quick scan (always runs)
      ↓ (if flagged)
Tier 2: Semgrep + Gitleaks static analysis
      ↓ (if still flagged or executable)
Tier 3: Docker sandbox execution
      ↓
Verdict: PASS / WARN / BLOCK
      ↓
PASS → Nova proceeds
WARN → Nova pauses, reports to Walt for decision
BLOCK → Hard stop, Nova reports, nothing proceeds
```

---

## Model Routing

Follows the same optimizer-first protocol as all Nova agents:

1. Ollama local → all Tier 1 scans (free, no API cost)
2. Haiku → Tier 2 when Ollama flags something needing LLM judgement
3. Sonnet → Tier 3 deep or multi-vector analysis
4. Opus → Not used (never needed for security scanning tasks)

---

## Environment Variables

```
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=llama3.2
ANTHROPIC_API_KEY=
GITHUB_TOKEN=
DOCKER_SOCKET=/var/run/docker.sock
SEMGREP_APP_TOKEN=        # optional — needed for cloud rules
```

---

## Integration Point with Nova

The bouncer is called as middleware. Nova's routing protocol:

```python
# Before any external read/import/install:
verdict = security_bouncer.scan(target)
if verdict.result == "BLOCK":
    nova.report_block(verdict)
    return  # hard stop
elif verdict.result == "WARN":
    nova.ask_walt(verdict)
    return  # wait for confirmation
# PASS — proceed normally
```
