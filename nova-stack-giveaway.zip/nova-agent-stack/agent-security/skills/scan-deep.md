# Skill: scan-deep

**Tier 3 — Deep Sandbox Scan**
**Model:** Claude Sonnet (for analysis), Docker (for execution)
**Target time:** 2-10 minutes depending on scope

---

## When to Use

Use when:
- Tier 1 or Tier 2 returned WARN (not BLOCK — BLOCKs never reach here)
- The incoming item contains executable code (Python, JS, shell scripts)
- Walt or Nova explicitly requests a deep scan
- Any new GitHub repo being imported into the system

---

## What It Does

### Stage 1: Pre-execution static review (Sonnet)
- Full code review for logic-level threats
- Identifies: delayed execution triggers, obfuscated code, unusual import chains
- Checks for: data exfiltration patterns, file system traversal, process spawning

### Stage 2: Docker sandbox execution
- Spins up isolated Docker container (no network, no file system access beyond `/sandbox`)
- Executes the code with monitored runtime
- Captures: stdout, stderr, file system changes, attempted network calls, process spawning
- Tears down container completely after scan

### Stage 3: Behaviour analysis (Sonnet)
- Reviews execution output
- Flags: any attempted network call, unexpected file writes, process escalation
- Cross-references with Stage 1 findings

---

## Docker Config

```bash
docker run \
  --rm \
  --network none \
  --memory 256m \
  --cpus 0.5 \
  --read-only \
  --tmpfs /sandbox:rw,size=50m \
  --user nobody \
  python:3.11-slim \
  python /sandbox/target.py
```

Key flags:
- `--network none` — no internet access
- `--read-only` — cannot write to system
- `--user nobody` — no root privileges
- `--rm` — container deleted after scan

---

## Output

```
VERDICT: PASS | WARN | BLOCK
SCAN_TYPE: deep
RISK_SCORE: 1-10
STATIC_FINDINGS: [list from Stage 1]
RUNTIME_FINDINGS: [list from Stage 2]
BEHAVIOUR_ANALYSIS: [Stage 3 summary]
NETWORK_ATTEMPTS: [list or "none"]
FILE_WRITES: [list or "none"]
ACTION: proceed | review with Walt | hard block
```

---

## Hard Rules

- Never run deep scan without Docker installed and verified
- Never run deep scan on Walt's own committed code
- Never skip the container teardown
- Always log the full output to agent-memory.md threat log
