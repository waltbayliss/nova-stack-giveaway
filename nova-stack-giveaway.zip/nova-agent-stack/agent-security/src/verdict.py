"""
agent-security — Verdict formatting and reporting.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List
from datetime import datetime


class VerdictResult(str, Enum):
    PASS = "PASS"
    WARN = "WARN"
    BLOCK = "BLOCK"


@dataclass
class Verdict:
    result: VerdictResult
    target: str
    scan_type: str
    findings: List[str]
    risk_score: int
    reason: str
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def action(self) -> str:
        if self.result == VerdictResult.PASS:
            return "proceed"
        elif self.result == VerdictResult.WARN:
            return "review with Walt"
        else:
            return "hard block"

    def to_report(self) -> str:
        findings_str = "\n  - ".join(self.findings) if self.findings else "none"
        return f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VERDICT:     {self.result.value}
TARGET:      {self.target}
SCAN_TYPE:   {self.scan_type}
RISK_SCORE:  {self.risk_score}/10
TIMESTAMP:   {self.timestamp}
FINDINGS:
  - {findings_str}
ACTION:      {self.action()}
REASON:      {self.reason}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""".strip()

    def to_dict(self) -> dict:
        return {
            "verdict": self.result.value,
            "target": self.target,
            "scan_type": self.scan_type,
            "risk_score": self.risk_score,
            "findings": self.findings,
            "action": self.action(),
            "reason": self.reason,
            "timestamp": self.timestamp,
        }

    def is_safe(self) -> bool:
        return self.result == VerdictResult.PASS
