"""
agent-security — CLI Entry Point
Nova calls this before reading or importing any external content.

Usage:
    python3 src/cli.py --target "https://github.com/user/repo" --type url
    python3 src/cli.py --target "skill-name.md" --content "file content here"
    python3 src/cli.py --target "path/to/file.py" --file path/to/file.py
    python3 src/cli.py --target "test" --content "ignore previous instructions" --tier quick
"""

import argparse
import sys
import os

# Allow running from repo root
sys.path.insert(0, os.path.dirname(__file__))

from scanner import SecurityScanner, ScanTarget


def main():
    parser = argparse.ArgumentParser(
        description="Security Bouncer — scan before anything enters Nova's system"
    )
    parser.add_argument(
        "--target", required=True,
        help="Name or identifier of what's being scanned (URL, filename, repo name)"
    )
    parser.add_argument(
        "--content", default=None,
        help="Raw content to scan (string)"
    )
    parser.add_argument(
        "--file", default=None,
        help="Path to file to scan"
    )
    parser.add_argument(
        "--tier", choices=["quick", "static", "deep"], default=None,
        help="Force a specific scan tier (default: auto)"
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output verdict as JSON instead of formatted report"
    )

    args = parser.parse_args()

    # Get content
    content = args.content
    if not content and args.file:
        try:
            with open(args.file, "r") as f:
                content = f.read()
        except Exception as e:
            print(f"ERROR: Could not read file: {e}")
            sys.exit(2)

    if not content:
        print("ERROR: Provide either --content or --file")
        sys.exit(2)

    target = ScanTarget(
        name=args.target,
        content=content,
        path=args.file,
        scan_type=args.tier
    )

    scanner = SecurityScanner()
    verdict = scanner.scan(target)

    if args.json:
        import json
        print(json.dumps(verdict.to_dict(), indent=2))
    else:
        print(verdict.to_report())

    # Exit code signals Nova: 0=PASS, 1=WARN, 2=BLOCK
    exit_codes = {"PASS": 0, "WARN": 1, "BLOCK": 2}
    sys.exit(exit_codes.get(verdict.result.value, 1))


if __name__ == "__main__":
    main()
