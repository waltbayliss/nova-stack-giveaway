# ADR-001 — Self-Improvement Loop via lessons.md

**Date:** 2026-04-26
**Status:** Accepted
**Session:** 44
**Decided by:** Walt + Nova

---

## Context

Nova had session memory (`nova-memory.md`) but no mechanism to specifically capture mistakes and convert them into permanent prevention rules. Every new session could repeat the same errors because the correction loop was informal — learnings were mixed into general memory without a structured mistakes-only file.

Analysis of Boris Cherny's CLAUDE.md approach (Boris built Claude Code) confirmed: the self-improvement loop is the single highest-leverage missing piece in Nova's system.

**Gap identified:** Nova's setup was in the top 5% globally, but was missing the compounding mechanism that makes the system genuinely self-improving rather than just memory-persistent.

---

## Decision

Create `lessons.md` as a dedicated mistake-capture file with these properties:
- Every correction from Walt → Nova immediately appends an entry
- Entry format: Date / Mistake / Rule / Apply When
- File is read at session boot **before** nova-memory.md
- Nova confirms every write: "Lesson logged."
- File lives at repo root alongside nova-memory.md

Also added to CLAUDE.md:
- Boot Step 2: `lessons.md` added to read order (after AGENT-REGISTRY, before nova-memory)
- Operating Rule 16: SELF-IMPROVEMENT LOOP — mandatory correction capture
- Operating Rule 17: Plan mode for any 3+ step task
- Operating Rule 18: Verify before done

---

## Consequences

**Positive:**
- Mistakes compound into rules rather than repeating across sessions
- Session memory stays clean (nova-memory.md = patterns/context, lessons.md = mistakes/rules)
- Nova gets measurably smarter session over session — quantifiable improvement
- Zero babysitting for repeated errors
- Audit trail: every lesson is timestamped and attributed to a session

**Neutral:**
- Small overhead: Nova must write to lessons.md after corrections (~30 seconds)
- File will grow over time — will need occasional pruning once mature

---

## Rejected Alternatives

**Corrections into nova-memory.md:** Too mixed with general patterns. No clear structure for mistake→rule extraction. Hard to scan at boot.

**Corrections into CLAUDE.md directly:** CLAUDE.md is architecture and rules, not runtime learning. Would bloat the primary instruction file with operational history.

**No capture at all:** The default. Confirmed as the highest-cost option: every correction burns tokens twice (once when it happens, again when the same mistake repeats).

---

## Related Files

- `lessons.md` — the live mistake capture file
- `docs/runbooks/RUN-001-session-close.md` — includes lessons.md update in close protocol
- `nova-memory.md` — general session learnings (separate concern)
