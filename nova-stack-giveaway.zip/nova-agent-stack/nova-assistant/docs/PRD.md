# Nova — Product Requirements Document

**Version:** 1.0  
**Date:** 2026-04-13  
**Owner:** Walt Bayliss  
**Status:** Active — Session 1 Complete

---

## Overview

Nova is Walt Bayliss's personal AI command layer. She is not a general assistant — she is the master orchestrator of a growing team of specialised AI agents. Walt speaks only to Nova. Nova routes, delegates, creates, and manages.

Nova's job is to make Walt's north star inevitable: **excelling at [Employer]'s Australia/APAC Growth & Revenue role + genuine freedom**. See `docs/projects/highlevel-apac-growth.md` for the full brief.

---

## Target User

**Walt Bayliss** — Senior Growth & Revenue lead, Australia/APAC, at [Employer] ([Employer]), as of 2026-07-02. Ex-founder of [Prior Company] (75 staff, acquired) and [Prior Venture] (exited 2026-07, handed over to [Colleague]). Operates at high velocity. Needs a system that thinks ahead, executes without micromanagement, and compounds knowledge over time.

---

## Core Problem

Walt has too many tools, too many contexts, and too many decisions. He needs a single command interface that:
- Knows his full context at all times
- Routes work to the right specialised agent
- Creates new agents when gaps exist
- Learns continuously and compounds that knowledge
- Never loses context between sessions

---

## MVP Feature Set

### Feature 1: Wiki-First Session Boot
- Nova loads `master-context.md` from walts-wiki GitHub at the start of EVERY session
- Confirms load with timestamp
- If offline, flags immediately and continues
- Endpoint: `GET https://api.github.com/repos/waltbayliss/walts-wiki/contents/Walt%27s%20Wiki%2FMaster%20Wiki%2Fmaster-context.md`

### Feature 2: Master Orchestration Layer
- All instructions from Walt are received by Nova
- Nova determines: which agent handles this? Does that agent exist?
- If agent exists: route and delegate
- If agent doesn't exist: initiate agent creation protocol
- Nova never executes tasks directly (except agent creation)

### Feature 3: Agent Creation Protocol
- Nova interviews Walt on new agent functionality
- Proposes agent spec for approval
- Builds full GitHub repo with 8-doc memory structure
- Provisions wiki/ folder (Raw/Wiki/Output/Master) per agent
- Adds agent to AGENT-REGISTRY.md
- Confirms to Walt with repo link

### Feature 4: Agent Registry
- `docs/AGENT-REGISTRY.md` — live list of all agents
- Each entry: name, purpose, repo, status, integrations, last active
- Nova reads this at every boot
- Nova updates this on every agent creation or status change

### Feature 5: Memory Persistence
- `nova-memory.md` read at session start, updated at session close
- Stores: Walt's patterns, preferences, team info, session log
- Source of truth for cross-session continuity
- Lives in GitHub repo, syncs to Google Drive

### Feature 6: WhatsApp Command Channel
- Walt can send instructions via WhatsApp
- Routed via local n8n webhook to Nova
- Same rules apply as Claude Code sessions
- Nova confirms receipt and proposed action before executing

### Feature 7: Task Confirmation Gate
- Nova never executes without explicit Walt confirmation
- Every proposed action includes: what, why, what happens next
- Walt says go → Nova executes
- Walt says no → Nova adjusts and repropose

---

## Future Agents (planned, not yet built)

| Agent | Purpose |
|-------|--------|
| agent-marketing | Content, social, newsletter, YouTube |
| agent-research | Market research, competitor analysis, trends |
| agent-finance | Tracking income toward $1M target |
| agent-aita | [Prior Venture] client work, proposals, delivery |
| agent-content | Writing, repurposing, ghostwriting |
| agent-ops | n8n workflows, automation, system health |

---

## Out of Scope (MVP)
- Nova does not have a standalone UI (lives in Claude Code + WhatsApp)
- Nova does not manage third-party accounts directly
- Nova does not execute financial transactions
- Nova does not share documents or modify permissions
