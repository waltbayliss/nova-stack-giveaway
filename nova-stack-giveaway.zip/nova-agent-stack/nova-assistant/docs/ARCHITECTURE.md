# Nova — Architecture

**Version:** 1.1  
**Date:** 2026-04-14 (updated from v1.0 on 2026-04-13)

---

## System Overview

Nova is a GitHub-native, Claude Code-powered master orchestrator. The architecture is designed for maximum portability, zero vendor lock-in, and continuous compounding of knowledge.

```
Walt
  │
  ▼
Nova (master-orchestrator)
  │
  ├── Agent Registry (who exists, what they do)
  ├── Walt's Wiki (always-current context)
  ├── Nova Memory (cross-session learning)
  │
  ├── agent-builder/        ← active: builds new agents via 8-question interview
  ├── agent-daily-brief/    ← active: 7am AEST daily brief via Cloudflare cron
  ├── agent-marketing/
  ├── agent-research/
  ├── agent-aita/
  ├── agent-finance/
  └── [new agents created as needed]
```

---

## Nova's Runtime

- **Primary interface:** Claude Code (local)
- **Secondary interface:** Notion → n8n → nova-telegram Cloudflare Worker → Telegram → Claude Code
- **Persistence:** GitHub (`waltbayliss/nova-assistant`) + Google Drive (nova-memory.md)
- **Context loading:** walts-wiki GitHub API (`api.github.com/repos/waltbayliss/walts-wiki`)

---

## n8n Pipeline (Session 3 — 2026-04-14)

n8n is the automation backbone. It is **managed by PM2** (not run bare or via systemd).

### PM2 Process

- **Process name:** `walts-wiki-n8n`
- **Required env vars (must be in PM2 env config, not shell):**
  - `NOTION_TOKEN`
  - `TELEGRAM_BOT_TOKEN`
  - `TELEGRAM_CHAT_ID`
  - `ANTHROPIC_API_KEY`
  - `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` ← critical: without this, n8n nodes cannot read env vars

### Active Workflows

| Workflow | ID | Poll Interval | What it does |
|----------|----|---------------|--------------|
| Nova — Agent Build Trigger | `93FksIH1V2iKIXSY` | Every 3 min | Polls Quick To-Dos DB for Status=Now → sends Telegram to Walt → marks as Next |
| Nova — Notion Task Watcher | `GswZbjVTLUP2w4Ni` | Every 2 min | Polls Task List DB for Status="Ai Queued" assigned to Nova → calls Claude Haiku → writes result back to Notion |
| Nova — Agent Intake (Notion → Telegram) | `cEufgWVvzd1dk9JA` | Every 5 min | Polls Quick To-Dos for Status=Now + not completed → triggers nova-telegram Cloudflare Worker |

### Agent Intake Pipeline (end-to-end)

```
Notion Quick To-Dos (Status=Now)
  → n8n Agent Intake workflow (ID: cEufgWVvzd1dk9JA)
  → nova-telegram Cloudflare Worker
      https://nova-telegram.waltbayliss.workers.dev/agent-intake
  → Walt receives Telegram message
  → Walt replies YES
  → Telegram bridge spawns Claude Code session in my-ai-team workspace
  → agent-builder runs 8-question interview
  → new agent built and deployed
```

### Cloudflare Tunnel

- **URL:** `https://nova-n8n.[personal-site]`
- **Purpose:** Permanently exposes local n8n for inbound webhooks and external access
- **Setup script:** `~/nova-work/tunnel/setup_cloudflare_tunnel.sh`
- **Status:** Live. `cloudflared` process running.

---

## Repository Structure

```
nova-assistant/
├── CLAUDE.md                    # Nova's operating system — read by Claude Code at every session
├── README.md                    # Entry point and setup guide
├── nova-memory.md               # Cross-session memory — read and updated every session
├── .env.example                 # Environment variable template (no secrets committed)
├── docs/
│   ├── PRD.md                   # What Nova is and does
│   ├── ARCHITECTURE.md          # This file
│   ├── SOUL.md                  # Nova's identity and personality
│   ├── SECURITY.md              # Hard rules — HIGHEST PRIORITY
│   ├── ROADMAP.md               # What's being built and when
│   ├── DECISIONS.md             # Log of key technical decisions
│   ├── SPRINT_LOG.md            # Session-by-session progress log
│   └── AGENT-REGISTRY.md        # Master list of all agents
├── skills/
│   └── nova-orchestration.md    # Nova's orchestration skill definition
└── wiki/
    ├── Raw/                     # Unprocessed inputs, session captures
    ├── Wiki/                    # Structured knowledge (for AI consumption)
    ├── Output/                  # Saved agent outputs
    └── Master/                  # master-context.md synthesis layer
```

---

## Agent Repository Standard Structure

Every agent Nova creates follows this exact structure:

```
agent-[name]/
├── CLAUDE.md                    # Agent-specific boot sequence and rules
├── README.md                    # What this agent does and how to invoke
├── agent-memory.md              # Agent's own cross-session memory
├── .env.example
├── docs/
│   ├── PRD.md
│   ├── ARCHITECTURE.md
│   ├── SOUL.md
│   ├── SECURITY.md
│   ├── ROADMAP.md
│   ├── DECISIONS.md
│   └── SPRINT_LOG.md
├── skills/
│   └── [agent-specific skill files]
└── wiki/
    ├── Raw/
    ├── Wiki/
    ├── Output/
    └── Master/
        └── master-context.md   # Agent's synthesised knowledge
```

---

## Walt's Wiki Structure (walts-wiki GitHub)

Mirrors the three-folder architecture from `RAW-WIKI-OUTPUT-ARCHITECTURE.md`:

```
Walt's Wiki/
├── Raw/           # Unprocessed captures, notes, AI session dumps
├── Wiki/          # Structured knowledge — built for AI consumption, not human browsing
├── Output/        # Saved AI outputs that compound over time
└── Master Wiki/
    └── master-context.md   # Single-file synthesis — loaded by Nova every session
```

**Key principle:** The Wiki is for the AI, not the human. It is structured to maximise AI comprehension and context density.

---

## Key Integrations

| Service | Purpose | How |
|---------|---------|-----|
| walts-wiki GitHub | Walt's Wiki — primary context source | REST API `api.github.com/repos/waltbayliss/walts-wiki` |
| Local n8n | Workflow automation engine — managed by PM2 (`walts-wiki-n8n`) | `localhost:5678` — NOT cloud n8n |
| Cloudflare Tunnel | Exposes local n8n externally | `https://nova-n8n.[personal-site]` |
| nova-telegram Worker | Bridge between n8n and Claude Code agent sessions | `https://nova-telegram.waltbayliss.workers.dev` |
| GitHub | Code + memory persistence | `waltbayliss/*` repos |
| Google Drive | nova-memory.md sync + agent session workspace (`my-ai-team`) | Google Drive API |
| Telegram | Field command channel — Walt receives alerts + confirms agent builds | Telegram Bot API |
| Notion | Operational hub — Task List DB + Quick To-Dos DB | Notion API |
| [Employer] | Client/CRM (via future agent) | HL API |

---

## Architectural Principles

1. **GitHub-native** — all memory, docs, and skills live in version-controlled repos
2. **Claude Code-native** — CLAUDE.md is the OS, not a config file
3. **Wiki-mirrored** — every agent has its own Raw/Wiki/Output/Master structure
4. **Compound learning** — outputs become inputs; the system gets smarter every session
5. **Portable** — no proprietary platform lock-in; can be rebuilt anywhere from the docs
6. **Confirmation-gated** — nothing executes without Walt's explicit go-ahead
