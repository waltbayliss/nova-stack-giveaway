## 2026-05-12 — daily — verdict: DIRTY
Run at: 2026-05-12T11:28:10Z
Counts: LOW=17 MEDIUM=39 HIGH=1305 CRITICAL=2 TOTAL=1363
NEW since baseline: HIGH=1305 CRITICAL=2
heartbeat: 2026-05-12T11:28:10Z

### NEW HIGH/CRITICAL findings (redacted)
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L82) [z8max_inclus***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L12) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L161) [5baa61e4c9b9***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L189) [7ade65b460f5***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L71) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L48) [308201ab0201***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L21) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L153) [4612c550263f***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L193) [c5eb01eb457f***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L240) [fdea67cf831f***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L243) [dc4a146313cc***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L284) [cb29a95649dc***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L287) [fc1c87d2f383***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L154) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L34) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L28) [-----BEGIN D***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L41) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L15) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L126) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L150) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L176) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L146) [-----BEGIN D***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L200) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L227) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L208) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L81) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L190) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L9) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L15) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L1123) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L1378) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L65) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L152) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L1668) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L1957) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L2256) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L239) [121fae78165b***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L375) [121fae78165b***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L406) [121fae78165b***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L34) [p1a2l3o4a5l6***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L359) [ACCAC7814C3A***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L941) [ACCACAEBB449***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1676) [ACCA7A1241D6***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L2019) [ACCA9DD7D66B***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.json:L108) [5TjFsfGktEDX***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3377) [ACCA80F25387***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1380) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1384) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1385) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1386) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1387) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1388) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3607) [ACCA7E1942DD***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3616) [ACCAC117ACC3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1259) [c2cb86c3a511***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1265) [72049b7019c7***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1269) [dc6zaTOxFJmz***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1271) [ee0b8233adff***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1288) [OTU3MDMwMHwx***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1300) [AIzaSyA_QlOn***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1320) [c2cb86c3a511***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1326) [72049b7019c7***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1330) [dc6zaTOxFJmz***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1332) [ee0b8233adff***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1352) [OTU3MDMwMHwx***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1381) [AIzaSyA_QlOn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1301) [AIzaSyChkPdC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L1382) [AIzaSyChkPdC***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L94) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L104) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L176) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L191) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L205) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L217) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L234) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L235) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L242) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L262) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L440) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.0.170.dist-info/ME***:L585) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3416) [56753253-tyu***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3267) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3275) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3303) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3346) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3358) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3363) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3375) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3390) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3440) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3584) [0123456789A0***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L3458) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L4151) [6nguxckrzchn***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L4152) [6nguxckrzchn***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L4554) [AIzaSyBzDJ0C***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L4557) [7ecb71622dad***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L4558) [7ecb71622dad***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L5689) [121107811423***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L5695) [121247121254***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L5963) [123667974863***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6126) [133357030333***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6182) [148067525892***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6291) [209546559074***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6311) [186131434747***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6360) [193673707489***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6722) [100000465435***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6748) [212284848941***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6819) [223219223371***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6886) [234658231234***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L6988) [258443224256***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L7412) [323594700988***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L7489) [342986686057***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L7953) [421388333306***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L8110) [475827182628***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L8115) [478845318813***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L8520) [549716278513***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L8908) [627634673965***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L9646) [775908159169***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L9978) [833367813443***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L9987) [839761616150***]
- [HIGH] git_history: gitleaks: facebook-acc*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L10534) [975498622499***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12031) [63a49ada73bc***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12035) [pk.eyJ1Ijoib***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12037) [I98umgPiu02G***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12047) [37068e0a72b2***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12048) [625023d7336d***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12049) [7d7a79eb6ca4***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12050) [9e493b8e1d5c***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12054) [b5c3cfd30f42***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12062) [4317fce92810***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12777) [AIZaSyCBhrmS***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12845) [AIzaSyA0pOZf***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12849) [AIzaSyA25OPW***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12850) [AIzaSyA2D9aQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12851) [AIzaSyA2HhbL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12853) [AIzaSyA2LNhL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12854) [AIzaSyA2TDh6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12855) [AIzaSyA2TMNF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12860) [AIzaSyA39tPZ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12861) [AIzaSyA3FQFr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12862) [AIzaSyA41FxV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12863) [AIzaSyA44sw3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12864) [AIzaSyA4EF_e***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12865) [AIzaSyA4NL7v***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12866) [AIzaSyA4c4bz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12867) [AIzaSyA4v81W***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12868) [AIzaSyA5JE7Q***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12871) [AIzaSyA6Cw8V***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12873) [AIzaSyA7dAzz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12875) [AIzaSyA8nk5d***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12876) [AIzaSyA8rtBY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12878) [AIzaSyA9ap6p***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12879) [AIzaSyA9cLQk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12880) [AIzaSyA9eC36***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12881) [AIzaSyA9gUmS***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12882) [AIzaSyA9mZQ6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12884) [AIzaSyAAOpU0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12886) [AIzaSyAAU3Pq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12887) [AIzaSyAB3pLz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12888) [AIzaSyABQRp0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12889) [AIzaSyABXoV5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12890) [AIzaSyABbKiw***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12891) [AIzaSyABcmhL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12894) [AIzaSyABzkV4***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12895) [AIzaSyAC1MEF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12896) [AIzaSyACln4e***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12897) [AIzaSyADGLd5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12899) [AIzaSyADZdRR***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12901) [AIzaSyADzG0b***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12903) [AIzaSyAEvd23***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12905) [AIzaSyAFbhJL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12908) [AIzaSyAFwIDM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12909) [AIzaSyAFxuAA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12911) [AIzaSyAGbQAZ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12914) [AIzaSyAH7S_g***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12919) [AIzaSyAIY9XO***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12921) [AIzaSyAJAx2Q***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12922) [AIzaSyAJIAVk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12923) [AIzaSyAJQWiK***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12925) [AIzaSyAJUYpl***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12926) [AIzaSyAJsAst***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12927) [AIzaSyAJvT_T***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12929) [AIzaSyAK56IP***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12932) [AIzaSyAKIvPg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12933) [AIzaSyAKlWtF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12934) [AIzaSyAKoDxa***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12935) [AIzaSyAL8dST***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12936) [AIzaSyALTBvI***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12937) [AIzaSyALl1yI***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12939) [AIzaSyAMhLAP***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12940) [AIzaSyAMuW4a***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12942) [AIzaSyANBdLQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12943) [AIzaSyAND7gp***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12945) [AIzaSyAOWTFI***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12946) [AIzaSyAO_FJ2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12948) [AIzaSyAOfxiG***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12949) [AIzaSyAPXjwY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12951) [AIzaSyAPr9RX***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12954) [AIzaSyAQfxPJ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12955) [AIzaSyAQmlKQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12956) [AIzaSyAQoOXm***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12957) [AIzaSyAQp34H***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12959) [AIzaSyAR84lF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12960) [AIzaSyARFKGT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12962) [AIzaSyASbhZE***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12967) [AIzaSyAU7FVM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12968) [AIzaSyAU9Shu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12969) [AIzaSyAUEtS1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12972) [AIzaSyAUUcpv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12976) [AIzaSyAV4rl5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12979) [AIzaSyAWk8PN***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12980) [AIzaSyAXavmN***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12981) [AIzaSyAXjBSS***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12983) [AIzaSyAY1TWv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12984) [AIzaSyAYLFPy***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12986) [AIzaSyAYyvjD***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12988) [AIzaSyAZQpyu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12991) [AIzaSyA__3pv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12992) [AIzaSyA_kaqH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12993) [AIzaSyAa6b4k***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12995) [AIzaSyAaMAfu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12996) [AIzaSyAaVB1r***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L12997) [AIzaSyAandJA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13004) [AIzaSyAdjHPT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13005) [AIzaSyAdxxOj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13006) [AIzaSyAdyeoT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13008) [AIzaSyAe45P2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13010) [AIzaSyAf7Lv3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13011) [AIzaSyAfFM6L***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13013) [AIzaSyAfeEpM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13014) [AIzaSyAfjQC4***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13015) [AIzaSyAfv657***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13018) [AIzaSyAgAShL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13019) [AIzaSyAgAiDu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13020) [AIzaSyAgIKHY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13021) [AIzaSyAghrye***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13024) [AIzaSyAhhxfq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13027) [AIzaSyAi1CzV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13028) [AIzaSyAi6qre***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13029) [AIzaSyAiFpFd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13030) [AIzaSyAiM1Jx***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13032) [AIzaSyAiw0iU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13033) [AIzaSyAj2Cj2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13036) [AIzaSyAjcDSQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13037) [AIzaSyAjp8cv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13038) [AIzaSyAjtXXy***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13041) [AIzaSyAkNJVj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13042) [AIzaSyAkYD2T***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13043) [AIzaSyAkgFXy***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13044) [AIzaSyAkjsSc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13045) [AIzaSyAl2HdB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13046) [AIzaSyAl9hbp***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13048) [AIzaSyAlluI5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13049) [AIzaSyAlqXgT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13050) [AIzaSyAm9yWC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13054) [AIzaSyAnJGXM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13055) [AIzaSyAnWuSF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13057) [AIzaSyAniTNs***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13058) [AIzaSyAnyNiF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13059) [AIzaSyAoFih8***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13060) [AIzaSyAobypY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13062) [AIzaSyApWxw8***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13063) [AIzaSyAplINl***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13065) [AIzaSyAqFmfm***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13069) [AIzaSyAqlZ1M***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13074) [AIzaSyAt3gEL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13077) [AIzaSyAtkjdI***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13080) [AIzaSyAuJmox***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13081) [AIzaSyAujQlZ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13083) [AIzaSyAvKPts***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13084) [AIzaSyAvSuAX***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13085) [AIzaSyAvWazT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13086) [AIzaSyAvb0NH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13089) [AIzaSyAw9IGg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13090) [AIzaSyAwp7hh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13092) [AIzaSyAxwEYp***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13093) [AIzaSyAxwxRu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13094) [AIzaSyAyVk7g***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13097) [AIzaSyAyesbQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13098) [AIzaSyAz0J5c***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13099) [AIzaSyAz4sf5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13101) [AIzaSyAzXrVT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13102) [AIzaSyAzYHm1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13104) [AIzaSyAzxFH7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13107) [AIzaSyB05jkP***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13109) [AIzaSyB0bEes***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13111) [AIzaSyB0y847***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13112) [AIzaSyB0zPyF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13113) [AIzaSyB181It***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13114) [AIzaSyB1eIxh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13115) [AIzaSyB1gqlq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13118) [AIzaSyB2L4Q3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13119) [AIzaSyB2OIqO***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13124) [AIzaSyB3kpx3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13128) [AIzaSyB4VfSN***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13129) [AIzaSyB4YTQA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13130) [AIzaSyB4sGJQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13131) [AIzaSyB5aqeE***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13132) [AIzaSyB6JuQn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13135) [AIzaSyB74usn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13138) [AIzaSyB7VgN5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13139) [AIzaSyB7cfgb***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13143) [AIzaSyB9AnPp***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13144) [AIzaSyB9Dq3w***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13147) [AIzaSyB9UkK4***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13148) [AIzaSyB9bqJ6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13149) [AIzaSyBAQYQx***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13150) [AIzaSyBBh4dd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13152) [AIzaSyBD7pLw***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13153) [AIzaSyBDJvZA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13155) [AIzaSyBDQeqh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13157) [AIzaSyBE0eCj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13160) [AIzaSyBF1fGT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13161) [AIzaSyBF2wl4***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13162) [AIzaSyBFx8hq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13163) [AIzaSyBGCsyr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13165) [AIzaSyBGKWHQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13167) [AIzaSyBGmZUd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13168) [AIzaSyBGoAWo***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13170) [AIzaSyBHZjt1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13172) [AIzaSyBHggo3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13173) [AIzaSyBHhzP3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13174) [AIzaSyBHsAxV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13175) [AIzaSyBIGAWQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13176) [AIzaSyBIHK8O***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13177) [AIzaSyBIV0dP***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13178) [AIzaSyBIi34n***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13179) [AIzaSyBIyD8Z***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13180) [AIzaSyBIyc6n***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13181) [AIzaSyBJOZIB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13182) [AIzaSyBK0z6R***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13183) [AIzaSyBKJw43***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13186) [AIzaSyBKwPHe***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13187) [AIzaSyBLCsBQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13190) [AIzaSyBNKM6P***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13191) [AIzaSyBNSwEo***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13192) [AIzaSyBNXabr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13193) [AIzaSyBNpjyk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13194) [AIzaSyBNqgJO***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13196) [AIzaSyBOReI8***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13198) [AIzaSyBOShlC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13200) [AIzaSyBOb5gh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13201) [AIzaSyBOhdOO***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13202) [AIzaSyBOsjes***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13203) [AIzaSyBPlIeq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13204) [AIzaSyBQ3GFA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13207) [AIzaSyBQevlE***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13210) [AIzaSyBQu8oX***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13211) [AIzaSyBQxopw***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13212) [AIzaSyBRC2kz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13214) [AIzaSyBS0vnU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13216) [AIzaSyBSGW3k***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13220) [AIzaSyBT7dQn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13221) [AIzaSyBTY8Xl***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13224) [AIzaSyBU1fYq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13225) [AIzaSyBU2Vqq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13227) [AIzaSyBUORmX***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13228) [AIzaSyBUlnM6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13229) [AIzaSyBUyjLk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13231) [AIzaSyBVIv8a***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13235) [AIzaSyBWGuVx***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13236) [AIzaSyBWcc6O***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13237) [AIzaSyBWeRU0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13238) [AIzaSyBWl1q1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13239) [AIzaSyBXJwI8***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13240) [AIzaSyBXMthQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13244) [AIzaSyBYJ9WC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13247) [AIzaSyBYurAd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13248) [AIzaSyBZ6CC6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13249) [AIzaSyBZIP5u***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13252) [AIzaSyB_3BMA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13255) [AIzaSyB_z8Wr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13256) [AIzaSyBaEjoh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13260) [AIzaSyBavsIg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13261) [AIzaSyBb5Hiu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13262) [AIzaSyBb5fLt***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13263) [AIzaSyBbGgoa***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13264) [AIzaSyBbmdee***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13265) [AIzaSyBc5VI2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13266) [AIzaSyBcTv77***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13268) [AIzaSyBcVJsd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13269) [AIzaSyBcfYNu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13271) [AIzaSyBdreXk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13272) [AIzaSyBe1yXR***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13273) [AIzaSyBeFuR4***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13275) [AIzaSyBeU6ow***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13276) [AIzaSyBedN_o***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13277) [AIzaSyBem7Nl***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13280) [AIzaSyBfCGRs***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13281) [AIzaSyBfHNkF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13282) [AIzaSyBfHuyR***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13283) [AIzaSyBfPIuV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13286) [AIzaSyBfrAgR***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13288) [AIzaSyBg3G3Q***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13289) [AIzaSyBgFUWz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13291) [AIzaSyBgYGot***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13292) [AIzaSyBggyzr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13293) [AIzaSyBgnC5f***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13297) [AIzaSyBhOu_b***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13298) [AIzaSyBhQ671***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13301) [AIzaSyBi6A83***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13303) [AIzaSyBiI0FH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13305) [AIzaSyBiVsxq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13306) [AIzaSyBicqfA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13309) [AIzaSyBjG8pV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13310) [AIzaSyBjS4dU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13312) [AIzaSyBjn1_8***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13313) [AIzaSyBjzGfi***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13316) [AIzaSyBlOhVQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13318) [AIzaSyBluDFL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13319) [AIzaSyBm38rc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13320) [AIzaSyBmILjd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13321) [AIzaSyBmMPMq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13323) [AIzaSyBnQsKC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13325) [AIzaSyBndxO_***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13327) [AIzaSyBoi6gB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13328) [AIzaSyBoxPRJ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13332) [AIzaSyBpDL_l***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13333) [AIzaSyBpGlZd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13334) [AIzaSyBpozlY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13338) [AIzaSyBqbBvT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13339) [AIzaSyBqscqB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13344) [AIzaSyBrvFpU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13345) [AIzaSyBryuJr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13347) [AIzaSyBs2_ql***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13348) [AIzaSyBsUCvL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13349) [AIzaSyBsY_tf***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13351) [AIzaSyBsZbpq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13353) [AIzaSyBtCBqq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13354) [AIzaSyBtMrZJ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13357) [AIzaSyBtft4U***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13358) [AIzaSyBuFGsj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13362) [AIzaSyBugjav***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13363) [AIzaSyBujzii***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13365) [AIzaSyButrP5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13366) [AIzaSyBv_v_U***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13368) [AIzaSyBwAGLv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13369) [AIzaSyBwdvui***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13370) [AIzaSyBwjU0Z***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13372) [AIzaSyBx6hRn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13373) [AIzaSyBxPKfO***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13374) [AIzaSyBxdPiM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13375) [AIzaSyBxdZNX***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13376) [AIzaSyBxmZNZ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13381) [AIzaSyBz13ei***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13390) [AIzaSyC04no7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13393) [AIzaSyC0Te2p***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13394) [AIzaSyC0WDs0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13395) [AIzaSyC0bwgo***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13397) [AIzaSyC0m1wW***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13398) [AIzaSyC0rCQY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13402) [AIzaSyC1H97d***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13403) [AIzaSyC1Ky_5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13408) [AIzaSyC21Snt***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13410) [AIzaSyC2mn0P***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13411) [AIzaSyC366vT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13412) [AIzaSyC36gV0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13414) [AIzaSyC3Z3qT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13415) [AIzaSyC4g2Yj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13416) [AIzaSyC4tW7h***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13417) [AIzaSyC5IcRc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13420) [AIzaSyC6SWJi***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13422) [AIzaSyC6pDjA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13423) [AIzaSyC6zb1g***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13425) [AIzaSyC7HkjU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13426) [AIzaSyC7UjgI***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13427) [AIzaSyC7aXtP***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13428) [AIzaSyC7nH1y***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13429) [AIzaSyC7t5n2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13434) [AIzaSyC8hYnL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13435) [AIzaSyC94rD8***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13436) [AIzaSyC9TWEH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13437) [AIzaSyC9UxLH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13438) [AIzaSyC9jUMx***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13440) [AIzaSyCADWr4***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13443) [AIzaSyCAfIty***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13446) [AIzaSyCBpVn9***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13447) [AIzaSyCBuAN1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13449) [AIzaSyCCJSgB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13452) [AIzaSyCD3yDw***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13455) [AIzaSyCDfKgY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13456) [AIzaSyCDre_v***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13459) [AIzaSyCDyoPV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13460) [AIzaSyCE2BK7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13461) [AIzaSyCEgLQ7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13462) [AIzaSyCF7K58***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13463) [AIzaSyCFRYmS***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13464) [AIzaSyCFYWd6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13465) [AIzaSyCGhZLg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13466) [AIzaSyCGweuE***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13467) [AIzaSyCH313T***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13468) [AIzaSyCHDKOd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13469) [AIzaSyCHVUY5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13470) [AIzaSyCHoJfq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13474) [AIzaSyCIFdBA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13475) [AIzaSyCIYsOj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13476) [AIzaSyCIbsDt***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13478) [AIzaSyCJKI3t***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13480) [AIzaSyCJbAJT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13482) [AIzaSyCJiVka***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13487) [AIzaSyCKPMaz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13488) [AIzaSyCKSbrv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13491) [AIzaSyCKjJFl***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13494) [AIzaSyCL3REK***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13495) [AIzaSyCLLeT5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13496) [AIzaSyCLh6M0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13497) [AIzaSyCLpexd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13499) [AIzaSyCM6Ubl***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13500) [AIzaSyCMhmAM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13501) [AIzaSyCMy1cF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13502) [AIzaSyCMysH7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13505) [AIzaSyCNPlrq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13510) [AIzaSyCOJZqf***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13513) [AIzaSyCOpkFk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13515) [AIzaSyCPW020***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13516) [AIzaSyCPYu_i***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13517) [AIzaSyCPkzR0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13518) [AIzaSyCPrebe***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13520) [AIzaSyCQgPGh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13524) [AIzaSyCQuuCK***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13525) [AIzaSyCQxLWF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13526) [AIzaSyCR3cKh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13528) [AIzaSyCRLa4L***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13529) [AIzaSyCROIg2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13530) [AIzaSyCROYDM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13532) [AIzaSyCSTh76***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13533) [AIzaSyCS_bFU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13537) [AIzaSyCSjg3r***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13538) [AIzaSyCT6NeH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13539) [AIzaSyCTPwxS***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13540) [AIzaSyCU7LWl***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13541) [AIzaSyCV1Ost***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13544) [AIzaSyCVm5YM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13545) [AIzaSyCW6jCk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13546) [AIzaSyCWRv_T***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13548) [AIzaSyCWfP6Q***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13551) [AIzaSyCX6ZUe***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13553) [AIzaSyCXydC2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13555) [AIzaSyCYI12U***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13556) [AIzaSyCYcMhC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13557) [AIzaSyCYlSCY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13558) [AIzaSyCZjrgD***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13562) [AIzaSyC_FJ7v***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13564) [AIzaSyC_vb5G***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13565) [AIzaSyCa1vcy***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13566) [AIzaSyCaYbzc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13567) [AIzaSyCaama1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13569) [AIzaSyCb2pCH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13571) [AIzaSyCc0MsN***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13572) [AIzaSyCcESmp***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13573) [AIzaSyCdAXs0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13575) [AIzaSyCdnAhU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13577) [AIzaSyCdqgGd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13579) [AIzaSyCeFfqi***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13585) [AIzaSyCgSK8Q***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13586) [AIzaSyCgbjmk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13587) [AIzaSyCh86BT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13588) [AIzaSyChOUhc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13591) [AIzaSyChya4B***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13594) [AIzaSyCip0O3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13595) [AIzaSyCjQMFo***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13598) [AIzaSyCk5Pjt***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13599) [AIzaSyCkAuE5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13600) [AIzaSyCkUOdZ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13602) [AIzaSyCkfPOP***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13603) [AIzaSyClMdXK***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13604) [AIzaSyClNEQb***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13605) [AIzaSyClNqQC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13607) [AIzaSyClhqB9***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13608) [AIzaSyClk5kD***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13609) [AIzaSyClkzZF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13616) [AIzaSyCnmZWN***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13619) [AIzaSyCoC87q***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13620) [AIzaSyCoJ1l1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13621) [AIzaSyCpBpPY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13622) [AIzaSyCpC852***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13623) [AIzaSyCpN9QV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13626) [AIzaSyCq3Iys***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13628) [AIzaSyCqhW82***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13629) [AIzaSyCqkkQe***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13631) [AIzaSyCrNndi***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13632) [AIzaSyCrPO3V***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13633) [AIzaSyCrdxzz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13635) [AIzaSyCsQksA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13636) [AIzaSyCsZHda***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13637) [AIzaSyCt35MZ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13641) [AIzaSyCtbzna***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13642) [AIzaSyCtjWoc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13643) [AIzaSyCu0GO5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13646) [AIzaSyCuUm2L***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13647) [AIzaSyCuYGrn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13650) [AIzaSyCvAEr1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13651) [AIzaSyCvMbBa***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13652) [AIzaSyCvhcU6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13655) [AIzaSyCwua_W***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13656) [AIzaSyCx7eq9***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13657) [AIzaSyCxY1X7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13658) [AIzaSyCxitB5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13659) [AIzaSyCxmfKG***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13660) [AIzaSyCy2C82***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13662) [AIzaSyCyC23v***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13663) [AIzaSyCyKS3Q***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13664) [AIzaSyCyT7Io***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13666) [AIzaSyCzCada***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13667) [AIzaSyCzFMBx***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13668) [AIzaSyCzNxnQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13669) [AIzaSyCzbKLa***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13681) [AIzaSyD0C9hh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13682) [AIzaSyD0CVBm***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13684) [AIzaSyD0kwTs***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13685) [AIzaSyD0q8uT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13686) [AIzaSyD13MBv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13687) [AIzaSyD1LYEo***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13689) [AIzaSyD1mVN9***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13690) [AIzaSyD2BmXO***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13693) [AIzaSyD2lf1s***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13695) [AIzaSyD3_xJ0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13699) [AIzaSyD4COht***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13701) [AIzaSyD56uqn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13702) [AIzaSyD5BL8K***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13708) [AIzaSyD6EHgx***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13712) [AIzaSyD71sHr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13714) [AIzaSyD7K54G***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13717) [AIzaSyD8CL18***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13718) [AIzaSyD8F41C***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13723) [AIzaSyD9WN2t***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13726) [AIzaSyDA5dlL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13727) [AIzaSyDA98XB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13728) [AIzaSyDAKcVa***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13730) [AIzaSyDAYEiY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13731) [AIzaSyDAvfWc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13732) [AIzaSyDB2i7V***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13734) [AIzaSyDCFvYZ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13735) [AIzaSyDCS0Bt***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13736) [AIzaSyDD73ZA***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13737) [AIzaSyDDBk8t***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13738) [AIzaSyDDHAjg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13739) [AIzaSyDDkKdD***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13741) [AIzaSyDEA8md***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13742) [AIzaSyDEDrYV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13744) [AIzaSyDEkmqc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13745) [AIzaSyDEvv0l***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13746) [AIzaSyDFDGOM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13749) [AIzaSyDFO_Rf***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13751) [AIzaSyDG4B9o***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13752) [AIzaSyDGYiab***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13753) [AIzaSyDGgVTq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13754) [AIzaSyDH1bPI***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13755) [AIzaSyDHACIH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13759) [AIzaSyDI4rWo***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13760) [AIzaSyDIALcT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13761) [AIzaSyDIQZLu***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13765) [AIzaSyDIqLvj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13766) [AIzaSyDJ31Yr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13767) [AIzaSyDJAaPL***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13769) [AIzaSyDKTvsq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13771) [AIzaSyDKbr_j***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13772) [AIzaSyDKfWHz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13773) [AIzaSyDL5stf***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13774) [AIzaSyDLBKR3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13775) [AIzaSyDLJmls***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13777) [AIzaSyDLUTzd***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13778) [AIzaSyDLbX1a***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13779) [AIzaSyDLgdwe***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13780) [AIzaSyDMS4J2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13782) [AIzaSyDNzEht***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13783) [AIzaSyDOZOxx***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13784) [AIzaSyDOifyV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13785) [AIzaSyDOpRsh***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13787) [AIzaSyDPCSci***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13788) [AIzaSyDPN6S2***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13789) [AIzaSyDQ6mA6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13791) [AIzaSyDQSvOi***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13792) [AIzaSyDRFx2W***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13795) [AIzaSyDRfgPj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13796) [AIzaSyDRgiUg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13797) [AIzaSyDS1p3m***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13799) [AIzaSyDSoVz0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13800) [AIzaSyDSwcrC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13801) [AIzaSyDSyK89***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13802) [AIzaSyDTFG3_***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13804) [AIzaSyDTNHit***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13805) [AIzaSyDTOyqT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13806) [AIzaSyDTP6kB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13809) [AIzaSyDTqOkV***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13810) [AIzaSyDU6qxb***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13811) [AIzaSyDUPTN4***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13812) [AIzaSyDUWTdk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13813) [AIzaSyDUdGaR***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13814) [AIzaSyDV4cbT***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13815) [AIzaSyDVE9os***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13816) [AIzaSyDV_vLg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13817) [AIzaSyDVrdPv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13819) [AIzaSyDWG1Ho***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13821) [AIzaSyDWaO_6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13825) [AIzaSyDWedZY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13827) [AIzaSyDXlQso***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13830) [AIzaSyDY0kkJ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13831) [AIzaSyDY4SXY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13832) [AIzaSyDYjLGr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13835) [AIzaSyDZ2wk0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13836) [AIzaSyDZ4iVB***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13838) [AIzaSyDZP2E_***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13840) [AIzaSyD_H_Tg***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13841) [AIzaSyD_PC6U***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13842) [AIzaSyD_UZKq***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13843) [AIzaSyD_dTaK***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13844) [AIzaSyD_shO5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13845) [AIzaSyDaMf0e***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13847) [AIzaSyDaeSEk***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13848) [AIzaSyDapkNC***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13849) [AIzaSyDb7PQj***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13850) [AIzaSyDbAz1X***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13852) [AIzaSyDbNIb7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13854) [AIzaSyDc7eBt***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13855) [AIzaSyDc9ac6***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13856) [AIzaSyDcFG73***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13859) [AIzaSyDcPq_z***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13860) [AIzaSyDcbjOv***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13861) [AIzaSyDcnW6W***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13863) [AIzaSyDdA1PO***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13864) [AIzaSyDdSdp3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13865) [AIzaSyDdZu1n***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13866) [AIzaSyDdhkb3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13867) [AIzaSyDdvc_z***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13868) [AIzaSyDeNN1X***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13869) [AIzaSyDe_oVp***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13871) [AIzaSyDevXt3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13873) [AIzaSyDf5i7U***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13874) [AIzaSyDfJ5Ku***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13878) [AIzaSyDgy1QF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13879) [AIzaSyDhPhJn***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13880) [AIzaSyDhdEhc***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13881) [AIzaSyDhozz5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13882) [AIzaSyDhp2d1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13883) [AIzaSyDhsJ06***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13885) [AIzaSyDi3f9p***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13889) [AIzaSyDielPM***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13892) [AIzaSyDj8qos***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13893) [AIzaSyDjYqNK***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13895) [AIzaSyDjwhA3***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13896) [AIzaSyDk7clY***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13898) [AIzaSyDkzj1P***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13900) [AIzaSyDmQWd7***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13901) [AIzaSyDmTh_L***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13902) [AIzaSyDmdWsz***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13905) [AIzaSyDnBCds***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13907) [AIzaSyDni9jo***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13909) [AIzaSyDou2Q9***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13910) [AIzaSyDouxn1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13911) [AIzaSyDpBltU***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13912) [AIzaSyDpMNCW***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13915) [AIzaSyDpY9FH***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13916) [AIzaSyDp_LRG***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13917) [AIzaSyDpdrSD***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13920) [AIzaSyDqFsGP***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13921) [AIzaSyDqt4E0***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13922) [AIzaSyDr2Im1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13923) [AIzaSyDr2mpF***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13924) [AIzaSyDrHKl8***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13926) [AIzaSyDrw2z1***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13928) [AIzaSyDsPufr***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13929) [AIzaSyDsSKWe***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13932) [AIzaSyDtQ0zs***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13933) [AIzaSyDtg4aQ***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13934) [AIzaSyDtnnxW***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13935) [AIzaSyDu888R***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13936) [AIzaSyDvTjB5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13938) [AIzaSyDveKkS***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13940) [AIzaSyDvrfwE***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13947) [AIzaSyDznC6S***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L13959) [AIzaXyBa0HT1***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14007) [AKIAABCDEFGU***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14008) [AKIAANONIMIZ***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14011) [AKIAI4JYMHUI***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14012) [AKIAI4ZP7EZG***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14013) [AKIAI6TCJ7BD***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14014) [AKIAI6VTFZ6K***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14015) [AKIAI7BKNRSI***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14017) [AKIAIBXKGGNZ***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14018) [AKIAIBZQRVYD***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14019) [AKIAICPB2GGI***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14020) [AKIAICUCAP6S***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14021) [AKIAICW46AB5***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14022) [AKIAID432MWI***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14024) [AKIAIEEES6MK***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14025) [AKIAIEHFBME6***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14026) [AKIAIFIV4LN6***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14027) [AKIAIHHMU7Y4***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14028) [AKIAIIESFCKM***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14029) [AKIAIIJPYU3R***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14030) [AKIAIJ4ZNXCK***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14031) [AKIAILA4KWEG***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14032) [AKIAIM5CBG3W***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14033) [AKIAIN5SWSZA***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14034) [AKIAION65XYY***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14035) [AKIAIOSFODNN***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14036) [AKIAIOYMALO6***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14037) [AKIAIPT6J4T6***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14039) [AKIAIQYAFTLB***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14040) [AKIAIR3RKOJH***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14041) [AKIAIRGYI76B***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14042) [AKIAISJ2OHTB***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14043) [AKIAITLSY742***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14044) [AKIAIUBE3DGP***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14045) [AKIAIXVR6TAN***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14046) [AKIAIYWQRFTH***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14047) [AKIAIZKAZR5V***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14048) [AKIAJ3OTZKPC***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14049) [AKIAJ4CKN2HX***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14050) [AKIAJ4VQLGW6***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14051) [AKIAJ65ALLZM***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14053) [AKIAJB6BSMFW***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14055) [AKIAJECBPJO2***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14056) [AKIAJETPI54G***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14057) [AKIAJGBULS6Q***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14058) [AKIAJGWHYL43***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14059) [AKIAJHEOGLJK***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14061) [AKIAJJJJJJJJ***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14064) [AKIAJPR3ESEJ***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14065) [AKIAJQH5XY2N***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14066) [AKIAJRMTDHEG***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14067) [AKIAJSTZ34GW***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14068) [AKIAJUGFU2PN***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14069) [AKIAJUWRQBUU***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14070) [AKIAJWJUEAFR***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14071) [AKIAJXXTQPOM***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14072) [AKIAJYCJAFZY***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14073) [AKIAJZJPXOGT***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14074) [AKIANABBDUSE***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14075) [AKIAXXXXXXXX***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14342) [ASIAJVMWYU3B***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L14343) [ASIAQFXSYL2V***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L15177) [sk_test_0426***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16358) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16360) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16363) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16365) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16366) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16368) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16369) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16370) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16371) [EAACEdEose0c***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16372) [EAACEdEoseZB***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16373) [EAACgZAhHOaP***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16408) [EAAMc0KQg6xY***]
- [HIGH] git_history: gitleaks: facebook-pag*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L16435) [EAAcK4oLnAeU***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.pyi:L76) [x25519.X2551***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.pyi:L100) [x25519.X2551***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L20976) [R_c46273fd67***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L6) [-----BEGIN O***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21360) [SG.1DXXKXSzR***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21362) [SG.8_bvMJy2Q***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21363) [SG.BNpsQzGgQ***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21365) [SG.WiOCMUO0R***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21368) [SG.amAnqVp7R***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21370) [SG.jT9TgirJS***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21371) [SG.rISXkTYTS***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21372) [SG.uXmeWMfDR***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21373) [SG.xULI63jeS***]
- [HIGH] git_history: gitleaks: sendgrid-api*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21381) [SG.yuyOKgspS***]
- [HIGH] git_history: gitleaks: square-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L21368) [eAAAE1i5oo3G***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L78) [-----BEGIN O***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L27980) [2499d4a4f8ad***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L27981) [CD75737EF4CA***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L27983) [a98debe57ccd***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L27984) [e0cbb327025c***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L27989) [sdwertyujgfv***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L27990) [u366xz3zv6s9***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L30765) [abcd12345678***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33409) [eyB9eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33436) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33437) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33442) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33443) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33444) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33445) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33446) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33447) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33448) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33449) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33450) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33451) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33452) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33453) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33454) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33455) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33456) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33457) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33458) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33461) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33462) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33463) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33466) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33467) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33468) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33469) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33470) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33472) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33473) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33474) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33475) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33476) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33477) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33478) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33479) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33480) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33481) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33482) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33483) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33484) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33485) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33486) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33490) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33491) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33493) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33495) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33498) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33500) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33501) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33502) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33503) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33505) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33506) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33510) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33513) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33515) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33517) [eyJ0eXAiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33524) [eyJ5bGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33526) [eyJef4AiOiJK***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33533) [eyJhbGciOi78***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33536) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33537) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33538) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33539) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33540) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33541) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33542) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33543) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33544) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33545) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33546) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33547) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33548) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33550) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33551) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33552) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33553) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33554) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33555) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33556) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33557) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33558) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33559) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33560) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33561) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33562) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33563) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33564) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33565) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33572) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33573) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33574) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33575) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33576) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33577) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33579) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33583) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33587) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33588) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33589) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33590) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33591) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33592) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33593) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33594) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33595) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33596) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33597) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33598) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33599) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33600) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33601) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33603) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33604) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33605) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33606) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33612) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33613) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33614) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33615) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33616) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33618) [eyJhbGciOiJS***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33620) [eyJhbGciOiJu***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L33628) [eyJraWQiOiIz***]
- [HIGH] git_history: gitleaks: heroku-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L35995) [c9c65c38-961***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L37789) [key=AIzaSyC5***]
- [HIGH] git_history: gitleaks: gcp-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L37791) [AIzaSyDdZu1n***]
- [HIGH] git_history: gitleaks: openai-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45528) [sk-d9TqyWf8h***]
- [HIGH] git_history: gitleaks: openai-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45529) [sk-faeCk1Chl***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45546) [sk_live_149d***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45548) [sk_live_BAta***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45549) [sk_live_K7uf***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45550) [sk_live_OOOP***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45551) [sk_live_Sv81***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45553) [sk_live_af72***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45554) [sk_live_dSqz***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45555) [sk_live_n8Wr***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45556) [sk_live_troL***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45566) [sk_test_0000***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45567) [sk_test_0wgm***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45568) [sk_test_1111***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45571) [sk_test_14wG***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45572) [sk_test_1VJe***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45574) [sk_test_2uoG***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45575) [sk_test_3aec***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45577) [sk_test_4eC3***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45578) [sk_test_51Ka***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45580) [sk_test_5SLL***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45581) [sk_test_7Qsv***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45582) [sk_test_7dTO***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45583) [sk_test_8rdF***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45585) [sk_test_9Okp***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45586) [sk_test_9fe1***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45587) [sk_test_9kYp***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45589) [sk_test_AJKe***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45590) [sk_test_BJUl***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45591) [sk_test_BQok***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45592) [sk_test_BQok***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45593) [sk_test_Bsdq***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45594) [sk_test_CfoP***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45595) [sk_test_CpkB***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45596) [sk_test_D8XQ***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45597) [sk_test_EDpv***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45598) [sk_test_ESb8***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45599) [sk_test_EkZm***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45600) [sk_test_FZOJ***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45601) [sk_test_I2eG***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45602) [sk_test_Ig7H***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45603) [sk_test_ItmA***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45604) [sk_test_IuUd***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45605) [sk_test_Iv7H***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45606) [sk_test_JU23***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45607) [sk_test_JlKC***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45608) [sk_test_JvMg***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45610) [sk_test_KT79***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45612) [sk_test_O6BW***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45613) [sk_test_OXZN***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45614) [sk_test_P4Fj***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45617) [sk_test_Smq1***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45618) [sk_test_UW12***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45619) [sk_test_Ujde***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45620) [sk_test_VAjL***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45621) [sk_test_VpFU***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45622) [sk_test_X9S2***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45623) [sk_test_XVDF***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45625) [sk_test_XXXX***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45626) [sk_test_Xxxx***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45627) [sk_test_XyBI***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45629) [sk_test_abcd***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45630) [sk_test_anoY***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45631) [sk_test_anyt***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45633) [sk_test_asdf***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45634) [sk_test_b2ZF***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45635) [sk_test_bb2N***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45638) [sk_test_blab***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45639) [sk_test_cHNn***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45640) [sk_test_ejKN***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45641) [sk_test_enH3***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45642) [sk_test_exhH***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45643) [sk_test_exhH***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45644) [sk_test_f5Jj***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45645) [sk_test_f9Lq***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45646) [sk_test_fFHn***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45647) [sk_test_fSaK***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45648) [sk_test_g9fT***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45649) [sk_test_gcpX***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45650) [sk_test_hkiY***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45651) [sk_test_hkiY***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45652) [sk_test_iGn9***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45653) [sk_test_ibbT***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45654) [sk_test_k4aH***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45655) [sk_test_kLyQ***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45657) [sk_test_l35X***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45658) [sk_test_made***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45659) [sk_test_md0Z***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45660) [sk_test_myst***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45661) [sk_test_myte***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45662) [sk_test_nclp***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45663) [sk_test_notm***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45664) [sk_test_nra5***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45665) [sk_test_nxhH***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45666) [sk_test_o9Yl***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45667) [sk_test_pOJq***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45668) [sk_test_qMab***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45669) [sk_test_qa9c***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45670) [sk_test_r3Es***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45671) [sk_test_reda***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45672) [sk_test_sOlY***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45674) [sk_test_secr***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45675) [sk_test_srlC***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45677) [sk_test_v8wW***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45678) [sk_test_vizt***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45679) [sk_test_wCVo***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45681) [sk_test_what***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45682) [sk_test_x5mf***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45683) [sk_test_xUdH***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45684) [sk_test_xv3y***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45686) [sk_test_xxxx***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45687) [sk_test_xxxx***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45688) [sk_test_xxxx***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45689) [sk_test_xxxx***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45690) [sk_test_xxxx***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45691) [sk_test_xxxx***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45693) [sk_test_yBDh***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45694) [sk_test_yEW8***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45698) [sk_test_your***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45699) [sk_test_ypuq***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45700) [sk_test_z3b8***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45701) [sk_test_zVqL***]
- [HIGH] git_history: gitleaks: stripe-acces*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L45702) [sk_test_zgiz***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L48027) [d27nrsstx6z5***]
- [HIGH] git_history: gitleaks: slack-legacy*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L49865) [xoxb-1102763***]
- [HIGH] git_history: gitleaks: slack-legacy*** (/home/walt/a***.venv/lib/pyt***.12/site-pack***.txt:L49871) [xoxs-8627407***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L56) [ed25519.Ed25***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L57) [ed25519.Ed25***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L68) [ed448.Ed448P***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L69) [ed448.Ed448P***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L871) [Ed25519Priva***]
- [HIGH] git_history: gitleaks: jwt (/home/walt/a***.venv/lib/pyt***.12/site-pack***.12.1.dist-info/ME***:L91) [eyJhbGciOiJI***]
- [HIGH] git_history: gitleaks: github-pat (/home/walt/a***.md:L22) [ghp_IoKnB8Dk***]
- [HIGH] git_history: gitleaks: github-pat (/home/walt/a***.md:L84) [ghp_IoKnB8Dk***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L53) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L49) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L63) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L61) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L38) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L10) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L32) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L21) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L50) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.v1alpha.json:L964) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.v1beta.json:L2247) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.v1.json:L2021) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L24) [0685bd9184jf***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L30) [0685bd9184jf***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L230) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L289) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L292) [tGzv3JOkF0XG***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L330) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L408) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L411) [tGzv3JOkF0XG***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.v1.json:L101415) [0-8r1KcmFaOH***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.v1.json:L101910) [0-8r1KcmFaOH***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.v1.json:L102412) [0-8r1KcmFaOH***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.v1.json:L125987) [mF_9.B5f-4.1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.v1.json:L125988) [mF_9.B5f-4.1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L33) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L33) [rfc4357.Gost***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L30) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L36) [rfc5652.Reci***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L38) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L37) [rfc5280.KeyI***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L63) [rfc5280.KeyI***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L110) [rfc3447.RSAP***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L119) [rfc7191.id_a***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L39) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L51) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L57) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L138) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L153) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L180) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L199) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L205) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L219) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L75) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L87) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L93) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L231) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L246) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L278) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L305) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L311) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L335) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L19) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L88) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L603) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L299) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.ts:L24) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.pyi:L76) [x25519.X2551***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.pyi:L100) [x25519.X2551***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L5) [-----BEGIN O***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L78) [-----BEGIN O***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L53) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L49) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L61) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L63) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L11) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L39) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L37) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L21) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.py:L50) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.v1alpha.json:L1584) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.v1.json:L3140) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.12/site-pack***.v1beta.json:L3369) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L24) [0685bd9184jf***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L30) [0685bd9184jf***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L230) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L289) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L292) [tGzv3JOkF0XG***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L330) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L408) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L411) [tGzv3JOkF0XG***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L33) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L33) [rfc4357.Gost***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L30) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L36) [rfc5652.Reci***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L38) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L37) [rfc5280.KeyI***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L63) [rfc5280.KeyI***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L110) [rfc3447.RSAP***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L119) [rfc7191.id_a***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L39) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L51) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L57) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L138) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L153) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L180) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L199) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L205) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.cpython-312.pyc:L219) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L75) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L87) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L93) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L231) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L246) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L278) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L305) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L311) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.12/site-pack***.py:L335) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.12/site-pack***.py:L1246) [AKIAAQAAAAAA***]
- [HIGH] git_history: gitleaks: aws-access-t*** (/home/walt/a***.12/site-pack***.cpython-312.pyc:L816) [AKIAAQAAAAAA***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.pyi:L76) [x25519.X2551***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.pyi:L100) [x25519.X2551***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L5) [-----BEGIN O***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L78) [-----BEGIN O***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L49) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L53) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L63) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L61) [eav1OzQB0OM8***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L11) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L39) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L37) [-----BEGIN P***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L21) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L50) [-----BEGIN E***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.v1beta.json:L3369) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.v1.json:L3140) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: private-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.v1alpha.json:L1584) [-----BEGIN R***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L24) [0685bd9184jf***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L30) [0685bd9184jf***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L230) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L289) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L292) [tGzv3JOkF0XG***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L330) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L408) [2YotnFZFEjr1***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L411) [tGzv3JOkF0XG***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L33) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L33) [rfc4357.Gost***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L30) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L36) [rfc5652.Reci***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L38) [rfc5652.Subj***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L37) [rfc5280.KeyI***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L63) [rfc5280.KeyI***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L119) [rfc7191.id_a***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L110) [rfc3447.RSAP***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L39) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L51) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L57) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L138) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L153) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L180) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L199) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L205) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.cpython-312.pyc:L219) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L75) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L87) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L93) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L231) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L246) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L278) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L305) [lsdajfh92387***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L311) [2kjshdfp92i3***]
- [HIGH] git_history: gitleaks: generic-api-key (/home/walt/a***.venv/lib/pyt***.12/site-pack***.py:L335) [lsdajfh92387***]
- [HIGH] github_repos: agent-* repo is PUBLIC and not in allowlist (waltbayliss/***)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/53)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/2019)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/3000)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/3001)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/5678)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/7681)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/8080)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/11434)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/43016)
- [HIGH] vps: secret pattern in dotfile (/home/walt/.bash_history:L1) [ghp_IoKnB8Dk***]
- [CRITICAL] self_scan: required pin missing: mcp-audit==1.0.0 (/home/walt/a***.txt)
- [CRITICAL] self_scan: credential pattern in own source (/home/walt/a***.md:L84) [ghp_IoKnB8Dk***]
## 2026-05-12 — daily — verdict: CLEAN
Run at: 2026-05-12T17:30:16Z
Counts: LOW=17 MEDIUM=40 HIGH=11 CRITICAL=0 TOTAL=68
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-12T17:30:16Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-13 — daily — verdict: CLEAN
Run at: 2026-05-13T17:30:21Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-13T17:30:21Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-14 — daily — verdict: DIRTY
Run at: 2026-05-14T17:30:39Z
Counts: LOW=17 MEDIUM=41 HIGH=11 CRITICAL=0 TOTAL=69
NEW since baseline: HIGH=1 CRITICAL=0
heartbeat: 2026-05-14T17:30:39Z

### NEW HIGH/CRITICAL findings (redacted)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/37639)

### Investigation + resolution (Session 81, 2026-05-14)
tcp/37639 not listening at investigation time — ephemeral loopback port owned by a Node helper (code-server extension host / MCP child). Root cause: `scanners/ports.py` flagged every new ephemeral port regardless of bind address or owner. Fix: scanner now (a) calls `sudo -n ss -tlnp` so it can see owners of root-owned and other-user sockets, (b) skips ports bound only to 127.0.0.0/8 or [::1] whose owner matches a `known_good_processes` entry. Added node, code-server, ttyd, ollama, caddy, systemd-resolve, docker-proxy to the known-good list. Re-ran scanner: residual HIGHs reduced from 8 to 3, all of which are public-bound and already in baseline (3000/3001 google-calendar-mcp, 5678 n8n). Same loopback ephemeral noise class won't re-fire.
## 2026-05-15 — daily — verdict: CLEAN
Run at: 2026-05-15T17:30:20Z
Counts: LOW=17 MEDIUM=32 HIGH=4 CRITICAL=0 TOTAL=53
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-15T17:30:20Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-16 — daily — verdict: CLEAN
Run at: 2026-05-16T17:30:20Z
Counts: LOW=17 MEDIUM=27 HIGH=4 CRITICAL=0 TOTAL=48
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-16T17:30:20Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-17 — daily — verdict: CLEAN
Run at: 2026-05-17T17:30:18Z
Counts: LOW=17 MEDIUM=36 HIGH=4 CRITICAL=0 TOTAL=57
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-17T17:30:18Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-17 — weekly — verdict: CLEAN
Run at: 2026-05-17T19:00:22Z
Counts: LOW=17 MEDIUM=39 HIGH=4 CRITICAL=0 TOTAL=60
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-17T19:00:22Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-18 — daily — verdict: CLEAN
Run at: 2026-05-18T17:30:41Z
Counts: LOW=17 MEDIUM=37 HIGH=4 CRITICAL=0 TOTAL=58
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-18T17:30:41Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-19 — daily — verdict: CLEAN
Run at: 2026-05-19T17:30:24Z
Counts: LOW=17 MEDIUM=33 HIGH=4 CRITICAL=0 TOTAL=54
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-19T17:30:24Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-20 — daily — verdict: CLEAN
Run at: 2026-05-20T17:30:23Z
Counts: LOW=17 MEDIUM=21 HIGH=4 CRITICAL=0 TOTAL=42
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-20T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-21 — daily — verdict: CLEAN
Run at: 2026-05-21T17:30:29Z
Counts: LOW=17 MEDIUM=24 HIGH=4 CRITICAL=0 TOTAL=45
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-21T17:30:29Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-22 — daily — verdict: CLEAN
Run at: 2026-05-22T17:30:32Z
Counts: LOW=17 MEDIUM=22 HIGH=4 CRITICAL=0 TOTAL=43
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-22T17:30:32Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-23 — daily — verdict: CLEAN
Run at: 2026-05-23T17:30:23Z
Counts: LOW=17 MEDIUM=24 HIGH=4 CRITICAL=0 TOTAL=45
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-23T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-24 — daily — verdict: CLEAN
Run at: 2026-05-24T17:30:19Z
Counts: LOW=17 MEDIUM=26 HIGH=4 CRITICAL=0 TOTAL=47
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-24T17:30:19Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-24 — weekly — verdict: CLEAN
Run at: 2026-05-24T19:00:20Z
Counts: LOW=17 MEDIUM=29 HIGH=4 CRITICAL=0 TOTAL=50
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-24T19:00:20Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-25 — daily — verdict: CLEAN
Run at: 2026-05-25T17:30:22Z
Counts: LOW=17 MEDIUM=30 HIGH=4 CRITICAL=0 TOTAL=51
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-25T17:30:22Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-26 — daily — verdict: CLEAN
Run at: 2026-05-26T17:30:25Z
Counts: LOW=17 MEDIUM=27 HIGH=4 CRITICAL=0 TOTAL=48
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-26T17:30:25Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-27 — daily — verdict: CLEAN
Run at: 2026-05-27T17:30:23Z
Counts: LOW=17 MEDIUM=28 HIGH=4 CRITICAL=0 TOTAL=49
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-27T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-28 — daily — verdict: CLEAN
Run at: 2026-05-28T17:30:27Z
Counts: LOW=17 MEDIUM=34 HIGH=4 CRITICAL=0 TOTAL=55
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-28T17:30:27Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-29 — daily — verdict: CLEAN
Run at: 2026-05-29T17:30:50Z
Counts: LOW=17 MEDIUM=31 HIGH=4 CRITICAL=0 TOTAL=52
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-29T17:30:50Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-30 — daily — verdict: CLEAN
Run at: 2026-05-30T17:30:22Z
Counts: LOW=17 MEDIUM=32 HIGH=4 CRITICAL=0 TOTAL=53
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-30T17:30:22Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-31 — daily — verdict: CLEAN
Run at: 2026-05-31T17:30:22Z
Counts: LOW=17 MEDIUM=32 HIGH=4 CRITICAL=0 TOTAL=53
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-31T17:30:22Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-05-31 — weekly — verdict: CLEAN
Run at: 2026-05-31T19:00:20Z
Counts: LOW=17 MEDIUM=35 HIGH=4 CRITICAL=0 TOTAL=56
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-05-31T19:00:20Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-01 — daily — verdict: CLEAN
Run at: 2026-06-01T17:30:26Z
Counts: LOW=17 MEDIUM=32 HIGH=4 CRITICAL=0 TOTAL=53
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-01T17:30:26Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-02 — daily — verdict: CLEAN
Run at: 2026-06-02T17:30:26Z
Counts: LOW=17 MEDIUM=28 HIGH=4 CRITICAL=0 TOTAL=49
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-02T17:30:26Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-03 — daily — verdict: CLEAN
Run at: 2026-06-03T17:30:32Z
Counts: LOW=17 MEDIUM=27 HIGH=4 CRITICAL=0 TOTAL=48
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-03T17:30:32Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-04 — daily — verdict: CLEAN
Run at: 2026-06-04T17:30:23Z
Counts: LOW=17 MEDIUM=30 HIGH=4 CRITICAL=0 TOTAL=51
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-04T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-05 — daily — verdict: CLEAN
Run at: 2026-06-05T17:30:23Z
Counts: LOW=17 MEDIUM=30 HIGH=4 CRITICAL=0 TOTAL=51
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-05T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-06 — daily — verdict: CLEAN
Run at: 2026-06-06T17:30:21Z
Counts: LOW=17 MEDIUM=26 HIGH=4 CRITICAL=0 TOTAL=47
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-06T17:30:21Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-07 — daily — verdict: CLEAN
Run at: 2026-06-07T17:30:22Z
Counts: LOW=17 MEDIUM=26 HIGH=4 CRITICAL=0 TOTAL=47
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-07T17:30:22Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-07 — weekly — verdict: CLEAN
Run at: 2026-06-07T19:00:21Z
Counts: LOW=17 MEDIUM=29 HIGH=4 CRITICAL=0 TOTAL=50
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-07T19:00:21Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-08 — daily — verdict: CLEAN
Run at: 2026-06-08T17:30:24Z
Counts: LOW=17 MEDIUM=26 HIGH=4 CRITICAL=0 TOTAL=47
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-08T17:30:24Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-09 — daily — verdict: CLEAN
Run at: 2026-06-09T17:30:28Z
Counts: LOW=17 MEDIUM=28 HIGH=4 CRITICAL=0 TOTAL=49
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-09T17:30:28Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-10 — daily — verdict: CLEAN
Run at: 2026-06-10T17:30:30Z
Counts: LOW=17 MEDIUM=26 HIGH=4 CRITICAL=0 TOTAL=47
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-10T17:30:30Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-11 — daily — verdict: CLEAN
Run at: 2026-06-11T17:30:33Z
Counts: LOW=17 MEDIUM=26 HIGH=5 CRITICAL=0 TOTAL=48
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-11T17:30:33Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-12 — daily — verdict: CLEAN
Run at: 2026-06-12T17:30:23Z
Counts: LOW=17 MEDIUM=26 HIGH=5 CRITICAL=0 TOTAL=48
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-12T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-13 — daily — verdict: DIRTY
Run at: 2026-06-13T17:30:20Z
Counts: LOW=17 MEDIUM=26 HIGH=6 CRITICAL=0 TOTAL=49
NEW since baseline: HIGH=1 CRITICAL=0
heartbeat: 2026-06-13T17:30:20Z

### NEW HIGH/CRITICAL findings (redacted)
- [HIGH] vps: secret pattern in dotfile (/home/walt/.bash_history:L130) [sk-ant-api03***]
## 2026-06-14 — daily — verdict: CLEAN
Run at: 2026-06-14T17:30:27Z
Counts: LOW=17 MEDIUM=26 HIGH=6 CRITICAL=0 TOTAL=49
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-14T17:30:27Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-14 — weekly — verdict: CLEAN
Run at: 2026-06-14T19:00:32Z
Counts: LOW=17 MEDIUM=29 HIGH=6 CRITICAL=0 TOTAL=52
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-14T19:00:32Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-15 — daily — verdict: DIRTY
Run at: 2026-06-15T17:30:26Z
Counts: LOW=17 MEDIUM=40 HIGH=10 CRITICAL=0 TOTAL=67
NEW since baseline: HIGH=3 CRITICAL=0
heartbeat: 2026-06-15T17:30:26Z

### NEW HIGH/CRITICAL findings (redacted)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/34311)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/38135)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/58984)
## 2026-06-16 — daily — verdict: CLEAN
Run at: 2026-06-16T17:30:25Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-16T17:30:25Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-17 — daily — verdict: CLEAN
Run at: 2026-06-17T17:30:25Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-17T17:30:25Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-18 — daily — verdict: CLEAN
Run at: 2026-06-18T17:30:29Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-18T17:30:29Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-19 — daily — verdict: CLEAN
Run at: 2026-06-19T17:30:24Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-19T17:30:24Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-20 — daily — verdict: CLEAN
Run at: 2026-06-20T17:30:20Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-20T17:30:20Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-21 — daily — verdict: CLEAN
Run at: 2026-06-21T17:30:20Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-21T17:30:20Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-21 — weekly — verdict: CLEAN
Run at: 2026-06-21T19:00:18Z
Counts: LOW=17 MEDIUM=37 HIGH=10 CRITICAL=0 TOTAL=64
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-21T19:00:18Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-22 — daily — verdict: CLEAN
Run at: 2026-06-22T17:30:25Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-22T17:30:25Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-23 — daily — verdict: CLEAN
Run at: 2026-06-23T17:30:25Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-23T17:30:25Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-24 — daily — verdict: CLEAN
Run at: 2026-06-24T17:30:27Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-24T17:30:27Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-25 — daily — verdict: CLEAN
Run at: 2026-06-25T17:30:26Z
Counts: LOW=17 MEDIUM=34 HIGH=10 CRITICAL=0 TOTAL=61
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-25T17:30:26Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-26 — daily — verdict: CLEAN
Run at: 2026-06-26T17:30:23Z
Counts: LOW=17 MEDIUM=36 HIGH=10 CRITICAL=0 TOTAL=63
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-26T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-27 — daily — verdict: CLEAN
Run at: 2026-06-27T17:30:30Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-27T17:30:30Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-28 — daily — verdict: CLEAN
Run at: 2026-06-28T17:30:24Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-28T17:30:24Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-28 — weekly — verdict: CLEAN
Run at: 2026-06-28T19:00:23Z
Counts: LOW=17 MEDIUM=42 HIGH=10 CRITICAL=0 TOTAL=69
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-28T19:00:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-29 — daily — verdict: CLEAN
Run at: 2026-06-29T17:30:27Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-29T17:30:27Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-06-30 — daily — verdict: CLEAN
Run at: 2026-06-30T17:30:24Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-06-30T17:30:24Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-01 — daily — verdict: CLEAN
Run at: 2026-07-01T17:30:25Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-01T17:30:25Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-02 — daily — verdict: CLEAN
Run at: 2026-07-02T17:30:35Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-02T17:30:35Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-03 — daily — verdict: CLEAN
Run at: 2026-07-03T17:30:26Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-03T17:30:26Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-04 — daily — verdict: CLEAN
Run at: 2026-07-04T17:30:23Z
Counts: LOW=17 MEDIUM=39 HIGH=10 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-04T17:30:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-05 — daily — verdict: CLEAN
Run at: 2026-07-05T17:30:24Z
Counts: LOW=17 MEDIUM=37 HIGH=9 CRITICAL=0 TOTAL=63
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-05T17:30:24Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-05 — weekly — verdict: CLEAN
Run at: 2026-07-05T19:00:23Z
Counts: LOW=17 MEDIUM=40 HIGH=9 CRITICAL=0 TOTAL=66
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-05T19:00:23Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-06 — daily — verdict: DIRTY
Run at: 2026-07-06T17:30:26Z
Counts: LOW=17 MEDIUM=49 HIGH=10 CRITICAL=0 TOTAL=76
NEW since baseline: HIGH=1 CRITICAL=0
heartbeat: 2026-07-06T17:30:26Z

### NEW HIGH/CRITICAL findings (redacted)
- [HIGH] ports: listening port not in known_good_p*** allowlist (tcp/8787)
## 2026-07-07 — daily — verdict: CLEAN
Run at: 2026-07-07T17:30:38Z
Counts: LOW=17 MEDIUM=47 HIGH=10 CRITICAL=0 TOTAL=74
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-07T17:30:38Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-08 — daily — verdict: CLEAN
Run at: 2026-07-08T17:30:27Z
Counts: LOW=17 MEDIUM=47 HIGH=10 CRITICAL=0 TOTAL=74
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-08T17:30:27Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-09 — daily — verdict: CLEAN
Run at: 2026-07-09T17:30:45Z
Counts: LOW=17 MEDIUM=46 HIGH=10 CRITICAL=0 TOTAL=73
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-09T17:30:45Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-10 — daily — verdict: CLEAN
Run at: 2026-07-10T17:30:37Z
Counts: LOW=17 MEDIUM=46 HIGH=10 CRITICAL=0 TOTAL=73
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-10T17:30:37Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-11 — daily — verdict: CLEAN
Run at: 2026-07-11T17:30:28Z
Counts: LOW=17 MEDIUM=46 HIGH=10 CRITICAL=0 TOTAL=73
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-11T17:30:28Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-12 — daily — verdict: CLEAN
Run at: 2026-07-12T17:30:27Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-12T17:30:27Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-12 — weekly — verdict: CLEAN
Run at: 2026-07-12T19:00:29Z
Counts: LOW=17 MEDIUM=47 HIGH=10 CRITICAL=0 TOTAL=74
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-12T19:00:29Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-13 — daily — verdict: CLEAN
Run at: 2026-07-13T17:30:30Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-13T17:30:30Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-14 — daily — verdict: CLEAN
Run at: 2026-07-14T17:30:32Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-14T17:30:32Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-15 — daily — verdict: CLEAN
Run at: 2026-07-15T17:30:35Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-15T17:30:35Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-16 — daily — verdict: CLEAN
Run at: 2026-07-16T17:30:32Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-16T17:30:32Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-17 — daily — verdict: CLEAN
Run at: 2026-07-17T17:30:32Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-17T17:30:32Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-18 — daily — verdict: CLEAN
Run at: 2026-07-18T17:30:31Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-18T17:30:31Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-19 — daily — verdict: CLEAN
Run at: 2026-07-19T17:30:41Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-19T17:30:41Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-19 — weekly — verdict: CLEAN
Run at: 2026-07-19T19:00:32Z
Counts: LOW=17 MEDIUM=47 HIGH=10 CRITICAL=0 TOTAL=74
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-19T19:00:32Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-20 — daily — verdict: CLEAN
Run at: 2026-07-20T17:30:35Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-20T17:30:35Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-21 — daily — verdict: CLEAN
Run at: 2026-07-21T17:31:09Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-21T17:31:09Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
## 2026-07-22 — daily — verdict: CLEAN
Run at: 2026-07-22T17:31:31Z
Counts: LOW=17 MEDIUM=44 HIGH=10 CRITICAL=0 TOTAL=71
NEW since baseline: HIGH=0 CRITICAL=0
heartbeat: 2026-07-22T17:31:31Z

### NEW HIGH/CRITICAL findings (redacted)
(none)
