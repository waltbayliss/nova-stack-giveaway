# Runbook 001 — Session Close Protocol

**Trigger:** Walt says "update docs", "end session", "save this session", or similar close phrase.
**Owner:** Nova
**Estimated time:** 5 minutes
**Git rule:** All writes via `mcp__github__create_or_update_file`. Never local git commit + push for nova-assistant docs.

---

## Steps (execute in order)

### Step 1 — Update SPRINT_LOG.md
Via `mcp__github__create_or_update_file` → `docs/SPRINT_LOG.md`:
- Session number and date
- Status (Complete / In Progress)
- Type (New Agent Build / Bug Fix / Upgrade / etc.)
- What was done (bullet points, specific)
- Key decisions made
- Blockers hit and how resolved
- What's next (P1/P2/P3 priority order)

Get current SHA first: `mcp__github__get_file_contents(path="docs/SPRINT_LOG.md")`

---

### Step 2 — Update nova-memory.md
Via `mcp__github__create_or_update_file` → `nova-memory.md`:
- Update header comment: Last Updated date + session summary
- Update agent count if changed
- Add new agents to the agent table
- Add session to Session Log table
- Update any relevant sections (content pipeline, infra state, etc.)

Get current SHA first: `mcp__github__get_file_contents(path="nova-memory.md")`

---

### Step 3 — Update lessons.md (if corrections occurred)
Via `mcp__github__create_or_update_file` → `lessons.md`:
- If Walt corrected Nova on anything during this session → add a new entry
- Format: Date / Mistake / Rule / Apply When
- Confirm: "Lesson logged."
- If no corrections this session: skip this step

Get current SHA first: `mcp__github__get_file_contents(path="lessons.md")`

---

### Step 4 — Update AGENT-REGISTRY.md (if agents changed)
Via `mcp__github__create_or_update_file` → `docs/AGENT-REGISTRY.md`:
- New agents: add full row with all columns populated
- Modified agents: update version, notes, status
- Decommissioned agents: mark with date

Get current SHA first: `mcp__github__get_file_contents(path="docs/AGENT-REGISTRY.md")`

---

### Step 5 — Save session notes to Walt's Wiki
Via `mcp__github__create_or_update_file` → `waltbayliss/walts-wiki`:
- Path: `Walt's Wiki/Claude Sessions/Raw/[YYYY-MM-DD-topic].md`
- Content: session summary, key outputs, decisions, agent changes
- This is a CREATE (new file) — no SHA needed

---

### Step 6 — Confirm to Walt
```
"Session closed. Memory updated. Nova standing by."
```

---

## Hard Rules

1. All writes use `mcp__github__create_or_update_file` — never local git for nova-assistant docs
2. Always fetch current SHA before updating an existing file
3. SPRINT_LOG gets a new entry every session — no exceptions
4. nova-memory.md agent count must match AGENT-REGISTRY active count
5. lessons.md is checked every close — if any correction occurred, it must be logged
