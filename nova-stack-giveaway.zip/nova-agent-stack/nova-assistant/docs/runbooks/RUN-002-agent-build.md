# Runbook 002 — Agent Build Protocol

**Trigger:** Walt approves a new agent build after intake + PRD review.
**Owner:** Nova (orchestrates), agent-builder (builds), agent-code-reviewer (reviews)
**Estimated time:** 30–90 minutes
**Hard rule:** All 8 steps must complete in order. No skipping. No exceptions.

---

## The 8-Step Pipeline

### Step 1 — Intake Interview
- Walt sets Notion entry Status = "Now" → Telegram ping arrives
- Walt types `intake` in Nova session
- Nova runs 4-question interview inline:
  - Q1: One-line purpose — what specific problem does this solve?
  - Q2: 3–5 main functions it needs to do
  - Q3: Which tools or APIs does it connect to?
  - Q4: How does it get triggered? Sync or async?
- Nova saves brief to `pending-builds/<slug>.md` on GitHub
- Nova sets Notion Status: Now → Building

**Gate:** Brief must be saved to GitHub before Step 2.

---

### Step 2 — Draft PRD
- Structured brief written from intake answers
- Saved alongside or as part of `pending-builds/<slug>.md`
- Covers: purpose, functions, integrations, trigger, failure modes, scope limits

---

### Step 3 — agent-quick-searcher ← HARD GATE
- Route: "quick-search [agent-name] — [one-line purpose]"
- CLI: `python3 src/cli.py --name "[name]" --purpose "[purpose]"`
- Returns: exists (yes/no), worth adapting, relevance score, flagged repos
- HIGH RELEVANCE (stars ≥100, last commit ≤180 days) → route to agent-security before proceeding
- **Nova does NOT proceed to Step 4 until quick-search report is in hand.**

---

### Step 4 — agent-prd-reviewer ← HARD GATE
- Pass brief + quick-search findings to agent-prd-reviewer
- Returns: upgraded PRD with missing features, security gaps, prior art, scope tightened, failure modes mapped
- **Nova does NOT proceed to Step 5 until upgraded PRD is returned.**

---

### Step 5 — Nova Approval Gate
- Present upgraded PRD to Walt
- Wait for explicit "go" or approval
- No silent assumptions. "Let's build it" = go. Ambiguous = ask.

---

### Step 6 — agent-builder
Build full Nova standard structure:
- `CLAUDE.md` — boot sequence, operating rules, trigger phrases, hard rules
- `docs/` — 8 files: PRD, ARCHITECTURE, SECURITY, SOUL, ROADMAP, SPRINT_LOG, DECISIONS, AGENT-REGISTRY
- `skills/` — minimum 2 skill .md files
- `wiki/` — Raw, Wiki, Output, Master folders
- `.env.example` — all required vars listed, no values
- `agent-memory.md` — seeded with known context
- `src/` — if the agent has executable code

Push to GitHub repo (`waltbayliss/agent-[name]`) and mirror to local `my-ai-team/agent-[name]/`.

---

### Step 7 — Code Review (inline, same session)
**Pass 1:** Run all 5 review dimensions:
1. Nova Standard Structure — all required files present
2. Security — no exposed credentials, SECURITY.md loaded at boot
3. CLAUDE.md Quality — boot sequence complete, rules clear, trigger phrases defined
4. Functionality Alignment — PRD matches CLAUDE.md, skills cover main functions
5. Documentation Quality — no empty template sections, real content throughout

Produce findings report → fix all blocking items → push fixes.

**Pass 2:** Re-run all 5 dimensions against fixed build.
Verdict: PASS or ESCALATE.

**No build is complete without Pass 2 PASS.**

---

### Step 8 — Register
- Add agent to `docs/AGENT-REGISTRY.md` (GitHub + local)
- Update nova-memory.md agent table and agent count
- Set Notion Status: Building → Completed
- Confirm to Walt: "[agent-name] built, Pass 1 + Pass 2 signed off. [N] active agents."

---

## Hard Rules

1. Steps 1–5 must complete before agent-builder starts — no exceptions
2. Pass 2 sign-off is required — no shipping on Pass 1 only
3. Agent security check if any HIGH RELEVANCE repos found in Step 3
4. Registry entry is a non-negotiable gate — build isn't done until agent is registered
5. All doc writes via GitHub MCP — never local git for nova-assistant docs
6. If Walt says "build [name]" and Steps 3–4 haven't run: Nova runs them first. Say: "Running quick-search first, then PRD review — then I'll build."
