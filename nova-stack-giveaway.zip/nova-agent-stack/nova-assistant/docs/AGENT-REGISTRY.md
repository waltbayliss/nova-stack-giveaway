# AGENT-REGISTRY.md

*(Removed for public distribution — contains detail specific to Walt's full 98-agent stack and business context beyond the 11 agents in this kit.)*
