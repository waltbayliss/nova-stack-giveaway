# Nova CLAUDE.md — Rewrite Plan

**Generated:** 2026-05-12 (Session 76)
**Framework applied:** `skills/claude-md-quality.md`
**Backup of current file:** `/home/walt/backups/nova-CLAUDE.md.2026-05-12-200247.bak` (chmod 444, SHA256 `8ffc7ff4...e94f142`)
**Target draft path:** `/docs/CLAUDE.md.draft` (to be written in Phase F — not yet existing)
**Scope:** Tier 1 (compression) + Tier 2 (hooks) + Tier 3 (quality additions). Tier 4 (specialist agent polish) deferred to follow-up.

---

## 1. Current State

- **Path:** `/home/walt/agents/nova-assistant/CLAUDE.md`
- **Length:** 450 lines / 80–150 budget (3–6× over)
- **Bytes:** 33,092
- **Last reviewed (header):** none — no header exists today
- **Sections:** 14
- **Numbered hard rules:** 24
- **Emphasis markers (IMPORTANT / MANDATORY / NO EXCEPTIONS / HARD GATE / etc):** 23 instances (target: ≤5)

---

## 2. Audit Table — every section, every line accounted for

| # | Section | Lines | Bucket Verdict | Recommended Move |
|---|---|---|---|---|
| 1 | Header (none — file starts at H2) | — | Missing | **Add required header** with owner / date / budget |
| 2 | Boot Sequence — Step 0 (git sync) | 9–17 | **Hook** (SessionStart) | Move to a SessionStart hook script. Mac+VPS path resolution becomes a shell conditional in the script. |
| 3 | Boot Sequence — Step 1 (load wiki) | 19–33 | **CLAUDE.md (compressed)** | Keep — this is "model behaviour: fetch and read." Compress to 4 lines + skill pointer. |
| 4 | Boot Sequence — Step 2 (read memory docs) | 35–43 | **CLAUDE.md (compressed)** | Keep — model behaviour. Compress to 3 lines (list as `@docs/SECURITY.md @docs/PRD.md ...`). |
| 5 | Boot Sequence — Step 3 (registry audit) | 45–50 | **Hook** (SessionStart) | Deterministic — shell script can do this and write the report to stdout. |
| 6 | Boot Sequence — Step 3.5 (pending rules) | 52–60 | **Skill** + Hook trigger | Hook fires if `pending-agent-rules/` has non-template content; skill loads on trigger. |
| 7 | Boot Sequence — Step 3.6 (NEXT-SESSION.md) | 62–63 | **CLAUDE.md** | Keep — 2 lines, model behaviour. |
| 8 | Boot Sequence — Step 3.7 (worktree cleanup) | 65–77 | **Hook** (SessionStart) | Fully deterministic. Move to script. |
| 9 | Boot Sequence — Step 4 (confirm readiness) | 80–81 | **CLAUDE.md** | Keep — model behaviour. 2 lines. |
| 10 | Who Nova Is | 85–89 | **CLAUDE.md** | Keep — 4 lines, identity that drives behaviour. |
| 11 | Subagent Invocation pattern | 93–137 | **Skill** | Move full pattern to `@skills/subagent-invocation.md`. Inline becomes 5 lines: "Use general-purpose dispatcher with agent identity in prompt. Pass-through outputs verbatim. See skill." |
| 12 | Single-Session Orchestration | 140–151 | **CLAUDE.md (trimmed)** | Keep — but trim to 5 lines. Core rule + the "stop and ask" trigger. |
| 13 | Rule 1 (load wiki first) | 157 | **CLAUDE.md** | Keep — already in boot sequence. Dedupe — delete from rules list. |
| 14 | Rule 2 (never execute without confirmation) | 158 | **CLAUDE.md** | Keep — core behaviour rule. |
| 15 | Rule 3 (route to correct agent) | 159 | **CLAUDE.md** | Keep — core. |
| 16 | Rule 4 (full interview for new agents) | 160 | **Skill pointer** | Lives in `@skills/intake.md`. Cut from CLAUDE.md. |
| 17 | Rule 5 (full agent structure) | 161 | **Skill pointer** | Lives in `@skills/agent-creation-pipeline.md`. Cut. |
| 18 | Rule 6 (secrets in .env) | 162 | **CLAUDE.md** | Keep — short, critical, universal. |
| 19 | Rule 7 (update nova-memory at session close) | 163 | **Skill pointer** | Lives in `@skills/session-close.md`. Cut. |
| 20 | Rule 8 (reflect Walt's voice) | 164 | **SOUL.md** | Aspirational voice rule. Move to SOUL.md. |
| 21 | Rule 9 (confirm before creating repos / writing externally) | 165 | **CLAUDE.md** | Keep — security-adjacent. |
| 22 | Rule 10 (flag blockers immediately) | 166 | **CLAUDE.md** | Keep — short, universal behaviour. |
| 23 | Rule 11 (security check before external add) | 167 | **Skill pointer** | `@skills/security-bouncer.md`. Cut prose. |
| 24 | Rule 12 (code review after build) | 168 | **Skill pointer** | `@skills/code-review.md`. Cut. |
| 25 | Rule 13 (register every agent immediately) | 169 | **Hook** (PostToolUse on agent-folder creation) | Mechanical — deserves enforcement, not memory. |
| 26 | Rule 14 (boot-time registry audit) | 170 | **Hook** (SessionStart) | Already deterministic — moves to script. |
| 27 | Rule 15 (build pipeline is hard gate) | 171 | **Hook** (PreToolUse on agent-builder) | Mechanical gate. |
| 28 | Rule 16 (self-improvement loop) | 172 | **Skill** + light CLAUDE.md mention | Skill: `@skills/self-improve.md` (already exists). CLAUDE.md gets one line. |
| 29 | Rule 17 (plan mode for 3+ step tasks) | 173 | **CLAUDE.md** | Keep — judgement rule, must stay in memory. |
| 30 | Rule 18 (verify before done) | 174 | **Definition of Done block** | Replace prose rule with the concrete checklist at end of file. |
| 31 | Rule 19 (pending rules review) | 175 | **Hook + skill** | Hook detects content; skill loads on trigger. Cut from rules. |
| 32 | Rule 20 (subagent output pass-through) | 176 | **CLAUDE.md** | Keep — core behaviour. Compress to 2 lines. |
| 33 | Rule 21 (single-session orchestration) | 177 | **CLAUDE.md** | Dedupe with the dedicated section above. Pick one location. |
| 34 | Rule 22 (background notifications) | 178 | **CLAUDE.md** | Keep — short, universal. |
| 35 | Rule 23 (quick-search for upgrades too) | 179 | **Skill pointer** | Lives in `@skills/agent-creation-pipeline.md`. Cut prose. |
| 36 | Rule 24 (all posts must have images) | 180 | **Hook** (PostToolUse on Notion writes) | Mechanical — verifiable. Hook checks Image property populated before commit. |
| 37 | Intake Command protocol | 184–219 | **Skill** | Already exists at `@skills/intake.md`. Cut entire section. |
| 38 | Agent Creation Protocol (8 steps) | 223–295 | **Skill** | Move full content to `@skills/agent-creation-pipeline.md`. Cut. |
| 39 | Brief Actioning Protocol | 299–318 | **Skill** | Move to `@skills/brief-actioning.md`. Cut. |
| 40 | Security Bouncer Protocol | 322–347 | **Skill** | Move to `@skills/security-bouncer.md`. Cut. |
| 41 | Code Reviewer Protocol | 351–381 | **Skill** | Move to `@skills/code-review.md`. Cut. |
| 42 | Communication Channels | 385–391 | **CLAUDE.md** | Keep — short, contextual. |
| 43 | Model Routing Protocol | 395–420 | **Skill** | Move to `@skills/model-routing.md`. CLAUDE.md gets one-line pointer. |
| 44 | Always True About Walt | 424–432 | **SOUL.md** | Identity content. Belongs in SOUL.md. |
| 45 | End of Session Protocol | 436–448 | **Skill** | Move to `@skills/session-close.md`. Cut. |

---

## 3. Anti-Pattern Scan (12 checks against the current file)

| # | Check | Status | Evidence |
|---|---|---|---|
| 1 | Code-style rules present | ✓ Clean | None found |
| 2 | Personality directives present | ✗ HIT | Rule 8 "Reflect Walt's voice" — move to SOUL.md |
| 3 | File-by-file directory descriptions | ✓ Clean | — |
| 4 | Multi-paragraph rationale per rule | ✗ HIT | Rules 13, 15, 16, 19, 20, 24 all have multi-line "why" prose. Tighten or move to skill. |
| 5 | Auto-generated `/init` content | ✓ Clean | File is hand-curated |
| 6 | Self-evident practices | ✓ Clean | — |
| 7 | Standard language conventions | ✓ Clean | — |
| 8 | Long tutorials inside CLAUDE.md | ✗ HIT | Agent Creation Protocol (72 lines), Brief Actioning Protocol (20 lines), Code Reviewer Protocol (30 lines), Security Bouncer Protocol (25 lines) are all tutorial-length |
| 9 | API documentation inside CLAUDE.md | ✓ Clean | — |
| 10 | Rules that contradict each other | ✓ Clean | — |
| 11 | Rules a hook/CI would catch | ✗ HIT | Rules 13, 14, 15, 19, 24 are mechanical, deserve hooks |
| 12 | Dead path / invalid MCP references | ⚠ PARTIAL | Step 0 still references Mac path; "VPS note" overrides it. Acceptable for now but ugly. |

**Headline:** 4 anti-pattern hits, all addressed by the recommendations below.

---

## 4. Gap Analysis vs Framework

| Framework requirement | Current file | Action |
|---|---|---|
| Required header (owner / date / budget) | Missing | Add |
| Length ≤150 lines | 450 lines | Compress |
| ≤5 emphasis markers | 23 instances | Audit & cut |
| Definition of Done block | Missing | Add at end |
| Three-bucket categorization | Partial | Apply systematically per audit table |
| All references resolve | Some dead/Mac-only paths | Clean up |
| Tool-minimization | N/A (this is Nova, not a specialist agent) | — |

---

## 5. Recommendations — Tiered

### **TIER 1 — Structural compression** (text-only, fully reversible from backup)

| # | Recommendation | Effect | Risk |
|---|---|---|---|
| T1.1 | Add required header (owner / date / budget / line count) | Forces periodic pruning. Header = trivial. | None |
| T1.2 | Move Intake Protocol (lines 184–219) → leave 1-line pointer to `@skills/intake.md` (already exists) | -35 lines | None — skill already exists |
| T1.3 | Move Agent Creation Protocol (lines 223–295) → new `@skills/agent-creation-pipeline.md` | -72 lines | LOW — requires writing new skill in Phase D |
| T1.4 | Move Brief Actioning Protocol (lines 299–318) → new `@skills/brief-actioning.md` | -20 lines | LOW — same |
| T1.5 | Move Security Bouncer Protocol (lines 322–347) → new `@skills/security-bouncer.md` | -25 lines | LOW — same |
| T1.6 | Move Code Reviewer Protocol (lines 351–381) → new `@skills/code-review.md` | -30 lines | LOW — same |
| T1.7 | Move Model Routing Protocol (lines 395–420) → new `@skills/model-routing.md` | -25 lines | LOW — same |
| T1.8 | Move End of Session Protocol (lines 436–448) → new `@skills/session-close.md` | -13 lines | LOW — same |
| T1.9 | Move "Always True About Walt" (lines 424–432) → SOUL.md | -10 lines | None |
| T1.10 | Move Rule 8 ("Reflect Walt's voice") → SOUL.md | -1 line | None |
| T1.11 | Compress Subagent Invocation section (lines 93–137 → ~10 lines), full protocol to `@skills/subagent-invocation.md` | -35 lines | LOW |
| T1.12 | Dedupe Rule 1 (already in boot sequence) | -1 line | None |
| T1.13 | Dedupe Rule 21 (already in dedicated section) | -1 line | None |
| T1.14 | Cut multi-paragraph rationale on Rules 13/15/16/19/20/23/24 (preserve the rule, drop the explainer) | ~-20 lines | None |
| **TIER 1 subtotal** | | **~-288 lines (450 → ~162)** | Reversible |

### **TIER 2 — Mechanical enforcement** (hooks — careful, more risk)

| # | Recommendation | Hook type | Risk |
|---|---|---|---|
| T2.1 | Boot Step 0 (git sync) → SessionStart hook script | SessionStart | LOW |
| T2.2 | Boot Step 3 (registry audit) → SessionStart hook script | SessionStart | LOW |
| T2.3 | Boot Step 3.5 (pending-rules check) → SessionStart hook script (trigger only; skill handles content) | SessionStart | MEDIUM |
| T2.4 | Boot Step 3.7 (worktree cleanup) → SessionStart hook script | SessionStart | LOW |
| T2.5 | Rule 13 (register every agent) → PostToolUse hook on new-agent-folder commit | PostToolUse | MEDIUM — needs detection logic |
| T2.6 | Rule 15 (build-pipeline gate) → PreToolUse hook on agent-builder invocation | PreToolUse | MEDIUM — needs pre-condition check |
| T2.7 | Rule 24 (image attached on Notion post) → PostToolUse hook on Notion writes | PostToolUse | HIGH — Notion writes are common, false-positives expensive |

**Tier 2 note:** Phase E (Research Claude Code hook patterns safely) precedes any of these. We won't write hooks until we understand the harness's hook surface here on the VPS. T2.7 in particular needs careful scoping — only triggers on Social Media Posts DB writes, not every Notion call.

### **TIER 3 — Quality additions** (text-only, easy wins)

| # | Recommendation | Source |
|---|---|---|
| T3.1 | Add Definition of Done block at end of file (replaces Rule 18 prose) | OmerFarukOruc + rosmur |
| T3.2 | Add Context Management Discipline section (5 lines): "/clear at 60k tokens; Document & Clear pattern over /compact" | rosmur |
| T3.3 | Add Verification-Before-Sign-Off rule: every PASS verdict from a subagent must reference a concrete test/lint/output, not judgement alone | Anthropic top-of-page tip |

### TIER 4 — Specialist agent polish (deferred to follow-up session)

Adopt Anthropic's `<example>` block format in each specialist agent's CLAUDE.md frontmatter. Not in this pass.

---

## 6. Checklist Verdict — Current File

| # | Check | Verdict |
|---|---|---|
| 1 | Length within budget (80–150) | **FAIL** (450 / 150) |
| 2 | Rules pass testability OR in SOUL.md | **FAIL** (Rule 8 + Rule 18 fail) |
| 3 | No protocol over 10 lines inline | **FAIL** (5 long protocols inline) |
| 4 | No code-style / personality rules | **FAIL** (Rule 8 personality) |
| 5 | Required header present with date | **FAIL** (no header) |
| 6 | Definition of Done block present | **FAIL** (missing) |
| 7 | All `@skills/X.md` references resolve | **PASS** (no broken references — there just aren't enough references) |
| 8 | All MCP tool names valid | **PASS** |
| 9 | All file paths exist | **PARTIAL** (Mac-only paths in Step 0 — overridden by VPS note) |
| 10 | ≤5 emphasis markers | **FAIL** (23 instances) |
| 11 | Anti-pattern scan clean (12 checks) | **FAIL** (4 hits) |
| 12 | Tool-minimization | **N/A** (orchestrator, not specialist) |

**Overall verdict:** **NEEDS REWORK** — 8 of 11 applicable checks fail.

---

## 7. Sign-off Path

This plan is the work product of Phase B. Phase C is Walt's review of this document.

**Sign-off decisions Walt makes here:**
1. Approve the audit table (every cell) — or specify cells to override.
2. Approve all Tier 1 moves — or specify which to drop.
3. Approve Tier 2 scope (all 7 hooks) — or narrow.
4. Approve Tier 3 additions (DoD, context discipline, verification rule) — or narrow.
5. Approve target line count budget (proposal: 150 lines) — or set different number.

Once approved → Phase D begins (build referenced skills). The live CLAUDE.md remains untouched until Phase J atomic swap.

---

## Sources
See `skills/claude-md-quality.md` — sources list at bottom.

**Plan owner:** Nova / Walt | **Generated:** 2026-05-12 (Session 76) | **Status:** Awaiting Walt sign-off (Phase C)
