# Nova VPS — Complete User Manual

**Last updated:** 2026-05-03
**Author:** Nova
**Purpose:** Everything you need to access, control, and work with your Nova VPS from any device, without technical knowledge.

---

## What Is This System?

Your AI team runs on a powerful server (VPS) hosted in the cloud. This server — called **[vps-hostname]** — runs 24 hours a day, 7 days a week, whether your Mac is on or off.

You access and control this server entirely through your **browser**. No special software. No SSH. No command line expertise required.

You have two browser-based tools:

| Tool | Address | What It Is |
|------|---------|------------|
| **Browser Terminal** | https://terminal.[personal-site] | A terminal window in your browser — type commands, run agents, check status |
| **VS Code in Browser** | https://code.[personal-site] | Full Visual Studio Code editor in your browser — files, terminals, editor, everything |

---

## Quick Reference — Credentials

Save these. You will need them every time.

### Browser Terminal
- **URL:** https://terminal.[personal-site]
- **Username:** `walt`
- **Password:** `[REDACTED-PASSWORD]`

### VS Code in Browser
- **URL:** https://code.[personal-site]
- **Password:** `[REDACTED-PASSWORD]`
- *(No username — just the password)*

### SSH (if ever needed from Mac Terminal)
- **Command:** `ssh nova`
- **Server IP:** [VPS-IP]

---

## Part 1 — Browser Terminal (terminal.[personal-site])

### What It Is

A full Linux terminal running directly on your VPS, inside a browser tab. It is identical to connecting via SSH — but you don't need SSH. You just need a browser.

Use this for: quick commands, checking on agents, starting Nova, running scripts.

### How to Log In

1. Open any browser and go to **https://terminal.[personal-site]**
2. A login box will appear
3. Enter:
   - **Username:** `walt`
   - **Password:** `[REDACTED-PASSWORD]`
4. Press Enter or click Login
5. A black terminal screen appears — you are now inside your VPS

### The Golden Rule

**When you are done — just close the browser tab.**

Do NOT close the tab by typing `exit` or pressing anything special. Just close it. Your Nova session (and any running agents) will keep running on the server. Nothing stops. Nothing is lost.

---

## Part 2 — VS Code in Browser (code.[personal-site])

### What It Is

A full Visual Studio Code editor — the same tool professional developers use — running inside your browser, connected directly to your VPS. You can browse files, edit them, run multiple terminals, and download/upload files, all from a browser tab.

Use this for: working sessions with Nova, running multiple agents in parallel, editing files, downloading files from the VPS to your Mac.

### How to Log In

1. Open any browser and go to **https://code.[personal-site]**
2. A password box will appear
3. Enter: `[REDACTED-PASSWORD]`
4. Press Enter
5. VS Code opens in your browser

### First-Time Setup — Open Your Workspace

The first time you log in, VS Code will show an empty screen. Set up your workspace:

1. Click **File** → **Open Folder**
2. Type: `/home/walt/agents/nova-assistant`
3. Press Enter or click OK
4. The left panel will show all Nova's files

You only need to do this once. VS Code remembers it next time.

### The VS Code Layout

```
┌─────────────────────────────────────────────────────────┐
│  Menu bar (File, Edit, View, etc.)                       │
├──────────┬──────────────────────────────────────────────┤
│          │                                               │
│  File    │   Editor area                                 │
│  Explorer│   (files open here when you click them)       │
│  (left   │                                               │
│  panel)  ├───────────────────────────────────────────────┤
│          │   Terminal panel (bottom)                     │
│          │   (type commands here)                        │
└──────────┴───────────────────────────────────────────────┘
```

### Opening a Terminal in VS Code

Press **Ctrl + `** (that's the backtick key — top-left of your keyboard, above Tab)

A terminal panel opens at the bottom. You are now inside your VPS and can type commands.

---

## Part 3 — Starting Nova (Your AI Session)

This is what you will do every time you want to work with Nova.

### The One Command You Need

In either the Browser Terminal or the VS Code terminal, type:

```
nova
```

Press Enter.

That's it. This command:
- Starts a tmux session (a persistent session manager — explained below)
- Launches Claude Code inside it
- Boots Nova's full memory and system

Nova will greet you and confirm she is online.

### If Nova Is Already Running

If you previously started Nova and just closed the browser tab (correctly), your session is still alive. Type `nova` again and it will reconnect you to exactly where you left off.

### Starting a Fresh Nova Session

If you want to start completely fresh (new context, clean slate):

```
nova-kill
```

Then start again:

```
nova
```

---

## Part 4 — tmux (Session Manager)

### What Is tmux?

tmux is a "session manager" running invisibly in the background. Think of it like this:

- **Without tmux:** closing the browser tab = killing Nova. Everything stops.
- **With tmux:** closing the browser tab = walking away from your desk. Nova keeps working. You come back and pick up exactly where you left off.

tmux also lets you have multiple terminal "windows" inside one browser tab — like tabs within tabs.

### The Most Important tmux Concept

**Detach vs. Kill**

- **Detach** = "I'm stepping away. Keep everything running." → `Ctrl+B, D`
- **Kill** = "Stop everything, end the session." → `nova-kill`

Always use Detach when you are done for a while. Use Kill only when you want a clean restart.

---

### tmux Commands — Complete Reference

All tmux shortcuts start with **Ctrl+B** (press and release), then press the next key.

#### Sessions

| What you want to do | Command |
|---------------------|---------|
| Start or reconnect Nova session | `nova` |
| Detach (close browser safely, keep running) | `Ctrl+B` then `D` |
| See all running sessions | `sessions` |
| Kill the Nova session | `nova-kill` |
| Kill a specific session by name | `tmux kill-session -t nova` |
| List sessions (detailed) | `tmux ls` |

#### Windows (like browser tabs, inside tmux)

| What you want to do | Command |
|---------------------|---------|
| Create a new window | `Ctrl+B` then `C` |
| Switch to next window | `Ctrl+B` then `N` |
| Switch to previous window | `Ctrl+B` then `P` |
| Switch to window by number | `Ctrl+B` then `0–9` |
| Rename current window | `Ctrl+B` then `,` |
| Close current window | Type `exit` in the terminal |

#### Panes (split the screen)

| What you want to do | Command |
|---------------------|---------|
| Split screen left/right | `Ctrl+B` then `|` |
| Split screen top/bottom | `Ctrl+B` then `-` |
| Move to pane on the left | `Ctrl+B` then `←` (left arrow) |
| Move to pane on the right | `Ctrl+B` then `→` (right arrow) |
| Move to pane above | `Ctrl+B` then `↑` (up arrow) |
| Move to pane below | `Ctrl+B` then `↓` (down arrow) |
| Zoom in on current pane (fullscreen) | `Ctrl+B` then `Z` |
| Zoom back out | `Ctrl+B` then `Z` again |
| Close current pane | `Ctrl+B` then `X`, then `Y` to confirm |

#### Scrolling

| What you want to do | Command |
|---------------------|---------|
| Enter scroll mode (read back through history) | `Ctrl+B` then `[` |
| Scroll up | Arrow keys or Page Up |
| Scroll down | Arrow keys or Page Down |
| Exit scroll mode | `Q` |

---

## Part 5 — VS Code Keyboard Shortcuts

These are the shortcuts you will actually use. You do not need to learn the full VS Code — just these.

### Essential Shortcuts

| What you want to do | Shortcut |
|---------------------|----------|
| Open a terminal | `Ctrl + `` ` (backtick) |
| Open a new terminal tab | Click the `+` icon in the terminal panel |
| Split terminal (two side by side) | Click the split icon in the terminal panel |
| Open a file | Click it in the left file explorer |
| Save a file | `Ctrl + S` |
| Close a file | `Ctrl + W` |
| Search within a file | `Ctrl + F` |
| Search across all files | `Ctrl + Shift + F` |
| Open the command palette (find any action) | `Ctrl + Shift + P` |
| Toggle the file explorer panel | `Ctrl + B` |
| Zoom in | `Ctrl + =` |
| Zoom out | `Ctrl + -` |
| Undo | `Ctrl + Z` |
| Redo | `Ctrl + Shift + Z` |

### Working With Files

**To open a file:**
Click on it in the left-side file explorer panel.

**To edit a file:**
Click on it to open it. Click anywhere in the content. Edit. Press `Ctrl+S` to save.

**To download a file to your Mac:**
Right-click the file in the left explorer panel → click **Download**. It saves to your Mac's Downloads folder.

**To upload a file from your Mac to the VPS:**
Drag a file from your Mac's Finder window and drop it into the VS Code file explorer panel. It uploads to that folder on the VPS.

**To create a new file:**
Right-click in the file explorer panel → **New File** → type the filename → press Enter.

### Working With Multiple Terminals

VS Code lets you run multiple terminal sessions at the same time — very useful for watching Nova while running an agent in another window.

1. Open first terminal: `Ctrl + `` `
2. Open second terminal: click the `+` in the terminal toolbar
3. Switch between them: click the terminal name in the list on the right side of the terminal panel
4. Split them side by side: click the split icon (two rectangles) in the terminal toolbar

---

## Part 6 — Common Commands Reference

These are the commands you will type most often in any terminal (Browser Terminal or VS Code terminal).

### Nova and Agent Sessions

| What you want to do | Command |
|---------------------|---------|
| Start / reconnect Nova | `nova` |
| Kill Nova session | `nova-kill` |
| List all tmux sessions | `sessions` |
| List all agent folders | `agents` |

### Navigating the VPS

| What you want to do | Command |
|---------------------|---------|
| Go to Nova's folder | `cd /home/walt/agents/nova-assistant` |
| Go to a specific agent | `cd /home/walt/agents/content-agent` |
| List files in current folder | `ls` |
| List files with details | `ls -la` |
| Show current folder path | `pwd` |
| Go up one folder | `cd ..` |
| Go to home folder | `cd ~` |

### Checking Agent Status

| What you want to do | Command |
|---------------------|---------|
| Check if a service is running | `sudo systemctl status agent-social-poster` |
| See recent logs for a service | `sudo journalctl -u agent-social-poster -n 50` |
| Follow live logs (real-time) | `sudo journalctl -u agent-social-poster -f` |
| Stop following logs | `Ctrl + C` |
| Restart a service | `sudo systemctl restart agent-social-poster` |
| Stop a service | `sudo systemctl stop agent-social-poster` |
| Start a service | `sudo systemctl start agent-social-poster` |

Replace `agent-social-poster` with any service name from the list below.

### Your Running Services (VPS Daemons)

| Service Name | What It Does | Schedule |
|-------------|-------------|----------|
| `agent-content-quality-auditor` | Audits content before publishing | Continuous |
| `agent-social-poster` | Posts approved content to social media | Every 15 min |
| `agent-auditor` | Weekly health check of entire stack | Saturdays 14:00 UTC |
| `mcp-calendar` | Google Calendar MCP connection | Always on |
| `code-server@walt` | VS Code in browser | Always on |
| `ttyd` | Browser terminal | Always on |
| `rclone-gdrive` | Syncs files to/from Google Drive | Always on |
| `sync-agents` | Syncs agent files every 15 min | Every 15 min |

### Viewing and Editing Files

| What you want to do | Command |
|---------------------|---------|
| View a file's contents | `cat filename.md` |
| View a large file one page at a time | `less filename.md` (press `Q` to exit) |
| View last 20 lines of a file | `tail -20 filename.md` |
| Follow a file in real-time (logs) | `tail -f filename.log` |
| Edit a file | `nano filename.md` |
| Save in nano | `Ctrl + O`, then Enter |
| Exit nano | `Ctrl + X` |

### Environment and System

| What you want to do | Command |
|---------------------|---------|
| Check disk space | `df -h` |
| Check memory usage | `free -h` |
| Check CPU and running processes | `htop` (press `Q` to exit) |
| Check VPS uptime | `uptime` |
| Reload environment variables | `source ~/.env` |
| See what's in your .env (safely) | `grep -v '=' ~/.env \| head -20` |

### Git (syncing files with GitHub)

| What you want to do | Command |
|---------------------|---------|
| Go to nova-assistant folder | `cd /home/walt/agents/nova-assistant` |
| Pull latest from GitHub | `git pull` |
| Check what has changed | `git status` |
| See recent commits | `git log --oneline -10` |
| Add a file for committing | `git add filename.md` |
| Add all changed files | `git add -A` |
| Commit with a message | `git commit -m "your message here"` |
| Push to GitHub | `git push origin main` |

---

## Part 7 — Complete Workflow Examples

### Workflow 1: Starting a Nova Work Session

1. Open https://code.[personal-site] in your browser
2. Enter password: `[REDACTED-PASSWORD]`
3. Press Ctrl+` to open a terminal
4. Type `nova` and press Enter
5. Wait for Nova to boot and greet you
6. Work as normal
7. When done — **just close the browser tab**

### Workflow 2: Checking If Your Agents Are Running

1. Open https://terminal.[personal-site]
2. Log in: `walt` / `[REDACTED-PASSWORD]`
3. Type:
```
sudo systemctl status agent-social-poster
sudo systemctl status agent-content-quality-auditor
```
4. You will see `Active: active (running)` if healthy
5. Close the tab when done

### Workflow 3: Running Two Things at Once (Nova + an Agent)

1. Open https://code.[personal-site]
2. Press Ctrl+` to open a terminal
3. Type `nova` — Nova starts in that terminal
4. Click the `+` in the terminal panel — a new terminal opens
5. In the new terminal, navigate to your agent and run it:
```
cd /home/walt/agents/content-agent
python3 src/pipeline.py --idea "your idea here"
```
6. Click between the two terminals in the panel to switch

### Workflow 4: Viewing Nova's Memory or Logs

1. Open https://code.[personal-site]
2. In the left file explorer, navigate to:
   - `nova-memory.md` — Nova's cross-session memory
   - `docs/SPRINT_LOG.md` — session history
   - `lessons.md` — Nova's mistake log
   - `docs/AGENT-REGISTRY.md` — all active agents
3. Click any file to open and read it

### Workflow 5: Downloading a File from the VPS

1. Open https://code.[personal-site]
2. Find the file in the left file explorer
3. Right-click it
4. Click **Download**
5. The file saves to your Mac's Downloads folder

### Workflow 6: Reconnecting to a Session You Left Running

1. Open https://terminal.[personal-site] or https://code.[personal-site]
2. Log in
3. Type `nova`
4. If a session is already running, you will reconnect to it exactly where you left off
5. If no session is running, a fresh one starts

### Workflow 7: Restarting a Stuck Service

If an agent stops working or you see it's not running:

```
sudo systemctl restart agent-social-poster
sudo journalctl -u agent-social-poster -n 30
```

The first command restarts it. The second shows you the last 30 lines of logs so you can see if it came back up correctly.

---

## Part 8 — Troubleshooting

### "The page won't load"

- Check you have internet
- Try refreshing the browser
- Try from a different browser or device
- The services auto-restart — wait 30 seconds and try again

### "I typed exit and the session closed"

- Don't panic. Type `nova` to start a new session
- Your agents are still running in the background — typing `exit` only closes your view

### "Nova seems slow or unresponsive"

- The context window may be getting large after a long session
- Type: `nova-kill` to end it cleanly
- Type: `nova` to start fresh

### "I can't remember which terminal I'm in"

- Look at the terminal panel in VS Code — the active one is highlighted
- In the Browser Terminal, you always have one terminal
- Type `pwd` to see which folder you are currently in

### "A service shows as 'failed'"

```
sudo systemctl status agent-social-poster
sudo journalctl -u agent-social-poster -n 50
sudo systemctl restart agent-social-poster
```

Read the logs (second command) to understand what failed, then restart.

### "I accidentally closed everything — is my work lost?"

No. The VPS keeps running regardless of what happens on your browser or Mac. tmux keeps your session alive. Just log back in and type `nova` to reconnect.

### "code.[personal-site] asks for a password again"

Enter: `[REDACTED-PASSWORD]`

Sessions expire after some time of inactivity. This is normal.

---

## Part 9 — Key File Locations

| File | Path | What It Is |
|------|------|------------|
| Nova's memory | `/home/walt/agents/nova-assistant/nova-memory.md` | Cross-session memory |
| Sprint log | `/home/walt/agents/nova-assistant/docs/SPRINT_LOG.md` | Session history |
| Lessons log | `/home/walt/agents/nova-assistant/lessons.md` | Nova's mistake log |
| Agent registry | `/home/walt/agents/nova-assistant/docs/AGENT-REGISTRY.md` | All active agents |
| Environment variables | `/home/walt/.env` | All API keys and credentials |
| Nova's rules | `/home/walt/agents/nova-assistant/CLAUDE.md` | Nova's operating system |
| VPS-specific rules | `/home/walt/CLAUDE.md` | VPS overrides (e.g. GitHub via curl) |
| Agent folders | `/home/walt/agents/` | All 23 agents |
| Pending builds | `/home/walt/agents/nova-assistant/pending-builds/` | Agent briefs waiting to be built |

---

## Part 10 — System Architecture (Plain English)

Understanding what's running where helps you know what to restart if something breaks.

```
YOUR BROWSER
    │
    ├── terminal.[personal-site]  →  ttyd service on VPS
    │
    └── code.[personal-site]     →  code-server service on VPS
                                         │
                                    ┌────┴─────────────────────┐
                                    │   NOVA VPS ([vps-hostname]) │
                                    │   [VPS-IP]           │
                                    │   Ubuntu 24.04, 16GB RAM │
                                    │                          │
                                    │  Always-on services:     │
                                    │  • content-auditor       │
                                    │  • social-poster         │
                                    │  • mcp-calendar          │
                                    │  • rclone (GDrive sync)  │
                                    │  • caddy (HTTPS)         │
                                    │                          │
                                    │  When you run nova:      │
                                    │  • tmux session          │
                                    │  • Claude Code CLI       │
                                    │  • Nova boots            │
                                    └──────────────────────────┘
                                               │
                                    ┌──────────┴──────────┐
                               Cloudflare           GitHub
                               (DNS + HTTPS)     (code storage)
```

**Cloudflare** sits in front of everything — it provides security and HTTPS. Your subdomains (`terminal.[personal-site]`, `code.[personal-site]`) are DNS records in Cloudflare pointing to the VPS IP.

**Caddy** is a web server running on the VPS that handles routing — terminal goes to ttyd, code goes to code-server, n8n goes to n8n.

---

## Part 11 — Quick Reference Card

Print this or save it somewhere accessible.

```
╔══════════════════════════════════════════════════════════════╗
║              NOVA VPS — QUICK REFERENCE                      ║
╠══════════════════════════════════════════════════════════════╣
║ BROWSER TERMINAL                                             ║
║   URL:      https://terminal.[personal-site]                 ║
║   Username: walt                                             ║
║   Password: [REDACTED-PASSWORD]                          ║
╠══════════════════════════════════════════════════════════════╣
║ VS CODE IN BROWSER                                           ║
║   URL:      https://code.[personal-site]                     ║
║   Password: [REDACTED-PASSWORD]                          ║
╠══════════════════════════════════════════════════════════════╣
║ START NOVA              nova                                 ║
║ KILL NOVA               nova-kill                            ║
║ LIST SESSIONS           sessions                             ║
║ DETACH (keep running)   Ctrl+B then D                        ║
║ OPEN TERMINAL (VSCode)  Ctrl+`                               ║
║ NEW TERMINAL (VSCode)   Click + in terminal panel            ║
║ SAVE FILE (VSCode)      Ctrl+S                               ║
╠══════════════════════════════════════════════════════════════╣
║ CHECK SERVICE           sudo systemctl status [name]         ║
║ RESTART SERVICE         sudo systemctl restart [name]        ║
║ VIEW LOGS               sudo journalctl -u [name] -n 50      ║
╠══════════════════════════════════════════════════════════════╣
║ WHEN DONE: just close the browser tab. Nothing stops.        ║
╚══════════════════════════════════════════════════════════════╝
```

---

*Document maintained by Nova. Updated each session when infrastructure changes.*
