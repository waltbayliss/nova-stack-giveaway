# Nova — Roadmap

**Current Phase:** Phase 1 — Become Nova  
**Date:** 2026-04-13

---

## North Star

Nova is a fully operational master orchestrator with a growing team of specialised agents — each with their own memory, skills, and wiki structure — all working toward Walt's $1M/year + freedom goal.

---

## Phase 1 — Become Nova (Current)

**Goal:** Nova is properly initialised, documented, and ready to receive instructions and begin orchestrating.

**Definition of Done:**
- [x] App Builder Memory system initialised (all 8 docs)
- [x] CLAUDE.md updated with full orchestration operating system
- [x] SOUL.md reflects Nova as master orchestrator
- [x] AGENT-REGISTRY.md created (empty, ready)
- [x] wiki/ folder structure provisioned in nova-assistant repo
- [ ] Nova boots successfully in Claude Code and confirms Wiki load
- [ ] Walt confirms: "Nova is online and behaving correctly"

---

## Phase 2 — First Agents

**Goal:** Identify and build Walt's first 2-3 specialised agents.

Likely candidates (to be confirmed with Walt):
- `agent-ops` — n8n workflow management, automation health
- `agent-content` — newsletter, social, YouTube content
- `agent-aita` — [Prior Venture] client work, proposals, delivery

**Process for each:**
1. Nova interviews Walt on agent functionality
2. Walt approves spec
3. Nova builds full repo + 8 docs + wiki structure
4. Agent added to registry
5. Walt confirms agent is working

---

## Phase 3 — WhatsApp Command Channel

**Goal:** Walt can command Nova from his phone via WhatsApp.

- n8n webhook receives WhatsApp message
- Webhook triggers Nova session with message as input
- Nova processes, proposes action, waits for Walt confirmation
- All same rules apply as Claude Code sessions

---

## Phase 4 — Compound Intelligence

**Goal:** The system learns and compounds continuously.

- Every agent session updates its own wiki/Master/master-context.md
- Nova synthesises agent learnings into nova-memory.md
- Walt's Wiki grows automatically from agent outputs
- New agents benefit from all previous agent learnings

---

## Milestone: Nova v1.0

Nova v1.0 is achieved when:
- 3+ active agents are running and being used regularly
- WhatsApp command channel is live
- Wiki structure is compounding (new entries weekly)
- Walt's daily workflow routes through Nova by default
- Nova has saved Walt measurable time or generated measurable revenue
