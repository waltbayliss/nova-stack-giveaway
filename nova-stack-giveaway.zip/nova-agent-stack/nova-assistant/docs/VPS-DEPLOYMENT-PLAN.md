# VPS Deployment Plan — [vps-hostname]
**Server:** [VPS-IP] | Hetzner CCX23 | Ashburn VA
**Domain:** agents.[personal-site] ✅ live
**Created:** 2026-04-29

---

## Agent Tiers — What Goes Where

### Tier 1 — Already on Cloudflare Workers (nothing to do)
These are already cloud-native. No VPS action needed.

| Agent | URL | Status |
|-------|-----|--------|
| agent-daily-brief | agent-daily-brief.waltbayliss.workers.dev | ✅ Live |
| nova-telegram-worker | nova-telegram.waltbayliss.workers.dev | ✅ Live |

---

### Tier 2 — Claude Code Orchestration Only (no daemon, no deployment)
These agents have no running Python/Node process. They are CLAUDE.md instruction sets that Nova invokes during sessions. They live in GitHub and are "deployed" simply by being cloned to wherever Nova runs.

| Agent | What It Is | Deployment |
|-------|-----------|------------|
| nova-assistant | Nova herself — the orchestrator | Runs in Claude Code session |
| agent-builder | Session-based agent builder | Runs in Claude Code session |
| agent-code-reviewer | Inline code review | Runs in Claude Code session |
| agent-cloudflare | Cloudflare platform expert | Runs in Claude Code session |
| ghl-agent | GHL CRM specialist | Runs in Claude Code session |
| google-workspace-agent | Gmail + Calendar specialist | Runs in Claude Code session |
| youtube-agent | YouTube content specialist | Runs in Claude Code session |
| agent-prd-reviewer | PRD quality gate | Runs via Python CLI when called |
| agent-quick-searcher | Pre-build search engine | Runs via Python CLI when called |
| research-agent | Perplexity + synthesis | Runs via Python CLI when called |
| agent-openrouter-optimizer | Model routing middleware | Python module, imported inline |

**Action for Tier 2:** Clone all repos to VPS under `~/agents/`. Nova sessions running on VPS (or locally) will call them directly.

---

### Tier 3 — VPS Daemons (systemd services replacing Mac LaunchAgents)
These run as persistent processes or scheduled jobs. Mac LaunchAgents → Linux systemd.

| Agent | Trigger | Python Deps | External APIs | Complexity |
|-------|---------|-------------|---------------|------------|
| agent-content-quality-auditor | Every 3 min (poll Notion) | anthropic, requests | Anthropic, OpenRouter, Notion, Telegram, Perplexity, Fal.ai | Medium |
| agent-social-poster | Every 3 min (poll Notion) | notion-client, requests, google-api-python-client, google-auth | Notion, GHL, YouTube, Telegram, GitHub | Medium |
| agent-auditor | Weekly Sunday midnight AEST | requests, python-dotenv | GitHub, Notion, Telegram, Cloudflare | Medium |
| agent-video-editor | Continuous (GDrive watcher) | google-api-python-client, google-auth, requests | Google Drive, SubMagic API, Telegram | Complex |
| content-agent | On-demand + audit rewriter loop | requests, python-dotenv | Anthropic, Perplexity, Notion, GitHub, Fal.ai | Complex |
| agent-image-creator | Called by content-agent | (fal.ai SDK) | Fal.ai (FLUX Kontext), OpenAI (DALL-E 3) | Medium |
| agent-test-runner | Weekly Sunday 2am AEST | pytest, requests, python-dotenv | Telegram, GitHub, Anthropic, Notion | Simple |
| agent-backup | Daily 3am | bash (rsync) | GitHub (replaces GDrive rsync on VPS) | Simple |
| agent-security | On-demand (Nova routing) | requests | Ollama (local), Anthropic, GitHub, Docker | Complex |
| agent-giveaway-creator | On-demand | weasyprint, jinja2, requests, python-docx | GitHub, Notion | Medium |

---

## VPS Base Requirements

Everything that must be installed on [vps-hostname] BEFORE deploying any agent.

### Phase A — Core system packages
```bash
sudo apt update && sudo apt install -y \
  python3 python3-pip python3-venv \
  git curl wget unzip \
  ffmpeg \
  build-essential \
  libcairo2 libpango-1.0-0 libpangocairo-1.0-0 \
  libgdk-pixbuf2.0-0 libffi-dev shared-mime-info \
  libxml2-dev libxslt1-dev libjpeg-dev libopenjp2-7
```
*Note: The libcairo/libpango group is required for WeasyPrint (agent-giveaway-creator PDF generation)*

### Phase B — Node.js (for Claude Code CLI)
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node --version && npm --version
```

### Phase C — Claude Code CLI
```bash
sudo npm install -g @anthropic-ai/claude-code
claude --version
```

### Phase D — Ollama (for agent-security + openrouter-optimizer)
```bash
curl -fsSL https://ollama.ai/install.sh | sh
sudo systemctl enable ollama
sudo systemctl start ollama
# Pull default model
ollama pull llama3.2
```

### Phase E — Environment file
Create `/home/walt/.env` on VPS with all credentials (copy from Mac .env, updating any local paths).

**Local paths that must be updated for VPS:**
| Variable | Mac value | VPS value |
|----------|-----------|-----------|
| MY_AI_TEAM_PATH | `/Users/walt/.../my-ai-team` | `/home/walt/agents` |
| GDRIVE_UPLOAD_PATH | GDrive path | `/home/walt/media/upload` |
| GDRIVE_DONE_PATH | GDrive path | `/home/walt/media/done` |
| VIDEO_EDITOR_LOG_PATH | GDrive path | `/home/walt/logs/video-editor.log` |
| POSES_DIR | `/Users/walt/.../poses` | `/home/walt/agents/agent-image-creator/poses` |
| OUTPUT_DIR | `/Users/walt/.../output` | `/home/walt/agents/agent-image-creator/output` |
| OLLAMA_BASE_URL | `http://localhost:11434` | `http://localhost:11434` (same) |
| DOCKER_SOCKET | `/var/run/docker.sock` | `/var/run/docker.sock` (same) |

### Phase F — Clone all agent repos
```bash
mkdir -p ~/agents
cd ~/agents

# Tier 2 — orchestration agents
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-builder.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-code-reviewer.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-quick-searcher.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-prd-reviewer.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/research-agent.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/nova-assistant.git

# Tier 3 — daemons
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-content-quality-auditor.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-social-poster.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-auditor.git
git clone https://$GITHUB_TOKEN@github.com/waltbayliss/agent-security.git
# content-agent, agent-image-creator, agent-video-editor, agent-giveaway-creator, agent-test-runner, agent-backup — no GitHub repos yet, copy from Mac
```

### Phase G — pip install for each Python agent
```bash
for agent in agent-content-quality-auditor agent-social-poster agent-auditor agent-security agent-giveaway-creator agent-test-runner; do
  cd ~/agents/$agent
  pip3 install -r requirements.txt
done
```

---

## Deployment Order — Phased Rollout

### Phase 2 ✅ — Domain + HTTPS (DONE)
- agents.[personal-site] DNS A record created
- Caddy configured + HTTPS live
- /health endpoint responding 200

### Phase 3 — VPS Base Setup
Install all system requirements (Phases A–E above). No agents running yet. Verify each tool installed correctly.

**Success criteria:**
- `python3 --version` → 3.12+
- `claude --version` → current
- `ffmpeg -version` → installed
- `ollama list` → models available
- `.env` file present at `/home/walt/.env`

### Phase 4 — Deploy Tier 3 Simple Agents First
Start with low-risk, no-GDrive-dependency agents.

**4a. agent-test-runner** (simplest — no persistent state, weekly cron)
- Clone / copy to VPS
- `pip3 install -r requirements.txt`
- Create systemd timer (replaces LaunchAgent)
- Test: `python3 src/test_runner.py` — should run tests + send Telegram report

**4b. agent-quick-searcher + research-agent** (CLI tools, no daemon needed)
- Clone to VPS
- `pip3 install -r requirements.txt`
- Test: `python3 src/cli.py --target "test" --type "repo"`

**4c. agent-backup** (daily cron, but needs to change target — no GDrive on VPS)
- New backup strategy: daily `git push` of ~/agents/ state + compress to `/home/walt/backups/`
- Create systemd timer

### Phase 5 — Deploy Tier 3 Medium Agents

**5a. agent-content-quality-auditor** (polls Notion every 3 min)
- Copy from Mac (no GitHub repo)
- `pip3 install -r requirements.txt`
- Create systemd service (continuous polling)
- Test: run manually, check Notion audit picks up Pending Audit row

**5b. agent-social-poster** (polls Notion every 3 min)
- Clone from GitHub
- `pip3 install -r requirements.txt`
- Create systemd service
- Test: run manually against a test Notion row

**5c. agent-auditor** (weekly cron)
- Clone from GitHub
- Update path env vars (MY_AI_TEAM_PATH → /home/walt/agents)
- Create systemd timer (Sunday midnight AEST = Sunday 14:00 UTC)
- Test: run manually

### Phase 6 — Deploy Tier 3 Complex Agents

**6a. agent-image-creator** (called by content-agent)
- Copy from Mac
- Set POSES_DIR + OUTPUT_DIR to VPS paths
- Upload poses/ folder to VPS
- Test: `python3 src/image_creator.py --prompt "test" --no-notion`

**6b. content-agent** (pipeline + audit rewriter)
- Copy from Mac (no GitHub repo)
- `pip3 install -r requirements.txt`
- Update GDrive paths → local VPS paths
- Create systemd service for audit_rewriter.py
- Test: run pipeline.py against a test transcript

**6c. agent-video-editor** (GDrive watcher → VPS poller)
- Copy from Mac
- Convert GDrive watcher → Google Drive API polling (already uses Google Drive API)
- `pip3 install -r requirements.txt`
- Create systemd service
- Test: upload a test video to Drive upload folder, verify processing

**6d. agent-security** (Docker + Ollama)
- Clone from GitHub
- Verify Docker socket accessible
- Pull Semgrep Docker image
- Install gitleaks
- Test: `python3 src/cli.py --target "test-repo" --type "repo" --source "https://github.com/..."`

**6e. agent-giveaway-creator** (on-demand, WeasyPrint)
- Copy from Mac
- `pip3 install -r requirements.txt` (WeasyPrint needs system libs — installed in Phase A)
- Test: run against existing nova-data.json

### Phase 7 — Caddy Routing Update
Add each deployed agent as a Caddy route so they're accessible via HTTPS:

```
agents.[personal-site] {
    handle /health { respond "Nova VPS online" 200 }
    handle /audit*  { reverse_proxy localhost:8001 }
    handle /poster* { reverse_proxy localhost:8002 }
    handle /search* { reverse_proxy localhost:8003 }
    ...
}
```

### Phase 8 — Decommission Mac
Only after ALL agents verified working on VPS:
- Stop all Mac LaunchAgents
- Mac returns to being a thin client
- Nova sessions run from anywhere via claude.ai/code or local terminal

---

## systemd Service Template
For every Python daemon agent, use this template:

```ini
# /etc/systemd/system/agent-NAME.service
[Unit]
Description=Nova agent-NAME
After=network.target

[Service]
Type=simple
User=walt
WorkingDirectory=/home/walt/agents/agent-NAME
EnvironmentFile=/home/walt/.env
ExecStart=/usr/bin/python3 src/MAIN_FILE.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable agent-NAME
sudo systemctl start agent-NAME
sudo systemctl status agent-NAME
```

---

## Known Issues / Watch Points

1. **GDrive paths** — content-agent and agent-image-creator write images to a local GDrive folder. On VPS, images will write to a local path. Google Drive sync is handled via Google Drive API (agent-video-editor already does this). content-agent needs updating to upload images to GDrive via API rather than local folder copy.

2. **Ollama on VPS** — CCX23 has 4 vCPU / 16GB RAM. llama3.2 (3B) runs fine. Larger models may be slow. agent-security uses Ollama as Tier 1 of its three-tier scan — if slow, can skip Ollama tier and go straight to Semgrep + Anthropic.

3. **agent-backup** — Current Mac version rsyncs to Google Drive. On VPS, no local GDrive mount. Replace with: daily git commit + push of ~/agents state, OR copy to R2 bucket via rclone.

4. **content-agent has no GitHub repo** — Must be copied from Mac first. Create GitHub repo as part of Phase 6b.

5. **agent-giveaway-creator has no GitHub repo** — Same as above.

6. **YouTube OAuth token** — agent-social-poster uses YOUTUBE_REFRESH_TOKEN. Token is tied to the OAuth client. Should transfer fine as long as the same CLIENT_ID/SECRET/REFRESH_TOKEN are in the VPS .env.

7. **LaunchAgent → systemd cron conversion**:
   - `com.walt.social-poster` (every 3 min) → systemd timer: `OnCalendar=*:0/3`
   - `com.walt.content-audit-poller` (every 3 min) → same
   - `com.walt.agent-auditor` (Sunday 14:00 UTC) → `OnCalendar=Sun 14:00:00`
   - `com.walt.agent-backup` (daily 3am AEST = daily 17:00 UTC) → `OnCalendar=daily 17:00:00`
   - `com.walt.agent-test-runner` (Sunday 2am AEST = Saturday 16:00 UTC) → `OnCalendar=Sat 16:00:00`
