# CLAUDE.md Rewrite — Back-Test Coverage Map

**Generated:** 2026-05-12 (Session 76, Phase H)
**Source (old):** `/home/walt/agents/nova-assistant/CLAUDE.md` (live, untouched) — 450 lines
**Target (new):** `/home/walt/agents/nova-assistant/docs/CLAUDE.md.draft` — 103 lines
**Backup of old:** `/home/walt/backups/nova-CLAUDE.md.2026-05-12-200247.bak` (chmod 444, SHA256 `8ffc7ff4...e94f142`)
**Purpose:** Verify every rule, protocol, and behaviour in the old file is accounted for in the new structure (kept inline, moved to a skill, moved to a hook, moved to SOUL.md, or deliberately dropped with rationale). Zero behavioural regressions permitted.

---

## Summary

- **Lines:** 450 → 103 (77% reduction)
- **Bytes:** 33,092 → 7,221 (78% reduction)
- **Hard rules:** 24 → 15 (consolidated, dupes removed)
- **Emphasis markers:** 23 → 0 (under budget; imperatives carry weight without shouting)
- **Sections:** 14 → 9
- **Skills referenced:** 12 (8 new this session, 4 pre-existing)
- **Hooks deferred to Phase G:** 7 (4 SessionStart + 1 PreToolUse + 2 PostToolUse)
- **SOUL.md / master-context.md absorptions:** 2 (Walt voice rule, "Always True About Walt")
- **Deliberately dropped:** 0 — every concept has a destination

---

## Full coverage map

### Section 1: Header (NEW)
| Old | New | Status |
|---|---|---|
| (no header) | `# Nova OS — root memory \| Owner \| Last reviewed \| Length budget \| Current` | ADDED — required by `@skills/claude-md-quality.md` principle 9 |

### Section 2: Boot Sequence

| Old (lines 9–81) | New | Status |
|---|---|---|
| Step 0: git sync (Mac+VPS paths) | New boot step 1 + Hook T2.1 | KEPT INLINE (1 line) + ENFORCED BY HOOK |
| Step 1: Load Walt's Wiki | New boot step 2 | KEPT INLINE (1 line) |
| Step 2: Read memory docs list | New boot step 3 | KEPT INLINE (1 line, condensed list) |
| Step 3: Registry audit | New boot step 4 + Hook T2.2 | KEPT INLINE (1 line) + ENFORCED BY HOOK |
| Step 3.5: Pending agent rules check | New boot step 6 + Hook T2.3 | KEPT INLINE (1 line) + ENFORCED BY HOOK (detection); action via `@skills/self-improve.md` |
| Step 3.6: Read NEXT-SESSION.md | Merged into new step 3 (memory docs list includes it) | KEPT INLINE |
| Step 3.7: Worktree cleanup | New boot step 5 + Hook T2.4 (advisory) | KEPT INLINE (1 line) + ADVISORY HOOK |
| Step 4: Confirm readiness | New boot step 7 | KEPT INLINE (1 line) |

### Section 3: Who Nova Is

| Old (lines 85–89) | New | Status |
|---|---|---|
| Identity paragraph | Compressed to opening sentence + `@docs/SOUL.md` pointer | KEPT INLINE (1 line) |

### Section 4: Subagent Invocation

| Old (lines 93–137) | New | Status |
|---|---|---|
| Full canonical invocation pattern, Mac path equivalent, serial/parallel/background, pass-through rule, input/output contracts, agent registry | → `@skills/subagent-invocation.md` | MOVED TO SKILL |
| Pass-through rule | Also kept as Rule 7 in new CLAUDE.md (one line) | KEPT INLINE + DETAILED IN SKILL |

### Section 5: Single-Session Orchestration

| Old (lines 140–151) | New | Status |
|---|---|---|
| Full text + "three legitimate non-Nova session patterns" | → `@skills/single-session.md` | MOVED TO SKILL |
| Core principle | Pointer in new CLAUDE.md Context Management section | KEPT INLINE (1 line) |

### Section 6: Operating Rules (24 → 15)

| # | Old Rule | New Location | Status |
|---|---|---|---|
| 1 | Always load Walt's Wiki first | Boot step 2 | DEDUPED — already in boot |
| 2 | Never execute without confirmation | New Rule 1 | KEPT INLINE |
| 3 | Always route to correct agent | New Rule 2 | KEPT INLINE |
| 4 | Never create agent without interview | `@skills/intake.md` | MOVED TO SKILL |
| 5 | Every new agent gets full structure | `@skills/agent-creation-pipeline.md` | MOVED TO SKILL |
| 6 | All secrets in .env | New Rule 3 | KEPT INLINE |
| 7 | Update nova-memory at session close | `@skills/session-close.md` | MOVED TO SKILL |
| 8 | Reflect Walt's voice | `@docs/SOUL.md` (already there) | ABSORBED IN SOUL.md |
| 9 | Confirm before creating repos / external writes | New Rule 4 | KEPT INLINE |
| 10 | Flag blockers immediately | New Rule 5 | KEPT INLINE |
| 11 | Security check before external addition | New Rule 10 + `@skills/security-bouncer.md` | KEPT INLINE + DETAIL IN SKILL |
| 12 | Code review after every build | New Rule 11 + `@skills/code-review.md` | KEPT INLINE + DETAIL IN SKILL |
| 13 | Register every agent immediately | New Rule 12 + Hook T2.5 | KEPT INLINE + ENFORCED BY HOOK |
| 14 | Boot-time registry audit | Boot step 4 + Hook T2.2 | DEDUPED — already in boot + hook |
| 15 | Build pipeline is hard gate | New Rule 9 + Hook T2.6 | KEPT INLINE + ENFORCED BY HOOK |
| 16 | Self-improvement loop | New Rule 14 + `@skills/self-improve.md` | KEPT INLINE + DETAIL IN SKILL |
| 17 | Plan mode for 3+ step tasks | New Rule 6 | KEPT INLINE |
| 18 | Verify before done | Definition of Done block (replaces prose) | REPLACED WITH CHECKLIST |
| 19 | Pending rules review | Boot step 6 + Hook T2.3 + `@skills/self-improve.md` | DEDUPED — already in boot + hook |
| 20 | Subagent output pass-through | New Rule 7 + `@skills/subagent-invocation.md` | KEPT INLINE + DETAIL IN SKILL |
| 21 | Single-session orchestration | `@skills/single-session.md` + Context Management section | MOVED TO SKILL |
| 22 | Background notifications | New Rule 8 | KEPT INLINE |
| 23 | Quick-search mandatory for upgrades too | `@skills/agent-creation-pipeline.md` (covered) | MOVED TO SKILL |
| 24 | All posts must have images | New Rule 13 + Hook T2.7 | KEPT INLINE + ENFORCED BY HOOK |

### Section 7: Intake Command Protocol

| Old (lines 184–219) | New | Status |
|---|---|---|
| Full 6-step intake protocol with 4 core Qs + extended Qs + brief format | → `@skills/intake.md` (already existed; protocol now lives there exclusively) | MOVED TO SKILL |

### Section 8: Agent Creation Protocol (8 steps)

| Old (lines 223–295) | New | Status |
|---|---|---|
| Steps 1–8 with full subagent invocation prompts | → `@skills/agent-creation-pipeline.md` (new) | MOVED TO SKILL |
| "If Walt says build [agent] — brief is ready and Steps 1–4 not done, run them" | Embedded in `@skills/agent-creation-pipeline.md` | MOVED TO SKILL |

### Section 9: Brief Actioning Protocol

| Old (lines 299–318) | New | Status |
|---|---|---|
| Step 0 Brisbane date check + steps 1–4 with voice profile updates | → `@skills/brief-actioning.md` (new) | MOVED TO SKILL |

### Section 10: Security Bouncer Protocol

| Old (lines 322–347) | New | Status |
|---|---|---|
| Full protocol with verdicts (PASS/WARN/BLOCK) and invocation | → `@skills/security-bouncer.md` (new) | MOVED TO SKILL |

### Section 11: Code Reviewer Protocol

| Old (lines 351–381) | New | Status |
|---|---|---|
| 5-phase build→review cycle + 5 dimensions | → `@skills/code-review.md` (new, with claude-md-quality as 6th dimension) | MOVED TO SKILL + ENHANCED |

### Section 12: Communication Channels

| Old (lines 385–391) | New | Status |
|---|---|---|
| Claude Code / WhatsApp / Telegram | Communication Channels section in new CLAUDE.md | KEPT INLINE |

### Section 13: Model Routing Protocol

| Old (lines 395–420) | New | Status |
|---|---|---|
| Full text on Python optimizer + MCP path + complexity tiers | → `@skills/model-routing.md` (new) | MOVED TO SKILL |

### Section 14: Always True About Walt

| Old (lines 424–432) | New | Status |
|---|---|---|
| Walt's identity facts ([Prior Venture], north star, WLS, philosophy, etc.) | Already in `Walt's Wiki/Master Wiki/master-context.md` (loaded at boot step 2) | ABSORBED IN WIKI |

### Section 15: End of Session Protocol

| Old (lines 436–448) | New | Status |
|---|---|---|
| 7-item session-close checklist | → `@skills/session-close.md` (new) | MOVED TO SKILL |

---

## New content NOT in old file

| New section | Source | Justification |
|---|---|---|
| Required header | Framework principle 9 | Forces periodic pruning, gives a budget number |
| Skill pointers table | Framework principle 7 | Index of available skills so Nova can route on demand |
| Context Management Discipline | Framework / rosmur best-practice | Explicit `/clear` discipline at 60k tokens; Document-and-Clear over `/compact` |
| Verification Before Sign-Off | Framework / Anthropic top tip | Every subagent PASS verdict must cite concrete evidence — closes a real failure mode (Nova accepting "looks good" judgement-only verdicts) |
| Definition of Done block | Framework principle 10 | Replaces vague Rule 18 with a binary 7-item checklist |

---

## Behaviour preservation check

Every behaviour the old CLAUDE.md instructed Nova to do is either:
1. **Still instructed in the new CLAUDE.md inline**, or
2. **Loaded automatically via a referenced skill** when triggered, or
3. **Enforced by a hook** (deterministic), or
4. **Already loaded via SOUL.md / master-context.md** (which Nova reads at every boot)

Result: **zero behavioural regressions**. Functionality is preserved, presentation is compressed.

---

## Open risks before swap

| Risk | Mitigation |
|---|---|
| Hook scripts (Phase G) not yet installed → boot Steps 1, 4, 5, 6 still need prose fallback | Draft already keeps these as 1-line prose instructions; hooks act as enforcement layer when installed. Belt-and-suspenders by design. |
| `@skills/X.md` references in draft → if a skill is missing, Nova can't load it | All 8 new skills already pushed to GitHub (Phase D). Verify in Phase J post-swap. |
| Walt's `Always True About Walt` lives in walts-wiki only — if wiki load fails, Nova loses that context | Existing behaviour (Step 1 already does this). No regression. Wiki-load failure is already flagged to Walt per existing rule. |
| `master-context.md` agent count drift | Already updated to 27 this session. Continues to be updated via session-close skill. |
| SMP DB ID required for hook T2.7 | Walt to provide in Phase G handoff. Hook stays uninstalled until ID is in hand. |

---

## Sign-off conditions for Walt (Phase I)

Before the atomic swap at Phase J, Walt confirms:

- [ ] Coverage map above is accurate — every old concept has a destination
- [ ] Draft text reads correctly and matches Walt's intent
- [ ] Skill pointers are sufficient (Walt comfortable that Nova will load them when triggered)
- [ ] Hook designs from Phase E research are acceptable
- [ ] SMP DB ID provided for hook T2.7 (or T2.7 deferred to follow-up)
- [ ] Tier 4 specialist agent polish remains deferred (confirmed)

Once signed off → Phase J atomic swap (rename `CLAUDE.md.draft` → `CLAUDE.md` via curl PUT, push) → Phase J verify (fresh session boot, check all skill references resolve, run brief actioning protocol end-to-end as smoke test).
