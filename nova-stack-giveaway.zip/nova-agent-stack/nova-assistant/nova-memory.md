# nova-memory.md

*(Real entries removed for public distribution. This file exists in the real structure as the cross-session memory of patterns, preferences, and session summaries — the shape is real, the history in it is not.)*
