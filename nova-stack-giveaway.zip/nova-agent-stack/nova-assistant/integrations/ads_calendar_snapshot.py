#!/usr/bin/env python3
"""
Snapshot of Meta Ads, Google Ads, and Calendar for daily brief or on-demand.

Usage:
  python3 ads_calendar_snapshot.py           # prints plain text summary
  python3 ads_calendar_snapshot.py --json    # prints JSON for pipeline use

Called by Nova from Telegram or wired into the daily brief cron.
Gracefully skips any integration whose env vars aren't set yet.
"""
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

def try_meta():
    if not os.environ.get("META_ACCESS_TOKEN"):
        return "Meta Ads: not configured (add META_ACCESS_TOKEN + META_AD_ACCOUNT_ID to .env)"
    from integrations.meta_ads import format_spend_summary
    return format_spend_summary("last_7d")

def try_google_ads():
    if not os.environ.get("GOOGLE_ADS_DEVELOPER_TOKEN"):
        return "Google Ads: not configured (add GOOGLE_ADS_DEVELOPER_TOKEN + GOOGLE_ADS_CUSTOMER_ID + GOOGLE_ADS_REFRESH_TOKEN to .env)"
    from integrations.google_ads import format_spend_summary
    return format_spend_summary(7)

def try_calendar():
    if not os.environ.get("GOOGLE_CALENDAR_REFRESH_TOKEN"):
        return "Calendar: not configured (run integrations/setup/google_calendar_auth.py)"
    from integrations.google_calendar import get_upcoming_events, format_events_for_brief
    events = get_upcoming_events(days=7)
    return "Calendar (next 7 days):\n" + "\n".join(
        f"  {format_events_for_brief([e])}" for e in events
    ) if events else "Calendar: no upcoming events"

def main():
    as_json = "--json" in sys.argv
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    sections = {}
    for name, fn in [("meta_ads", try_meta), ("google_ads", try_google_ads), ("calendar", try_calendar)]:
        try:
            sections[name] = fn()
        except Exception as e:
            sections[name] = f"{name}: error — {e}"

    if as_json:
        print(json.dumps({"timestamp": ts, **sections}))
    else:
        print(f"=== Ads & Calendar Snapshot — {ts} ===\n")
        for v in sections.values():
            print(v)
            print()

if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv("/home/walt/.env")
    main()
