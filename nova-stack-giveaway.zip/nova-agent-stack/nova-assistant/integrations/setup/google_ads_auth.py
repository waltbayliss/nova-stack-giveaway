#!/usr/bin/env python3
"""
One-time setup: generate GOOGLE_ADS_REFRESH_TOKEN.

Run this once from the VPS:
  python3 /home/walt/agents/integrations/setup/google_ads_auth.py

Then copy the printed refresh token into /home/walt/.env as:
  GOOGLE_ADS_REFRESH_TOKEN=<token>
"""
import json, os, sys, urllib.request, urllib.parse

SCOPES = "https://www.googleapis.com/auth/adwords"

def main():
    client_id     = os.environ.get("GOOGLE_CLIENT_ID", "")
    client_secret = os.environ.get("GOOGLE_CLIENT_SECRET", "")
    if not client_id or not client_secret:
        sys.exit("Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env first.")

    params = urllib.parse.urlencode({
        "client_id":     client_id,
        "redirect_uri":  "urn:ietf:wg:oauth:2.0:oob",
        "response_type": "code",
        "scope":         SCOPES,
        "access_type":   "offline",
        "prompt":        "consent",
    })
    print("\n1. Visit this URL in your browser and grant access:")
    print(f"\nhttps://accounts.google.com/o/oauth2/auth?{params}\n")
    code = input("2. Paste the authorisation code here: ").strip()

    data = urllib.parse.urlencode({
        "code":          code,
        "client_id":     client_id,
        "client_secret": client_secret,
        "redirect_uri":  "urn:ietf:wg:oauth:2.0:oob",
        "grant_type":    "authorization_code",
    }).encode()
    req = urllib.request.Request(
        "https://oauth2.googleapis.com/token",
        data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    with urllib.request.urlopen(req) as r:
        tokens = json.loads(r.read())

    refresh = tokens.get("refresh_token")
    if not refresh:
        print("No refresh token. Response:", json.dumps(tokens, indent=2))
        sys.exit(1)

    print(f"\n3. Add these lines to /home/walt/.env:\n")
    print(f"GOOGLE_ADS_REFRESH_TOKEN={refresh}")
    print(f"GOOGLE_ADS_DEVELOPER_TOKEN=<paste from ads.google.com → Tools → API Center>")
    print(f"GOOGLE_ADS_CUSTOMER_ID=<10-digit account ID, no dashes>\n")

if __name__ == "__main__":
    main()
