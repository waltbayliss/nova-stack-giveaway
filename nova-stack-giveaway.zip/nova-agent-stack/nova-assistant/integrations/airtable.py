"""
Airtable integration — read/write records via REST API.

Required env vars:
  AIRTABLE_API_KEY   — Personal access token from airtable.com/create/tokens
                       Scopes needed: data.records:read, data.records:write
  AIRTABLE_BASE_ID   — The base ID (starts with "app..."), from the base URL
                       or airtable.com/api

Usage:
  from integrations.airtable import list_records, create_record, update_record
"""
import json
import os
import urllib.request
import urllib.error
from typing import Any

BASE_URL = "https://api.airtable.com/v0"


def _headers():
    key = os.environ.get("AIRTABLE_API_KEY", "")
    if not key:
        raise RuntimeError("AIRTABLE_API_KEY not set in .env")
    return {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "User-Agent": "nova-integrations/1.0",
    }


def _base_id():
    b = os.environ.get("AIRTABLE_BASE_ID", "")
    if not b:
        raise RuntimeError("AIRTABLE_BASE_ID not set in .env")
    return b


def list_records(table: str, filter_formula: str = "", max_records: int = 100) -> list[dict]:
    """Return all records from a table. table can be table name or ID."""
    base = _base_id()
    params = [f"maxRecords={max_records}", "pageSize=100"]
    if filter_formula:
        import urllib.parse
        params.append(f"filterByFormula={urllib.parse.quote(filter_formula)}")

    results, offset = [], None
    while True:
        query = "&".join(params + ([f"offset={offset}"] if offset else []))
        url = f"{BASE_URL}/{base}/{urllib.parse.quote(table)}?{query}"
        req = urllib.request.Request(url, headers=_headers())
        with urllib.request.urlopen(req, timeout=15) as r:
            data = json.loads(r.read())
        results.extend(data.get("records", []))
        offset = data.get("offset")
        if not offset or len(results) >= max_records:
            break

    return results[:max_records]


def get_record(table: str, record_id: str) -> dict:
    import urllib.parse
    base = _base_id()
    url = f"{BASE_URL}/{base}/{urllib.parse.quote(table)}/{record_id}"
    req = urllib.request.Request(url, headers=_headers())
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def create_record(table: str, fields: dict[str, Any]) -> dict:
    import urllib.parse
    base = _base_id()
    url = f"{BASE_URL}/{base}/{urllib.parse.quote(table)}"
    body = json.dumps({"fields": fields}).encode()
    req = urllib.request.Request(url, data=body, headers=_headers(), method="POST")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def update_record(table: str, record_id: str, fields: dict[str, Any]) -> dict:
    """PATCH — only updates specified fields."""
    import urllib.parse
    base = _base_id()
    url = f"{BASE_URL}/{base}/{urllib.parse.quote(table)}/{record_id}"
    body = json.dumps({"fields": fields}).encode()
    req = urllib.request.Request(url, data=body, headers=_headers(), method="PATCH")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def delete_record(table: str, record_id: str) -> bool:
    import urllib.parse
    base = _base_id()
    url = f"{BASE_URL}/{base}/{urllib.parse.quote(table)}/{record_id}"
    req = urllib.request.Request(url, headers=_headers(), method="DELETE")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read()).get("deleted", False)
