"""
Google Ads integration — campaign and keyword performance via REST API.

Required env vars:
  GOOGLE_ADS_DEVELOPER_TOKEN  — From Google Ads API Center
                                (Google Ads account → Tools → API Center)
                                Basic access is enough for your own account.
  GOOGLE_ADS_CUSTOMER_ID      — Your Google Ads account ID, digits only (no dashes)
                                e.g. "1234567890" (shown as 123-456-7890 in UI)
  GOOGLE_ADS_REFRESH_TOKEN    — OAuth token with Google Ads scope.
                                Run setup script to generate:
                                  python3 /home/walt/agents/integrations/setup/google_ads_auth.py
  GOOGLE_CLIENT_ID            — Same as used for Gmail/Calendar
  GOOGLE_CLIENT_SECRET        — Same

Setup steps:
  1. Apply for API access at ads.google.com/nav/selectaccount → Tools → API Center
  2. Create OAuth credentials in Google Cloud Console (same project)
  3. Run the auth setup script to generate GOOGLE_ADS_REFRESH_TOKEN
  4. Add GOOGLE_ADS_DEVELOPER_TOKEN and GOOGLE_ADS_CUSTOMER_ID to .env

Usage:
  from integrations.google_ads import get_campaign_performance, format_spend_summary
"""
import json
import os
import urllib.request
import urllib.parse

REST_URL = "https://googleads.googleapis.com/v17"


def _access_token() -> str:
    data = json.dumps({
        "client_id":     os.environ["GOOGLE_CLIENT_ID"],
        "client_secret": os.environ["GOOGLE_CLIENT_SECRET"],
        "refresh_token": os.environ["GOOGLE_ADS_REFRESH_TOKEN"],
        "grant_type":    "refresh_token",
    }).encode()
    req = urllib.request.Request(
        "https://oauth2.googleapis.com/token",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())["access_token"]


def _headers() -> dict:
    return {
        "Authorization":               f"Bearer {_access_token()}",
        "developer-token":             os.environ["GOOGLE_ADS_DEVELOPER_TOKEN"],
        "Content-Type":                "application/json",
        "User-Agent":                  "nova-integrations/1.0",
    }


def _customer_id() -> str:
    cid = os.environ.get("GOOGLE_ADS_CUSTOMER_ID", "").replace("-", "")
    if not cid:
        raise RuntimeError("GOOGLE_ADS_CUSTOMER_ID not set in .env")
    return cid


def _query(gaql: str) -> list[dict]:
    """Execute a Google Ads Query Language query."""
    cid  = _customer_id()
    body = json.dumps({"query": gaql}).encode()
    req  = urllib.request.Request(
        f"{REST_URL}/customers/{cid}/googleAds:search",
        data=body,
        headers=_headers(),
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read()).get("results", [])


def get_campaign_performance(days: int = 7) -> list[dict]:
    """Return campaign stats for the past N days."""
    gaql = f"""
        SELECT
          campaign.name,
          campaign.status,
          metrics.cost_micros,
          metrics.impressions,
          metrics.clicks,
          metrics.conversions,
          metrics.ctr,
          metrics.average_cpc
        FROM campaign
        WHERE segments.date DURING LAST_{days}_DAYS
          AND campaign.status = 'ENABLED'
        ORDER BY metrics.cost_micros DESC
        LIMIT 20
    """
    results = []
    for row in _query(gaql):
        c = row.get("campaign", {})
        m = row.get("metrics", {})
        results.append({
            "name":         c.get("name", "?"),
            "spend":        round(int(m.get("costMicros", 0)) / 1_000_000, 2),
            "impressions":  int(m.get("impressions", 0)),
            "clicks":       int(m.get("clicks", 0)),
            "conversions":  float(m.get("conversions", 0)),
            "ctr":          round(float(m.get("ctr", 0)) * 100, 2),
            "avg_cpc":      round(int(m.get("averageCpc", 0)) / 1_000_000, 2),
        })
    return results


def get_keyword_performance(days: int = 7, limit: int = 10) -> list[dict]:
    """Return top keywords by spend."""
    gaql = f"""
        SELECT
          ad_group_criterion.keyword.text,
          ad_group_criterion.keyword.match_type,
          metrics.cost_micros,
          metrics.impressions,
          metrics.clicks,
          metrics.conversions
        FROM keyword_view
        WHERE segments.date DURING LAST_{days}_DAYS
          AND ad_group_criterion.status != 'REMOVED'
        ORDER BY metrics.cost_micros DESC
        LIMIT {limit}
    """
    results = []
    for row in _query(gaql):
        kw = row.get("adGroupCriterion", {}).get("keyword", {})
        m  = row.get("metrics", {})
        results.append({
            "keyword":     kw.get("text", "?"),
            "match_type":  kw.get("matchType", "?"),
            "spend":       round(int(m.get("costMicros", 0)) / 1_000_000, 2),
            "clicks":      int(m.get("clicks", 0)),
            "conversions": float(m.get("conversions", 0)),
        })
    return results


def format_spend_summary(days: int = 7) -> str:
    """Format a compact spend summary for the daily brief."""
    try:
        campaigns = get_campaign_performance(days)
        total_spend = sum(c["spend"] for c in campaigns)
        total_clicks = sum(c["clicks"] for c in campaigns)
        total_conv = sum(c["conversions"] for c in campaigns)
        lines = [f"Google Ads (last {days}d):"]
        lines.append(f"  Total: ${total_spend:.2f} spend  |  {total_clicks:,} clicks  |  {total_conv:.0f} conversions")
        for c in campaigns[:3]:
            lines.append(
                f"  • {c['name'][:40]}  ${c['spend']:.2f}  "
                f"CTR {c['ctr']}%  {c['conversions']:.0f} conv"
            )
        return "\n".join(lines)
    except Exception as e:
        return f"Google Ads: unavailable ({e})"
