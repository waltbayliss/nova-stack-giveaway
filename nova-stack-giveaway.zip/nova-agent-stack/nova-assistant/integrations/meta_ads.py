"""
Meta Ads integration — campaign performance, spend, and top ad insights.

Required env vars:
  META_ACCESS_TOKEN   — Long-lived user or system user token from
                        developers.facebook.com/tools/explorer
                        Permissions needed: ads_read, read_insights
  META_AD_ACCOUNT_ID  — Your ad account ID, format: "act_XXXXXXXXXX"
                        Found at business.facebook.com/adsmanager

To generate a long-lived token (90 days):
  1. Create an app at developers.facebook.com (type: Business)
  2. In Graph API Explorer, add ads_read + read_insights permissions
  3. Generate short-lived token → exchange for long-lived:
     curl "https://graph.facebook.com/oauth/access_token?
       grant_type=fb_exchange_token&
       client_id=APP_ID&
       client_secret=APP_SECRET&
       fb_exchange_token=SHORT_TOKEN"
  4. Add to .env as META_ACCESS_TOKEN

Usage:
  from integrations.meta_ads import get_campaign_insights, get_account_spend
"""
import json
import os
import urllib.request
import urllib.parse

GRAPH_URL = "https://graph.facebook.com/v20.0"


def _token() -> str:
    t = os.environ.get("META_ACCESS_TOKEN", "")
    if not t:
        raise RuntimeError("META_ACCESS_TOKEN not set in .env")
    return t


def _account() -> str:
    a = os.environ.get("META_AD_ACCOUNT_ID", "")
    if not a:
        raise RuntimeError("META_AD_ACCOUNT_ID not set in .env")
    return a


def _get(path: str, params: dict) -> dict:
    params["access_token"] = _token()
    qs = urllib.parse.urlencode(params)
    req = urllib.request.Request(
        f"{GRAPH_URL}/{path}?{qs}",
        headers={"User-Agent": "nova-integrations/1.0"},
    )
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read())


def get_account_spend(date_preset: str = "last_7d") -> dict:
    """Return total spend and impressions for the account this period."""
    data = _get(f"{_account()}/insights", {
        "fields":      "spend,impressions,clicks,reach",
        "date_preset": date_preset,
        "level":       "account",
    })
    items = data.get("data", [])
    return items[0] if items else {}


def get_campaign_insights(date_preset: str = "last_7d", limit: int = 20) -> list[dict]:
    """Return per-campaign performance sorted by spend descending."""
    data = _get(f"{_account()}/insights", {
        "fields":      "campaign_name,spend,impressions,clicks,reach,cpc,ctr,actions",
        "date_preset": date_preset,
        "level":       "campaign",
        "limit":       limit,
        "sort":        "spend_descending",
    })
    return data.get("data", [])


def get_top_ads(date_preset: str = "last_7d", metric: str = "spend", limit: int = 5) -> list[dict]:
    """Return top performing ads by spend (or clicks/impressions)."""
    data = _get(f"{_account()}/insights", {
        "fields":      f"ad_name,campaign_name,{metric},clicks,impressions,ctr,spend",
        "date_preset": date_preset,
        "level":       "ad",
        "limit":       limit,
        "sort":        f"{metric}_descending",
    })
    return data.get("data", [])


def get_active_campaigns() -> list[dict]:
    """Return currently active campaigns with budget info."""
    data = _get(f"{_account()}/campaigns", {
        "fields":          "name,status,daily_budget,lifetime_budget,objective",
        "effective_status": '["ACTIVE"]',
        "limit":           50,
    })
    return data.get("data", [])


def format_spend_summary(date_preset: str = "last_7d") -> str:
    """Format a compact spend summary for the daily brief."""
    try:
        spend = get_account_spend(date_preset)
        campaigns = get_campaign_insights(date_preset, limit=5)
        lines = [f"Meta Ads ({date_preset.replace('_',' ')}):"]
        if spend:
            lines.append(
                f"  Total: ${float(spend.get('spend',0)):.2f} spend  |  "
                f"{int(spend.get('impressions',0)):,} impressions  |  "
                f"{int(spend.get('clicks',0)):,} clicks"
            )
        for c in campaigns[:3]:
            lines.append(
                f"  • {c.get('campaign_name','?')[:40]}  "
                f"${float(c.get('spend',0)):.2f}  CTR {c.get('ctr','0')}%"
            )
        return "\n".join(lines)
    except Exception as e:
        return f"Meta Ads: unavailable ({e})"
