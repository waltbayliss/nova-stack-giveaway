"""
Google Calendar integration — read upcoming events, create events.

Required env vars:
  GOOGLE_CLIENT_ID              — from Google Cloud Console (same project as Gmail)
  GOOGLE_CLIENT_SECRET          — same
  GOOGLE_CALENDAR_REFRESH_TOKEN — separate token with calendar scope (see setup/)

To generate GOOGLE_CALENDAR_REFRESH_TOKEN, run once:
  python3 /home/walt/agents/integrations/setup/google_calendar_auth.py

Then paste the token into /home/walt/.env as GOOGLE_CALENDAR_REFRESH_TOKEN.

Usage:
  from integrations.google_calendar import get_upcoming_events, create_event
"""
import json
import os
import urllib.request
import urllib.parse
from datetime import datetime, timezone, timedelta

CALENDAR_API = "https://www.googleapis.com/calendar/v3"


def _access_token() -> str:
    data = json.dumps({
        "client_id":     os.environ["GOOGLE_CLIENT_ID"],
        "client_secret": os.environ["GOOGLE_CLIENT_SECRET"],
        "refresh_token": os.environ["GOOGLE_CALENDAR_REFRESH_TOKEN"],
        "grant_type":    "refresh_token",
    }).encode()
    req = urllib.request.Request(
        "https://oauth2.googleapis.com/token",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())["access_token"]


def _headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}", "User-Agent": "nova-integrations/1.0"}


def get_upcoming_events(days: int = 7, calendar_id: str = "primary", max_results: int = 20) -> list[dict]:
    """Return events for the next N days, sorted by start time."""
    token = _access_token()
    now   = datetime.now(timezone.utc)
    end   = now + timedelta(days=days)
    params = urllib.parse.urlencode({
        "timeMin":    now.isoformat(),
        "timeMax":    end.isoformat(),
        "maxResults": max_results,
        "singleEvents": "true",
        "orderBy":    "startTime",
    })
    req = urllib.request.Request(
        f"{CALENDAR_API}/calendars/{urllib.parse.quote(calendar_id)}/events?{params}",
        headers=_headers(token),
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        data = json.loads(r.read())

    events = []
    for item in data.get("items", []):
        start = item.get("start", {})
        events.append({
            "id":          item["id"],
            "title":       item.get("summary", "(no title)"),
            "start":       start.get("dateTime") or start.get("date"),
            "all_day":     "dateTime" not in start,
            "description": item.get("description", ""),
            "location":    item.get("location", ""),
            "html_link":   item.get("htmlLink", ""),
        })
    return events


def list_calendars() -> list[dict]:
    """Return all calendars on the account."""
    token = _access_token()
    req = urllib.request.Request(
        f"{CALENDAR_API}/users/me/calendarList",
        headers=_headers(token),
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        data = json.loads(r.read())
    return [{"id": c["id"], "summary": c["summary"]} for c in data.get("items", [])]


def create_event(
    title: str,
    start: str,          # ISO 8601 — "2026-05-25T10:00:00+10:00"
    end: str,            # ISO 8601
    description: str = "",
    location: str = "",
    calendar_id: str = "primary",
) -> dict:
    """Create a calendar event. Returns the created event dict."""
    token = _access_token()
    body = json.dumps({
        "summary":     title,
        "description": description,
        "location":    location,
        "start":       {"dateTime": start},
        "end":         {"dateTime": end},
    }).encode()
    req = urllib.request.Request(
        f"{CALENDAR_API}/calendars/{urllib.parse.quote(calendar_id)}/events",
        data=body,
        headers={**_headers(token), "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def format_events_for_brief(events: list[dict]) -> str:
    """Format upcoming events as a compact brief string."""
    if not events:
        return "No upcoming calendar events."
    lines = []
    for e in events:
        start = e["start"]
        if start and "T" in start:
            dt = datetime.fromisoformat(start)
            label = dt.strftime("%a %b %-d, %-I:%M%p").lower()
        else:
            label = start or "all day"
        lines.append(f"• {e['title']} — {label}")
    return "\n".join(lines)
