# Pending Rule Proposals — agent-builder

Proposals from build failures. Nova reviews at boot (Step 6) and actions or clears each entry.

---

(No proposals yet.)
