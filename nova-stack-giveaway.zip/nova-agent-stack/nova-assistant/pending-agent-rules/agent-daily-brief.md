# Pending Rule Proposals — agent-daily-brief

Proposals from the daily brief's failure-mode learning loop. Nova reviews at boot (Step 6) and actions or clears each entry.

---

(No proposals yet.)
