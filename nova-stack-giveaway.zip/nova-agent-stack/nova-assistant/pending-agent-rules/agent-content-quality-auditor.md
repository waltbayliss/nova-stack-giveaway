# Pending Rule Proposals — agent-content-quality-auditor

Proposals from the content quality auditor's self-improvement loop. Nova reviews at boot (Step 3.5) and actions or clears each entry.

---

(No proposals yet.)
