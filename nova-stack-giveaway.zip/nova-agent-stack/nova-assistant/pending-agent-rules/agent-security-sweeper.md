# Pending Rule Proposals — agent-security-sweeper

Proposals from sweep-loop learning and post-session security findings. Nova reviews at boot (Step 6) and actions or clears each entry.

---

(No proposals yet.)
