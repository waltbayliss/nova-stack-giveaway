# Pending Rule Proposals — agent-image-creator

Proposals from image-creator failures. Nova reviews at boot (Step 6) and actions or clears each entry.

---

(No proposals yet.)
