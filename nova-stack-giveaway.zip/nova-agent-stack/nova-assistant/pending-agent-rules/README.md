# pending-agent-rules/ — Central Inbox

Nova reads this folder at every session boot (or on demand: "Nova, check pending rules").

Each file is named `{agent-name}.md` and contains proposals written by that agent's self-improvement loop via `skills/self-improve.md`.

---

## Nova's Review Protocol

At session boot — or when Walt says "Nova, check pending rules":

1. Read every `.md` file in this folder (skip README.md)
2. For each proposal entry:
   - **Sound rule?** → Update the agent's CLAUDE.md on GitHub, clear the entry, log to the agent's DECISIONS.md
   - **Not warranted?** → Note the rejection reason, clear the entry
   - **Unsure?** → Flag to Walt before actioning
3. After full review: all entries cleared. Files remain (empty) ready for future proposals.
4. Log review completion to nova-memory.md: `[DATE] Pending rules reviewed — N proposals actioned.`

---

## Entry Format

Agents write entries using this format (via skills/self-improve.md):

```
## [{DATE}] Proposed Rule Change — {agent-name}

**Pattern observed:** {what happened}
**Occurrences:** {N}
**Proposed CLAUDE.md addition:** {exact text of the rule}
**Reason this should be a hard rule:** {why memory-level guidance is not sufficient}
```

---

## Wiki Synthesis Requests

Agents also write here when their wiki/Raw/ folder has 10+ unprocessed captures:

```
## [{DATE}] Wiki Synthesis Due — {agent-name}
{N} raw captures are unprocessed. Run wiki synthesis for this agent.
```

Nova actions these by running the synthesis protocol defined in `skills/self-improve.md`.

---

*This folder is maintained by Nova. Written to by agents via skills/self-improve.md.*
