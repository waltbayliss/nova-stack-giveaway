#!/usr/bin/env python3
"""
refresh-google-tokens.py
========================

One-shot OAuth helper for the agent-daily-brief Cloudflare Worker.

Run this on your Mac (anywhere you have a browser). It opens Google's consent
screen, listens on http://localhost:8080/callback, captures the auth code,
exchanges it for a refresh token, and prints the token to your terminal.

Run it ONCE for personal ([email]) and ONCE for [Prior Venture]
(walt@[prior-venture-site]) — sign into a different Google account each time.

Why we need this regularly: the OAuth app for agent-daily-brief is in
"Testing" mode, so Google auto-expires refresh tokens every 7 days. The
durable fix is to publish the OAuth app to "Production" status in Google
Cloud Console — see the END NOTE printed after the token is captured.

USAGE
-----
    cd /Users/walt/Library/CloudStorage/GoogleDrive-[email]/My\\ Drive/AI\\ Agents/Ai\\ Agent\\ Team/my-ai-team/nova-assistant
    git pull
    python3 tools/refresh-google-tokens.py

The script reads GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET from /Users/walt/.env
(or env vars if already set).
"""

from __future__ import annotations

import http.server
import os
import socketserver
import sys
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path


SCOPES = " ".join(
    [
        # gmail.metadata (Sensitive, not Restricted) — strictly enough to read
        # From/Subject/labels which is all the brief uses. Avoids the
        # Restricted-scope verification requirement that was killing tokens.
        "https://www.googleapis.com/auth/gmail.metadata",
        "https://www.googleapis.com/auth/calendar.readonly",
    ]
)
REDIRECT_URI = "http://localhost:8080/callback"
PORT = 8080


def load_env_vars() -> tuple[str, str]:
    cid = os.environ.get("GOOGLE_CLIENT_ID", "")
    csec = os.environ.get("GOOGLE_CLIENT_SECRET", "")
    if cid and csec:
        return cid, csec

    candidates = [
        Path.home() / ".env",
        Path("/Users/walt/.env"),
    ]
    for path in candidates:
        if path.exists():
            for line in path.read_text().splitlines():
                if line.startswith("GOOGLE_CLIENT_ID=") and not cid:
                    cid = line.split("=", 1)[1].strip()
                elif line.startswith("GOOGLE_CLIENT_SECRET=") and not csec:
                    csec = line.split("=", 1)[1].strip()
            if cid and csec:
                break
    if not (cid and csec):
        sys.exit("ERROR: GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET not found in env or ~/.env")
    return cid, csec


_captured_code: dict[str, str] = {}


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return
        params = urllib.parse.parse_qs(parsed.query)
        code = params.get("code", [None])[0]
        err = params.get("error", [None])[0]
        if err:
            _captured_code["error"] = err
            body = f"<h1>OAuth error</h1><p>{err}</p><p>Close this tab and re-run the script.</p>"
        elif code:
            _captured_code["code"] = code
            body = "<h1>Got it.</h1><p>Auth code captured. You can close this tab and return to your terminal.</p>"
        else:
            body = "<h1>Unexpected callback</h1><p>No code, no error.</p>"
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))

    def log_message(self, *_args, **_kwargs):  # silence default access log
        return


def run_oauth_flow(label: str, client_id: str, client_secret: str) -> str:
    print(f"\n=== {label} ===")
    auth_url = (
        "https://accounts.google.com/o/oauth2/v2/auth?"
        + urllib.parse.urlencode(
            {
                "client_id": client_id,
                "redirect_uri": REDIRECT_URI,
                "response_type": "code",
                "scope": SCOPES,
                "access_type": "offline",
                "prompt": "consent",  # forces refresh_token to be returned every time
            }
        )
    )
    print(f"Opening browser. If it doesn't open automatically, paste this URL:\n{auth_url}\n")
    print(f"Sign in as the {label} Google account, approve all scopes, then return here.")
    webbrowser.open(auth_url)

    _captured_code.clear()
    with socketserver.TCPServer(("127.0.0.1", PORT), _CallbackHandler) as httpd:
        while not _captured_code:
            httpd.handle_request()

    if "error" in _captured_code:
        sys.exit(f"OAuth error for {label}: {_captured_code['error']}")

    code = _captured_code["code"]

    # Exchange code for tokens
    data = urllib.parse.urlencode(
        {
            "code": code,
            "client_id": client_id,
            "client_secret": client_secret,
            "redirect_uri": REDIRECT_URI,
            "grant_type": "authorization_code",
        }
    ).encode()

    req = urllib.request.Request(
        "https://oauth2.googleapis.com/token",
        data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            payload = resp.read().decode()
    except urllib.error.HTTPError as e:  # type: ignore[attr-defined]
        sys.exit(f"Token exchange failed for {label}: {e.read().decode()}")

    import json

    parsed = json.loads(payload)
    refresh_token = parsed.get("refresh_token")
    if not refresh_token:
        sys.exit(
            f"No refresh_token returned for {label}. Likely cause: this Google account "
            "previously authorised the same OAuth client and Google won't re-issue a "
            "refresh_token. Visit https://myaccount.google.com/permissions, revoke the "
            "app, then re-run this script."
        )
    return refresh_token


def main() -> None:
    cid, csec = load_env_vars()

    print("Refreshing Google tokens for agent-daily-brief CF Worker.")
    print("You will sign in TWICE — once per account.")
    print(f"OAuth client: ...{cid[-12:]}\n")

    personal = run_oauth_flow("PERSONAL ([email])", cid, csec)
    aita = run_oauth_flow("[Prior Venture] (walt@[prior-venture-site])", cid, csec)

    print("\n" + "=" * 60)
    print("DONE. Send these to Nova in the chat:")
    print("=" * 60)
    print(f"\nGOOGLE_REFRESH_TOKEN={personal}")
    print(f"GOOGLE_REFRESH_TOKEN_AITA={aita}\n")
    print("=" * 60)
    print("END NOTE — durable fix:")
    print("Both tokens just expired together because the OAuth client is in")
    print("'Testing' mode. Google auto-expires testing tokens every 7 days.")
    print("Stop this happening monthly by:")
    print("  1. Open https://console.cloud.google.com/apis/credentials/consent")
    print("  2. Switch the OAuth consent screen from 'Testing' to 'In production'")
    print("  3. Save. Tokens stop expiring on the 7-day timer.")
    print("=" * 60)


if __name__ == "__main__":
    main()
