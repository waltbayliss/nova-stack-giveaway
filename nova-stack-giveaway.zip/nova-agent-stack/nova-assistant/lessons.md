# lessons.md

*(Real entries removed for public distribution. This file exists in the real structure as the self-improvement log — a dated entry every time a correction changes behaviour — the shape is real, the history in it is not.)*
