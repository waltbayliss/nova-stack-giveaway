# Skill — Build an SLO Funnel (Hybrid Model)

**Owner:** Nova (orchestration skill — not an agent). | **Last reviewed:** 2026-05-20 | **Project:** [AI Content Empire](../docs/projects/ai-content-empire.md)

## What this skill does

End-to-end build of an Anik-Singal-style 4-tier Self-Liquidating Offer funnel using the **Hybrid Model**: funnel pages live on **Cloudflare Pages** for full design control + programmatic deploy, and [Employer] handles **forms, products, payments, email automation, and AI chat** via embedded snippets.

The skill orchestrates four executors. Nova does not write code, copy, or design — she sequences these:

| Executor | Role |
|---|---|
| `agent-copywriter` | All copy: 4 pages × sales letter, ad copy, 5-7 email sequence |
| `agent-image-creator` | Hero image per page + email graphics + social ad creatives |
| `ghl-agent` | Products, custom fields, tags, forms, email templates in [Employer] |
| Cloudflare MCP | Pages deploy + DNS subdomain creation |

## When to invoke

Walt says any of:
- `"Nova, build a funnel for [offer]"`
- `"Build the SLO for [product name]"`
- `"Run build-slo-funnel for [offer]"`

Before invoking, confirm one-time setup is complete (see "Pre-flight" below).

## Pre-flight (one-time per location, ~1 hour Walt)

Before this skill can run the first time, the following must be true. Nova checks each in Stage 0 and halts if any are missing:

1. **Stripe wired in GHL location** — payments will fail otherwise. Walt confirms in GHL UI.
2. **Master email workflow built in HL** — welcome → 5-7 nurture → cart-abandon → post-purchase → continuity ramp. The skill **clones** this per offer. Without a master, every offer needs a hand-built workflow.
3. **`[personal-site]` zone confirmed in Cloudflare** with the agent's API token having DNS edit + Pages deploy scopes.
4. **Brand assets** under `walts-wiki/Brand Assets/` — logo (light + dark SVG), brand colour hex codes, font choice.
5. **`.env` keys present:** `GHL_LOCATION_ID`, `GHL_PIT_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_API_TOKEN`.

Nova: if any pre-flight check fails, stop and report exactly what's missing. Do NOT proceed with a partial setup — half-built funnels are worse than none.

---

## Stage 0 — Intake (mandatory)

Run this interview with Walt before any executor is called. Fields required:

| Field | Example | Notes |
|---|---|---|
| Offer name | `AI Agent Template Pack` | Used in subdomain, copy, product names |
| Offer slug | `agent-templates` | Subdomain will be `agent-templates.[personal-site]` |
| Tier 1 ($5) | name + 1-line desc + delivery format (PDF / .zip / Notion clone) | Front-end SLO |
| Tier 2 ($35 OTO) | name + 1-line desc + delivery format | One-click upsell |
| Tier 3 ($297 OTO) | name + 1-line desc + delivery format | Mid-ticket upsell |
| Tier 4 ($20/mo) | name + 1-line desc + delivery format | Continuity |
| Target audience | 1-2 sentences | Feeds agent-copywriter intake |
| Top 3 pains | bullets | Copy hook material |
| Dream outcome | 1 sentence | Promise of the offer |
| Top 3 objections | bullets | What the copy must defuse |
| Proof elements | testimonials / screenshots / metrics | Trust assets |
| Traffic source | cold / warm / hot | Drives copy register |
| Launch deadline | date | Skill paces to this |

Signal completion explicitly: `"Intake complete — beginning Stage 1."` and write the intake to `nova-assistant/funnels/<offer-slug>/intake.md` so it can be re-run.

---

## Stage 1 — Copy generation (agent-copywriter)

**HARD GATE:** all sales-page copy is written by agent-copywriter against the **`@skills/dr-sales-page.md`** standard (the ~18-block DR skeleton + persuasion checklist). Nova NEVER writes page copy herself — she assembles the copywriter's output into HTML in Stage 3a. A page whose copy didn't come from the copywriter is incomplete. (Codified Session 98 after a thin landing-page miss.)

Invoke `agent-copywriter` with the intake as a brief. Required outputs, all written to `nova-assistant/funnels/<offer-slug>/copy/`:

| File | Purpose | Length target |
|---|---|---|
| `tier-1-sales.md` | $5 front-end sales page | ~800-1200 words |
| `tier-2-oto.md` | $35 OTO upgrade page | ~400-600 words |
| `tier-3-oto.md` | $297 mid-ticket OTO | ~1000-1500 words |
| `tier-4-thankyou.md` | Thank-you + continuity pitch | ~300-500 words |
| `email-01-welcome.md` | Deliver Tier 1 + intro | |
| `email-02-nurture.md` to `email-06-nurture.md` | Story / authority / pain agitation / case study / objection-killer | |
| `email-07-tripwire.md` | Hard pitch for Tier 3 | |
| `email-cart-abandon.md` | If checkout abandoned | |
| `email-post-purchase.md` | Post-buy onboarding | |
| `ad-fb.md`, `ad-ig.md`, `ad-yt.md`, `ad-linkedin.md`, `ad-google.md` | Channel-specific ad copy | |

Frameworks per page:
- Tier 1: Hormozi Grand Slam Offer scaffold + Halbert hook
- Tier 2: Brunson OTO formula (single-decision, scarce)
- Tier 3: Abraham preeminence + Kennedy directness
- Tier 4: Kern conversational continuity pitch

Quality gate: agent-copywriter's checklist must PASS on all 4 sales pages before moving to Stage 2. Re-run on FAIL.

---

## Stage 2 — Asset generation (agent-image-creator)

Invoke `agent-image-creator` per the [image-generation skill](./image-generation.md) — **Nano Banana standard, one-shot, never composite**.

Required outputs to `nova-assistant/funnels/<offer-slug>/assets/`:

| Asset | Notes |
|---|---|
| `hero-tier1.jpg` | Front-end LP hero |
| `hero-tier2.jpg`, `hero-tier3.jpg`, `hero-tier4.jpg` | Each page hero |
| `section-graphics/` | 3-5 in-page graphics per tier |
| `email-header.jpg` | Email template header |
| `ad-creative-fb-1.jpg` ... | Per-channel ad creatives (×2 per channel min) |
| `social-share-card.jpg` | OG image for the LP |

Brand colours, fonts, logo from `walts-wiki/Brand Assets/`. Pass them in the prompt every time.

---

## Stage 3a — Page generation + Cloudflare Pages deploy

Generate four static HTML pages from copy + assets. Each page is a single-file HTML/Tailwind bundle, self-contained.

For each tier:

1. **Render template** — minimal Tailwind structure: hero / problem / solution / offer stack / proof / CTA / FAQ / footer
2. **Inject copy** from `copy/tier-N-sales.md`
3. **Inject hero + section assets**
4. **Inject [Employer] form embed** (created in Stage 3b) at primary opt-in
5. **Inject [Employer] payment link** (created in Stage 3b) at CTA buttons
6. **Inject [Employer] Conversation AI widget** in page footer (once configured in Stage 3c)
7. **Inject Cloudflare Web Analytics** script
8. **Inject UTM-capture JS** (writes utm_source/medium/campaign into hidden form fields)

Output to `nova-assistant/funnels/<offer-slug>/pages/`:
- `index.html` → Tier 1 ($5 front-end)
- `oto-1.html` → Tier 2 ($35)
- `oto-2.html` → Tier 3 ($297)
- `thankyou.html` → Tier 4 ($20/mo continuity)

**Deploy** — via `skills/helpers/cf_pages_deploy.py` (`CFPagesDeployer`):
1. `deploy(local_dir="funnels/<offer-slug>/pages", project_name="slo-<offer-slug>")` — wrangler@3 deploys all four HTML files, auto-creates the Pages project, returns the `.pages.dev` URL
2. `ensure_cname(subdomain="<offer-slug>", target=<pages-url>, zone="[personal-site]")` — creates/updates the CNAME so `<offer-slug>.[personal-site]` points at the deployment
3. Optionally `attach_custom_domain(project_name, "<offer-slug>.[personal-site]")` for managed cert
4. Smoke-fetch each URL to confirm 200 + body length > 1000 bytes

> Helper smoke-tested 2026-05-21: Pages list OK, zone `[personal-site]` resolved. Token scopes confirmed.

**Failure mode:** if Pages deploy or DNS fails, halt and report. Do NOT proceed to Stage 3b — broken page links in HL emails are worse than a delayed launch.

---

## Stage 3b — [Employer] build (ghl-agent, extended)

Route to `ghl-agent`, which executes via `ghl-agent/src/ghl_funnel.py` (`GHLFunnel` class — `create_product`, `create_payment_link`, `create_custom_field`, `create_tag`, `create_form`, `create_email_template`). ghl-agent uses cached IDs from `agent-memory.md` where possible.

> Module smoke-tested 2026-05-21: products + contacts read OK against live location. `create_form` has a built-in read-only fallback if GHL v2 rejects it.

| # | Action | Endpoint | Output captured |
|---|---|---|---|
| 1 | Create **4 products** (one per tier) | `POST /products/` | product IDs |
| 2 | Create **payment link per product** | `POST /payments/links/` | 4 payment URLs (handed back to Stage 3a for re-deploy if needed) |
| 3 | Create **custom fields** (slo_tier_reached, slo_offer_slug, utm_source, utm_medium, utm_campaign) if absent | `POST /locations/{loc}/customFields` | field IDs |
| 4 | Create **tags** (`slo:<offer-slug>:tier-1`, ...:tier-2, ...:tier-3, ...:tier-4-continuity, ...:cart-abandon) | `POST /locations/{loc}/tags` | tag IDs |
| 5 | Create **opt-in form** (email + first name + slo_offer_slug hidden) | `POST /forms/` | form ID + embed snippet |
| 6 | Create **email templates** (welcome, 5× nurture, tripwire, cart-abandon, post-purchase, continuity-welcome) | `POST /emails/templates` | template IDs |
| 7 | **Manual workflow clone** — surface the clone-from-master-workflow instruction to Walt (one-click in HL UI: Settings → Workflows → master → Clone → rename `<offer-slug>-workflow` → swap email templates to the IDs from step 6) | n/a — manual | Walt confirms done before Stage 4 |
| 8 | Update `ghl-agent/agent-memory.md` with all IDs created | n/a | |

**Step 2 callback:** payment links are needed by Stage 3a's HTML CTAs. If Stage 3a deployed *before* this stage, redeploy here with the live links injected. Cleanest: Stage 3b runs first for products+payment links, THEN Stage 3a runs with them in hand.

**Revised stage order:** 1 → 2 → **3b** → **3a** → 3c → 4 → 5 → 6.

---

## Stage 3c — [Employer] Conversation AI (one-time per offer)

Walt's manual step (~5 min):
1. In HL → Conversation AI Studio → New Agent → name: `<offer-slug>-support`
2. Knowledge base: upload Tier 3 product docs + FAQ + refund policy
3. Tone: match brand voice
4. Escalation: route to Walt's inbox if KB confidence < 0.6
5. Embed code → paste into Stage 3a's redeploy

Nova surfaces this checklist to Walt and waits for `"chat configured"` before continuing.

---

## Stage 4 — Smoke test

Nova-driven. All must PASS before going live.

1. **Page render** — `curl` each page URL, body length > 1000, no 404s in embedded asset URLs
2. **Form submit** — submit a test contact via the form's embed endpoint (test email `nova-smoke+<offer-slug>@[personal-site]`)
3. **Verify in GHL** — fetch contact, confirm: tagged, custom fields populated, workflow triggered (first email enqueued)
4. **First email fires** — wait 90 seconds, fetch the test contact's email log, confirm welcome email sent
5. **Checkout** — Tier 1 payment link in test mode, complete with Stripe test card, confirm contact tagged `slo:<offer-slug>:tier-1` + product purchase recorded
6. **OTO routing** — confirm post-purchase redirects to `oto-1.html`
7. **Conversation AI** — open page, type a sample question, confirm AI responds

Smoke-test report written to `nova-assistant/funnels/<offer-slug>/smoke-test.md` with PASS/FAIL per check + concrete evidence (response codes, contact IDs, email log IDs).

If any check FAILS — halt, report to Walt, do NOT proceed to Stage 5.

---

## Stage 5 — Notion + GitHub write-back

1. **Products For Sale DB** — new row per tier (4 rows). Properties: Name / Price / Status (`Built`) / Funnel URL / Product ID / Created / SLO Tier.
2. **AI Content Empire working page** — append to "Built Funnels" section: offer name + live URLs + decision log entry.
3. **GitHub commit** — `funnels/<offer-slug>/` directory pushed to `nova-assistant`. Commit message: `funnel: <offer-slug> built — Tier 1-4 live, smoke PASS`.
4. **walts-wiki** — append a build summary under `Walt's Wiki/Funnels/Raw/<date>-<offer-slug>.md`.

---

## Stage 6 — Telegram ping

```
✅ SLO funnel built: <offer-name>

Tier 1 ($5):    https://<offer-slug>.[personal-site]
Tier 2 ($35):   https://<offer-slug>.[personal-site]/oto-1
Tier 3 ($297):  https://<offer-slug>.[personal-site]/oto-2
Tier 4 ($20mo): https://<offer-slug>.[personal-site]/thankyou

Smoke test PASS (7/7).
Test purchase confirmed in HL contact: <contact-id>.

Walt: live & ready to drive traffic? Reply YES to switch payment links from test → live mode.
```

After Walt confirms YES, ghl-agent flips payment links from test → live.

---

## Failure modes & rollback

| Failure | Rollback action |
|---|---|
| Copy quality FAIL after 2 retries | Halt. Don't burn budget retrying. Report copy gaps to Walt; he edits OR re-runs Stage 1 with adjusted brief |
| Cloudflare Pages deploy fails | Don't create the HL artifacts. No half-built funnel. |
| HL form create returns 4xx | Investigate locationId / scopes. If PIT token expired, halt with rotation instruction. |
| Workflow clone not done by Walt | Stage 4 smoke test will fail at "first email fires". Telegram nudge: "Workflow clone pending — Stage 4 blocked." |
| Smoke test FAIL anywhere | Generate failure report. Do NOT push live or commit GitHub. Funnel stays in `funnels/<offer-slug>/draft/` until resolved. |

**Hard rule:** the skill never flips payment links from test → live without explicit Walt confirmation. (Maps to CLAUDE.md Operating Rule 1.)

---

## Self-improve

After every funnel built:
1. Append a row to `nova-assistant/funnels/_metrics.md` — offer / build time / smoke-test pass rate / live URL / first 7-day conversion rate (filled in once data exists)
2. If a stage failed → log to `lessons.md` per CLAUDE.md Operating Rule 17
3. If a pattern repeated 3× → propose a CLAUDE.md amendment via `pending-agent-rules/`

---

## What this skill explicitly does NOT do

- **Drive traffic.** That's faceless content (Phase 2) + JV outreach + paid ads (Phase 4).
- **Generate the actual digital product.** The .zip / templates / agent files for each tier must exist before the funnel is built. The skill assumes delivery files are ready in `walts-wiki/Products/<offer-slug>/deliverables/`.
- **Make pricing or positioning decisions.** Those are upstream in the intake.
- **A/B test pages.** Phase 5 work (Cloudflare split-testing utility).
- **Run paid ads.** Phase 4.

---

## Related

- Master plan: [`docs/projects/ai-content-empire.md`](../docs/projects/ai-content-empire.md)
- Notion working page: https://www.notion.so/[REDACTED-ID]
- agent-copywriter: `[agents-root]/agent-copywriter/CLAUDE.md`
- agent-image-creator: `[agents-root]/agent-image-creator/CLAUDE.md`
- ghl-agent: `[agents-root]/ghl-agent/CLAUDE.md` + `src/ghl_funnel.py`
- Cloudflare Pages helper: `skills/helpers/cf_pages_deploy.py` (`CFPagesDeployer`) — wrangler@3 deploy + CF API DNS
- Cloudflare MCP (for non-Pages CF ops): `mcp__[REDACTED-ID]__*` (DNS, R2, KV, D1, Workers)
