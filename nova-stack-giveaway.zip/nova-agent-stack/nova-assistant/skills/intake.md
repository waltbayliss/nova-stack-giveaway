---
name: intake
description: Nova's agent intake skill. Triggered by the word "intake". Queries Notion for agents with Status = "Now", runs a structured interview (4 core questions + follow-up questions as needed), saves the completed brief to GitHub pending-builds/, and updates Notion status to "Building". The goal is a PRD-ready brief — ask as many questions as the brief requires.
---

# Intake Skill

## What This Skill Does

When Walt types **"intake"** in any Nova session (Claude Code or Dispatch), Nova:

1. Queries the Notion Agent Pipeline DB for entries with Status = "Now"
2. Runs a structured interview (4 core questions + extended questions as needed)
3. Saves the completed brief to `pending-builds/<slug>.md` on GitHub (nova-assistant repo)
4. Updates the Notion entry Status: "Now" → "Building"
5. If multiple "Now" entries exist, completes the first then asks about the next

---

## Status Flow (never goes backwards)

```
Now → (interview done) → Building → (agent built + registered) → Completed
```

- **Now** — Walt has queued this agent for intake. n8n pings Telegram. Status stays here until Nova runs the interview.
- **Building** — Interview done, brief saved. agent-builder run in progress.
- **Completed** — Agent fully built, reviewed, and registered in AGENT-REGISTRY.md. Nova sets this at sign-off.

Status never changes to "Next". "Next" = future queue only (not yet ready for intake).

---

## Trigger

**Word:** `intake`

Walt types it. Nova executes immediately — no confirmation step needed.

---

## Notion DB

- **DB ID:** `[REDACTED-ID]`
- **Filter:** Status = "Now"
- **Fields used:** Name, Description (notes/context), Status
- **Status flow:** Now → Building → Completed

---

## Interview Protocol

**The goal is a brief good enough to produce a solid PRD.** The 4 core questions are mandatory. After those, Nova reads the answers and decides whether additional questions are needed. If the brief has gaps that would produce a weak PRD — ask. There is no maximum question count.

Ask one question at a time. Wait for Walt's answer before asking the next.

If Walt's description field in Notion already has context, acknowledge it before Q1:
> "Notion notes say: [description]. I'll use that as context — just confirm or correct as we go."

---

### Core Questions (always ask all 4)

```
Q1: What does this agent do — in one sentence?
Q2: What are its top 3–5 functions?
Q3: What external services or tools does it need to connect to?
Q4: How will it be triggered — on demand, on a schedule, or event-driven?
```

---

### Extended Questions (ask any that the brief requires)

After Q4, Nova reviews the answers. If any of the following would materially improve the PRD, ask them. Skip any that are already clearly answered.

**Output & handoff**
- What does this agent produce? What format is the output (JSON, markdown, Notion update, message, file)?
- What happens after it finishes — does it hand off to another agent? Which one?

**Data access**
- What data does it need to read or write? (databases, Notion tables, Google Drive, GHL fields, etc.)
- Are there schemas or field names Nova should know about?

**Constraints & failure modes**
- What should this agent NEVER do?
- What does failure look like, and how should it be handled? Retry? Alert Walt? Fail silently?

**Scope & MVP**
- What's the must-have for v1, and what's nice-to-have for later?
- Is there anything currently done manually that this agent is replacing?

**Quality & persona**
- Whose voice or standards does this agent need to match?
- What does "good enough" look like? What would make Walt reject its output?

**Prior art**
- Has this been attempted before? Is there an existing agent, tool, or workflow this builds on?

---

### When to stop asking

Stop when Nova is confident the brief covers: purpose, core functions, integrations, trigger mode, output format, failure handling, and scope boundaries. If those are clear from the core 4 answers, no extended questions are needed. If they're not — keep asking until they are.

---

## Brief Format

Save to: `pending-builds/<slug>.md` in the `waltbayliss/nova-assistant` GitHub repo.

`<slug>` = agent name lowercased, spaces replaced with hyphens, **with the `agent-` prefix dropped**. The repo is always `agent-<slug>` but the pending-builds file is just `<slug>.md`. Example: agent "Quick Searcher" → repo `waltbayliss/agent-quick-searcher`, brief `pending-builds/quick-searcher.md`, PRD-reviewer output `pending-builds/quick-searcher-reviewed.md`.

```markdown
# Agent Brief: [Agent Name]

**Created:** [YYYY-MM-DD]
**Status:** pending-build
**Notion entry:** [entry_id]

## Purpose
[Q1 answer — one sentence]

## Core Functions
[Q2 answer — bulleted list]

## Integrations
[Q3 answer — bulleted list]

## Trigger Mode
[Q4 answer]

## Output & Handoff
[What it produces, format, and what receives it next]

## Constraints
[What it must never do. Failure handling.]

## Scope — v1 vs later
[MVP boundary clearly defined]

## Quality Bar
[What good looks like. What would make Walt reject the output.]

## Additional Context
[Any extended question answers, prior art, notes from Notion]
```

---

## Notion Update

After saving the brief:
- Update the Notion entry's Status: "Now" → "Building"
- Confirm to Walt: "Brief saved. [Agent name] set to Building in Notion. Ready for agent-builder."

After agent is fully built, reviewed (Pass 1 + Pass 2), and registered:
- Update the Notion entry's Status: "Building" → "Completed"
- Confirm to Walt: "[Agent name] signed off. Notion set to Completed."

---

## Multiple "Now" Entries

If there are multiple Status = "Now" entries:
- Complete intake for the **first one** (lowest created/updated timestamp)
- After finishing: "That's [Name] done. There's also [Name2] at Now — want to intake that one too?"
- Wait for Walt's response before proceeding

---

## Flow Triggered by n8n

When n8n detects Status = "Now", it sends a Telegram ping **only** — no Notion changes:

> 🤖 *New agent ready for intake:* [Agent Name]
> Notes: [description if present]
>
> Open Dispatch or Claude Code → type: **intake**

n8n does NOT change Status. n8n does NOT set completed. Nova owns all Notion status changes.

---

## What Happens After

1. Brief lives at `pending-builds/<slug>.md` on GitHub
2. Notion Status = "Building"
3. Next session: Walt types "build [agent-name]" or "what's in pending-builds?" to trigger agent-builder
4. On sign-off: Nova sets Notion Status → "Completed"

---

## Errors

| Issue | Action |
|-------|--------|
| No "Now" entries found | "Nothing at Now in the Agent Pipeline. Want to set one to Now or add a new entry?" |
| Notion API error | Flag immediately: "Can't reach Notion right now — [error]. Try again in a minute." |
| GitHub write error | Retry once. If still failing: save brief locally to pending-builds/ on disk, log the path. |
| Walt gives incomplete answer | Ask for clarification before moving to next question |
