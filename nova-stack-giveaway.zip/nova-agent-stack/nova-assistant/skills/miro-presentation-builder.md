---
name: miro-presentation-builder
description: Build a Hamza Baig-style vertical-flowchart Miro board for a given topic — black canvas, coloured-border nodes, white connectors, Caveat annotations. Built for screen-record-style course content. Triggered by "create a Miro presentation about [topic]", "build a Miro board for [topic]", "make a Hamza-style board on [topic]", or from a daily brief instruction that says "create this as a Miro presentation".
---

# Skill: miro-presentation-builder

**Style validated:** 2026-05-14 on test board `https://miro.com/app/board/uXjVHTwtPW0=/`. Walt-approved right-side frame as reference.

**Trigger phrases:**
- "Create a Miro presentation about [topic]"
- "Build a Miro board for [topic]"
- "Make a Hamza-style board on [topic]"
- "Turn this into a Miro presentation" (in a daily brief or following a content draft in this session)
- Any daily-brief section item that contains the instruction "create as Miro presentation" or similar

**Output:** A Miro board URL — one vertical-flowchart frame, ready for Walt to screen-record. The board contains exactly one FRAME at board coords (0,0); the FRAME contains the nodes, connectors, and annotations. No extra clutter.

---

## STEP 0 — PLAN THE FLOW BEFORE TOUCHING MIRO

Before any tool call, Nova drafts the flow in plain text and shows Walt:

- **Topic title** (becomes the frame title and the top node)
- **Flow structure** — ordered list of 6–15 nodes, with branch points marked
- **Each node:** label (≤2 short lines), border colour (red / blue / orange / purple / green / white), shape role (start node / process / decision / end)
- **Annotations** — sub-process labels that float on connectors (e.g. "POST to CRM", "via webhook", "after 24h delay")
- **Decision branches** — for every decision node, name the Yes/No (or other) outcomes

Confirm with Walt before building. Don't burn a Miro board on a flow Walt would have re-scoped.

---

## STEP 1 — CREATE THE BOARD (with explicit Walt confirmation)

Per Operating Rule 4 AND the Miro MCP's own `board_create` warning ("Always confirm with the user before creating a board"):

> "Going to create a new Miro board: **`<board_name>`**. Title pattern: `[Course] <topic>` or `[Brief YYYY-MM-DD] <topic>`. OK to proceed?"

On confirmation, call `mcp__<miro>__board_create` with `name` and a one-line `description`. Capture the returned `miro_url`.

---

## STEP 2 — CREATE THE FRAME (own call)

Frame is created FIRST, in its own `layout_create` call. Cross-batch frame parent references via `parent=alias` are unreliable — empirically confirmed 2026-05-14. So:

```
clean_frame FRAME x=0 y=0 w=900 h=<calculated_height> fill=#000000 "<topic>"
```

**Frame sizing:**
- Width: `900` (fixed — matches Walt's screen-record portrait crop comfortably)
- Height: `180 + (220 * node_count) + 80` — top padding + per-node vertical block + bottom padding. Bump by an extra 100 per branch point (decision nodes split horizontally and add height).
- Background: `#000000` always.

Capture the returned frame URL — it ends in `?moveToWidget=<frame_id>`. **All subsequent layout_create calls use this URL.**

---

## STEP 3 — BUILD CONTENT IN BATCHES OF ≤ 3 ITEMS

Bulk creates above ~3 items intermittently fail with generic HTTP 400 (empirically confirmed 2026-05-14). The skill chunks every build into batches of ≤3.

**Recommended batch order:**
1. Batch 1 — node 1, node 2, node 3
2. Batch 2 — node 4, node 5, node 6 (continue until all nodes placed)
3. Batch 3 — connector segments for nodes 1→2 (above-annotation line, below-annotation line, arrowhead)
4. Batch 4 — annotation TEXT between nodes 1→2
5. Continue connectors + annotations in 3-item batches

Place all batch URLs against the FRAME via `?moveToWidget=<frame_id>`. Never reference `parent=frame_alias` across batches — the alias only exists within a single DSL submission.

---

## STEP 4 — STYLE SPEC (LOCKED 2026-05-14)

### Canvas
- **Frame** — `fill=#000000`, width `900`, height variable per Step 2 formula
- Coordinate origin inside frame: top-left = (0, 0). Vertical axis grows downward.

### Primary nodes
- **Shape type:** `round_rectangle`
- **Fill:** `#000000` (matches canvas — gives the "border-only" look)
- **Border:** `border_width=4`
- **Border colour palette** — rotate through these in order, or pick by semantic role:
  - Red `#E63946` — start node / trigger / alert / error state
  - Blue `#3B82F6` — process / system action / standard step
  - Orange `#F59E0B` — wait / delay / time-bound step
  - Purple `#A855F7` — branching / variation / parallel path
  - Green `#4ADE80` — success / completion / "yes" outcomes
  - White `#FFFFFF` — neutral / default when no semantic colour fits
- **Text:**
  - colour: `#FFFFFF`
  - font: `fredoka_one` (rounded friendly display — matches Hamza)
  - size: `20`
  - align: `center`, valign: `middle`
- **Dimensions:**
  - Default node: `w=320 h=120`
  - Long-label node (3+ words per line): `w=360 h=120`
  - Short single-word node: `w=240 h=120`
- **Content formatting:** multi-line wraps with `<p>` tags — e.g. `"<p>Customer books an appointment</p><p>on the Plumber's website</p>"`. Keep to ≤2 lines per node.

### Decision branches (Yes / No)
- **Shape type:** `round_rectangle`
- **Width:** `120–150`, height `80`
- **Yes border:** green `#4ADE80`
- **No border:** red `#E63946`
- **Position:** side-by-side under the decision parent, horizontally offset by ±150 from frame centre x=450
- **Text:** white, fredoka_one, size 20, content typically `"Yes"` / `"No"`
- **Below each branch:** continue a vertical sub-flow with its own connectors

### Connector lines
- **Shape type:** `rectangle`
- **Fill:** `#FFFFFF`
- **Border:** `border_color=#FFFFFF border_width=1` (border same as fill = solid white line)
- **Width:** `8` (minimum allowed by Miro DSL; w=3 rejected)
- **Height:** variable depending on segment — typical 40–80px between elements
- **Content:** `" "` (single space — empty string `""` is rejected)

### Connector arrowheads
- **Item type:** `TEXT`
- **Content:** `"▼"` (unicode down triangle)
- **Font:** `arial`
- **Size:** `28`
- **Width:** `80` (minimum reliable text width; w=40 rejected)
- **Colour:** `#FFFFFF`
- **Align:** center
- **Position:** centred horizontally on the connector column, vertically placed at the end of the line segment immediately before the destination node's top edge

### Annotations (sub-process labels floating on connectors)
- **Item type:** `TEXT`
- **Font:** `caveat` (handwritten style)
- **Size:** `22`
- **Width:** `360` (or wider for long labels)
- **Colour:** `#FFFFFF`
- **Align:** center
- **Position:** on the connector path between two nodes, mid-way vertically. Split the connector into two segments — line above the annotation, line below — to give the visual of text sitting on the wire.

### Vertical spacing (centre-to-centre between nodes)
- **Simple connector (no annotation):** node bottom + 90px gap + next node top → centre-to-centre ≈ `240` for 120-tall nodes
- **Connector with annotation:** node bottom + 130px gap + next node top → centre-to-centre ≈ `300`
- **Decision split block:** allow `180` extra height for the Yes/No row plus its continuations

---

## STEP 5 — DSL TEMPLATES (copy-and-fill)

### Template — primary node
```
<id> SHAPE x=450 y=<center_y> w=<width> h=120 type=round_rectangle fill=#000000 border_color=<#BORDER> border_width=4 color=#FFFFFF font=fredoka_one size=20 align=center valign=middle "<p><line1></p><p><line2></p>"
```

### Template — connector segment with annotation
Below a node centred at `y=<node_center>` with node height 120, building down to the next node centred at `y=<next_center>`:

```
ln_<i>a SHAPE x=450 y=<node_center + 90> w=8 h=40 type=rectangle fill=#FFFFFF border_color=#FFFFFF border_width=1 " "
a_<i> TEXT x=450 y=<node_center + 135> w=360 color=#FFFFFF font=caveat size=22 align=center "<annotation>"
ln_<i>b SHAPE x=450 y=<node_center + 185> w=8 h=35 type=rectangle fill=#FFFFFF border_color=#FFFFFF border_width=1 " "
ah_<i> TEXT x=450 y=<node_center + 220> w=80 color=#FFFFFF font=arial size=28 align=center "▼"
```

### Template — connector segment without annotation
```
ln_<i> SHAPE x=450 y=<node_center + 110> w=8 h=70 type=rectangle fill=#FFFFFF border_color=#FFFFFF border_width=1 " "
ah_<i> TEXT x=450 y=<node_center + 165> w=80 color=#FFFFFF font=arial size=28 align=center "▼"
```

### Template — decision node (parent of Yes / No row)
```
nd_<i> SHAPE x=450 y=<center_y> w=300 h=100 type=round_rectangle fill=#000000 border_color=#FFFFFF border_width=4 color=#FFFFFF font=fredoka_one size=20 align=center valign=middle "<question>"
```

Below it, two split connectors and the two branch nodes:

```
# Y-arm line
ln_y SHAPE x=300 y=<center_y + 80> w=8 h=50 type=rectangle fill=#FFFFFF border_color=#FFFFFF border_width=1 " "
ah_y TEXT x=300 y=<center_y + 115> w=80 color=#FFFFFF font=arial size=28 align=center "▼"
# Y branch node — green border
n_yes SHAPE x=300 y=<center_y + 180> w=140 h=80 type=round_rectangle fill=#000000 border_color=#4ADE80 border_width=4 color=#FFFFFF font=fredoka_one size=20 align=center valign=middle "Yes"

# N-arm line
ln_n SHAPE x=600 y=<center_y + 80> w=8 h=50 type=rectangle fill=#FFFFFF border_color=#FFFFFF border_width=1 " "
ah_n TEXT x=600 y=<center_y + 115> w=80 color=#FFFFFF font=arial size=28 align=center "▼"
# N branch node — red border
n_no SHAPE x=600 y=<center_y + 180> w=140 h=80 type=round_rectangle fill=#000000 border_color=#E63946 border_width=4 color=#FFFFFF font=fredoka_one size=20 align=center valign=middle "No"
```

Continue each arm's sub-flow at its respective x (300 for Yes side, 600 for No side) until it converges or ends.

---

## STEP 6 — REPORT TO WALT

Return the board URL + the frame's deep-link. Format:

> ✅ Miro board ready: `<board_url>`
> Open the frame directly: `<board_url>?moveToWidget=<frame_id>`
> [N] nodes, [M] decision branches, [K] annotations. Built in Hamza style — black canvas, [colour list] borders, Caveat annotations. Walt-deletable any time via the Miro UI.

If any batch failed during build, surface the failed item count + the DSL of the failed batch verbatim so Walt can see what didn't land.

---

## DAILY-BRIEF INTEGRATION

When `@skills/brief-actioning.md` runs and a section instruction contains "create as Miro presentation" / "build a Miro board" / "Miro this":

1. Load THIS skill
2. Pass the section content (e.g. an AI Ideas item, a Nova Can Do task) as the topic source
3. Plan the flow from that content (Step 0)
4. Confirm with Walt (Step 0 close)
5. Execute Steps 1–6

The Miro URL gets surfaced in the brief-actioning final report alongside the other Notion writes.

---

## CONSTRAINTS REFERENCE (LEARNED 2026-05-14)

| Constraint | Cause | Workaround |
|---|---|---|
| `parent=alias` cross-batch fails silently | Alias scope is per-DSL-submission | Create FRAME in batch 1, use `?moveToWidget=<frame_id>` URL for all child batches |
| Shape `w<8` rejected | Minimum width validation | Use `w=8` minimum for connector lines |
| Text `w<80` for short content rejected | Minimum width for short strings | Use `w=80` for arrowheads / single-char items |
| Empty content `""` rejected on SHAPE | Required content field | Use `" "` (single space) for visually-blank shapes |
| `border_width=0` rejected | Minimum border width | Use `border_width=1` with border_color matched to fill |
| Bulk batches ≥4–10 items intermittently HTTP 400 | Unclear (validation timing or rate limit) | Chunk to ≤3 items per `layout_create` call |
| Flowchart DSL forces pastel-fill nodes with dark text | Built-in palette only allows light fills | Don't use `diagram_create` flowchart for this style — pure `layout_create` only |

---

## OUTPUT CONTRACT

- One Miro board, one frame, structured content inside.
- No Notion writes from this skill (the Miro URL IS the artefact). If Walt wants the URL surfaced in a Notion tracker, that's a follow-on rule, not part of this skill.
- No file writes. The skill operates entirely through the Miro MCP.
- Source attribution — if the topic came from a daily brief, the frame description includes a line like *"Source: Daily Brief YYYY-MM-DD — [section]. Walt instruction: [verbatim]."*

---

## EXAMPLE INVOCATION (end-to-end)

User: *"Create a Miro presentation about how a plumber's CRM workflow works"*

Nova:
1. (Step 0) Drafts plain-text flow: 5 nodes — *Customer books appointment → POST to CRM → New Contact Created → Wait 24h → Confirmation SMS (Yes/No decision) → Yes branch: Schedule, No branch: Reschedule SMS.* Shows Walt. Walt confirms.
2. (Step 1) `board_create` named `"[Course] Plumber CRM workflow"` — confirmation surfaced first. Board URL returned.
3. (Step 2) `layout_create` adds the FRAME alone, captures `moveToWidget` ID.
4. (Step 3a) `layout_create` adds nodes 1–3 (batch of 3).
5. (Step 3b) `layout_create` adds nodes 4–5 (batch of 2).
6. (Step 3c) Connector segments + arrowhead for 1→2 (batch of 3).
7. (Step 3d) Annotation for 1→2 (batch of 1).
8. (Step 3e+) Continue connectors + annotations for 2→3, 3→4, 4→5.
9. (Step 3f) Decision-node split for the final Yes/No — two connector segments + two branch nodes (chunked to ≤3 per call).
10. (Step 6) Reports URL to Walt.
