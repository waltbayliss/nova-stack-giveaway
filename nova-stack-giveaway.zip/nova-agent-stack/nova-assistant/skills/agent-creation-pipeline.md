---
name: agent-creation-pipeline
description: The 8-step pipeline for building every new agent in Walt's stack. Hard-gated at Steps 3 (quick-search) and 4 (PRD review). No agent reaches agent-builder without these gates clearing. Use this skill for new agent builds AND major upgrades to existing ones.
---

# Skill: agent-creation-pipeline

**When to invoke:** Any new agent build, or any major upgrade to an existing agent (new capability, new integration, new src/ logic). Skip only for minor fixes (typos, broken paths, config values).

**Hard rule:** Steps run in order. No skipping. If Walt says "build [agent] — brief is ready" and Steps 1–4 aren't done, run the missing steps first.

---

## STEP 1 — INTAKE

Run `@skills/intake.md`. Brief saved to `pending-builds/<slug>.md` on GitHub.

---

## STEP 2 — DRAFT PRD

The brief from intake **is** the v0 PRD at `pending-builds/<slug>.md`. No separate step required.

---

## STEP 3 — QUICK-SEARCH (HARD GATE)

```
Agent(
  subagent_type="general-purpose",
  prompt="""You are agent-quick-searcher. Read /home/walt/agents/agent-quick-searcher/CLAUDE.md as your full operating instructions and source of truth, then /home/walt/CLAUDE.md for VPS overrides. Then execute: quick-search <agent-name> — <one-line purpose>. Return findings in the full OUTPUT FORMAT — GitHub findings table, Perplexity findings, Feature Menu (with per-repo feature extraction and consolidated Build-with-these list), Repos Flagged for Security Vetting, and Recommendation. The Feature Menu is the primary deliverable — do not truncate."""
)
```

**Output:** exists (yes/no), worth-adapting (yes/no), relevance score, Feature Menu, flagged repos.

**Pass-through:** verbatim report. The Feature Menu section MUST be visible — copy it into Nova's reply if the agent panel collapses it.

**Branch:** if HIGH RELEVANCE repos found → fire `@skills/security-bouncer.md` in parallel before Step 4.

**Gate:** do not proceed past Step 3 until quick-search report is in hand.

---

## STEP 4 — PRD REVIEW (HARD GATE)

```
Agent(
  subagent_type="general-purpose",
  prompt="""You are agent-prd-reviewer. Read /home/walt/agents/agent-prd-reviewer/CLAUDE.md as source of truth, then /home/walt/CLAUDE.md for VPS overrides. Then execute the 9-point review on this brief: <paste full brief from pending-builds/<slug>.md>. Use this prior-art context: <paste full quick-searcher Feature Menu>. Ensure every Feature Menu item is either incorporated into the upgraded PRD or explicitly excluded with a reason. Write the upgraded PRD to waltbayliss/nova-assistant/pending-builds/<slug>-reviewed.md via curl. Return the review report (9-point table + blocking items + additions + verdict)."""
)
```

**Output:** 9-point review table, upgraded PRD path, verdict.

**Pass-through:** verbatim.

**Gate:** do not proceed past Step 4 until upgraded PRD is written AND verdict is in hand.

---

## STEP 5 — NOVA APPROVAL GATE

Show Walt: the upgraded PRD link + the review verdict + any reviewer-flagged decisions (cron timing, integration choices, etc.). Wait for explicit "go" before proceeding.

No silent assumptions. No "I'll take that as a yes."

---

## STEP 6 — BUILD (default: run_in_background=true)

```
Agent(
  subagent_type="general-purpose",
  run_in_background=true,
  prompt="""You are agent-builder. Read /home/walt/agents/agent-builder/CLAUDE.md as source of truth, then /home/walt/CLAUDE.md for VPS overrides. Then execute: build agent-<name> from the upgraded PRD at waltbayliss/nova-assistant/pending-builds/<slug>-reviewed.md. Feature Menu from quick-search: <paste full Feature Menu>. Run Step 1 (Feature Integration Review) before generating any files — document each incorporate/skip/improve decision in DECISIONS.md. Push the full Nova-standard structure (8 docs + CLAUDE.md + skills + wiki + .env.example + src/ if needed) to waltbayliss/agent-<name>. Apply @skills/claude-md-quality.md when writing the new CLAUDE.md. Confirm completion with repo URL + file manifest."""
)
```

Builds typically take 5–10 minutes. On completion → Telegram via nova-telegram (Rule 22 in CLAUDE.md).

---

## STEP 7 — CODE REVIEW (two-pass)

See `@skills/code-review.md`. Pass 1 → fixes → Pass 2. ESCALATE = stop, surface to Walt, do not sign off.

---

## STEP 8 — REGISTER

1. Add agent to `docs/AGENT-REGISTRY.md` via curl PUT to GitHub.
2. Update master-context.md agent count in walts-wiki via curl PUT.
3. Confirm to Walt: "<agent-name> built, reviewed (Pass 1 + Pass 2), signed off."

---

## Notes

- **No build is complete until Step 8 lands.** Pass 2 PASS verdict + registry entry + master-context bump.
- **Major upgrades to existing agents** follow the same flow. Quick-search is mandatory for upgrades that add new capability — what the best tools do is just as relevant when upgrading as when building.
- **Minor fixes** (typo corrections, broken paths, config values) skip the pipeline. Direct edit + commit is fine.
