#!/usr/bin/env python3
"""
Weekly newsletter Thursday auto-nudge.

Fires Thursday 08:00 AEST (Wed 22:00 UTC) via cron. Pulls this week's
candidate material (blog posts + YouTube videos from Notion) and pings Walt
on Telegram to start the newsletter interview. Does NOT draft or write
anything — the drafting/interview/[Employer]-ship happens with Nova when Walt
engages (see @skills/weekly-newsletter.md).

Run:  python3 newsletter_nudge.py [--dry-run]
Env:  NOTION_TOKEN, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
"""
from __future__ import annotations

import os
import sys
import json
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta
from pathlib import Path

HEARTBEAT_DIR = Path("/home/walt/agents/.heartbeats")

NOTION_TOKEN = os.environ.get("NOTION_TOKEN", "")
BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")

SMP_DB = "[REDACTED-ID]"        # Social Media Posts DB
YT_DB = "[REDACTED-ID]"          # YouTube Content Tracker
NOTION_VERSION = "2022-06-28"
WINDOW_DAYS = 7


def _post(url: str, payload: dict, headers: dict) -> dict:
    data = json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)


def _query_recent(db_id: str) -> list[dict]:
    """Return pages in db created within the last WINDOW_DAYS, newest first."""
    since = (datetime.now(timezone.utc) - timedelta(days=WINDOW_DAYS)).isoformat()
    payload = {
        "filter": {"timestamp": "created_time", "created_time": {"on_or_after": since}},
        "sorts": [{"timestamp": "created_time", "direction": "descending"}],
        "page_size": 25,
    }
    headers = {
        "Authorization": f"Bearer {NOTION_TOKEN}",
        "Notion-Version": NOTION_VERSION,
        "Content-Type": "application/json",
    }
    try:
        res = _post(f"https://api.notion.com/v1/databases/{db_id}/query", payload, headers)
        return res.get("results", [])
    except urllib.error.HTTPError as e:
        print(f"[notion] {db_id} query failed: {e.code} {e.read()[:200]!r}")
        return []
    except Exception as e:  # network etc.
        print(f"[notion] {db_id} query error: {e}")
        return []


def _title_of(page: dict) -> str:
    for prop in page.get("properties", {}).values():
        if prop.get("type") == "title":
            parts = prop.get("title", [])
            txt = "".join(p.get("plain_text", "") for p in parts).strip()
            if txt:
                return txt
    return "(untitled)"


def _select_value(page: dict, prop_name: str) -> str | None:
    prop = page.get("properties", {}).get(prop_name)
    if not prop:
        return None
    if prop.get("type") == "select" and prop.get("select"):
        return prop["select"].get("name")
    if prop.get("type") == "status" and prop.get("status"):
        return prop["status"].get("name")
    return None


def _multiselect_values(page: dict, prop_name: str) -> list[str]:
    prop = page.get("properties", {}).get(prop_name)
    if not prop or prop.get("type") != "multi_select":
        return []
    return [opt.get("name", "") for opt in prop.get("multi_select", [])]


def gather() -> tuple[list[str], list[str]]:
    blogs, videos = [], []
    for page in _query_recent(SMP_DB):
        platforms = [p.lower() for p in _multiselect_values(page, "Platform")]
        if "blog" in platforms:
            blogs.append(_title_of(page))
    for page in _query_recent(YT_DB):
        status = (_select_value(page, "Status") or "").lower()
        if status in ("published", "recorded"):
            videos.append(_title_of(page))
    return blogs, videos


def build_message(blogs: list[str], videos: list[str]) -> str:
    story = f'"{blogs[0]}"' if blogs else "[no blog this week — we'll pick a story]"
    video = f'"{videos[0]}"' if videos else "[no video this week — we'll teach a lesson]"
    lines = [
        "📰 *Newsletter time* — Thursday compile.",
        "",
        f"*Story of the week:* {story}",
        f"*Video / lesson:* {video}",
        "*Promo:* you tell me what you're promoting this week.",
        "",
        "Reply here to do the 5-question interview, or open Nova and say "
        "“do the newsletter”. Ships into [Employer] Friday, ready to send.",
    ]
    return "\n".join(lines)


def send_telegram(text: str) -> None:
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": text, "parse_mode": "Markdown"}
    try:
        _post(url, payload, {"Content-Type": "application/json"})
        print("[telegram] nudge sent")
    except urllib.error.HTTPError as e:
        print(f"[telegram] send failed: {e.code} {e.read()[:200]!r}")
        sys.exit(1)


def main() -> None:
    dry = "--dry-run" in sys.argv
    if not NOTION_TOKEN:
        print("NOTION_TOKEN not set")
        sys.exit(1)
    blogs, videos = gather()
    msg = build_message(blogs, videos)
    if dry:
        print("--- DRY RUN — would send: ---")
        print(msg)
        return
    if not (BOT_TOKEN and CHAT_ID):
        print("TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID not set")
        sys.exit(1)
    send_telegram(msg)
    HEARTBEAT_DIR.mkdir(parents=True, exist_ok=True)
    (HEARTBEAT_DIR / "newsletter-nudge").write_text(datetime.now(timezone.utc).isoformat())


if __name__ == "__main__":
    main()
