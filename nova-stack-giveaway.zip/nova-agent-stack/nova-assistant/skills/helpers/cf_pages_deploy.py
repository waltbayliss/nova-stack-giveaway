"""
nova-assistant/skills/helpers/cf_pages_deploy.py

Cloudflare Pages deploy + DNS helper for the build-slo-funnel skill (Hybrid model).

WHY THIS EXISTS
---------------
The funnel-builder Hybrid model hosts SLO funnel pages as static HTML on
Cloudflare Pages (full design control, programmatic deploy, automated DNS),
while [Employer] handles forms / products / payments / email / chat via
embedded snippets.

The Cloudflare MCP available on the VPS covers Workers / D1 / KV / R2 / DNS
but NOT Pages project deploys. This helper fills that gap:
  - deploy a local HTML directory to a Pages project (via wrangler)
  - attach a custom subdomain + create the CNAME (via CF REST API)

TOOLING
-------
- Pages deploy: `npx wrangler@3 pages deploy` (wrangler@3 supports Node 20;
  wrangler@4 requires Node 22 which the VPS doesn't have yet).
- DNS + zone + custom-domain: Cloudflare REST API v4 via `requests`.

ENV VARS REQUIRED
-----------------
- CLOUDFLARE_ACCOUNT_ID
- CLOUDFLARE_API_TOKEN   (needs Pages:Edit + DNS:Edit + Zone:Read scopes)

RETURN SHAPE
------------
Every function returns {ok, status, data, error} — never raises on
remote errors; the caller decides what's fatal.

USAGE
-----
    from skills.helpers.cf_pages_deploy import CFPagesDeployer
    cf = CFPagesDeployer()
    res = cf.deploy(local_dir="funnels/agent-templates/pages",
                    project_name="slo-agent-templates")
    if res["ok"]:
        pages_url = res["data"]["url"]            # https://slo-agent-templates.pages.dev
    cf.ensure_cname(subdomain="agent-templates",  # agent-templates.[personal-site]
                    target=pages_url, zone="[personal-site]")
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from typing import Any

import requests

try:
    from dotenv import load_dotenv
    load_dotenv("/home/walt/.env")
except ImportError:
    pass


CF_API_BASE = "https://api.cloudflare.com/client/v4"
WRANGLER_SPEC = "wrangler@3"  # pinned: wrangler@4 needs Node 22; VPS is on Node 20


class CFPagesDeployer:
    def __init__(
        self,
        account_id: str | None = None,
        api_token: str | None = None,
        timeout: int = 120,
    ):
        self.account_id = account_id or os.getenv("CLOUDFLARE_ACCOUNT_ID")
        self.api_token = api_token or os.getenv("CLOUDFLARE_API_TOKEN")
        self.timeout = timeout

        if not self.account_id:
            raise RuntimeError("CLOUDFLARE_ACCOUNT_ID not set in /home/walt/.env")
        if not self.api_token:
            raise RuntimeError("CLOUDFLARE_API_TOKEN not set in /home/walt/.env")

    # ──────────────────────────── internal ────────────────────────────

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
        }

    def _api(
        self,
        method: str,
        path: str,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{CF_API_BASE}{path}"
        try:
            resp = requests.request(
                method, url, headers=self._headers(),
                json=json_body, params=params, timeout=self.timeout,
            )
        except requests.RequestException as exc:
            return {"ok": False, "status": 0, "data": None, "error": f"network: {exc}"}

        try:
            payload = resp.json() if resp.text else {}
        except json.JSONDecodeError:
            payload = {"raw": resp.text}

        cf_ok = isinstance(payload, dict) and payload.get("success") is True
        ok = (200 <= resp.status_code < 300) and cf_ok
        return {
            "ok": ok,
            "status": resp.status_code,
            "data": payload.get("result") if ok else None,
            "error": None if ok else (payload.get("errors") or payload),
        }

    # ──────────────────────────── pages deploy ────────────────────────────

    def deploy(self, local_dir: str, project_name: str, branch: str = "main") -> dict[str, Any]:
        """
        Deploy a local directory of static files to a Cloudflare Pages project.

        Creates the project on first deploy (wrangler does this automatically
        when --project-name is given and CI=true avoids interactive prompts).
        Returns the deployment URL.
        """
        if not os.path.isdir(local_dir):
            return {"ok": False, "status": 0, "data": None,
                    "error": f"local_dir not found: {local_dir}"}

        env = os.environ.copy()
        env["CLOUDFLARE_ACCOUNT_ID"] = self.account_id
        env["CLOUDFLARE_API_TOKEN"] = self.api_token
        env["CI"] = "true"  # non-interactive

        cmd = [
            "npx", "--yes", WRANGLER_SPEC, "pages", "deploy", local_dir,
            f"--project-name={project_name}",
            f"--branch={branch}",
            "--commit-dirty=true",
        ]
        try:
            proc = subprocess.run(
                cmd, env=env, capture_output=True, text=True, timeout=300,
            )
        except subprocess.TimeoutExpired:
            return {"ok": False, "status": 0, "data": None,
                    "error": "wrangler deploy timed out after 300s"}

        output = (proc.stdout or "") + "\n" + (proc.stderr or "")
        # wrangler prints a line like: https://<hash>.<project>.pages.dev
        url_match = re.search(r"https://[a-z0-9.\-]+\.pages\.dev", output)
        deploy_url = url_match.group(0) if url_match else None

        if proc.returncode != 0:
            return {"ok": False, "status": proc.returncode, "data": None,
                    "error": output.strip()[-1500:]}

        return {
            "ok": True,
            "status": 0,
            "data": {
                "url": deploy_url,
                "alias": f"https://{project_name}.pages.dev",
                "project_name": project_name,
                "raw_tail": output.strip()[-500:],
            },
            "error": None,
        }

    def ensure_project(self, project_name: str, production_branch: str = "main") -> dict[str, Any]:
        """Create a Pages project explicitly (optional — deploy auto-creates)."""
        existing = self._api("GET", f"/accounts/{self.account_id}/pages/projects/{project_name}")
        if existing["ok"]:
            return {"ok": True, "status": 200, "data": {"existed": True, "project": existing["data"]}, "error": None}
        return self._api(
            "POST", f"/accounts/{self.account_id}/pages/projects",
            json_body={"name": project_name, "production_branch": production_branch},
        )

    # ──────────────────────────── dns ────────────────────────────

    def get_zone_id(self, zone: str) -> dict[str, Any]:
        res = self._api("GET", "/zones", params={"name": zone})
        if not res["ok"]:
            return res
        zones = res["data"] or []
        if not zones:
            return {"ok": False, "status": 404, "data": None,
                    "error": f"zone not found in this account: {zone}"}
        return {"ok": True, "status": 200, "data": {"zone_id": zones[0]["id"]}, "error": None}

    def ensure_cname(self, subdomain: str, target: str, zone: str, proxied: bool = True) -> dict[str, Any]:
        """
        Create or update a CNAME record `<subdomain>.<zone>` -> target.

        target may be a full URL (https://x.pages.dev) or a bare hostname;
        the scheme is stripped automatically.
        """
        zres = self.get_zone_id(zone)
        if not zres["ok"]:
            return zres
        zone_id = zres["data"]["zone_id"]

        record_name = f"{subdomain}.{zone}"
        target_host = re.sub(r"^https?://", "", target).rstrip("/")

        # Look for an existing record
        existing = self._api(
            "GET", f"/zones/{zone_id}/dns_records",
            params={"type": "CNAME", "name": record_name},
        )
        body = {
            "type": "CNAME",
            "name": record_name,
            "content": target_host,
            "proxied": proxied,
            "ttl": 1,  # 1 = automatic
        }
        if existing["ok"] and existing["data"]:
            record_id = existing["data"][0]["id"]
            return self._api("PUT", f"/zones/{zone_id}/dns_records/{record_id}", json_body=body)
        return self._api("POST", f"/zones/{zone_id}/dns_records", json_body=body)

    def attach_custom_domain(self, project_name: str, domain: str) -> dict[str, Any]:
        """Attach a custom domain to a Pages project (handles cert provisioning)."""
        return self._api(
            "POST", f"/accounts/{self.account_id}/pages/projects/{project_name}/domains",
            json_body={"name": domain},
        )

    # ──────────────────────────── smoke ────────────────────────────

    def smoke(self, zone: str = "[personal-site]") -> dict[str, Any]:
        """Verify token scopes: list Pages projects + resolve the zone."""
        projects = self._api("GET", f"/accounts/{self.account_id}/pages/projects")
        zone_res = self.get_zone_id(zone)
        return {
            "ok": projects["ok"] and zone_res["ok"],
            "status": "ok" if (projects["ok"] and zone_res["ok"]) else "fail",
            "data": {
                "pages_list": projects["ok"],
                "pages_status": projects["status"],
                "zone_resolved": zone_res["ok"],
                "zone_id": (zone_res.get("data") or {}).get("zone_id"),
            },
            "error": None if (projects["ok"] and zone_res["ok"]) else {
                "pages_error": projects["error"],
                "zone_error": zone_res["error"],
            },
        }


def _main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: cf_pages_deploy.py <smoke|deploy|ensure-cname>", file=sys.stderr)
        return 1
    cmd = argv[1]
    cf = CFPagesDeployer()

    if cmd == "smoke":
        result = cf.smoke(argv[2] if len(argv) > 2 else "[personal-site]")
    elif cmd == "deploy" and len(argv) >= 4:
        result = cf.deploy(local_dir=argv[2], project_name=argv[3])
    elif cmd == "ensure-cname" and len(argv) >= 5:
        result = cf.ensure_cname(subdomain=argv[2], target=argv[3], zone=argv[4])
    else:
        print(f"unknown or malformed command: {' '.join(argv[1:])}", file=sys.stderr)
        return 1

    print(json.dumps(result, indent=2, default=str))
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
