# Skill — DR Sales Page Standard

**Owner:** Nova | **Last reviewed:** 2026-05-21 | **Trigger:** any time a sales/landing page is built for a funnel or offer.

## Why this exists

Session 98: Nova built a thin SaaS-style landing page for the $5 SLO and bypassed agent-copywriter for the page copy. Walt rejected it — he expects real direct-response sales pages with the depth of ClickFunnels / GuruOS bundle pages / PR Rage. This skill defines the standard and the hard gate so it never regresses.

## HARD GATE — non-negotiable

**Sales-page COPY is always written by agent-copywriter. Nova never writes page copy herself.** Nova assembles the copywriter's output into HTML and handles design — but the persuasion copy is the trained specialist's job, every time. A page built without routing copy through agent-copywriter is incomplete. (This also applies inside `build-slo-funnel.md` Stage 1.)

## What a DR sales page is (and isn't)

- ❌ NOT a landing page: a hero, a few feature bullets, one CTA, ~500 words.
- ✅ A long-form direct-response sales page: 2,500–3,500 words for a low-ticket front-end; 4,000–6,000 for a core offer. Multiple CTAs. Full objection demolition. Value stacking with price anchoring.

Reference benchmarks (studied 2026-05-21): GuruOS bundle (~31 sections, ~8–9k words), PR Rage (Walt's own — problem→agitation→authority→solution→proof→CTA), ClickFunnels, AdEspresso University.

## THE SKELETON (~18 blocks — every DR page hits these)

1. **Pre-head + Hero** — eyebrow, hook headline, subheadline, primary CTA, hero visual/VSL slot
2. **Social-proof bar** — one-line credibility strip (logos / user count / track record)
3. **Problem identification** — name the pain specifically (Kennedy directness)
4. **Agitation** — stack the cost of staying stuck (Kennedy/Halbert)
5. **Founder story** — origin narrative, why this exists (Halbert story-driven)
6. **Solution reveal** — the offer named + positioned (Brunson epiphany bridge)
7. **How it works** — clear sequential steps, visual
8. **Value stack** — itemise components, each with a value line, then anchor against build cost/time (Hormozi value-stacking)
9. **Who it's for / not for** — two short lists (qualifies + disqualifies)
10. **Proof / testimonials / case studies** — real only. Mark `[TESTIMONIAL PLACEHOLDER]` if none yet — never fabricate (ACL)
11. **Offer + price anchor** — stack value → reveal price → justify (Brunson/Hormozi)
12. **Risk reversal / guarantee** — explicit, honest (Abraham)
13. **Bonus stack** — if any
14. **Scarcity / urgency** — honest only. No fake countdowns
15. **Binary-choice close** — two futures (Kennedy/Brunson)
16. **FAQ** — 8–12 questions, objection demolition
17. **Final CTA + PS** — restate offer; PS reinforces promise or risk reversal
18. **Footer + legal** — earnings disclaimer where any results are implied

Lean front-end pages may compress blocks 7+13, but never skip: problem, agitation, founder story, value stack, guarantee, FAQ, binary close.

## Persuasion checklist (Nova verifies before sign-off)

- [ ] **WIIFM — every block leads with the buyer's outcome, not the feature.** This is the bar (set on the $5 page, 2026-05-21). After every feature, the copy must answer "so what does that mean for ME?" In the value stack especially: lead the bold line with the outcome the buyer *feels*, name the deliverable second. The scanner's eye must land on benefit, never on "Feature #2". People buy the transformation, not the parts list.
- [ ] Specificity over abstraction throughout (real numbers, named things)
- [ ] At least 3 distinct CTAs down the page
- [ ] Value stack with explicit anchoring (what it's worth / what it cost to build vs the price)
- [ ] Risk reversal present
- [ ] Objections demolished in FAQ (the real top 4–5 for this offer)
- [ ] No fabricated proof — track-record proof or marked placeholders only
- [ ] Voice matches the owner (no AI slop, no "in today's fast-paced world")
- [ ] Word count in range (2.5–3.5k front-end / 4–6k core)

## Design requirements (Nova's assembly job)

Long-form copy needs supporting structure: testimonial cards, value-stack boxes, a guarantee badge, an FAQ accordion, repeated CTA buttons, a scarcity/urgency block, section rhythm (alternating emphasis). Match the brand (for Walt: dark, minimal, futuristic). The design serves the copy — never the reverse.

## Related

- `build-slo-funnel.md` Stage 1 (copy) routes here
- agent-copywriter: `/home/walt/agents/agent-copywriter/CLAUDE.md`
