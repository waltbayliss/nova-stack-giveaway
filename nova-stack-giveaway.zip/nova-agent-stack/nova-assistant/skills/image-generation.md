---
name: image-generation
description: Nova's image-creation standard. Any agent build or task that generates images uses Nano Banana (Gemini image model), one-shot, with real reference photos for people. Loaded when designing or building any agent that produces images, or when Nova generates an image directly.
---

# Skill: image-generation

**When to invoke:** Any time an agent build, a task, or Nova herself needs to
*generate* an image — thumbnails, social images, portraits, scenes, composites.
This is the stack-wide standard. Proven in `agent-youtube-thumbnailer`
(Session 85) — see its `src/image_generator.py` for the reference implementation.

---

## The standard

**Use Google's Nano Banana (Gemini image model) for image generation.**

| Model | ID | Use |
|---|---|---|
| Nano Banana Pro | `gemini-3-pro-image-preview` | Default — best identity lock, best in-image text, 2K/4K. ~$0.24/image. |
| Nano Banana (2.5 Flash Image) | `gemini-2.5-flash-image` | Cheaper fallback. |

Auth: `GEMINI_API_KEY` (in `/home/walt/.env`). SDK: `google-genai`.

`-preview` model IDs can change — pin the ID, allow an env override, watch for GA.

---

## Hard rules

1. **For any image of a person, generate ONE-SHOT from real reference photos.**
   Pass 2-4 real photos of the person as image Parts alongside the prompt. The
   model preserves their identity and **relights them into the scene** in a
   single pass. Walt's reference set: `/home/walt/agents/_seed-assets/walt-greenscreen-poses/`.
2. **Never chroma-key a cutout and composite it onto a separate background.**
   Separately-generated layers never share a lighting model — the result looks
   pasted-on. The one-shot model handles wrap light, rim light, contact shadows.
   (This was the Session 85 failure mode the rebuild fixed.)
3. **Always instruct the model to (a) preserve the exact face/identity from the
   reference photos and (b) relight the subject to match the scene** — reference
   photos are often flatly lit; without this the flat look carries over.
4. **Let the model render short headline text natively** (1-3 words, ALL CAPS) —
   it integrates with the scene lighting. Pillow text overlay is a flat last
   resort only.

---

## Prompt structure — SLCT

Structured prompts succeed ~90% vs ~30% unstructured. Order every prompt:

1. **Subject** + exaggerated expression ("intense raised-eyebrow", "shocked open-mouth")
2. **Composition** — framing, and explicit empty space ("leave the right third clean for text")
3. **Lighting** — name the key + rim light colours
4. **Colour** — bold, high-saturation, complementary pairs (orange/teal, blue/orange, magenta/yellow)
5. **Camera** — lens language ("35mm lens", "shallow depth of field", "sharp focus on the eyes")
6. **Text** — the headline in quotes, exact spelling

Always include: "preserve the exact face/identity from the reference photos",
"relight the subject for the scene", aspect ratio, and the output use
("professional high-CTR YouTube thumbnail", etc.).

---

## API pattern (`google-genai`)

```python
from google import genai
from google.genai import types

client = genai.Client(api_key=GEMINI_API_KEY)
ref_parts = [types.Part.from_bytes(data=p.read_bytes(), mime_type="image/png")
             for p in reference_photos]          # 2-4 real photos of the person
resp = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[slct_prompt] + ref_parts,
)
img_bytes = next(p.inline_data.data for p in resp.candidates[0].content.parts
                 if getattr(p, "inline_data", None))
```

Retry once, then fall back to `gemini-2.5-flash-image`.

---

## Gotchas

- `-preview` IDs change — pin + env-override.
- Flat-lit reference photos → always tell the model to relight.
- Text >3 words drops below ~80% reliability — keep headlines short.
- Pro output may carry a SynthID/visible watermark on some tiers — verify before publishing.
- Cost is real at scale (~$0.24/image) — batch where possible.
