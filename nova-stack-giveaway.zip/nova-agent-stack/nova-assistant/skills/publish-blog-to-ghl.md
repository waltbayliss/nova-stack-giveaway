---
name: publish-blog-to-ghl
description: How Nova (and agent-social-poster) publish a blog post from the Social Media Posts DB to a [Employer] blog site. Covers the API contract, required Notion fields, and the auto-derivations the poster applies.
---

# Skill: publish-blog-to-ghl

**When to invoke:** Whenever a Notion row in the Social Media Posts DB lands with `Platform=Blog` and the row is moving toward publication. Walt approves the row by setting `Status=Approved` and agent-social-poster picks it up automatically on its 3-minute LaunchAgent. This skill documents the contract so anyone writing blog posts knows what to populate, and so the poster's code can be maintained without re-discovering the API shape.

**The runtime owner is `agent-social-poster/src/ghl_blog_poster.py`** — this skill is the spec it implements.

---

## [Employer] Blog API contract

**Endpoint:** `POST https://services.leadconnectorhq.com/blogs/posts`

**Headers:**
```
Authorization: Bearer $GHL_PIT_TOKEN
Version: 2021-07-28
Content-Type: application/json
```

**Required body fields:**
- `locationId` — from `$GHL_LOCATION_ID`
- `blogId` — the GHL blog site to publish to (see "Blog site resolution" below)
- `status` — `"PUBLISHED"` or `"DRAFT"`. Walt's approval → `PUBLISHED`.

**Optional body fields the poster sets:**
- `title` — from Notion `Title` (required by GHL UX even though API doesn't enforce it)
- `rawHTML` — from Notion `Full post body`, markdown-converted to HTML if not already HTML
- `urlSlug` — from Notion `URL Slug`, or auto-derived from title via slugify (lowercase, hyphens, ≤120 chars)
- `description` — from Notion `Meta Description` or fallback to `Caption`, ≤300 chars
- `imageUrl` + `imageAltText` — from Notion `Image` file URL + title
- `author` — `$GHL_BLOG_AUTHOR_ID` or first author returned by `GET /blogs/authors`
- `categories` — list of GHL category `_id`s resolved from Notion `Blog Category` multi-select labels
- `tags` — currently not piped through (GHL accepts a `tags` array of strings if needed later)

**Response:** `{ "blogPost": { "_id": "...", "blogId": "...", "urlSlug": "...", ... } }`

GHL does **not** return a public-facing URL on creation. The poster writes a stable planner URL back to Notion's `Post URL` field:
```
https://app.[Employer]/v2/location/{locationId}/sites/blogs/{blogId}/post/{postId}
```

Walt's public URL becomes available once the blog site renders the post — visible from the planner link.

---

## Supporting endpoints (used for resolution)

| Need | Endpoint | Pagination param | Max `limit` |
|---|---|---|---|
| List blog sites | `GET /blogs/site/all?locationId=$LOC&limit=50&skip=0` | `skip` (NOT `offset`) | 50 |
| List categories | `GET /blogs/categories?locationId=$LOC&limit=50&offset=0` | `offset` (required, not optional) | **50** (hard cap — `limit=100` returns 422 "limit must not be greater than 50") |
| List authors | `GET /blogs/authors?locationId=$LOC&limit=50&offset=0` | `offset` | 50 |

⚠️ **Both pagination param name and limit cap are per-endpoint** — `blogs/site/all` uses `skip` and accepts higher limits; `blogs/categories` and `blogs/authors` require `offset` and cap at 50. The poster hard-codes the correct shape per endpoint and paginates by incrementing offset until a short page returns.

---

## Notion row contract — what Nova writes

For a blog post, the SMP DB row must carry:

| Notion property | Required? | Source / default |
|---|---|---|
| `Title` | yes | The blog title |
| `Platform` (multi-select) | yes | Must include `Blog` |
| `Full post body` | yes | Markdown or HTML body. Markdown is auto-converted. |
| `Image` (file) | recommended | Featured image — uses the same image-creator pipeline as social posts |
| `Blog Site` (select) | recommended | `Default Blog Site` / `From Advertising to AI` / `Influencer Empires`. Defaults to `Default Blog Site`. |
| `Blog Category` (multi-select) | recommended | One or more of: `Leadership`, `AI and Tech`, `Professional Development`, `Side Hustles`, `Startups`, `Sales`, `Mistakes In Business` |
| `URL Slug` (text) | optional | Auto-derived from Title if blank |
| `Meta Description` (text) | optional | SEO description, falls back to `Caption` if blank, ≤300 chars |
| `Caption` (text) | optional | Backup for Meta Description |
| `Status` (status) | yes | Walt flips to `Approved` when ready to publish |
| `Audit Status` (select) | yes | Set to `Pending Audit` on create — content-quality-auditor runs first per the standard flow |

The poster will refuse a blog row whose `Full post body` is shorter than 200 chars — keeps half-finished drafts out of production.

---

## Image flow

Same as social posts:
1. agent-image-creator generates the featured image first (per CLAUDE.md rule 13)
2. Image lands in the `Image` property on the SMP row
3. Poster downloads the source image, **re-uploads to GHL `/medias/upload-file`** to get a short GHL CDN URL, then sends that as `imageUrl` in the blog payload

**Why the re-upload (discovered 2026-05-21 live):** GHL's `/blogs/posts` endpoint returns **404 Not Found** (not 400, not 422 — *misleading*) when `imageUrl` is a long signed source URL. Notion's S3 URLs are ~1700 chars with full AWS signature; GHL chokes on them. The exact same payload with a short GHL CDN URL returns 201. On any image-upload failure, the poster continues without an image rather than failing the publish.

---

## Manual one-off publish (rare)

If something needs to be pushed past the poster, the minimal viable payload is:

```bash
TOKEN=$(grep ^GHL_PIT_TOKEN /home/walt/.env | cut -d= -f2- | tr -d '[:space:]')
LOC=$(grep ^GHL_LOCATION_ID /home/walt/.env | cut -d= -f2- | tr -d '[:space:]')

curl -X POST "https://services.leadconnectorhq.com/blogs/posts" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Version: 2021-07-28" \
  -H "Content-Type: application/json" \
  -d '{
    "locationId":"'$LOC'",
    "blogId":"cgsoAxMqtUBujifgQDAn",
    "status":"PUBLISHED",
    "title":"...",
    "rawHTML":"<p>...</p>",
    "urlSlug":"...",
    "description":"..."
  }'
```

But the right path is **always** the SMP DB row + poster — that preserves audit/approval/wiki-log.

---

## Known quirks (discovered 2026-05-21 during build + first live publish)

- **No DELETE endpoint.** `DELETE /blogs/posts/{id}` returns 404. Test posts stay as drafts and must be cleaned up manually in GHL UI.
- **Archived flag is read-only at the API level.** Sending `"archived": true` in PUT is accepted but the field stays `false`.
- **Auth on `Version: 2023-02-21`** is what the public docs claim; `Version: 2021-07-28` (the same version social posts use) works fine and is what the poster sends — keep both versions in mind if a 401 ever shows up.
- **`/blogs/categories` and `/blogs/authors` cap `limit` at 50.** Sending `limit=100` returns 422 "limit must not be greater than 50". `/blogs/site/all` does not have this cap. Poster now paginates via offset increments.
- **Long source imageUrls trigger 404 on `/blogs/posts`.** Empirically confirmed: ~1700-char Notion S3 URL → 404; same payload with short URL → 201. Always re-upload via `/medias/upload-file` first. The 404 message is misleading because it points to `/blogs/posts` (correct path) when the actual fault is the imageUrl content.
- **Default Blog Site is not Walt's blog.** GHL returns 3 sites; the first is named "Default Blog Site" but Walt's actual blog is `cX4ShweP35iDC1seW5Xv` ("From Advertising to AI"). The SMP DB `Blog Site` property defaults to "From Advertising to AI" — change the default if Walt's primary blog ever changes.
