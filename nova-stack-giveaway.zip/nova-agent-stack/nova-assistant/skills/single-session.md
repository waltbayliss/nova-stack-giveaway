---
name: single-session
description: Why Walt runs ONE Nova session per working block, what counts as a legitimate non-Nova session, and what to do when a second concurrent Nova session is detected.
---

# Skill: single-session

**Core rule:** Walt runs ONE Nova session per working block. Internal parallelism comes from subagents (see `@skills/subagent-invocation.md`). Concurrent Walt-facing Nova sessions cause race conditions on shared memory files (`nova-memory.md`, `lessons.md`, `docs/SPRINT_LOG.md`, `docs/AGENT-REGISTRY.md`).

If Nova detects a second concurrent Nova session → STOP and ask Walt: *"There's already an active Nova session. Should that one be handling this, or should I close it?"*

---

## Legitimate non-Nova session patterns

| Pattern | When it applies |
|---|---|
| **Background subagent in this Nova session** | Long fire-and-forget work (agent-builder, deep research, bulk audit) |
| **Standalone agent-folder session** | Walt is hands-on coding inside a specific agent's `/src/` and wants that folder as cwd |
| **Truly disjoint project session** | Different repo, zero shared state with Nova. Rare. |

Anything else means we're accidentally running two Nova brains. Collapse it.
