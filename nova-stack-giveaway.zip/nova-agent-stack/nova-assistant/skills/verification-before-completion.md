---
name: verification-before-completion
description: Use before claiming any work is complete, fixed, passing, or done — before committing, pushing, creating a PR, signing off a build, or moving to the next task. Requires running the verification command and reading its output before any success claim. Reinforces the Definition of Done in CLAUDE.md.
---

# Skill: verification-before-completion

**When to invoke:** Before ANY completion or success claim — yours or a subagent's. This is the operational enforcement of the **Definition of Done** (CLAUDE.md, rule 18). The DoD lists *what* must be true; this skill enforces *proving* it before you say so.

*Adapted for Nova from obra/superpowers (MIT). Aligns with Nova's existing rule: "A PASS verdict must reference concrete evidence — not judgement."*

*Validated 2026-05-26 (RED→GREEN subagent test, 2 scenarios): INCONCLUSIVE — the no-skill baseline already refused false completion claims (both the "confirm tests pass" and the "exit 0 ≠ file contents" scenarios). No measurable behavioural delta against a strong fresh-context model. Retained as the codified gate behind rules 18/7; expected value is under degraded context, weaker agent models, and real (non-thought-exercise) pressure — not a demonstrated behavioural flip.*

---

## The Iron Law

```
NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE
```

If you haven't run the verification command *in this message*, you cannot claim it passes.

## The Gate Function

```
BEFORE claiming any status or expressing satisfaction:
1. IDENTIFY — what command proves this claim?
2. RUN — execute the full command, fresh
3. READ — full output, exit code, count failures
4. VERIFY — does the output confirm the claim?
       NO  → state the actual status with evidence
       YES → state the claim WITH the evidence
5. ONLY THEN make the claim
Skip any step = asserting, not verifying.
```

## What each claim actually requires

| Claim | Requires | NOT sufficient |
|---|---|---|
| Tests pass | Test output: 0 failures | "should pass", a previous run |
| Linter/typecheck clean | Tool output: 0 errors | partial check, extrapolation |
| Build succeeds | Build exit 0 | linter passed, logs "look good" |
| Bug fixed | Original symptom re-tested: gone | code changed, assumed fixed |
| File written / hook fires | `ls` / read it back / trigger it | "the Write succeeded" |
| Subagent completed | Check the actual diff/output | the agent reported "success" |
| Requirements met | Line-by-line against the brief | "tests pass, so done" |

This maps directly onto Nova's rule 7 (surface subagent reports verbatim) and the VPS habit of reading files back, checking `git log` SHAs, and confirming links resolve.

## Red Flags — STOP

- "should", "probably", "seems to"
- "Great!" / "Perfect!" / "Done!" *before* running verification
- About to commit / push / PR / sign off a build without fresh evidence
- Trusting a subagent's success report without checking the diff
- "Just this once" / "I'm confident" / "I'm tired, ship it"
- Any wording implying success without having run the check

## Rationalization counters

| Excuse | Reality |
|---|---|
| "Should work now" | Run the verification. |
| "I'm confident" | Confidence ≠ evidence. |
| "Linter passed" | Linter ≠ compiler ≠ runtime. |
| "Agent said success" | Verify the diff independently (rule 7). |
| "Partial check is enough" | Partial proves nothing. |

## The bottom line

Run the command. Read the output. THEN claim the result. A task with any unverified DoD box is `in_progress`, not `done`. If Walt ever has to say "I don't believe you," the gate was skipped — log a lesson via `@skills/self-improve.md`.
