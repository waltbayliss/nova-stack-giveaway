---
name: session-close
description: Nova's end-of-session checklist. Updates sprint log, nova-memory, agent registry, lessons (if corrections), commits and pushes to GitHub via git, runs permission cleanup, then confirms close to Walt. Triggered by session-end signal or "close the session".
---

# Skill: session-close

**When to invoke:** End of every working block. Walt says "close the session", or it's the natural close of the conversation.

---

## Checklist

### 1. Update `docs/SPRINT_LOG.md`
What was done, what broke, what's next. Append a new entry with today's date and session number.

### 2. Update `nova-memory.md`
New patterns, preferences, learnings discovered this session. Walt's tone signals. Cross-session knowledge.

### 3. Update `docs/AGENT-REGISTRY.md`
Only if any agents were created or modified this session.

### 4. Update `lessons.md` (if corrections occurred)
Any correction from Walt this session — append a lesson entry. Format: Date / Mistake / Rule / Apply When.

### 4b. Commit and push all nova-assistant doc changes via git
All edits from steps 1–4 (and 6–7) are committed to the repo with **git**, not curl PUT. Because boot synced the active checkout to `origin/main`, this session's commits stack cleanly on top:
```
git fetch origin
git rebase origin/main          # safety net — fast-forwards if origin moved (rare, single-session)
git add docs/SPRINT_LOG.md nova-memory.md docs/AGENT-REGISTRY.md lessons.md NEXT-SESSION.md .claude/settings.json
git commit -m "session NN close: <one-line summary>"
git push origin HEAD:main       # pushes the worktree branch's commits to main
```
This is what advances the local refs in lockstep with `origin` — the thing curl PUT never did, which is why sessions kept starting behind. **Never close nova-assistant via curl PUT.**

### 5. Save valuable outputs to walts-wiki
```
PUT https://api.github.com/repos/waltbayliss/walts-wiki/contents/Walt's%20Wiki/Claude%20Sessions/Raw/[YYYY-MM-DD-topic].md
```

### 6. Permission cleanup (mandatory)
Run `@skills/permission-cleanup.md`. Audit Bash/MCP commands used this session, add missing safe-operation patterns to `.claude/settings.json`, push to GitHub.
Report to Walt: "[N] permission patterns added."

### 7. Update NEXT-SESSION.md
Priority 1/2/3 items + system state. The next session boot will surface these.

### 8. Agent-repo hygiene sweep (added 2026-05-21 — Session 97)
Before declaring close, sweep every agent repo for dirty trees. Any agent the session edited — and the full set as a safety net — must end the session clean. No more silently-abandoned WIP.

```bash
for agent in $(ls -d /home/walt/agents/agent-* /home/walt/agents/content-agent /home/walt/agents/ghl-agent /home/walt/agents/google-workspace-agent /home/walt/agents/research-agent /home/walt/agents/youtube-agent 2>/dev/null); do
  dirty=$(git -C "$agent" status --porcelain 2>/dev/null)
  if [ -n "$dirty" ]; then
    echo "DIRTY: $(basename $agent)"
    git -C "$agent" status --short
  fi
done
```

For each dirty repo:
- If the diff is intentional work from this session → `git add`, commit with a clear message tying it to the session, `git push origin main`.
- If the diff is runtime noise (a tracked file the agent shouldn't be mutating, or a path the canonical `.gitignore` missed) → fix the architectural cause: either rewire the agent code to write to a gitignored runtime path (`runtime-journal.md`, `logs/`) or extend `.gitignore`. Commit + push.
- If the diff is genuinely unknown → `git stash push -m "session-NN-unknown-$(date +%Y%m%d)"` and flag to Walt at close.

The session does not close until every agent repo's `git status --short` is empty. See `@skills/claude-md-quality.md` principle 10 — agents must never mutate tracked files at runtime; any session that ends with dirty agent repos has either real WIP to commit or a discipline bug to fix.

### 9. Confirm close
> "Session closed. Memory updated. Agent repos clean. Nova standing by."

---

## Hard rules

- **nova-assistant's own repo closes via `git commit` + `git push origin HEAD:main`** — never curl PUT. curl PUT writes to `origin` without advancing any local ref, which leaves every subsequent worktree branched off a stale HEAD. The `git push` rule keeps local and `origin` in lockstep. curl-via-GitHub-API stays ONLY for repos where the GitHub MCP / git remote is genuinely the broken path: `walts-wiki` and other agent repos (see `/home/walt/CLAUDE.md`). nova-assistant's git remote works — use it.
- **Memory files MUST be updated** — Rule 7 in CLAUDE.md. Non-negotiable.
- **Permission cleanup is mandatory every session** — zero prompts for obviously safe operations is the goal.
- **Agent-repo hygiene sweep is mandatory every session** — Step 8. Zero dirty trees at close. Walt's high-performance team is only as clean as the last session that touched it.
