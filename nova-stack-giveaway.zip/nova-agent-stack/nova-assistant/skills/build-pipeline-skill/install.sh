#!/usr/bin/env bash
# Build Quality Pipeline — Claude Code Skill Installer
# Usage: bash install.sh
# Or: curl -fsSL https://raw.githubusercontent.com/waltbayliss/skill-build-pipeline/main/install.sh | bash

set -e

SKILL_NAME="build-pipeline"
SKILLS_DIR="${HOME}/.claude/skills"
INSTALL_DIR="${SKILLS_DIR}/${SKILL_NAME}"
REPO_URL="https://github.com/waltbayliss/skill-build-pipeline.git"
RAW_BASE="https://raw.githubusercontent.com/waltbayliss/skill-build-pipeline/main"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Build Quality Pipeline — Skill Installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Create skills directory if it doesn't exist
mkdir -p "${SKILLS_DIR}"

# Check if already installed
if [ -d "${INSTALL_DIR}" ]; then
  echo "⚠️  Skill already installed at ${INSTALL_DIR}"
  read -r -p "   Overwrite with latest version? [y/N] " response
  if [[ ! "$response" =~ ^[Yy]$ ]]; then
    echo "   Install cancelled."
    exit 0
  fi
  rm -rf "${INSTALL_DIR}"
fi

echo "📥 Installing to ${INSTALL_DIR}..."
echo ""

# Prefer git clone (clean), fall back to curl download
if command -v git &>/dev/null; then
  git clone --depth 1 --quiet "${REPO_URL}" "${INSTALL_DIR}"
  echo "✅ Cloned via git"
else
  # Fallback: download SKILL.md and README.md directly
  mkdir -p "${INSTALL_DIR}"
  curl -fsSL "${RAW_BASE}/SKILL.md" -o "${INSTALL_DIR}/SKILL.md"
  curl -fsSL "${RAW_BASE}/README.md" -o "${INSTALL_DIR}/README.md"
  curl -fsSL "${RAW_BASE}/install.sh" -o "${INSTALL_DIR}/install.sh"
  echo "✅ Downloaded via curl"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ Installation complete"
echo ""
echo "  Skill installed at:"
echo "  ${INSTALL_DIR}"
echo ""
echo "  Usage in Claude Code:"
echo "  /build-pipeline [optional: brief text]"
echo ""
echo "  Restart Claude Code (or start a new session)"
echo "  for the skill to become available."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
