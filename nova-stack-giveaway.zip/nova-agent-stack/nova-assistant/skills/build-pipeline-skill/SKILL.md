# Build Quality Pipeline

**Version:** 1.0  
**Trigger:** `/build-pipeline`  
**Purpose:** Four-stage quality gate for any software build — prior art research, PRD review, security pre-check, and post-build code review. Runs entirely in Claude Code. No external accounts or API keys required.

---

## INVOCATION

```
/build-pipeline                          → full pipeline (prompts for brief)
/build-pipeline [brief text]             → full pipeline with brief inline
/build-pipeline --research [brief]       → Stage 1 only: prior art + feature research
/build-pipeline --prd [brief or path]    → Stage 2 only: PRD review
/build-pipeline --security [url|path]    → Stage 3 only: security scan
/build-pipeline --review [path]          → Stage 4 only: post-build code review
/build-pipeline --review [path] --pass2  → Stage 4 Pass 2 after fixes applied
```

If no brief is provided and no flag is given, ask:
> "What are we building? Give me the brief — one paragraph minimum. What it does, who uses it, what tools/APIs it touches."

---

## HOW THIS PIPELINE WORKS

Four stages run in sequence. Each stage has a **gate verdict** that determines whether to proceed:

```
Brief/Spec
    │
    ▼
[STAGE 1] Prior Art Research ──────────► Always continues (research informs, doesn't block)
    │
    ▼
[STAGE 2] PRD Review ──────────────────► READY → continue | BLOCKED → stop and fix
    │
    ▼
[STAGE 3] Security Pre-Check ──────────► PASS → continue | WARN → continue (noted) | BLOCK → stop
    │
    ▼
     ── ( code is written here ) ──
    │
    ▼
[STAGE 4] Code Review (Pass 1) ────────► PASS → done | REQUIRES FIXES → fix then Pass 2
    │
    ▼
[STAGE 4] Code Review (Pass 2) ────────► PASS → sign off | ESCALATE → human review needed
```

Run Stages 1–3 **before** writing any code.  
Run Stage 4 **after** the code exists.

---

## STAGE 1 — PRIOR ART RESEARCH

**Purpose:** Discover what already exists so the build starts from the best available foundation, not from scratch guessing.

**Inputs:** Brief text or one-line purpose statement.

**Protocol — run all steps in order:**

### 1.1 GitHub Search
Use WebSearch with query: `site:github.com [key terms from brief] open source`  
Also try: `"[purpose keywords]" github stars`

For each result found — collect:
- Repo name and URL
- Stars and last active date (if visible)
- One-line summary of what it does

Flag any repo as **HIGH RELEVANCE** if:
- Stars > 100 AND last commit < 12 months ago
- OR: the purpose aligns closely (>70%) with the brief

### 1.2 Web Research
Use WebSearch with query: `"[purpose]" implementation approach best practices [year]`  
Also: `[purpose] common pitfalls failure modes`

Extract from results:
- Named tools, libraries, frameworks used for this type of build
- Architecture patterns that appear repeatedly (they're patterns for a reason)
- Known failure modes or edge cases others have documented

### 1.3 Feature Deep-Dive (HIGH RELEVANCE repos only)
For each HIGH RELEVANCE repo, use WebFetch to read its README:  
`https://raw.githubusercontent.com/[owner]/[repo]/main/README.md`  
(Try `master` if `main` fails)

Extract specifically:
- **Capabilities**: what does it do, step by step?
- **Architecture patterns**: what's clever about the design?
- **Edge cases handled**: what failure modes does it address?
- **APIs and integrations**: what external services does it wire up?
- **Limitations/anti-patterns**: what didn't work or was deliberately avoided?

Frame each finding as: `From [repo-name]: [specific, actionable insight]`

### 1.4 Feature Menu (mandatory — even if nothing strong found)
Consolidate all findings into a prioritised list of features/patterns to incorporate:
1. [Most important thing to build in from day one — specific]
2. [Second most important]
3. [Third]
...

If nothing relevant found: state that clearly. Absence of prior art is useful data.

**Stage 1 Output Format:**
```
## Stage 1: Prior Art Research
**Exists:** Yes / No / Partially
**Worth adapting:** Yes / No / Partially
**Relevance score:** HIGH / MEDIUM / LOW

### GitHub Findings
| Repo | Stars | Last Active | Relevance | Why |
|------|-------|-------------|-----------|-----|

### Web Research Findings
- [bullet 1]
- [bullet 2]

### Feature Menu
> What already exists that should be incorporated or improved upon.
**From [source]:** [insight]
**Build with these (priority order):**
1. ...

### Stage 1 Gate
✅ Research complete — proceeding to Stage 2
```

---

## STAGE 2 — PRD REVIEW

**Purpose:** Catch everything wrong with the spec before any code is written. Incomplete specs produce broken code. This stage fixes the spec.

**Inputs:** Brief text, or a PRD file path (read with Read tool).

**Announce:** "PRD Review running — 9-point check."

**Run all 9 points. Do not skip any.**

### Point 1 — Parse
- What does this build actually do? State it in one sentence.
- What are the inputs? What are the outputs?
- Who uses it and how?

### Point 2 — AI Improvement Pass
Think critically: what would make this 2× more useful?
Ask: "What would a senior engineer add that wasn't thought of?"
Generate 3–5 concrete suggestions (not vague — specific features or design decisions).

### Point 3 — Challenge Assumptions
Push back on weak specs:
- "This says X but what happens when Y?"
- Flag: vague trigger definitions, missing error handling, undefined success criteria
- Flag: "this will break in the real world because..."

### Point 4 — Prior Art Check
If Stage 1 ran: reference those findings.
If Stage 1 didn't run: do a quick WebSearch check now.
Output: "Build from scratch" OR "Start from / adapt [source] because..."

### Point 5 — Stack Fit Audit
- Does this integrate cleanly with what already exists in the project?
- Are there missing dependencies or API keys not yet in the setup?
- Does this duplicate anything that already exists?

### Point 6 — Scope Check
- Is this one thing or should it be two?
- Flag feature bloat that will tangle the build
- Flag under-scoping that will require immediate rebuilds
- Output: "Scope OK" OR "Recommend split: [A] + [B] because..."

### Point 7 — Failure Mode Mapping
What happens when:
- External APIs fail or return unexpected data?
- Input data is malformed or missing?
- The build runs in an unexpected environment?

For each integration: is the retry/timeout/fallback behaviour defined?

### Point 8 — Output & Observability Check
- How will you know it's working correctly?
- Is there logging, error output, or a success signal defined?
- If this is a background/automated build: is there a monitoring or alerting mechanism?

### Point 9 — Verdict
Based on all 8 points above:

**READY FOR BUILD** — spec is solid, no blocking gaps  
**REQUIRES APPROVAL** — good spec with open questions that need a decision  
**BLOCKED** — spec has gaps that will cause build failure; list what must be resolved first

**Stage 2 Output Format:**
```
## Stage 2: PRD Review

| Point | Status | Finding |
|-------|--------|---------|
| 1. Parse | ✅ | [one-sentence summary] |
| 2. AI Improvement | ✅/⚠️ | [N suggestions] |
| 3. Assumptions | ✅/⚠️/❌ | [issues or "clean"] |
| 4. Prior Art | ✅ | [scratch / adapt X] |
| 5. Stack Fit | ✅/⚠️ | [fits / gaps: ...] |
| 6. Scope | ✅/⚠️ | [ok / recommend split] |
| 7. Failure Modes | ✅/⚠️ | [covered / gaps: ...] |
| 8. Observability | ✅/⚠️ | [defined / missing] |
| 9. Verdict | — | READY / REQUIRES APPROVAL / BLOCKED |

### Blocking Items (must resolve before writing code)
- [list or "None"]

### Additions Recommended
- [what to add to the spec before starting]

### Stage 2 Gate
✅ READY — proceeding to Stage 3
⚠️ REQUIRES APPROVAL — proceeding with open questions noted
❌ BLOCKED — pipeline stopped. Fix these items first: [list]
```

---

## STAGE 3 — SECURITY PRE-CHECK

**Purpose:** Catch threats before they're built in. Scan any repos, packages, or external services named in the spec for red flags.

**Inputs:** The spec/brief + any repo URLs or package names mentioned.

**Announce:** "Security Pre-Check running."

**If no external dependencies are in the spec:** state "No external dependencies identified — Stage 3 N/A" and proceed.

### 3.1 Repository Existence Check (for any GitHub repos in the spec)
For each GitHub repo mentioned or proposed for use:
- Use WebFetch: `https://github.com/[owner]/[repo]`
- **If 404 / not found → BLOCK.** A non-existent repo in a spec is a factual error, not a security question.
- If exists: note stars, last commit date, contributor count

### 3.2 Package Legitimacy Check (for any packages/libraries named)
For each package:
- Use WebSearch: `[package-name] npm / pypi / [registry] official`
- Verify it exists on the official registry for its language
- **If cannot verify existence → BLOCK.** Phantom package names in specs cause supply-chain failures.
- Check: is it actively maintained? Last release date?

### 3.3 Prompt Injection Scan (if any external content is being ingested)
If the build ingests external data (web scraping, user input, file uploads, API responses fed to an LLM):
- Flag: is there sanitisation/validation before the data is processed?
- Flag: could user input manipulate the system's behaviour in unintended ways?
- This is a WARN, not a BLOCK — but it must be addressed before production.

### 3.4 Credential & Secret Hygiene
Review the spec for:
- Any mention of hardcoded credentials, tokens, or API keys
- Any secrets being passed as command-line arguments (visible in process lists)
- Any plan to commit secrets to version control

**Any of the above → BLOCK.**

### 3.5 Scope Creep Security Check
- Does the build request more permissions/access than it needs for its stated purpose?
- Principle of least privilege: flag anything accessing more than it needs.

**Stage 3 Output Format:**
```
## Stage 3: Security Pre-Check

| Check | Status | Finding |
|-------|--------|---------|
| 3.1 Repo existence | ✅/❌ | [verified or BLOCK: reason] |
| 3.2 Package legitimacy | ✅/⚠️/❌ | [verified or BLOCK/WARN: reason] |
| 3.3 Prompt injection | ✅/⚠️ | [N/A or WARN: surface area] |
| 3.4 Credential hygiene | ✅/❌ | [clean or BLOCK: location] |
| 3.5 Least privilege | ✅/⚠️ | [ok or WARN: excess scope] |

**VERDICT: PASS / WARN / BLOCK**
RISK_SCORE: [1–10]
ACTION: [Proceed / Proceed with warnings noted / Hard stop — fix before writing code]

### Stage 3 Gate
✅ PASS — proceeding
⚠️ WARN — proceeding with [N] warnings on record
❌ BLOCK — pipeline stopped. Fix these before writing any code: [list]
```

---

## STAGE 4 — CODE REVIEW

**Purpose:** Systematic quality gate after the code is written. Two-pass max. Sign off only when all blocking items are resolved.

**Inputs:** A file path or directory to review. Use Read and Bash tools to inspect the code.

**Announce:** "Code Review — Pass [1 or 2] — running 6-dimension review."

**Detect build type first:**
- Has `CLAUDE.md` → Claude agent build → apply full 6 dimensions
- Has `package.json`, `setup.py`, `Cargo.toml`, etc. → software project → apply all dimensions (skip agent-specific items in Dim 1, noted inline)
- Unknown → ask before proceeding

### Dimension 1 — Structure & Completeness
For **Claude agent builds:**
- [ ] `CLAUDE.md` exists with a boot sequence
- [ ] `README.md` exists
- [ ] `.env.example` exists (no real values — check every line)
- [ ] `docs/` folder contains: PRD, ARCHITECTURE, SECURITY, DECISIONS
- [ ] `skills/` folder exists
- [ ] `skills/self-improve.md` exists — **BLOCKING if missing**

For **software projects:**
- [ ] `README.md` exists and explains: what it does, how to install, how to run
- [ ] Entry point is clear and findable
- [ ] Configuration / environment setup is documented (`.env.example` or equivalent)
- [ ] `tests/` folder exists — **WARN if missing**
- [ ] `.gitignore` exists and excludes: `.env`, build artifacts, `node_modules` / `__pycache__` / `.venv`

### Dimension 2 — Security
- [ ] No hardcoded credentials anywhere in `src/`, scripts, or config files
  - Search: `grep -rn "sk-\|ghp_\|token.*=.*[a-zA-Z0-9]{20,}\|password.*=.*[^\$]" .`
- [ ] `.env.example` or equivalent contains no real values
- [ ] Secrets are loaded from environment variables, not from code
- [ ] No internal/private URLs hardcoded in public-facing docs or code
- [ ] Input validation exists at all user-facing or API-facing boundaries
- [ ] No `eval()`, `exec()`, `shell=True subprocess` on untrusted input

If the build makes HTTP requests with user-controlled parameters:
- [ ] No server-side request forgery (SSRF) surface — URLs are validated/allowlisted

### Dimension 3 — Code Quality
- [ ] Functions do one thing. Flag anything doing 3+ unrelated things.
- [ ] No obvious N+1 query patterns (looping API calls that could be batched)
- [ ] Error handling exists for every external API call
- [ ] No silent failures — errors are surfaced, logged, or raised, not swallowed
- [ ] No dead code or commented-out blocks left in
- [ ] Dependencies are real, pinned, and verified (not guessed version numbers)
  - For Python: `pip index versions [package]` to verify version exists
  - For Node: check npmjs.com for the exact version

### Dimension 4 — Spec Alignment
- [ ] Does the code actually do what the PRD/brief said it would do?
  - Walk through the stated features one by one — is each implemented?
- [ ] Are the integrations listed in the spec actually wired up in code?
- [ ] Is the output format what was specified?
- [ ] Are there features in the code that weren't in the spec? (Flag — scope creep or undocumented)

### Dimension 5 — Documentation Quality
- [ ] `README.md` is accurate — does the install/run process actually work?
  - Verify by reading the code, not just the README
- [ ] Complex or non-obvious logic has a comment explaining **why** (not what — the code says what)
- [ ] All environment variables are documented in `.env.example` or equivalent
- [ ] Any known limitations are documented

### Dimension 6 — Runtime Correctness (mechanical checks)
These are deterministic checks — run the commands, paste the output. Do not sign off on judgement alone.

- [ ] **6.1 Dependencies install cleanly.**
  - Python: `pip install -r requirements.txt` (or `pip install -e .`) in a fresh venv
  - Node: `npm install` or `yarn install`
  - Paste the last 5 lines of output.
  - Any error → **BLOCKING.**

- [ ] **6.2 Entry point runs without crashing.**
  - Run the main entry point with `--help` or equivalent: does it start without error?
  - Paste output.
  - Any crash on startup → **BLOCKING.**

- [ ] **6.3 Package/dependency versions are real.**
  - Pick 3 dependencies from the manifest. Verify each version exists on its registry.
  - Any phantom version → **BLOCKING.**

- [ ] **6.4 `.gitignore` covers the essentials.**
  - `grep -E "\.env|node_modules|__pycache__|\.venv|dist/" .gitignore`
  - Any missing → **BLOCKING.**

- [ ] **6.5 No secrets in git history** (if repo has commits).
  - `git log --all --oneline | head -20` — look for commit messages that suggest secrets were committed
  - If suspicious: `git show [sha] -- [file]` to verify
  - Any confirmed secret in history → **BLOCKING + immediate rotation required.**

**Stage 4 Output Format:**
```
## Code Review — Pass [N]
**Date:** [today]
**Path reviewed:** [path]
**Build type detected:** [Claude agent / Software project]

### Findings

| Dimension | Status | Issues |
|-----------|--------|--------|
| 1. Structure | ✅/⚠️/❌ | [list] |
| 2. Security | ✅/⚠️/❌ | [list] |
| 3. Code Quality | ✅/⚠️/❌ | [list] |
| 4. Spec Alignment | ✅/⚠️/❌ | [list] |
| 5. Documentation | ✅/⚠️/❌ | [list] |
| 6. Runtime | ✅/⚠️/❌ | [command outputs pasted] |

### Blocking Items (must fix before sign-off)
- [list or "None"]

### Recommended (non-blocking)
- [list or "None"]

### Verdict
PASS / PASS WITH NOTES / REQUIRES FIXES
```

**Pass Rules:**
- Pass 1 → fix all blocking items → Pass 2
- Pass 2 → sign off if all blocking items resolved
- If Pass 2 still has blocking items → ESCALATE. Do not run Pass 3. A human needs to review.
- Non-blocking items may ship — document them.

---

## PIPELINE RULES (apply to all stages)

1. **Never skip a stage** unless a flag explicitly targets one stage.
2. **Stage gates are hard.** BLOCKED in Stage 2 means no code gets written. BLOCK in Stage 3 means no code gets written. These are not suggestions.
3. **Always output every stage's verdict** — even if it's a pass, show the table.
4. **No phantom verdicts.** Every finding must reference a specific file, line, or search result. "Looks fine" is not a finding.
5. **Paste actual command outputs** for all Dimension 6 runtime checks. Judgement is not sufficient.
6. **Two-pass cap on code review.** If Pass 2 fails, escalate — don't grind.
7. **WARN is not PASS.** When a WARN is carried forward, it must be listed in the final summary.

---

## FINAL PIPELINE SUMMARY

After all stages complete, output:

```
## Build Pipeline Summary
**Brief:** [one-sentence description]
**Date:** [today]
**Stages run:** [list]

| Stage | Verdict | Key Findings |
|-------|---------|--------------|
| 1. Prior Art | ✅ | [top 2 Feature Menu items] |
| 2. PRD Review | ✅/⚠️/❌ | [verdict + blocking count] |
| 3. Security | ✅/⚠️/❌ | [verdict + risk score] |
| 4. Code Review | ✅/⚠️/❌ | [pass N verdict] |

### Warnings Carried Forward
- [any WARNs from Stages 2–3 that weren't blocking but need attention]

### Overall Status
🟢 READY TO SHIP / 🟡 SHIP WITH CAUTION (warnings on record) / 🔴 NOT READY (blocking items outstanding)
```

---

## QUICK REFERENCE — Stage Gates

| Stage | PASS condition | STOP condition |
|-------|---------------|----------------|
| 1. Prior Art | Always continues | — |
| 2. PRD Review | Verdict = READY or REQUIRES APPROVAL | Verdict = BLOCKED |
| 3. Security | Verdict = PASS or WARN | Verdict = BLOCK |
| 4. Code Review | No blocking items (Pass 1 or 2) | Blocking items in Pass 2 |
