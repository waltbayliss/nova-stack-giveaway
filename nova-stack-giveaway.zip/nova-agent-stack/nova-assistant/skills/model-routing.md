---
name: model-routing
description: How agents route external LLM API calls through the OpenRouter Optimizer to score complexity and dispatch to the cheapest competent model (Ollama → Haiku → Sonnet → Opus). Applies to agent-internal API calls only — NOT to the Agent-tool subagent_type dispatch, which is harness-controlled.
---

# Skill: model-routing

**When to invoke:** Any time an agent makes an external LLM API call (OpenRouter, Anthropic API) inside its src/ code — voice-layering pass, content generation, code synthesis, summarisation.

**Does NOT apply to:** The Agent tool's `subagent_type` dispatch. That's harness-controlled and uses the harness-selected model (typically Claude Sonnet 4.6 in the desktop app).

---

## Why route

Without routing, agents burn tokens on Sonnet/Opus for tasks that Haiku or local Ollama could handle. Routing cuts cost 5–20× on simple tasks with no quality loss.

---

## Complexity scoring → model tiers

| Score | Model | Use case |
|---|---|---|
| 1–2 | Ollama local (free, fast) | Lookups, simple text transforms, format conversions |
| 3 | Claude Haiku 4.5 | Light reasoning, structured extraction, summaries |
| 3–4 | Claude Sonnet 4.6 | Standard prose, code generation, analysis |
| 4–5 | Claude Opus 4.6 | Hard reasoning, multi-step synthesis, novel design |

---

## Two wiring paths

### 1. Python optimizer (preferred)

```python
from optimizer import optimize
result = optimize({
    "content": "<task>",
    "agent_name": "<agent>",
    "task_type": "code|prose|analysis|lookup"
})
# result["model"] is the dispatch target
```

Path: `my-ai-team/agent-openrouter-optimizer/src/optimizer.py` (Mac) or `/home/walt/agents/agent-openrouter-optimizer/src/optimizer.py` (VPS).

### 2. OpenRouter MCP

`@stabgan/openrouter-mcp-multimodal` — installed globally. Use the `chat_completion` tool with the model returned by the optimizer. Requires `OPENROUTER_API_KEY` in environment.

---

## Hard rule

**Never** dispatch external LLM API calls from agent src/ code without routing first. It burns tokens on tasks that don't need it.

Exception: model already pinned in agent's PRD with documented rationale (e.g. "Opus required for full Walt-voice fidelity in the personal-brand content path").
