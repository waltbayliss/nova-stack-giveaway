# Skill: Environment Variable Rotation

**Trigger:** Walt says any of: "I rotated [X]", "rotated [X]", "new [X] token in env", "swapped [X] key", or any phrase indicating a value in `/home/walt/.env` has been changed. Also runs on demand: `rotate <VAR>`.

**Purpose:** When a secret in `/home/walt/.env` is rotated, every long-running agent service that loaded the OLD value at start time keeps using it until restarted. This skill identifies the affected services, restarts them, and verifies the live process environment now matches `/home/walt/.env`.

**Why this exists:** On 2026-05-13, the GitHub PAT was rotated but `agent-video-editor.service` (running since 2026-05-06) kept the old token in its process env. Every video pipeline run silently failed voice-profile load with 401 — until a downstream symptom (a malformed X post) surfaced the issue. See `lessons.md` 2026-05-14 entry.

---

## How to Run

### Step 0 — Doppler is the source of truth (do this FIRST)

Secrets are managed in **Doppler** (project `mydpa-ai`, config `prd`); `/home/walt/.env` is a *rendered copy*. So a rotation is not real until it's in Doppler AND synced to `.env`:

1. Rotate the value **in Doppler** (dashboard, or `doppler login` then `doppler secrets set <VAR>` from a dir outside `/home/walt` so the write-capable login identity is used — the VPS service token is read-only).
2. Render it to `.env`: `bash /home/walt/scripts/doppler-sync.sh` (no-op if nothing changed; backs up the old `.env` and atomically swaps otherwise).
3. THEN continue to Step 1 below to restart the services that loaded the old value.

If Walt says "I rotated [X]" but only changed `.env` directly, remind him the change will be **overwritten on the next sync** unless it's also set in Doppler.

### Step 1 — Identify the rotated variable

Confirm with Walt the exact env-var name being rotated. Examples:
- `GITHUB_PERSONAL_ACCESS_TOKEN`
- `ANTHROPIC_API_KEY`
- `NOTION_TOKEN`
- `TELEGRAM_BOT_TOKEN`
- `FAL_KEY`
- `OPENAI_API_KEY`
- Any `GOOGLE_*` variable
- Any `TWITTER_*` variable

If Walt named the service informally ("the Anthropic key"), map it to the exact `.env` variable name before proceeding.

### Step 2 — Confirm the new value is in /home/walt/.env

```bash
grep ^<VAR_NAME>= /home/walt/.env | cut -d= -f2- | tr -d '[:space:]' | cut -c1-12
```

This prints the first 12 chars of the value in `.env` — enough to compare prefixes without leaking the full secret. If empty or missing, STOP and tell Walt the var isn't in `.env`.

### Step 3 — Find every running agent service

```bash
systemctl list-units --type=service --state=running --no-legend 'agent-*' | awk '{print $1}'
```

This lists all currently-active `agent-*.service` units. Plus check these known long-running services that aren't agent-prefixed:
- `content-pipeline*` (if any)
- Anything else in `systemctl list-units --type=service --state=running --no-legend` that references `/home/walt/agents/`

### Step 4 — Identify which services consume the rotated var

Two checks per service:

**A. Does the service load /home/walt/.env via dotenv at startup?**
```bash
grep -l "load_dotenv\|/home/walt/.env" /home/walt/agents/<service-name>/src/*.py 2>/dev/null
```
If yes, the service is a candidate.

**B. Does the service reference the specific var?**
```bash
grep -r "<VAR_NAME>" /home/walt/agents/<service-name>/src/ 2>/dev/null | head -3
```
If yes, the service definitely consumes the var.

If A is true but B is false, the service still loads the env at startup but may not use this specific var — restart anyway (cheap, safer than a missed restart).

### Step 5 — Restart the affected services

```bash
sudo systemctl restart <service1> <service2> ...
```

Batch all affected services in one command. Wait ~3 seconds, then check status:

```bash
systemctl is-active <service1> <service2> ...
```

Every line should print `active`.

### Step 6 — Verify live process env matches /home/walt/.env

For each restarted service:

```bash
PID=$(systemctl show -p MainPID --value <service>)
LIVE_PREFIX=$(sudo cat /proc/$PID/environ 2>/dev/null | tr '\0' '\n' | grep ^<VAR_NAME>= | cut -d= -f2- | cut -c1-12)
ENV_PREFIX=$(grep ^<VAR_NAME>= /home/walt/.env | cut -d= -f2- | tr -d '[:space:]' | cut -c1-12)
[ "$LIVE_PREFIX" = "$ENV_PREFIX" ] && echo "$<service>: MATCH ✓" || echo "$<service>: MISMATCH ✗ (live=$LIVE_PREFIX env=$ENV_PREFIX)"
```

If a service shows MISMATCH after restart, the service doesn't load `/home/walt/.env` via dotenv — it has its own EnvironmentFile= directive or sources elsewhere. Investigate the unit file (`systemctl cat <service>`) and the source code.

### Step 7 — Report to Walt

Plain English summary:
- Which services were restarted
- Which verified MATCH
- Any MISMATCH cases requiring further action
- Confirmation that the rotation is now live across all consumers

---

## Notes

- **Never** print the full secret value, only the first 12 chars for prefix comparison.
- If `sudo systemctl restart` is rejected by the permissions classifier, ask Walt to approve the prompt — restarting agent services is a known authorized operation.
- This skill assumes the new value is ALREADY in `/home/walt/.env`. If Walt is asking Nova to rotate, that's a different operation — get the new value from him, write to `.env`, then run this skill.
- **Embedded tokens in git remote URLs are a separate problem.** Some repos have a stale token baked into `git remote get-url origin` (legacy clone pattern: `https://<token>@github.com/...`). Rotating the env var does NOT fix these — they need `git remote set-url origin https://github.com/<owner>/<repo>.git` to remove the embedded token and rely on credential helper or env-supplied auth. Audit cmd: `cd <repo> && git remote get-url origin | grep -o 'ghp_[A-Za-z0-9]\{12\}'`. If anything prints, the URL has an embedded token.

---

## When this skill is NOT needed

- The rotated value is consumed only by scripts launched fresh each time (cron jobs, ad-hoc Python scripts). Those re-read `.env` on each invocation — restart not required.
- The rotated value is a local-only config (paths, flags, log levels) — no security/auth impact.
- The variable was already correct in `.env` and Nova was just asked to verify alignment — that's `skills/permission-cleanup.md` territory, not this one.
