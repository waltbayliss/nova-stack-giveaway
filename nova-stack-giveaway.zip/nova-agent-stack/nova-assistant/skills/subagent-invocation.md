---
name: subagent-invocation
description: How Nova invokes specialist agents as subagents in the same session. Covers the canonical Agent-tool invocation pattern, serial vs parallel vs background, the pass-through rule, and input/output contracts.
---

# Skill: subagent-invocation

**When to invoke:** Any time Nova needs specialist work (build, review, search, audit, security check) and a registered agent exists for it. One Nova session, internal parallelism. Walt sees one conversation; Nova multi-threads underneath.

---

## The canonical Agent-tool invocation

`subagent_type` accepts harness built-ins only (`general-purpose`, `Explore`, `Plan`, etc.). To invoke a specialist agent, use `general-purpose` and put the agent identity into the prompt:

```
Agent(
  subagent_type="general-purpose",
  prompt="""You are agent-<name>. Read /home/walt/agents/agent-<name>/CLAUDE.md as your full operating instructions and source of truth, then read /home/walt/CLAUDE.md for VPS environment overrides (GitHub MCP broken on the VPS — use curl with the token at /home/walt/.env). Then execute: <task>. Return output in the format specified in your CLAUDE.md."""
)
```

The agent's own CLAUDE.md is the single source of truth for its behaviour and output format. Nova constructs the invocation, the agent executes — Nova never re-implements specialist logic inline.

**Mac equivalent:** swap `/home/walt/agents/agent-<name>/` for `.../my-ai-team/agent-<name>/` and skip the VPS overrides note.

---

## Serial / parallel / background

- **Serial** — step B needs step A's output. Wait for A's report, paste relevant context into B's prompt. Most pipeline work is serial.
- **Parallel** — steps are independent. Issue multiple `Agent` calls in ONE assistant turn. Example: quick-searcher + agent-security on the same target — they don't need each other's findings.
- **Background** (`run_in_background=true`) — long-running work where Walt should keep talking. Example: agent-builder run that takes 5–10 minutes. On completion, fire a Telegram via the nova-telegram worker — see Rule 22 in CLAUDE.md.

---

## Pass-through rule (HARD)

When a subagent returns a structured report (verdict, audit, search summary, build manifest), Nova **surfaces it verbatim** before any commentary. Never paraphrase. Walt sees what the specialist actually said.

After the verbatim block, Nova may add a next-step recommendation — the report itself is sacred.

If the desktop app collapses the report under "Ran agent ▸", tell Walt to expand it AND include a short verbatim snippet (verdict line, blocking items, key tables) in the text reply so the critical content is visible without clicking.

---

## Input/output contracts at invocation time

Before invoking, Nova checks the agent's CLAUDE.md for:
- **Input contract** — raw brief? brief + prior-art findings? built code path?
- **Output format** — structured table? verdict only? upgraded document?
- **Output destination** — back to Nova, written to GitHub via curl, written to walts-wiki, written to Notion?

If Nova doesn't know the contract, she reads the agent's CLAUDE.md before constructing the prompt.

---

## Agent registry as the available-subagents list

The set of invokable specialist agents is the union of `docs/AGENT-REGISTRY.md` entries with present folders under `/home/walt/agents/` (VPS) or `my-ai-team/` (Mac). If Walt asks for work that maps to an unregistered agent, Nova proposes building it (intake → build pipeline) rather than improvising.

---

## Failure handling

- Subagent returns nothing / errors → flag verbatim to Walt, do not silently proceed
- Subagent returns a verdict Nova disagrees with → surface verbatim, then add Nova's perspective, let Walt decide
- Subagent times out → flag, ask Walt whether to retry or escalate
