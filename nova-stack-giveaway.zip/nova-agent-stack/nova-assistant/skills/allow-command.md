# skill: allow-command

## Trigger Phrases
- "Should we permanently allow this?"
- "Add this to the allowlist"
- "Always allow this"
- "Permanently allow that"
- "Can we just always allow that?"

## Purpose
When Walt sees a permission prompt and wants to suppress it permanently, Nova evaluates whether it's safe. If yes — and ONLY if yes — Nova adds the right glob pattern to `.claude/settings.json`, commits, and pushes. If not safe, Nova explains exactly why and declines.

---

## Step 1: Identify the command

Look at the most recent permission prompt in the conversation. Extract:
- **Tool type**: Bash / Read / Write / MCP tool name
- **Command text or file path**

---

## Step 2: Safety evaluation

### GREEN — safe to add without hesitation
- **Bash read-only**: `ls`, `cat`, `grep`, `find`, `head`, `tail`, `wc`, `sed -n`, `awk`, `echo`, `printf`, `base64`, `tr`, `python3`, `which`, `env`, `pwd`, `ps`, `systemctl status`
- **Bash git reads**: `git log`, `git status`, `git diff`, `git show`, `git fetch`, `git config`, `git branch`, `git worktree`, `git remote`
- **Bash git writes**: `git commit`, `git push` (not --force), `git clone`, `git stash`
- **Bash curl**: to `api.github.com`, `api.perplexity.ai`, `fal.ai`, or any service already in Walt's `.env` stack
- **Bash scripts**: `bash /home/walt/scripts/*` — scoped path only
- **Read**: any path under `/home/walt/`
- **Write**: paths under `/home/walt/agents/nova-assistant/`
- **WebSearch**, **WebFetch**
- **MCP read tools**: notion-fetch, clickup_get_*, calendar list/get, etc.

### RED — decline, explain why, do not add
- **Bash**: `rm`, `rmdir`, `unlink`, `shred` — file deletion
- **Bash**: `git push --force` — destructive and irreversible
- **Bash**: `chmod`, `chown` — permission changes
- **Bash**: `sudo <anything destructive>`
- **Bash**: `curl` POST/PUT to services NOT in Walt's known stack (unknown webhooks, unknown APIs)
- **Bash**: arbitrary scripts outside `/home/walt/scripts/`
- **Write**: paths outside `nova-assistant/` unless clearly justified (e.g., `~/.ssh/`, `/etc/`, system paths)
- **Any operation** that could send emails, post to social media, or expose secrets externally

### AMBER — ask Walt before adding
- `pip3 install`, `npm install -g` — installs (sometimes needed in build sessions)
- Scripts in paths Nova doesn't recognise
- Write to other agent repos (e.g., `waltbayliss/agent-builder`)
- MCP write tools that post externally (GHL, Telegram, social poster)

---

## Step 3: Extract the right pattern

Map the specific command to the broadest safe glob pattern. Don't add overly narrow entries — they'll just prompt again for a slightly different variant.

| Specific command | Pattern to add |
|-----------------|----------------|
| `curl -s -H "..." "https://api.github.com/..."` | `Bash(curl*)` |
| `git log --pretty=format:...` | `Bash(git log*)` |
| `sed -n '10,20p' /path/file` | `Bash(sed*)` |
| `python3 -c "import json..."` | `Bash(python3*)` |
| `Read(/home/walt/agents/agent-xyz/CLAUDE.md)` | `Read(/home/walt/agents/*)` |
| `Write(/home/walt/agents/nova-assistant/.claude/agents/xyz.md)` | `Write(/home/walt/agents/nova-assistant/*)` |
| `bash /home/walt/scripts/some-script.sh` | `Bash(bash /home/walt/scripts/*)` |

---

## Step 4: Check if already covered

Read `/home/walt/agents/nova-assistant/.claude/settings.json`.

If the pattern is already in `permissions.allow`, tell Walt:
> "That's already covered by `[existing entry]`. If it's still prompting, start a fresh session — the settings may not have loaded into this worktree."

---

## Step 5: Add to allowlist (only if GREEN)

```bash
# Read current file, add pattern, write, commit, push
cd /home/walt/agents/nova-assistant
# [Edit .claude/settings.json — insert new pattern into permissions.allow array]
git add .claude/settings.json
git commit -m "config: allow [pattern] — [one-line reason]"
git push origin main
```

---

## Step 6: Confirm to Walt

> "Added `Bash(pattern*)` to the allowlist — [one sentence on why it's safe]. Committed and pushed. Takes effect next session."

---

## Hard Rules (non-negotiable)

1. **NEVER add `rm*`, `rmdir*`, or any deletion** — not even once
2. **NEVER add `git push --force*`**
3. **NEVER add `chmod*`, `chown*`, or broad `sudo*`**
4. **NEVER add curl to services outside Walt's known stack** without an agent-security check first
5. **When uncertain — say so and ask**. Do not guess safe. The cost of one extra prompt is less than the cost of one unintended action.
6. **Always scope Write permissions to the minimum necessary path**
