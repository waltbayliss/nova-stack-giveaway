---
name: brief-actioning
description: How Nova actions Walt's daily brief — confirms Brisbane date first, fetches the right brief, writes Q2+Q3 answers to voice profile BEFORE other actioning, then runs every other task on the page. Triggered by "action today's brief" or "action the brief".
---

# Skill: brief-actioning

**Trigger:** Walt says "action today's brief", "action the brief", or any equivalent.

---

## STEP 0 — CONFIRM BRISBANE TODAY'S DATE (NON-NEGOTIABLE)

Run:
```bash
TZ=Australia/Brisbane date +%Y-%m-%d
```

Do NOT trust the system date in the conversation reminder — it can be a day behind Brisbane. If the Daily Briefs DB listing shows multiple briefs (yesterday/today/tomorrow), pick the one whose title matches the Brisbane date. If ambiguous, confirm with Walt before fetching.

**Why:** Walt has caught Nova actioning yesterday's brief on a stale system-date assumption. Cost of confirming = 5 seconds. Cost of actioning the wrong day = rebuilding trust.

---

## STEP 1 — FETCH TODAY'S BRIEF

Daily Briefs container ID: `[REDACTED-ID]`

Find the most recent daily brief page whose title matches today's Brisbane date.

---

## STEP 2 — READ THE FULL PAGE

Including Walt's answers in the **YOUR ANSWERS** section.

---

## STEP 3 — WRITE Q2 + Q3 TO VOICE PROFILE (BEFORE OTHER ACTIONING)

**Q2 (Opinion):** if Walt answered, fetch `waltbayliss/walts-wiki → Walt's Wiki/Master Wiki/walt-voice-profile.md`, insert his answer under `## CORE OPINIONS — WALT'S OPINION MAP` with today's date and topic label. Push update via curl.

**Q3 (Scenario):** if Walt answered, append to `Walt's Wiki/Voice Bank/Raw/{date}-scenario.md` with label "Scenario answer — [date]".

**If BOTH Q2 and Q3 are blank or still say `[your answer]`:** send a Telegram ping immediately:
> ❓ Your Q2/Q3 answers in today's brief haven't been filled in. Open the brief in Notion, add your answers under YOUR ANSWERS, then say "action today's brief" again to absorb them.

Then continue with normal actioning.

**If only one is blank:** process the one with content, skip the blank silently.

Confirm to Walt: "Voice profile updated with your [topic] opinion."

This step runs FIRST. 30 seconds spent here makes every future content piece more accurate.

---

## STEP 4 — ACTION EVERYTHING ELSE

Tasks, NOVA CAN DO items, AI Ideas, AI News, Content sections, etc.

**Image rule (mandatory):** for every post created during brief actioning — LinkedIn, Facebook, Instagram, X — from any section, invoke `agent-image-creator` immediately after writing the post content. Upload via Notion File Upload API and attach to the Image property (not the Links field).

- **`--type composite` is the default for every social post** — personal brand AND [Prior Venture]/opinion alike. Walt's face, view-optimized (large face, close to camera, vivid scroll-stopping background). Most posts get a composite.
- `--type abstract` is the rare exception — use only when the post genuinely has no natural place for a person (e.g. a pure data/metric post or a concept diagram). When in doubt, composite.

Walt decides at approval whether to include the image; Nova's job is to ensure it's always present.

If agent-image-creator fails, flag to Walt before marking the post as Pending.

---

## STEP 5 — ALL CONTENT DRAFTS LAND IN NOTION

Every content artefact produced during brief actioning goes to its canonical Notion destination in the same turn it's drafted. Local files (`brief-output/`, `/tmp/`) are scratch only — they get promoted to Notion before the brief is reported as actioned, or they get deleted. Walt should never need to open a terminal to read what Nova drafted.

**Canonical destinations:**

| Content type | Destination | DB / Container ID | Required properties |
|---|---|---|---|
| Social post (LinkedIn / FB / IG / X) | Social Media Posts DB | `[REDACTED-ID]` (data source `[REDACTED-ID]`) | Title, Platform (multi-select), Status, Full post body, Image (mandatory per Rule 13), Image Type, Image Prompt |
| YouTube script (script, deep dive, reel) | 🎬 YouTube Content Tracker | `[REDACTED-ID]` (data source `[REDACTED-ID]`) | Video Topic / Title, Track (`[Prior Venture]` or `Personal Brand`), Format (`Full Video (12-15 min)` / `Reel/Short (2 min)` / `Deep Dive (20 min)`), Status (`Idea` / `Scripted` / `Recorded` / `Published`), Date Suggested, Notes |
| **Blog post / long-form / 1-page framework** *(updated 2026-05-21)* | **Social Media Posts DB** | `[REDACTED-ID]` (data source `[REDACTED-ID]`) | Title, **Platform must include `Blog`**, Status (lifecycle as for social), Full post body (full markdown body), Image (mandatory per Rule 13), Blog Site (`Default Blog Site` / `From Advertising to AI` / `Influencer Empires`), Blog Category (multi-select), URL Slug (auto-derived if blank), Meta Description (≤300 chars). agent-social-poster picks it up at Status=Approved and publishes to [Employer] via `@skills/publish-blog-to-ghl.md`. **Legacy 📝 Blog Posts DB (`[REDACTED-ID]`) is archive-only — do not write new posts there.** |
| Voice profile opinion (Q2) | walts-wiki | `Walt's Wiki/Master Wiki/walt-voice-profile.md` — `## CORE OPINIONS — WALT'S OPINION MAP` section | Date-stamped entry with Context + Sales reframe + Content angle |
| Voice bank scenario (Q3) | walts-wiki | `Walt's Wiki/Voice Bank/Raw/YYYY-MM-DD-scenario.md` | Scenario + verbatim answer + interpretive note |

**Discipline:** Nova drafts to a local file only when the volume is too large to inline easily — and then writes to Notion before the next deliverable starts. If a deliverable closes without a Notion URL to show Walt, it isn't done.

**Source attribution:** every Notion page created from a daily brief carries a one-line provenance note — *"Source: Daily Brief YYYY-MM-DD — [section name]. Walt instruction: [verbatim]."* — written to the **Walt Review Notes** property (for social/blog posts) or the page body, **NEVER inside `Full post body`**. agent-social-poster (`ghl_poster.py`) posts `Full post body` verbatim and appends the Hashtags property — anything in `Full post body` goes public, and any hashtag line inside the body double-posts. So: provenance → Walt Review Notes; hashtags → Hashtags property only (never also in the body). Lets Walt audit what got actioned and from where without leaking internal process into the public post.
