---
name: weekly-newsletter
description: Nova's weekly newsletter playbook for Walt's direct audience. Thursday — compile the week's material into a 3-block draft (story / video-lesson / promo) and interview Walt; Friday — finalise in his voice and write it into [Employer] as a ready-to-send email template. Invoke on the Thursday auto-nudge or when Walt says "do the newsletter".
---

# Skill: weekly-newsletter

**When to invoke:**
- Automatically on the **Thursday 08:00 AEST auto-nudge** (scheduled routine — see "Scheduling" below). The routine runs the **Compile phase** headless and pings Walt on Telegram to start the interview.
- On demand whenever Walt says **"do the newsletter"** / **"newsletter"** — jump in at whichever phase the week is at.

**Cadence:** Thursday = Compile + Interview. Friday = Ship-ready in [Employer]. Walt is AEST (QLD).

**Audience:** Walt's *direct* audience (his personal subscriber list), not [Prior Venture]/corporate. Voice = Walt's personal DR voice (the same voice profile agent-copywriter and content-agent load from `walts-wiki`). Warm, direct, no fluff, no AI slop.

**The north-star test:** *"When I read this as a subscriber, do I get real value?"* Every issue must leave the reader with one concrete takeaway they can act on — not just news. If a draft fails that test, it is not ready.

---

## The three blocks

Every issue has exactly these three blocks, in this order:

| # | Block | What it is | Primary source |
|---|---|---|---|
| 1 | **Story of the week** | One thing that actually happened this week — a win, a lesson learned the hard way, a build, a moment. Anchored to a blog post when one exists. | Newest blog post in the Social Media Posts DB (`Platform=Blog`, last 7 days) + Walt's Daily Journal entries for the human/behind-the-scenes angle |
| 2 | **Video or lesson** | A teach. Either a video Walt shipped this week, or a standalone lesson distilled from the week's work. This is the value payload. | Newest 🎬 YouTube Content Tracker row (`Status=Published` or `Recorded`, last 7 days). Fallback: a teachable lesson Nova distils from the week's journal/blog/work |
| 3 | **Promotional piece** | One clear, soft-sell promotion. Walt names what he's promoting each week during the interview (offer, launch, event). | Walt-supplied during the Thursday interview. Nova writes the pitch in his voice |

Keep it to these three. A tight, high-value letter beats a long one.

---

## Source IDs (read these during Compile)

| Source | ID / location | Filter |
|---|---|---|
| Social Media Posts DB (blogs) | `[REDACTED-ID]` | `Platform=Blog`, created in last 7 days, newest first |
| 🎬 YouTube Content Tracker | `[REDACTED-ID]` | `Status` in {Published, Recorded}, last 7 days, newest first |
| Daily Journal | `[REDACTED-ID]` | last 7 days — for story colour / what mattered to Walt this week |

Notion reads via curl + `$NOTION_TOKEN` (see `nova-memory.md` Notion patterns). Notion DB query: `POST https://api.notion.com/v1/databases/{id}/query` with a `created_time` / property filter. Read fresh — never trust a cached snapshot for "this week".

---

## PHASE 1 — Compile (Thursday)

1. **Pull the week.** Query the three sources above. Collect: candidate blog post(s), candidate video(s), journal highlights.
2. **Pick one per block.** Newest/strongest blog → Story. Newest video → Video/Lesson. If no video this week, draft a standalone lesson from the week's work and flag it as "lesson (no video this week)".
3. **Draft the skeleton.** For each block write a 2–4 sentence draft in Walt's voice. Leave clearly-marked `[NEEDS WALT]` gaps where his input is required (the story's behind-the-scenes angle, the lesson's "why it matters", and the entire promo — Walt names that).
4. **Ping Walt** (the routine does this automatically; in an interactive session, just present the skeleton). Telegram format:
   `📰 Newsletter draft ready — Story: "<headline>" · Video/Lesson: "<title>" · Promo: [you tell me]. Reply here to do the interview, or open Nova.`

The skeleton is scratch — do NOT write it to a permanent file. Hold it in the session / pass it to the interview.

---

## PHASE 2 — Interview Walt (Thursday)

Walt answers on **Telegram (async)** or in a **Nova session** — either is fine. Ask these 5, conversationally, one or two at a time — not as a wall:

1. **Story angle:** "The story this week is <X>. What's the behind-the-scenes bit — what actually happened, what surprised you, or what did it cost you?"
2. **The lesson's why:** "For the <video/lesson>, what's the one thing you want a subscriber to walk away understanding — and why does it matter to *them*?"
3. **Promo:** "What are you promoting this week? Give me the offer/link and the hook — I'll write the pitch."
4. **The takeaway:** "If a reader does ONE thing after reading this, what is it?"
5. **Subject steer:** "Any angle you want the subject line to lean on?" (Nova proposes 3 subject options regardless.)

Fold Walt's answers in. If Walt skips a question, Nova fills the gap from the source material and the voice profile — never block on a missing answer, but flag what was inferred.

---

## PHASE 3 — Write the newsletter (Friday)

1. **Copy via agent-copywriter.** Route the assembled brief (3 blocks + Walt's interview answers + takeaway + subject steer) to `agent-copywriter` for the finished prose in Walt's personal DR voice. See `@skills/subagent-invocation.md`. Copy ALWAYS goes through agent-copywriter — Nova does not hand-write the final body.
2. **Assemble the HTML.** Wrap the copy in the email HTML template (below). Single column, ≤600px, web-safe fonts, one clear CTA in the promo block.
3. **Subject + preview.** Propose 3 subject lines; lead with the strongest. Write a one-line preview/preheader.
4. **Subscriber-value gate.** Re-read against the north-star test. One concrete takeaway present? Story has a human angle? Promo is soft, not shouty? If any fail → revise before writing to [Employer].
5. **Confirm with Walt before the [Employer] write** (Rule 4 — external write). Show subject + the full body (or preview link). Wait for "go".

### Email HTML structure
```
<html><body style="margin:0;padding:0;background:#f4f4f5;">
  <table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0"
           style="font-family:Arial,Helvetica,sans-serif;background:#ffffff;
                  color:#1a1a1a;line-height:1.5;">
      <!-- Optional masthead -->
      <!-- BLOCK 1: Story of the week  (h2 + 2–4 short paras) -->
      <!-- BLOCK 2: Video / Lesson     (h2 + teach + link/thumbnail if video) -->
      <!-- BLOCK 3: Promo              (h2 + pitch + ONE button CTA) -->
      <!-- Sign-off in Walt's name + unsubscribe placeholder ([Employer] injects) -->
    </table>
  </td></tr></table>
</body></html>
```
Keep inline styles only (email clients strip `<style>` blocks). Dark text on white. One accent colour for the CTA button.

---

## PHASE 4 — Ship into [Employer] (Friday)

Write the finished newsletter into [Employer] as a **reusable email template** (Walt then drops it into a campaign and sends to his audience). Runtime owner: `ghl-agent/src/ghl_funnel.py` `create_email_template()`.

```bash
cd /home/walt/agents/ghl-agent && set -a && source /home/walt/.env; set +a
python3 src/ghl_funnel.py create-email-template \
  "Newsletter — <Story headline> — <DD Mon YYYY>" \
  "<chosen subject line>" \
  /tmp/newsletter-YYYY-MM-DD.html \
  "<preview / preheader text>"
```

**Contract (verified 2026-05-24):** two-step builder flow — `POST /emails/builder` creates the shell (id returned in `redirect`), `POST /emails/builder/data` writes the HTML. Returns `template_id` + `preview_url`.

**Subject caveat:** [Employer] does NOT accept the subject on the template via the public API — the subject is set **at send time** when Walt builds the campaign. Nova passes the chosen subject through (it's echoed in the result and the template title) so Walt has it ready. Always tell Walt the subject to use when he sends.

After the write:
- Confirm the template appears: `GET /emails/builder?locationId=$GHL_LOCATION_ID&limit=5` — the new name should be top of the list.
- Give Walt: the template name, the **chosen subject line to paste at send**, and the `preview_url`.

---

## Scheduling

The **Thursday 08:00 AEST** auto-nudge runs the Compile phase and pings Walt. Mechanism: scheduled routine (see `@skills/` scheduling / the `schedule` skill) that invokes Nova headless with the prompt *"Run @skills/weekly-newsletter.md Phase 1 (Compile) only, then ping Walt on Telegram to start the interview. Do not write anything to [Employer]."* The Friday ship step is Walt-gated and runs interactively — it is never auto-sent.

---

## Hard rules

- **Never auto-send.** Nova writes a *template*; Walt sends the campaign. No exception.
- **Confirm before the [Employer] write** (Rule 4). Show subject + body, wait for "go".
- **Copy via agent-copywriter** — never hand-written final body.
- **Subscriber-value gate is mandatory** — a draft that fails the north-star test is not ready.
- **Read sources fresh** each week — no cached "this week" snapshots.
- **Voice = Walt's personal audience voice**, not [Prior Venture]/corporate.

## Definition of done (per issue)
- [ ] Three blocks present, each with real content (no `[NEEDS WALT]` left)
- [ ] Subscriber-value gate passed (one concrete takeaway)
- [ ] Subject (3 options, one chosen) + preview written
- [ ] Walt confirmed before the [Employer] write
- [ ] Template created in [Employer] (template_id + preview_url captured)
- [ ] Walt told: template name + subject-to-paste + preview link
