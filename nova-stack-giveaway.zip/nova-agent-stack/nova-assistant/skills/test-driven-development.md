---
name: test-driven-development
description: Use when implementing any feature or bugfix in an agent build or script, before writing implementation code. Enforces write-test-first, watch-it-fail, minimal-code-to-pass. Applies inside the agent-creation pipeline and any code Nova or a subagent writes.
---

# Skill: test-driven-development

**When to invoke:** Before writing production code for any agent feature or bugfix. Slots into `@skills/agent-creation-pipeline.md` (write tests before implementation) and into Phase 4 of `@skills/systematic-debugging.md` (failing repro before fix).

*Adapted for Nova from obra/superpowers (MIT).*

*Validated 2026-05-26 (RED→GREEN subagent test): without skill the subagent wrote implementation first and bolted on 3 thin tests, skipping the `now()`-dependent branch; with skill it refused the "skip testing" pressure, wrote tests first, verified RED, and covered the risky branch via freezegun. Clear behavioural flip — PASS.*

---

## The Iron Law

```
NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST
```

Wrote code before the test? Delete it and start over.

**No exceptions:** don't keep it "as reference", don't "adapt" it while writing the test, don't look at it. Delete means delete. Implement fresh from the test.

**Core principle:** If you didn't watch the test fail, you don't know if it tests the right thing.

## When to use

Always — new features, bug fixes, behaviour changes, refactors. Exceptions (ask Walt first): throwaway prototypes, generated code, config files. "Skip TDD just this once" is a rationalization — stop.

## Red-Green-Refactor

**RED — write a failing test.** One behaviour, clear name, real code (mocks only if unavoidable — Nova memory: don't mock what you can hit for real).

**Verify RED — watch it fail (MANDATORY).** Run the test. Confirm it *fails* (not errors), and fails for the expected reason (feature missing, not a typo). If it passes, you're testing existing behaviour — fix the test.

**GREEN — minimal code to pass.** Simplest thing that works. No extra options, no YAGNI features, no "improve while I'm here."

**Verify GREEN — watch it pass (MANDATORY).** Test passes, other tests still pass, output pristine (no errors/warnings). Test fails? Fix the code, not the test.

**REFACTOR — clean up while green.** Remove duplication, improve names, extract helpers. Keep tests green. Don't add behaviour.

**Repeat** for the next behaviour.

## Good tests

| Quality | Good | Bad |
|---|---|---|
| Minimal | One thing. "and" in the name? Split it. | `test('validates email and domain and whitespace')` |
| Clear | Name describes the behaviour | `test('test1')` |
| Real | Exercises actual code | Tests the mock, not the code |

## Common rationalizations

| Excuse | Reality |
|---|---|
| "Too simple to test" | Simple code breaks. Test takes 30 seconds. |
| "I'll test after" | Tests written after pass immediately — they prove nothing. |
| "Already manually tested" | Ad-hoc ≠ systematic. No record, can't re-run. |
| "Deleting X hours of work is wasteful" | Sunk cost. Unverified code is tech debt. |
| "Keep it as reference" | You'll adapt it — that's testing after. Delete means delete. |
| "TDD is dogmatic, I'm being pragmatic" | TDD is faster than debugging in production. |

## Red Flags — STOP and start over

Code before test · test after implementation · test passes immediately · can't explain why the test failed · "I already manually tested it" · "it's about spirit not ritual" · "keep as reference."

## Checklist before marking work complete

- [ ] Every new function has a test
- [ ] Watched each test fail before implementing
- [ ] Each failed for the expected reason
- [ ] Wrote minimal code to pass
- [ ] All tests pass, output pristine
- [ ] Tests use real code (mocks only if unavoidable)
- [ ] Edge cases and errors covered

Can't check all boxes? You skipped TDD. Start over. Then verify via `@skills/verification-before-completion.md` before claiming done.
