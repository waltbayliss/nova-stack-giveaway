---
name: code-review
description: Nova's 2-pass code review protocol — runs after every agent build or major upgrade. 5 dimensions (structure, security, CLAUDE.md, functionality, docs) + a 6th dimension (claude-md-quality framework). Pass 2 returns PASS or ESCALATE. No build is complete until PASS.
---

# Skill: code-review

**When to invoke:** After every agent build (Step 7 of `@skills/agent-creation-pipeline.md`). After every major upgrade. Before any agent is signed off and registered.

**Hard rule:** No build is complete until Pass 2 returns PASS. ESCALATE = stop, surface verbatim to Walt, Walt decides whether to run a manual fix session.

---

## PHASE 1 — BUILD COMPLETE

Step 6 of the agent-creation pipeline has finished. Repo is live on GitHub.

---

## PHASE 2 — PASS 1 REVIEW

```
Agent(
  subagent_type="general-purpose",
  prompt="""You are agent-code-reviewer. Read /home/walt/agents/agent-code-reviewer/CLAUDE.md as source of truth, then /home/walt/CLAUDE.md for VPS overrides. Then execute Pass 1 review of waltbayliss/agent-<name>: all 6 dimensions (1-5 from your CLAUDE.md + dimension 6 = claude-md-quality framework via @skills/claude-md-quality.md). Produce findings report. Append findings to that repo's docs/DECISIONS.md via curl. Return verbatim findings + blocking items list."""
)
```

Surface report verbatim (pass-through rule).

---

## PHASE 3 — FIXES

Nova implements every blocking fix. For substantive code changes, re-invoke `agent-builder` with a targeted patch prompt. Push fixes to GitHub.

---

## PHASE 4 — PASS 2 REVIEW

Same prompt as Pass 1, but: "execute **Pass 2** review against the fixed build". Verdict: **PASS** or **ESCALATE**.

---

## PHASE 5 — SIGN OFF

- **PASS** → proceed to Step 8 of `@skills/agent-creation-pipeline.md` (register).
- **ESCALATE** → stop. Surface verbatim to Walt. Do not sign off. Walt decides whether to run a manual fix session or rebuild.

---

## The 6 review dimensions

1. **Nova Standard Structure** — all required files present (8 docs + CLAUDE.md + skills/ + wiki/ + .env.example + src/ if needed)
2. **Security** — no exposed credentials, SECURITY.md loaded in boot, secrets in .env.example only as placeholders
3. **CLAUDE.md Quality (basic)** — boot sequence, operating rules, trigger phrases, hard rules present
4. **Functionality Alignment** — PRD matches CLAUDE.md, skills exist as referenced, .env.example matches stated integrations
5. **Documentation Quality** — no empty template sections, real content throughout
6. **CLAUDE.md Quality (framework)** — passes `@skills/claude-md-quality.md` review checklist (length budget, anti-pattern scan, testability, DoD block, required header)

---

## Verification-before-sign-off rule

A PASS verdict from agent-code-reviewer must reference **concrete evidence** — file paths checked, line counts, test outputs, lint outputs. Pure judgement ("looks good") is not sufficient. If Pass 2 returns PASS without concrete evidence in the body, treat as ESCALATE and ask the reviewer for the evidence trail.
