# Skill: claude-md-quality

**Purpose:** Apply a research-backed framework to every CLAUDE.md in Walt's stack — new builds and existing files — so every agent is built to the same bar. Not "another" system. The best one.

**When to invoke:**
- Building a new agent's CLAUDE.md (run before the file is committed)
- Reviewing or upgrading an existing agent's CLAUDE.md
- Reviewing Nova's own root CLAUDE.md
- During Step 7 (Code Review) — agent-code-reviewer applies this as a 6th dimension

**Input:** Path to a CLAUDE.md file (or a draft).
**Output:** Audit table + gap analysis + tiered recommendations + binary checklist verdict.

---

## The 11 Framework Principles

### 1. Length budget — 80 to 150 lines
Anthropic, HumanLayer and Bijit Ghosh converge on this range. Above 200 lines, Claude starts ignoring rules — important instructions get lost in the noise. If you're over budget, you're putting situational content where universal content belongs. Move it to a skill, a hook, or SOUL.md.

### 2. Three-bucket categorization
For every item in CLAUDE.md, pick a bucket:

| Item type | Lives in |
|---|---|
| Model behaviour that can't be enforced by code (judgement, tone, when-to-ask) | **CLAUDE.md** |
| Deterministic action that must happen every time (registry audit, lint, secret scan, image attached) | **Hook** (settings.json) |
| Protocol relevant only when triggered (intake, code review, brief actioning) | **Skill** (loaded on demand) |
| Identity, voice, personality, who-the-agent-is | **SOUL.md** |

### 3. Testability test
For each rule, ask: *"Could I verify a violation of this in code review?"* If no, it's aspirational — move to SOUL.md or delete.
- ✓ Testable: "Every agent registration must appear in docs/AGENT-REGISTRY.md before session close."
- ✗ Aspirational: "Reflect Walt's voice" → SOUL.md.

### 4. Pruning test
For every line: *"Would removing this cause Claude to make a mistake?"* If no, cut. Anthropic: "Bloated CLAUDE.md files cause Claude to ignore your actual instructions."

### 5. Imperative voice
- ✓ "Always validate input at boundaries."
- ✓ "Never commit secrets."
- ✗ "Try to prefer composition."
- ✗ "It would be nice to use TypeScript."

### 6. Reserve emphasis markers
`IMPORTANT`, `YOU MUST`, `NO EXCEPTIONS` appear on **≤5 lines per file**. Overuse trains the model to ignore them.

### 7. Pointers over copies
Any protocol over ~10 lines belongs in a skill. CLAUDE.md gets one line: `For the agent build flow, see @skills/agent-creation-pipeline.md`. The skill loads on demand. The CLAUDE.md stays under budget.

### 8. Anti-pattern scan (12 checks)
Any hit means rework before commit:

1. Code-style rules (belong in a linter)
2. Personality directives (move to SOUL.md or cut)
3. File-by-file directory descriptions (use README.md)
4. Multi-paragraph rationale per rule (one line + skill link)
5. Auto-generated `/init` content not manually curated
6. Self-evident practices ("write clean code")
7. Standard language conventions
8. Long tutorials inside CLAUDE.md
9. API documentation (link instead)
10. Rules that contradict each other
11. Rules a linter / CI / hook would catch (move them there)
12. Dead path references or invalid MCP tool names

### 9. Required header
Every CLAUDE.md starts with:
```
# [Agent] OS — root memory
Owner: [name] | Last reviewed: [YYYY-MM-DD] | Length budget: [N] lines | Current: [M] lines
```
Forces periodic pruning. If you can't fit the budget, you've drifted — fix the file, not the budget.

### 10. Runtime vs Tracked file discipline (added 2026-05-21 — Session 97)
Every agent has a clean boundary between files git tracks and files the agent writes at runtime. Mixing the two pollutes `git status` on every boot and hides real WIP behind runtime noise.

| File category | Tracked? | Who writes it |
|---|---|---|
| Source (`src/`, `systemd/`, config), `docs/`, `CLAUDE.md`, `skills/` | ✅ tracked | Humans / Nova during build sessions only |
| `agent-memory.md`, `pending-rules.md` | ✅ tracked | Humans / Nova / `@skills/feedback-router.md` — **never the agent at runtime** |
| Wiki `Raw/` build notes | ✅ tracked | Nova during build sessions, committed at session close |
| `logs/`, `runtime-journal.md`, caches, `test-results/` | ❌ gitignored | Agent at runtime, freely |
| `venv/`, `.venv/`, `__pycache__/`, `*.pyc`, `node_modules/`, `dist/`, `.wrangler/` | ❌ gitignored | Tooling |
| `wiki/Master/master-context.md` and the empty `Raw/`, `Output/`, `Wiki/` scaffolds | ❌ gitignored | Runtime wiki fetch — the canonical source is `waltbayliss/walts-wiki`, the local copy is a cache |

**The invariant in one line:** agents must never modify a tracked file at runtime. If the agent needs to journal, cache, or persist, the destination is a gitignored runtime path. `agent-memory.md` is human-edit-only.

**Verification:** boot a fresh checkout, run the agent once, run `git status`. The tree must be clean. Anything dirty is either a missing `.gitignore` entry or an agent code path writing to a tracked file — both are bugs.

### 11. Definition of Done block at the end
Concrete checklist, never prose:
```
## Definition of Done
A task is not complete until ALL of these are true:
- [ ] Acceptance criteria from the brief/PRD are met
- [ ] Tests / lint / typecheck pass (or documented why not)
- [ ] Output verified against expected behaviour
- [ ] Risky changes have a rollback path
- [ ] Documentation updated where touched
```

---

## The Review Checklist (13 binary items)

- [ ] File length within budget (80–150 lines)
- [ ] Every rule passes the testability test OR is correctly placed in SOUL.md
- [ ] No protocol over 10 lines is inline — all are skill pointers
- [ ] No code-style / personality / generic-best-practice rules
- [ ] Required header present with current date
- [ ] Definition of Done block at end
- [ ] All `@skills/X.md` and `@docs/X.md` references resolve to real files
- [ ] All MCP tool names referenced are real and current
- [ ] All file paths in code blocks exist
- [ ] No more than 5 emphasis markers
- [ ] Anti-pattern scan clean (all 12 checks pass)
- [ ] Tool-minimization principle followed (read-only agents get only read tools)
- [ ] Runtime vs Tracked discipline holds — `.gitignore` covers runtime paths; no agent code path writes to a tracked file (principle 10)

Pass = all 13 checked. Fail = back for rework.

---

## Output Format When Reviewing

```
# CLAUDE.md Review — [agent-name]

## 1. Current State
- Path: [absolute path]
- Length: [N] lines / [budget] budget
- Last reviewed: [date]

## 2. Audit Table
| Section | Lines | Bucket Verdict | Recommended Move |
|---|---|---|---|

## 3. Anti-Pattern Scan
[hits, if any — empty section = pass]

## 4. Gap Analysis
[what's missing vs framework: header, DoD, etc.]

## 5. Recommendations — Tiered
**Tier 1 (structural compression):**
**Tier 2 (mechanical / hooks):**
**Tier 3 (quality additions):**

## 6. Checklist Verdict
[12-item table with PASS / FAIL each]

## 7. Sign-off
APPROVED / NEEDS REWORK / BLOCKED
```

---

## Sources
- [Anthropic — Best practices for Claude Code](https://code.claude.com/docs/en/best-practices)
- [HumanLayer — Writing a good CLAUDE.md](https://www.humanlayer.dev/blog/writing-a-good-claude-md)
- [Bijit Ghosh — Complete Guide to CLAUDE.md](https://medium.com/@bijit211987/the-complete-guide-to-claude-md-memory-rules-loading-and-cross-tool-compression-97cc12ed037b)
- [rosmur — Claude Code Best Practices](https://rosmur.github.io/claudecode-best-practices/)
- [iamfakeguru/claude-md](https://github.com/iamfakeguru/claude-md)
- [Anthropic — Multi-agent coordination patterns](https://claude.com/blog/multi-agent-coordination-patterns)
- [shanraisshan/claude-code-best-practice](https://github.com/shanraisshan/claude-code-best-practice)
- [ComposioHQ/agent-orchestrator](https://github.com/ComposioHQ/agent-orchestrator)
- [barkain/claude-code-workflow-orchestration](https://github.com/barkain/claude-code-workflow-orchestration)
- [OmerFarukOruc — AI Coding Agent Guidelines](https://gist.github.com/OmerFarukOruc/a02a5883e27b5b52ce740cadae0e4d60)
- [Jose Parreño García — Claude Code memory explained](https://joseparreogarcia.substack.com/p/claude-code-memory-explained)
- [Anthropic — Complete agent examples](https://github.com/anthropics/claude-code/blob/main/plugins/plugin-dev/skills/agent-development/examples/complete-agent-examples.md)

---

**Last updated:** 2026-05-12 — initial creation from research-backed framework.
**Owner:** Nova / Walt.
**Skill budget:** This skill itself follows its own rules — currently ~140 lines.
