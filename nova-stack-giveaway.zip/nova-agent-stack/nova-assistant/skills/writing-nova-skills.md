---
name: writing-nova-skills
description: Use when creating a new skill under @skills/, editing an existing one, or deciding whether something should be a skill at all. Covers Nova's skill format, the skills-vs-agents test, description-writing for discovery, and testing a skill before it ships.
---

# Skill: writing-nova-skills

**When to invoke:** Before adding or editing any file under `nova-assistant/skills/`. Pairs with `@skills/claude-md-quality.md` (for CLAUDE.md files) and rule 16 (skills-first vs new agents).

*Adapted for Nova from obra/superpowers (MIT). "Writing a skill is TDD applied to process documentation."*

*Validated 2026-05-26 (RED→GREEN subagent test, answer-blind): INCONCLUSIVE — the no-skill baseline already refused to wrap project facts in a skill and routed them to memory/, citing rule 16. No measurable behavioural delta. Retained as the codified standard.*

---

## First gate: should this even be a skill? (rule 16)

A **skill** is a reusable playbook Nova herself runs — sequencing existing tools, deciding, routing. Build a **new agent** only when the work needs its own runtime, schedule, environment, or third-party tools (cron jobs, daemons, systemd units).

**Write a skill when:** the technique wasn't obvious, you'd reference it again across workflows, it applies broadly.
**Don't write a skill for:** one-off solutions, project-specific facts (→ CLAUDE.md or memory), or anything enforceable with a hook/regex (→ automate it, don't document it).

## Nova's skill format

```markdown
---
name: kebab-case-name
description: Use when [specific triggering conditions and symptoms]. [Keywords for discovery.]
---

# Skill: kebab-case-name

**When to invoke:** [concrete triggers] — and which rule/pipeline step it slots into.

[Iron Law / core principle if a discipline skill]
[Quick-reference table, red flags, rationalization counters as needed]
```

Then add a row to the **SKILL POINTERS** table in `nova-assistant/CLAUDE.md` so it's discoverable.

## Description field — the #1 discovery lever

The description decides whether future-Nova loads the skill. **It must describe ONLY when to use — never summarize the workflow.**

Why: if the description summarizes the process, Nova follows the summary and skips reading the body. A description saying "code review between tasks" caused one review when the skill required two. Changing it to triggering-conditions-only fixed it.

```
❌ "Use when executing plans — dispatches a subagent per task with review between tasks"  (summarizes workflow)
✅ "Use when executing implementation plans with independent tasks"  (triggers only)
```

Start with "Use when…", write in third person, pack in keywords Nova would actually search (error strings, symptoms, tool names).

## Naming

Verb-first / gerund, by what you DO: `systematic-debugging`, `env-rotation`, `publish-blog-to-ghl` — not `debugging-utils` or `ghl-stuff`.

## TDD for skills (the core method)

Same Iron Law as code: **no skill without a failing test first.** Applies to new skills AND edits.

- **RED:** Run the scenario with a subagent *without* the skill. Document the exact choices and rationalizations it makes (verbatim). This is "watch it fail."
- **GREEN:** Write the minimal skill that addresses those specific failures. Don't pad for hypothetical cases. Re-run — the subagent should now comply.
- **REFACTOR:** Subagent found a new loophole? Add an explicit counter. Re-test until bulletproof.

For discipline skills (rules), test under combined pressure (time + sunk cost + authority). For technique/reference skills, test that a subagent can *find* and *apply* it correctly on a fresh scenario.

### Validation reality-check (learned 2026-05-26)

When you run RED→GREEN, expect this pattern and report it honestly:

- A skill earns a **clear behavioural delta** only when it flips a *tempting wrong default* (e.g. TDD: write code first → write test first) or **holds a line under pressure** (e.g. debugging: ship the fix → withhold until root cause). These are the skills worth their tokens.
- A skill that merely **restates a prior the model already holds** (e.g. "don't claim done without checking", "facts go in memory not a skill") will show **no delta** against a strong fresh-context subagent. That's not failure — but don't label it PASS. Mark it INCONCLUSIVE and keep it only as a codified standard for degraded contexts / weaker agent models.
- **Don't leak the answer in the test prompt.** If the scenario telegraphs the right move, even the no-skill baseline "passes" and you've measured nothing.
- **Don't hunt for a flattering scenario.** If two honest scenarios show no delta, stop and report no delta — chasing a third until the skill "wins" is motivated reasoning, the exact failure `verification-before-completion` exists to prevent.

## Bulletproofing discipline skills

- State the rule, then **forbid the specific workarounds** ("don't keep it as reference, don't adapt it — delete means delete").
- Add early: "Violating the letter is violating the spirit" — kills the spirit-vs-letter dodge.
- Build a rationalization table from what subagents actually said in RED.
- Add a Red Flags list so Nova can self-check mid-task.

## Cross-references

Use Nova's `@skills/<name>.md` form (it force-loads — use deliberately) or name-only with a REQUIRED marker for background. Don't `@`-link heavy reference you won't always need.

## Anti-patterns

- Narrative ("in session 104 we found…") → not reusable. Write the technique, not the story.
- Multi-language example dilution → one excellent example.
- Code inside flowcharts → use code blocks; flowcharts only for non-obvious decisions.
- Shipping untested → "obviously clear to me" ≠ clear to a subagent. Test it.

## Before it ships — checklist

- [ ] Passes the skill-vs-agent gate (rule 16)
- [ ] `name` is kebab-case; `description` is triggers-only, third person, keyword-rich
- [ ] Iron Law / core principle stated (if discipline skill)
- [ ] Rationalization table + red flags (if discipline skill)
- [ ] Tested with a subagent (RED → GREEN → REFACTOR), not just read
- [ ] Row added to SKILL POINTERS in CLAUDE.md
- [ ] Committed and pushed to origin/main
