# Skill: feedback-router

**Trigger:** Walt gives Nova feedback that is clearly aimed at a specific agent's runtime behaviour. Fires BEFORE the standard `lessons.md` entry (CLAUDE.md rule 17b).

**Why this skill exists:** Walt's feedback in Nova sessions ("don't put deliverables in agent-named subfolders", "composite is the default for SMP rows", "stop inventing creators in AI IDEAS") historically only landed in `lessons.md` and `nova-memory.md`. The actual agent that needs to change behaviour (image-creator, daily-brief, video-creator, whichever) never saw it — the next cron-triggered run operated from its pre-correction CLAUDE.md / agent-memory.md. This skill closes that loop: the correction reaches the agent's own memory, the agent's next run sees it, the behaviour actually changes. The `lessons.md` entry still fires (Nova's meta-record), but it's now a record OF the change, not the change itself.

---

## STEP 0 — DURABILITY GATE

Apply the durability test before doing anything else: **"Would this correction still be true and load-bearing 30 days from now, for every similar run?"**

- **YES** → continue (this is rule-shaped feedback, route to the agent)
- **NO** → this is a one-off course-correction. Skip routing. Drop straight to the standard `lessons.md` entry per rule 17.

This filters out ephemeral steers ("use Sonnet for this one", "skip the Telegram ping this time", "smaller image this time") from durable rules ("composite is the default for SMP rows", "never invent named creators in AI IDEAS", "deliverables land in canonical folders").

When uncertain: ask. "Is this a one-off or should I route it as a durable rule?" — one word answer is enough.

---

## STEP 1 — IDENTIFY TARGET AGENT

Ask: which agent's runtime behaviour must change in response to this feedback?

**Explicit — no confirmation needed:**
- Walt named the agent ("the thumbnailer keeps inventing faces" → `agent-youtube-thumbnailer`)
- Walt referenced a clearly-owned capability ("the daily brief is hallucinating creators" → `agent-daily-brief`)
- Walt named a file path that belongs to one agent

**Ambiguous — propose then wait for one-word confirmation:**
- Walt described a behaviour that could match multiple agents
- The feedback could plausibly be a Nova-skill change OR an agent change
- Reply: "Routing to `agent-<name>` — confirm? (yes / no / different agent)"
- Wait for confirmation before any write.

**Nova-only — do not fire this skill, just `lessons.md`:**
- Feedback is about Nova's own routing, intake, planning, communication style
- No agent's CLAUDE.md / agent-memory.md would change in response
- Example: "don't ask me 5 confirmation questions in a row, batch them" — Nova behaviour, no agent change.

---

## STEP 2 — CLASSIFY SEVERITY

Two write paths into the agent's repo:

### Type A — `agent-memory.md` (immediate behavioural change, no Nova review needed)

Use when: Walt has expressed a preference / correction that should govern future runs but doesn't require a structural rule change. The agent reads `agent-memory.md` at boot and applies its contents as durable context.

Entry format:
```
## [YYYY-MM-DD] WALT FEEDBACK

**Trigger:** [Walt's verbatim or paraphrased feedback]
**Rule:** [What this agent now does differently]
**Apply when:** [The condition under which the new behaviour kicks in]
```

### Type B — `pending-rules.md` (CLAUDE.md change needed, queued for Nova review at next boot)

Use when: the change is structural enough to deserve a hard rule in the agent's CLAUDE.md. Agent never self-modifies CLAUDE.md — proposals go to `pending-rules.md`, and Nova actions them at next boot.

Entry format (same as `@skills/self-improve.md` Step 3):
```
## [YYYY-MM-DD] Proposed Rule Change — feedback-router

**Pattern observed:** [Walt's feedback verbatim]
**Occurrences:** 1 (Walt-feedback shortcut — 3x threshold waived)
**Proposed CLAUDE.md addition:** [exact text of the new rule]
**Reason this should be a hard rule:** [why memory-level guidance isn't sufficient]
```

**Mirror Type B writes to the central inbox:** `nova-assistant/pending-agent-rules/<agent>.md` (per rule 6 — Nova reads this folder at every boot).

---

## STEP 3 — WRITE + COMMIT + PUSH

1. **Locate the agent's local checkout** at `/home/walt/agents/<agent>/`
2. **Check for uncommitted WIP** — `git status --short` in the agent dir:
   - **Clean** → proceed with local edit + commit + push
   - **WIP present** → STOP. Ask Walt: "agent-<name> has uncommitted WIP. (a) stash → apply → unstash, (b) write via GitHub API curl direct (bypass local checkout), (c) skip the route and just log to lessons.md?" Wait for answer.
3. **Apply the edit** — append to `agent-memory.md` OR `pending-rules.md` per Step 2 classification.
4. **Commit** with a clear message:
   - Type A: `agent-memory: Walt feedback YYYY-MM-DD — <one-line>`
   - Type B: `pending-rules: proposed CLAUDE.md change — <one-line>`
5. **Push** to `origin/main` (per VPS conventions — see `/home/walt/CLAUDE.md` and `nova-assistant/CLAUDE.md`).

---

## STEP 4 — CONFIRM TO WALT

State verbatim what was written + where + commit SHA, before the lessons.md entry:

> Logged to `agent-<name>/agent-memory.md` as WALT FEEDBACK YYYY-MM-DD — <one-line>. Commit `<sha>` pushed to `waltbayliss/agent-<name>` main.

If Type B (pending-rules path) was used, also confirm the central-inbox mirror:

> Mirrored to `nova-assistant/pending-agent-rules/<agent>.md` for Nova review at next boot.

If multiple agents are affected by the same feedback, route to each one separately and confirm each commit individually.

---

## STEP 5 — THEN FIRE RULE 17 (lessons.md)

Now run the standard `@skills/self-improve.md` protocol for Nova's meta-record:
- Write the `lessons.md` entry (Date / Mistake / Rule / Apply When)
- Confirm: "Lesson logged."
- The `lessons.md` entry should reference the agent commit: "Routed to `agent-<name>/agent-memory.md` commit `<sha>`."

The Nova-side `lessons.md` is the record of WHY the agent change was made. The agent-side `agent-memory.md` is what actually changes behaviour. Both happen.

---

## HARD RULES

1. This skill fires BEFORE the standard `lessons.md` entry — not instead of, not after.
2. Never modify an agent's `CLAUDE.md` directly. `pending-rules.md` is the only path; Nova reviews and actions at next boot.
3. Never skip the durability gate (Step 0). Routing every minor course-correction to an agent's memory creates noise and degrades the signal.
4. Never write to an agent's repo without checking for WIP first.
5. The agent-side write is the change. The `lessons.md` entry is the record OF the change. Both happen — neither replaces the other.
6. If multiple agents are affected, route to each separately. Don't bundle.

---

## EXAMPLES

**Example 1 — explicit, Type A, clean push:**
- Walt: "stop putting deliverables in agent-named subfolders"
- Durability gate: yes — this is a general principle about where outputs land.
- Identify: `agent-video-creator` (only agent that did this) — explicit, no confirm.
- Severity: A (clear preference, agent-memory.md is sufficient).
- Edit: append `WALT FEEDBACK 2026-05-19` entry to `agent-video-creator/agent-memory.md`.
- Commit + push: `agent-memory: Walt feedback 2026-05-19 — deliverables to canonical folder, never per-agent subfolder`.
- Confirm: "Logged to agent-video-creator/agent-memory.md as WALT FEEDBACK 2026-05-19. Commit `abc123` pushed."
- Then `lessons.md` entry referencing commit `abc123`.

**Example 2 — ambiguous, confirmation needed:**
- Walt: "the image is wrong — wrong outfit"
- Could be: `content-agent` (passed bad brief), `agent-image-creator` (interpreted brief wrong), or Nova (chose the wrong path).
- Propose: "Routing to `agent-image-creator` — confirm? (yes / no / different agent)"
- Wait. Only proceed after one-word answer.

**Example 3 — fails durability gate:**
- Walt: "use Opus for this one, the default Sonnet isn't sharp enough"
- Durability check: would this be true for ALL similar runs in 30 days? No — it's about THIS run.
- Skip routing. Drop straight to standard `lessons.md` per rule 17 if there's a model-routing insight worth capturing; otherwise skip entirely.

**Example 4 — Nova-only:**
- Walt: "don't ask me 5 confirmation questions in a row, batch them"
- This is Nova's communication style. No agent's behaviour changes.
- Skip this skill entirely. Standard `lessons.md` per rule 17.

**Example 5 — Type B (structural):**
- Walt: "every image agent must use a neutral reference photo as a baseline — make it a hard rule"
- Durability gate: yes — explicit "hard rule" instruction.
- Identify: `agent-image-creator` AND `agent-youtube-thumbnailer` — Walt named the category. Route to each separately.
- Severity: B (Walt asked for a hard rule).
- For each agent: append entry to `<agent>/pending-rules.md` AND mirror to `nova-assistant/pending-agent-rules/<agent>.md`.
- Commit + push each agent's repo separately.
- Confirm both commits + both mirrors.
- Then `lessons.md`.
