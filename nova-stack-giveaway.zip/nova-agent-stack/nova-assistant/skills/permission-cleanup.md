# Skill: Permission Cleanup

**Trigger:** Runs automatically at every session close. Also triggered on demand: "clean up permissions" or "update permissions".

**Purpose:** Reduce the number of permission prompts Walt sees by auditing `.claude/settings.json` against commands Nova actually ran this session, and adding any missing allow-patterns.

---

## How to Run

### Step 1 — Read current settings

```bash
cat /home/walt/agents/nova-assistant/.claude/settings.json
```

### Step 2 — Identify gaps

Think through the commands and tool calls made this session. For each command that required a permission prompt (or is likely to in future), check if a matching pattern exists in the `allow` list. Common gaps:

| Command pattern | Allow entry to add |
|---|---|
| `sudo cp *` | `Bash(sudo cp*)` |
| `sudo mkdir *` | `Bash(sudo mkdir*)` |
| `sudo chmod *` | already in deny — leave it |
| `VAR=$(...)` assignments with new variable names | `Bash(VARNAME_*)` |
| Any new MCP server UUID | `mcp__<UUID>__*` |
| New script paths | `Bash(bash /home/walt/scripts/newscript.sh)` |

### Step 3 — Add missing patterns

Use the Edit tool to add missing entries to the `allow` array in `.claude/settings.json`.

### Step 4 — Push settings.json to GitHub

Settings.json is committed to the nova-assistant repo. Push the updated file:

```bash
TOKEN=$(grep ^GITHUB_PERSONAL_ACCESS_TOKEN /home/walt/.env | cut -d= -f2- | tr -d '[:space:]')
SHA=$(curl -s -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/waltbayliss/nova-assistant/contents/.claude/settings.json" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['sha'])")
CONTENT_B64=$(base64 -w0 < /home/walt/agents/nova-assistant/.claude/settings.json)
curl -s -X PUT -H "Authorization: token $TOKEN" -H "Content-Type: application/json" \
  -d "{\"message\":\"config: session close — permission cleanup\",\"content\":\"$CONTENT_B64\",\"sha\":\"$SHA\"}" \
  "https://api.github.com/repos/waltbayliss/nova-assistant/contents/.claude/settings.json"
```

### Step 5 — Confirm

Tell Walt: "Permissions updated — [N] new patterns added."

---

## Notes

- Never add `Bash(rm*)`, `Bash(sudo rm*)`, `Bash(git push --force*)` to allow — these stay in deny.
- When a new MCP server is added to the stack, add its `mcp__<UUID>__*` wildcard here immediately.
- Settings changes take effect on next session — existing session is not affected.
