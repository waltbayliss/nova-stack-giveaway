---
name: systematic-debugging
description: Use when encountering any bug, test failure, build failure, or unexpected behaviour in an agent or script — before proposing any fix. Enforces root-cause investigation first. Especially under time pressure or after a fix has already failed.
---

# Skill: systematic-debugging

**When to invoke:** ANY technical issue — test failure, agent crash, cron job not firing, unexpected output, build/lint failure, integration breakage — before proposing or applying a fix. Nova invokes this herself when debugging, and instructs subagents to follow it when they debug.

*Adapted for Nova from obra/superpowers (MIT). Cross-refs rewritten to Nova's namespace.*

*Validated 2026-05-26 (RED→GREEN subagent test): without skill the subagent proposed the fix then justified it ("I'd ship the hardened parser now"); with skill it withheld the fix and investigated root cause first under the same time pressure ("investigate, not fix… until I see the actual file"). Marginal value is holding the line under pressure — PASS.*

---

## The Iron Law

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

If Phase 1 isn't complete, you cannot propose a fix. Symptom fixes are failure — they mask the real problem and create new bugs.

**Violating the letter of this process is violating the spirit of debugging.**

## When this ESPECIALLY applies

- Under time pressure (emergencies make guessing tempting)
- "Just one quick fix" seems obvious
- You've already tried 1+ fixes that didn't work
- You don't fully understand the issue

Don't skip because the issue "seems simple" — simple bugs have root causes too, and the process is fast for them.

## The Four Phases — complete each before the next

### Phase 1: Root Cause Investigation (BEFORE any fix)

1. **Read error messages carefully.** Full stack traces, line numbers, file paths, error codes. They often contain the exact answer.
2. **Reproduce consistently.** Can you trigger it reliably? Exact steps? If not reproducible → gather more data, don't guess.
3. **Check recent changes.** `git diff`, recent commits, new deps, config/env changes. On the VPS this often means a Doppler secret, a cron change, or a worktree drift.
4. **Gather evidence across component boundaries.** For multi-layer systems (cron → agent → MCP → API, or hook → script → Notion), add diagnostic logging at each boundary: log what enters and exits each layer, verify env/config propagation. Run once to see WHERE it breaks, *then* investigate that layer. This is the Nova-VPS pattern already in memory: *write a one-shot diagnostic before guessing* (see `feedback_sa_diagnostic_pattern`).
5. **Trace data flow backward.** Where does the bad value originate? What passed it in? Keep tracing up to the source. Fix at source, not at symptom.

### Phase 2: Pattern Analysis

- Find a working example of the same thing elsewhere in the codebase / another agent.
- Read the reference implementation **completely** — don't skim, don't adapt a half-understood pattern.
- List every difference between working and broken, however small. Don't assume "that can't matter."

### Phase 3: Hypothesis and Testing

- State ONE hypothesis: "I think X is the root cause because Y."
- Test it with the **smallest possible change**, one variable at a time.
- Worked? → Phase 4. Didn't? → form a NEW hypothesis. Don't stack fixes.
- If you don't know, say "I don't understand X" — don't pretend.

### Phase 4: Implementation

1. **Create a failing test/repro first** (use `@skills/test-driven-development.md`). A one-off script is fine if there's no framework.
2. **Implement ONE fix** for the root cause. No "while I'm here" changes, no bundled refactoring.
3. **Verify** via `@skills/verification-before-completion.md` — run the command, read the output, confirm the symptom is gone and nothing else broke.
4. **If the fix fails:** STOP. Count attempts. <3 → return to Phase 1 with new info. **≥3 → stop and question the architecture** (the pattern may be fundamentally wrong). Discuss with Walt before attempting fix #4.

## Red Flags — STOP and return to Phase 1

- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "It's probably X, let me fix that" (before tracing)
- Proposing fixes before reading the full error / tracing data flow
- "One more fix attempt" after 2+ failures
- Each fix reveals a new problem in a different place → architecture is wrong

## Signals from Walt that you're doing it wrong

- "Is that not happening?" — you assumed without verifying
- "Stop guessing" — you're fixing without understanding
- "We're stuck?" (frustrated) — your approach isn't working

When you see these: STOP, return to Phase 1, and on any correction log a lesson via `@skills/self-improve.md`.

## Quick Reference

| Phase | Activity | Done when |
|---|---|---|
| 1. Root cause | Read errors, reproduce, check changes, instrument boundaries | You understand WHAT and WHY |
| 2. Pattern | Find working example, compare | Differences identified |
| 3. Hypothesis | One theory, minimal test | Confirmed or new hypothesis |
| 4. Implement | Failing repro, one fix, verify | Symptom gone, tests pass |
