"""
Shared heartbeat writer for Nova agents.

Usage (Python):
    from heartbeat import beat
    beat("my-agent-name")   # call at end of successful run

Usage (bash):
    python3 /home/walt/agents/nova-assistant/agent-ops-watchdog/src/heartbeat.py my-agent-name
"""
from __future__ import annotations
import sys
from datetime import datetime, timezone
from pathlib import Path

HEARTBEAT_DIR = Path("/home/walt/agents/.heartbeats")


def beat(name: str) -> None:
    HEARTBEAT_DIR.mkdir(parents=True, exist_ok=True)
    (HEARTBEAT_DIR / name).write_text(datetime.now(timezone.utc).isoformat())


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: heartbeat.py <agent-name>")
        sys.exit(1)
    beat(sys.argv[1])
    print(f"[heartbeat] {sys.argv[1]} — recorded")
