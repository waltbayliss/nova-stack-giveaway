#!/usr/bin/env python3
"""
agent-ops-watchdog — daily pipeline health check for Walt's content ops.

Checks (silent on all-clear):
  1. Failed agent-* systemd services
  2. Social posts stuck in Pending > STALE_DAYS days (not progressing)
  3. Social posts stuck in Pending Audit > AUDIT_STALE_DAYS days
  4. Image backfill queue depth (Include Image=True, no image file, status not Posted)
  5. Posts with Validation Failed status

Runs via cron at 8:00 UTC (6pm AEST) daily.
"""
import json
import os
import subprocess
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta
from pathlib import Path
from dotenv import load_dotenv

load_dotenv("/home/walt/.env")

NOTION_TOKEN = os.environ["NOTION_TOKEN"]
SOCIAL_DB   = "[REDACTED-ID]"
BOT_TOKEN   = os.environ["TELEGRAM_BOT_TOKEN"]
CHAT_ID     = os.environ["TELEGRAM_CHAT_ID"]

STALE_DAYS       = 3   # Pending posts older than this flagged as stuck
AUDIT_STALE_DAYS = 2   # Posts stuck in audit queue

HEARTBEAT_DIR = Path("/home/walt/agents/.heartbeats")


def _load_registry() -> list[dict]:
    """Load registry entries. Each entry: key, label, max_hours, and optional
    `unit` (systemd unit base, defaults to the key) and `proc` (pgrep -f pattern
    for persistent pollers with no heartbeat file)."""
    reg_path = HEARTBEAT_DIR / "registry.json"
    try:
        data = json.loads(reg_path.read_text())
        return [
            {"key": k, "label": v["label"], "max_hours": int(v["max_hours"]),
             "unit": v.get("unit", k), "proc": v.get("proc")}
            for k, v in data.items()
            if not k.startswith("_")
        ]
    except Exception as e:
        print(f"[watchdog] registry load error: {e}")
        return []


def _systemctl_value(prop: str, unit: str) -> str:
    """Return a single systemctl property value, or '' on any error."""
    try:
        out = subprocess.run(
            ["systemctl", "show", "-p", prop, "--value", unit],
            capture_output=True, text=True, timeout=10,
        )
        return out.stdout.strip()
    except Exception:
        return ""


def _parse_systemd_ts(val: str):
    """Parse a systemd timestamp like 'Mon 2026-05-25 22:45:16 UTC' -> aware datetime, or None."""
    if not val or val in ("n/a", "0", ""):
        return None
    # Drop leading weekday token, parse the rest.
    parts = val.split(None, 1)
    body = parts[1] if len(parts) == 2 else val
    for fmt in ("%Y-%m-%d %H:%M:%S %Z", "%Y-%m-%d %H:%M:%S"):
        try:
            dt = datetime.strptime(body, fmt)
            return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
        except ValueError:
            continue
    return None


def _systemd_ok(unit_base: str, max_hours: int, now: datetime) -> bool:
    """True if the component's systemd timer triggered, or its service is running /
    last started, within max_hours. Covers timer-driven oneshots AND long-running services."""
    timer = f"{unit_base}.timer"
    service = f"{unit_base}.service"
    # Timer: last trigger within window?
    lt = _parse_systemd_ts(_systemctl_value("LastTriggerUSec", timer))
    if lt and (now - lt).total_seconds() / 3600 <= max_hours:
        return True
    # Long-running service: currently active counts as healthy regardless of start age.
    if _systemctl_value("ActiveState", service) == "active":
        sub = _systemctl_value("SubState", service)
        if sub == "running":
            return True
        # oneshot/exited: fall through to last-start check
    started = _parse_systemd_ts(_systemctl_value("ActiveEnterTimestamp", service))
    if started and (now - started).total_seconds() / 3600 <= max_hours:
        return True
    return False


def _proc_alive(pattern: str) -> bool:
    """True if at least one process matches the pgrep -f pattern."""
    if not pattern:
        return False
    try:
        return subprocess.run(["pgrep", "-f", pattern], capture_output=True, timeout=10).returncode == 0
    except Exception:
        return False


# ── Notion helpers ────────────────────────────────────────────────────────────

def notion_query(db_id, filter_body, page_size=50):
    body = json.dumps({"filter": filter_body, "page_size": page_size}).encode()
    req = urllib.request.Request(
        f"https://api.notion.com/v1/databases/{db_id}/query",
        data=body,
        headers={
            "Authorization": f"Bearer {NOTION_TOKEN}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28",
        },
        method="POST",
    )
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())["results"]


def prop_title(p):
    items = p.get("Title", {}).get("title", [])
    return items[0]["text"]["content"] if items else "Untitled"


def prop_date(page, key="created_time"):
    val = page.get(key, "")
    if not val:
        return None
    return datetime.fromisoformat(val.replace("Z", "+00:00"))


# ── Checks ────────────────────────────────────────────────────────────────────

def check_failed_services():
    """Return list of failed agent-* service names."""
    try:
        r = subprocess.run(
            ["systemctl", "list-units", "agent-*", "--state=failed", "--no-legend", "--no-pager"],
            capture_output=True, text=True, timeout=10,
        )
        lines = [l.split()[0] for l in r.stdout.strip().splitlines() if l.strip()]
        return lines
    except Exception as e:
        return [f"(systemctl error: {e})"]


def check_stale_pending():
    """Posts in Pending status older than STALE_DAYS."""
    cutoff = (datetime.now(timezone.utc) - timedelta(days=STALE_DAYS)).isoformat()
    pages = notion_query(SOCIAL_DB, {
        "and": [
            {"property": "Status", "status": {"equals": "Pending"}},
            {"timestamp": "created_time", "created_time": {"before": cutoff}},
        ]
    })
    return [(prop_title(p["properties"]), prop_date(p, "created_time")) for p in pages]


def check_stale_audit():
    """Posts stuck in Pending Audit > AUDIT_STALE_DAYS."""
    cutoff = (datetime.now(timezone.utc) - timedelta(days=AUDIT_STALE_DAYS)).isoformat()
    pages = notion_query(SOCIAL_DB, {
        "and": [
            {"property": "Audit Status", "select": {"equals": "Pending Audit"}},
            {"timestamp": "created_time", "created_time": {"before": cutoff}},
        ]
    })
    return [(prop_title(p["properties"]), prop_date(p, "created_time")) for p in pages]


def check_image_backfill():
    """Posts that need an image but haven't had one generated yet."""
    pages = notion_query(SOCIAL_DB, {
        "and": [
            {"property": "Include Image", "checkbox": {"equals": True}},
            {"property": "Status", "status": {"does_not_equal": "Posted"}},
            {"property": "Status", "status": {"does_not_equal": "Failed"}},
            {"property": "Image Status", "select": {"is_empty": True}},
        ]
    }, page_size=100)
    # Filter out rows that already have image files attached
    waiting = []
    for p in pages:
        files = p["properties"].get("Image", {}).get("files", [])
        if not files:
            waiting.append(prop_title(p["properties"]))
    return waiting


def check_validation_failed():
    """Posts in Validation Failed status."""
    pages = notion_query(SOCIAL_DB, {
        "property": "Status", "status": {"equals": "Validation Failed"}
    })
    return [prop_title(p["properties"]) for p in pages]


def check_stale_timers():
    """Systemd timer units that haven't activated within their expected window."""
    try:
        r = subprocess.run(
            ["systemctl", "list-timers", "agent-*", "--all", "--no-legend", "--no-pager"],
            capture_output=True, text=True, timeout=10,
        )
        issues = []
        now = datetime.now(timezone.utc)
        for line in r.stdout.strip().splitlines():
            parts = line.split()
            if not parts or parts[0] in ("NEXT", ""):
                continue
            # Format: NEXT LEFT LAST PASSED UNIT ACTIVATES
            # Find UNIT column — it ends in .timer
            unit = next((p for p in parts if p.endswith(".timer")), None)
            if not unit:
                continue
            # Find "PASSED" value — token after the LAST timestamp block
            # systemctl output: "<date> <time> <tz>  <Xh ago>  <unit>  <activates>"
            # Join and search for "ago" marker
            passed_str = ""
            for i, p in enumerate(parts):
                if p == "ago" and i >= 1:
                    passed_str = parts[i - 1]
                    break
            if not passed_str:
                issues.append((unit, "never activated"))
                continue
            # Parse e.g. "17h" "3d" "45min"
            hours = None
            if passed_str.endswith("h"):
                try:
                    hours = float(passed_str[:-1])
                except ValueError:
                    pass
            elif passed_str.endswith("d"):
                try:
                    hours = float(passed_str[:-1]) * 24
                except ValueError:
                    pass
            elif passed_str.endswith("min"):
                hours = 0
            if hours is None:
                continue
            # Flag if overdue by more than 150% of expected interval
            # (We don't know the schedule, so flag if >26h for daily-looking timers,
            #  >9d for weekly. Use a generous threshold to avoid noise.)
            if hours > 9 * 24:
                issues.append((unit, f"last fired {hours:.0f}h ago"))
        return issues
    except Exception as e:
        return [(f"(systemctl timer check error: {e})", "")]


def check_heartbeats():
    """Liveness check per registered component. A component is healthy if ANY signal
    is fresh: (1) its heartbeat file, (2) its systemd timer/service last-run, or
    (3) a live matching process. Only alert when all available signals fail —
    this stops false 'never run' alarms for components that run via systemd/processes
    but don't (yet) write a heartbeat file."""
    issues = []
    now = datetime.now(timezone.utc)
    for entry in _load_registry():
        label, max_hours = entry["label"], entry["max_hours"]
        # 1. Heartbeat file (primary signal)
        path = HEARTBEAT_DIR / entry["key"]
        if path.exists():
            try:
                mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
                age_h = (now - mtime).total_seconds() / 3600
                if age_h <= max_hours:
                    continue  # healthy
                hb_detail = f"heartbeat {age_h:.0f}h old (limit {max_hours}h)"
            except Exception as e:
                hb_detail = f"heartbeat read error: {e}"
        else:
            hb_detail = "no heartbeat file"
        # 2. systemd timer/service fallback
        if _systemd_ok(entry["unit"], max_hours, now):
            continue
        # 3. live process fallback (persistent pollers)
        if _proc_alive(entry["proc"]):
            continue
        # All signals failed — genuine concern
        issues.append((label, f"{hb_detail}; no active systemd unit; no live process"))
    return issues


# ── Telegram send ─────────────────────────────────────────────────────────────

def send_telegram(text):
    payload = json.dumps({"chat_id": CHAT_ID, "text": text}).encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
        data=payload,
        headers={"Content-Type": "application/json", "User-Agent": "agent-ops-watchdog/1.0"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        print(f"[telegram] sent ({r.status})")


# ── Report builder ────────────────────────────────────────────────────────────

def build_report(failed_svcs, stale_pending, stale_audit, image_queue, val_failed,
                 stale_timers, stale_heartbeats):
    issues = []

    if failed_svcs:
        issues.append(f"FAIL Failed services ({len(failed_svcs)}):")
        for s in failed_svcs:
            issues.append(f"  - {s}")

    if stale_pending:
        issues.append(f"\nWARN Posts stuck in Pending > {STALE_DAYS}d ({len(stale_pending)}):")
        for title, dt in stale_pending[:5]:
            age = (datetime.now(timezone.utc) - dt).days if dt else "?"
            issues.append(f"  - {title[:50]} ({age}d old)")

    if stale_audit:
        issues.append(f"\nWARN Posts stuck in audit > {AUDIT_STALE_DAYS}d ({len(stale_audit)}):")
        for title, dt in stale_audit[:5]:
            age = (datetime.now(timezone.utc) - dt).days if dt else "?"
            issues.append(f"  - {title[:50]} ({age}d)")

    if image_queue:
        issues.append(f"\nINFO Image backfill queue: {len(image_queue)} posts waiting")
        for t in image_queue[:3]:
            issues.append(f"  - {t[:50]}")
        if len(image_queue) > 3:
            issues.append(f"  ... and {len(image_queue)-3} more")

    if val_failed:
        issues.append(f"\nFAIL Validation failed posts ({len(val_failed)}):")
        for t in val_failed[:3]:
            issues.append(f"  - {t[:50]}")

    if stale_timers:
        issues.append(f"\nWARN Overdue systemd timers ({len(stale_timers)}):")
        for unit, detail in stale_timers:
            issues.append(f"  - {unit}: {detail}")

    if stale_heartbeats:
        issues.append(f"\nWARN Stuck cron jobs ({len(stale_heartbeats)}):")
        for label, detail in stale_heartbeats:
            issues.append(f"  - {label}: {detail}")

    return issues


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    print(f"[watchdog] Running {now}")

    failed_svcs      = check_failed_services()
    stale_pending    = check_stale_pending()
    stale_audit      = check_stale_audit()
    image_queue      = check_image_backfill()
    val_failed       = check_validation_failed()
    stale_timers     = check_stale_timers()
    stale_heartbeats = check_heartbeats()

    issues = build_report(failed_svcs, stale_pending, stale_audit, image_queue, val_failed,
                          stale_timers, stale_heartbeats)

    # Write heartbeat so the weekly report (and future monitors) can verify we ran
    HEARTBEAT_DIR.mkdir(parents=True, exist_ok=True)
    (HEARTBEAT_DIR / "ops-watchdog").write_text(datetime.now(timezone.utc).isoformat())

    if not issues:
        print("[watchdog] All clear — no notification sent")
        return

    header = f"Ops Watchdog — {now}\n"
    msg = header + "\n".join(issues)
    print(msg)
    send_telegram(msg)
    print("[watchdog] Done")


if __name__ == "__main__":
    main()
