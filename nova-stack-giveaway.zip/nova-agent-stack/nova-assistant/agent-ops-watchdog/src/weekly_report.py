#!/usr/bin/env python3
"""
weekly_report.py — generates a formatted PDF ops summary and sends to Telegram.

Covers the past 7 days:
  - Posts published vs drafted vs failed
  - Platform breakdown
  - Image generation stats
  - Agent service health snapshot
  - Top content by platform

Runs via cron Sunday 8:30 UTC (6:30pm AEST).
"""
import json
import os
import subprocess
import tempfile
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv

load_dotenv("/home/walt/.env")

NOTION_TOKEN = os.environ["NOTION_TOKEN"]
SOCIAL_DB    = "[REDACTED-ID]"
BOT_TOKEN    = os.environ["TELEGRAM_BOT_TOKEN"]
CHAT_ID      = os.environ["TELEGRAM_CHAT_ID"]


# ── Notion helpers ────────────────────────────────────────────────────────────

def notion_query(db_id, filter_body, page_size=100):
    body = json.dumps({"filter": filter_body, "page_size": page_size}).encode()
    req = urllib.request.Request(
        f"https://api.notion.com/v1/databases/{db_id}/query",
        data=body,
        headers={
            "Authorization": f"Bearer {NOTION_TOKEN}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28",
        },
        method="POST",
    )
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())["results"]


def prop_title(p):
    items = p.get("Title", {}).get("title", [])
    return items[0]["text"]["content"] if items else "Untitled"


def prop_platforms(p):
    return [s["name"] for s in p.get("Platform", {}).get("multi_select", [])]


# ── Data gathering ────────────────────────────────────────────────────────────

def gather_stats():
    week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()

    all_recent = notion_query(SOCIAL_DB, {
        "timestamp": "created_time",
        "created_time": {"after": week_ago}
    })

    stats = {
        "total": len(all_recent),
        "posted": 0,
        "pending": 0,
        "failed": 0,
        "validation_failed": 0,
        "platforms": {},
        "posted_titles": [],
        "failed_titles": [],
    }

    for p in all_recent:
        props = p["properties"]
        status_name = props.get("Status", {}).get("status", {}).get("name", "")
        title = prop_title(props)
        platforms = prop_platforms(props)

        if status_name == "Posted":
            stats["posted"] += 1
            stats["posted_titles"].append((title, platforms))
        elif status_name == "Pending":
            stats["pending"] += 1
        elif status_name == "Failed":
            stats["failed"] += 1
            stats["failed_titles"].append(title)
        elif status_name == "Validation Failed":
            stats["validation_failed"] += 1
            stats["failed_titles"].append(f"{title} (validation)")

        for platform in platforms:
            stats["platforms"][platform] = stats["platforms"].get(platform, 0) + 1

    return stats


def gather_service_health():
    """Snapshot of agent service states."""
    try:
        r = subprocess.run(
            ["systemctl", "list-units", "agent-*", "--no-legend", "--no-pager", "--all"],
            capture_output=True, text=True, timeout=10,
        )
        services = {}
        for line in r.stdout.strip().splitlines():
            parts = line.split()
            if len(parts) >= 3:
                name = parts[0].replace(".service", "").replace("agent-", "")
                active = parts[2]
                services[name] = active
        return services
    except Exception:
        return {}


# ── HTML report ───────────────────────────────────────────────────────────────

def build_html(stats, services, week_label):
    platform_rows = "".join(
        f"<tr><td>{p}</td><td>{c}</td></tr>"
        for p, c in sorted(stats["platforms"].items(), key=lambda x: -x[1])
    )

    posted_rows = "".join(
        f"<tr><td>{t[:60]}</td><td>{', '.join(pl)}</td></tr>"
        for t, pl in stats["posted_titles"][:10]
    ) or "<tr><td colspan='2'>None this week</td></tr>"

    failed_list = "".join(
        f"<li>{t[:70]}</li>" for t in stats["failed_titles"]
    ) or "<li>None</li>"

    running = sum(1 for s in services.values() if s == "running")
    failed_svcs = [n for n, s in services.items() if s == "failed"]
    svc_status = f"{running} running" + (f", {len(failed_svcs)} FAILED: {', '.join(failed_svcs)}" if failed_svcs else "")
    svc_color = "#dc2626" if failed_svcs else "#16a34a"

    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<style>
  body {{ font-family: 'Helvetica Neue', Arial, sans-serif; color: #1a1a1a;
         max-width: 720px; margin: 0 auto; padding: 32px; background: #fff; }}
  h1 {{ color: #0891b2; font-size: 22px; border-bottom: 2px solid #0891b2; padding-bottom: 8px; }}
  h2 {{ color: #374151; font-size: 15px; margin-top: 24px; margin-bottom: 8px; }}
  .metric-row {{ display: flex; gap: 16px; margin: 16px 0; }}
  .metric {{ background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px;
             padding: 12px 20px; flex: 1; text-align: center; }}
  .metric .num {{ font-size: 32px; font-weight: 800; color: #0891b2; }}
  .metric .label {{ font-size: 11px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.05em; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 8px; }}
  th {{ background: #f3f4f6; text-align: left; padding: 6px 10px; font-weight: 600; color: #374151; }}
  td {{ padding: 5px 10px; border-bottom: 1px solid #f0f0f0; }}
  .ok {{ color: #16a34a; font-weight: 600; }}
  .bad {{ color: #dc2626; font-weight: 600; }}
  .footer {{ margin-top: 32px; font-size: 11px; color: #9ca3af; border-top: 1px solid #e5e7eb; padding-top: 12px; }}
</style>
</head>
<body>
  <h1>Nova Ops Report — {week_label}</h1>

  <div class="metric-row">
    <div class="metric"><div class="num">{stats['total']}</div><div class="label">Created</div></div>
    <div class="metric"><div class="num">{stats['posted']}</div><div class="label">Posted</div></div>
    <div class="metric"><div class="num">{stats['pending']}</div><div class="label">In Queue</div></div>
    <div class="metric"><div class="num" style="color:{'#dc2626' if stats['failed']+stats['validation_failed'] else '#16a34a'}">{stats['failed']+stats['validation_failed']}</div><div class="label">Failed</div></div>
  </div>

  <h2>Platform Breakdown (this week)</h2>
  <table>
    <tr><th>Platform</th><th>Posts</th></tr>
    {platform_rows or '<tr><td colspan="2">No data</td></tr>'}
  </table>

  <h2>Published This Week</h2>
  <table>
    <tr><th>Title</th><th>Platform</th></tr>
    {posted_rows}
  </table>

  {"<h2>Failed / Validation Issues</h2><ul>" + failed_list + "</ul>" if stats['failed_titles'] else ""}

  <h2>Agent Services</h2>
  <p style="color:{svc_color}; font-weight:600;">{svc_status}</p>

  <div class="footer">Generated by Nova agent-ops-watchdog &middot; {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}</div>
</body>
</html>"""


# ── PDF + send ────────────────────────────────────────────────────────────────

def html_to_pdf(html, output_path):
    import weasyprint
    weasyprint.HTML(string=html).write_pdf(output_path)


def send_document(pdf_path, caption):
    with open(pdf_path, "rb") as f:
        pdf_bytes = f.read()

    boundary = "----FormBoundary7MA4YWxkTrZu0gW"
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="chat_id"\r\n\r\n{CHAT_ID}\r\n'
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="caption"\r\n\r\n{caption}\r\n'
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="document"; filename="ops-report.pdf"\r\n'
        f"Content-Type: application/pdf\r\n\r\n"
    ).encode() + pdf_bytes + f"\r\n--{boundary}--\r\n".encode()

    req = urllib.request.Request(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument",
        data=body,
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "User-Agent": "agent-ops-watchdog/1.0",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        print(f"[telegram] document sent ({r.status})")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    now = datetime.now(timezone.utc)
    week_start = (now - timedelta(days=7)).strftime("%b %d")
    week_end   = now.strftime("%b %d, %Y")
    week_label = f"{week_start} – {week_end}"

    print(f"[weekly-report] Generating for {week_label}")

    stats    = gather_stats()
    services = gather_service_health()
    html     = build_html(stats, services, week_label)

    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
        pdf_path = f.name

    html_to_pdf(html, pdf_path)
    print(f"[weekly-report] PDF written: {pdf_path}")

    caption = (
        f"Nova Ops Report — {week_label}\n"
        f"{stats['posted']} posted · {stats['pending']} in queue · "
        f"{stats['failed']+stats['validation_failed']} failed"
    )
    send_document(pdf_path, caption)
    from pathlib import Path
    Path("/home/walt/agents/.heartbeats/ops-watchdog-weekly").write_text(datetime.now(timezone.utc).isoformat())
    print("[weekly-report] Done")


if __name__ == "__main__":
    main()
