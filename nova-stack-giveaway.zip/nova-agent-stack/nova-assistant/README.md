# Nova — Walt's Personal AI Assistant

Nova is Walt Bayliss's personal AI assistant. As of 2026-07-02, Walt has exited [Prior Venture] and holds a senior Growth & Revenue role covering Australia/APAC for [Employer] ([Employer]) — Nova's job is now to help him excel at that role. She is deeply contextualised, always loads Walt's current context, and maintains her own dynamic memory.

**Owner:** Walt Bayliss | **Repo:** waltbayliss/nova-assistant

---

## Quick start

1. Load Walt's context: GET https://api.github.com/repos/waltbayliss/walts-wiki/contents/Walt%27s%20Wiki%2FMaster%20Wiki%2Fmaster-context.md
2. Read `docs/` folder for Nova's full spec
3. Read `CLAUDE.md` for session rules

## Key connections

| Service | Purpose | Endpoint |
|---|---|---|
| Walt's Wiki | Live context — who Walt is, what he's working on | https://api.github.com/repos/waltbayliss/walts-wiki |
| walts-wiki GitHub repo | Local knowledge base | https://github.com/waltbayliss/walts-wiki |
| Local n8n | Workflow orchestration | http://localhost:5678 |
| Notion | Walt's operational HQ | Notion API |
| GitHub | Version control + memory | waltbayliss/* |

## Environment variables

| Variable | Description | Required |
|---|---|---|
| `ANTHROPIC_API_KEY` | Claude API for Nova's intelligence layer | Yes |
| `NOTION_API_KEY` | Notion integration token | Yes |
| `GITHUB_PERSONAL_ACCESS_TOKEN` | walts-wiki GitHub API token | Yes |

See `docs/` for full documentation.
