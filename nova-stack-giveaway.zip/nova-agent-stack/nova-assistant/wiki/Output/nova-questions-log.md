*(Real content removed for public distribution — nova-questions-log.md exists here to show the wiki folder structure this agent writes to, not its actual captured history.)*
