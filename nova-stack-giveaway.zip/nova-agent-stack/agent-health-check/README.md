# agent-health-check

Nova immune system.
Daily health check of Walt Bayliss AI agent stack.
Runs at 08:00 AEST via systemd timer. Silent on green, loud on failure.
See docs/PRD.md for specification.
