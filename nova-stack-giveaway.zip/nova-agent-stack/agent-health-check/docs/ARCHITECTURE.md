# agent-health-check Architecture

## Overview

Single Python process, systemd timer trigger. Runs 10 health checks in parallel via asyncio.gather,
aggregates results, auto-fixes, notifies via Telegram Worker, writes outputs to GitHub.

## Module Map

src/health_check.py - main entry point
src/config_loader.py - config.yaml + env var expansion
src/registry_reader.py - fetches AGENT-REGISTRY.md from walts-wiki
src/check_runner.py - asyncio.gather dispatcher, CheckStatus, backoff
src/auto_fix.py - safe restarts + temp cleanup
src/trend_detector.py - REGRESSION/ONGOING/RECOVERED annotation
src/telegram_notify.py - format + send via nova-telegram Worker
src/wiki_writer.py - health log + state.json PUT to GitHub
src/checks/process_check.py - dbus-next + systemctl + launchctl
src/checks/notion_check.py - Notion API queries
src/checks/github_check.py - GitHub token (lru_cache 60min)
src/checks/http_check.py - httpx async health pings
src/checks/log_check.py - filesystem log scanning
config.yaml - drives all check targets and thresholds
deploy/agent-health-check.service + .timer

## Data Flow

1. systemd timer fires at 22:00 UTC
2. acquire_lock() - exit if concurrent run detected
3. load_config() + fetch_registry()
4. asyncio.gather(10 checks) - parallel, per-check timeout + backoff
5. compute_diff(prev state.json) - REGRESSION/ONGOING/RECOVERED
6. attempt_fixes() - safe restarts only
7. compute_rating() - Healthy/Needs Attention/Degrading/Critical
8. send_notification() FIRST - never blocked by wiki write
9. write_health_log() to walts-wiki
10. write_state_json() to nova-assistant
11. release_lock()

## Wiki-Write Specification

Health log (every run):
- Repo: waltbayliss/walts-wiki
- Path: Walt Wiki/Health Logs/YYYY-MM-DD.md
- Trigger: end of every run

State file (every run):
- Repo: waltbayliss/nova-assistant
- Path: health-state.json
- Method: idempotent PUT

## Key Design Decisions

1. asyncio.gather + per-check timeout - core: never block on slow check
2. CheckStatus enum - TIMEOUT is distinct from FAIL
3. exponential_backoff_with_jitter - 3 attempts, prevents thundering-herd
4. lru_cache on GitHub token - 60min window key, auto-invalidates
5. Notification before wiki-write - GitHub down does not silence alert
6. dbus-next primary, subprocess fallback - both return same dict shape
7. GDrive as SKIP in v1 - needs service account, v2 in ROADMAP

## Dependencies

httpx, PyYAML, psutil, dbus-next (Linux only), asyncio (stdlib), urllib (stdlib)
