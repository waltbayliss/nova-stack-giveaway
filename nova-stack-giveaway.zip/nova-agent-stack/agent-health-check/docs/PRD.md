# agent-health-check PRD

Version: 1.0 (reviewed)
Review date: 2026-05-06
Status: APPROVED

## Purpose

Nova immune system. Proactively catches failures before Walt notices something missing.

Daily automated health check of entire Nova AI agent stack. Runs at 08:00 AEST (22:00 UTC) via systemd timer.
Checks each registered agent against defined criteria, attempts auto-fix on recoverable failures,
sends Telegram summary. Writes health log to walts-wiki and persists JSON state for trend detection.

Design principle: Silent on green, loud on red, never blocks on a single slow check.

## Core Functions

### 1. Load Registry + Config
- Read AGENT-REGISTRY.md from walts-wiki via GitHub API
- Load config.yaml - drives check types, thresholds, channels, remediation
- Config-driven: add agents to monitoring with zero code changes

### 2. Parallel Health Checks

| Check ID | Target | Method |
|----------|--------|--------|
| video_editor_launchagent | agent-video-editor | process check |
| daily_brief_fired | Notion Daily Briefs DB | Notion API |
| content_pipeline_logs | Content pipeline | Log scan |
| notion_writes_today | Social Media Posts DB | Notion API |
| github_token | GitHub API | API + lru_cache 60min |
| gdrive_images | GDrive Content Images | GDrive API |
| nova_telegram_worker | Cloudflare Worker | httpx GET /health |
| vps_agent_backup | agent-backup | Systemd journal |
| social_poster | agent-social-poster | Process + log |
| content_auditor | agent-content-quality-auditor | Process check |

### 3. Retry: exponential_backoff_with_jitter (3 attempts, base 1s, max 8s)

### 4. Trend Detection
Fetch previous health-state.json. Annotate: REGRESSION / ONGOING / RECOVERED

### 5. Auto-Fix
- Safe: restart LaunchAgent/systemd, delete stale temp files
- Not safe: GitHub token, Notion failures, Cloudflare Worker

### 6. Health Rating
Healthy / Needs Attention / Degrading / Critical

### 7. Telegram: silent on green, itemised on failure

### 8. Wiki-Write
- Health log: walts-wiki Walt Wiki/Health Logs/YYYY-MM-DD.md
- State JSON: nova-assistant health-state.json (idempotent PUT)

## v1 Must-Haves
1. All 10 checks (configurable)
2. asyncio parallel + per-check timeouts
3. Telegram: silent on green, itemised on failure
4. Auto-fix: safe restarts + temp cleanup
5. Health log write to walts-wiki
6. State JSON for trend diff
7. Lock file (concurrent run protection)
8. config.yaml driven
