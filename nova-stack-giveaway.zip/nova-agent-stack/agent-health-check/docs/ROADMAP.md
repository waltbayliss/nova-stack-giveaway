# agent-health-check Roadmap

## v1 - Current Build (May 2026)

- [x] All 10 checks from PRD catalogue
- [x] asyncio parallel execution with per-check timeouts
- [x] exponential_backoff_with_jitter retry wrapper
- [x] CheckStatus enum (PASS/FAIL/TIMEOUT/SKIP/PARTIAL)
- [x] Trend detection (REGRESSION/ONGOING/RECOVERED)
- [x] Auto-fix: safe restarts + temp cleanup
- [x] Telegram: silent on green, itemised on failure
- [x] Health log write to walts-wiki
- [x] State JSON persistence (nova-assistant/health-state.json)
- [x] Lock file (concurrent run protection)
- [x] config.yaml driven
- [x] dbus-next + subprocess fallback for Linux
- [x] lru_cache on GitHub token (60min TTL)

## v2 - Next Quarter

- [ ] 7-day rolling trend visualisation
- [ ] 5-dimension per-agent scoring
- [ ] Health rating badge in master-context.md
- [ ] GDrive API full implementation (currently SKIP)

## v3 - Future

- [ ] Multi-agent dependency chain prediction
- [ ] Historical trend charts (30-day)
- [ ] Alert escalation on Critical rating
- [ ] Notion dashboard live health status
