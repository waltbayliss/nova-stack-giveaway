# agent-health-check Security

HIGHEST PRIORITY. These rules override everything else.

## Hard Rules

1. Never commit real credentials - .env.example contains only placeholders
2. Read secrets at runtime only via os.environ.get() - never at import time
3. Auto-fix is strictly bounded - only restart services in safe_restart_services list
4. Lock file protects concurrent runs - if /tmp/health_check.lock exists, exit immediately
5. No secrets in GitHub writes - health logs and state.json never contain tokens
6. GitHub PUT is idempotent - always GET SHA before PUT on existing files
7. Telegram via Worker only - all messages via nova-telegram Cloudflare Worker
8. Fallback log is local only - /tmp/health_check_notify_fail.log never uploaded
9. dbus-next requires no elevated privileges - use user-level systemd
10. SECURITY.md is highest priority - read at every boot

## What This Agent Can Access

- GitHub API: read AGENT-REGISTRY.md, write health log and state.json
- Notion API: read Daily Briefs DB and Social Media Posts DB (read-only)
- Nova-telegram Worker: POST notifications
- Local filesystem: read log files, write/delete lock file, write temp failure log
- systemd/launchctl: check status, restart safe services only

## What This Agent Cannot Access

- Cannot write to Notion
- Cannot create or delete GitHub repos
- Cannot deploy or modify Cloudflare Workers
- Cannot access credentials beyond those in .env.example
