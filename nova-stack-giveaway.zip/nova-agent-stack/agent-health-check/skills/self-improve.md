# self-improve.md — Self-Improvement Skill

Execute after every health check run, without exception.

## What to capture

1. **Check failures** — which checks failed, error message, is this new or recurring?
2. **Auto-fix outcomes** — what was restarted/cleaned, did it succeed?
3. **Trend observations** — any agent degrading across multiple runs?
4. **Timing anomalies** — any checks consistently hitting timeout?
5. **Config gaps** — anything checked manually that should be in config.yaml?
6. **False positives** — any check that fired but wasn't actually broken?

## Update agent-memory.md

Append a dated entry to `agent-memory.md` in this repo (via GitHub API PUT):

```
## [YYYY-MM-DD] Run summary
- Rating: [Healthy/Needs Attention/Degrading/Critical]
- Checks: N pass / N fail / N timeout
- Regressions: [list or "none"]
- Auto-fixes: [list or "none"]
- Lessons: [what to watch next run]
```

Only append if there is something worth noting. Silent runs (all green, no fixes) skip the entry.

## Config improvement proposals

If a check is failing due to a missing config value, hardcoded path, or threshold that should be tunable:
- Add a proposal to `pending-rules.md` in this repo
- Format: `[DATE] Proposal: [description of config change needed]`
- Nova will review pending-rules.md at next session boot

## Hard rules

- Never modify src/ files from this skill — only agent-memory.md and pending-rules.md
- Never send a second Telegram — the main run already sent one
- This skill executes even if the health check run partially failed
- Keep entries concise — one line per observation
