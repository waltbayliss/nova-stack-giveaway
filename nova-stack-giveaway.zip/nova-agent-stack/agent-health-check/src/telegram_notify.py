import os, json, urllib.request, urllib.error

STATUS_EMOJI = {"PASS":"OK","FAIL":"FAIL","TIMEOUT":"TIMEOUT","SKIP":"SKIP","PARTIAL":"PARTIAL"}
TREND_LABEL = {"REGRESSION":" (REGRESSION)","ONGOING":" (ONGOING)","RECOVERED":" (RECOVERED)","NEW":"","STABLE":"","TIMEOUT":""}
RATING_EMOJI = {"Healthy":"GREEN","Needs Attention":"WARN","Degrading":"RED","Critical":"CRITICAL"}

def _fmt(results, rating, run_date, fix_log):
    if rating == "Healthy":
        return f"Daily health check OK [{run_date} 08:00 AEST]"
    re = RATING_EMOJI.get(rating,"RED")
    lines = [f"{re} Nova Health Check {run_date} {rating}",""]
    for check_id, result in results.items():
        status = result.get("status","FAIL")
        em = STATUS_EMOJI.get(status,"FAIL")
        trend = TREND_LABEL.get(result.get("trend",""),"")
        detail = result.get("detail","")
        fixed = " [auto-restarted]" if result.get("auto_fixed") else ""
        cid = check_id.replace("_", "-")
        line = f"{em} {cid}{trend}{fixed}"
        if status != "PASS" and detail:
            line += f"\n   - {detail}"
        lines.append(line)
    if fix_log:
        lines += ["", "Auto-fix log:"] + [f"  {e}" for e in fix_log]
    return "\n".join(lines)

async def send_notification(results, rating, run_date, fix_log, config):
    url = os.environ.get("NOVA_TELEGRAM_WORKER_URL","").rstrip("/")
    silent = config.get("notifications",{}).get("silent_on_green",True)
    if not url:
        print("[telegram] NOVA_TELEGRAM_WORKER_URL not set - skipping")
        return
    if rating == "Healthy" and silent:
        print("[telegram] All green + silent=true - no notification")
        return
    msg = _fmt(results, rating, run_date, fix_log)
    # The nova-telegram Cloudflare Worker expects {"text": ...}, not {"message": ...}.
    # Matches the working pattern used by agent-youtube-thumbnailer, agent-daily-brief,
    # and 4+ other agents that successfully ping via the Worker. Using "message" was
    # silently 403'ing for an unknown number of runs (surfaced Session 96, 2026-05-20).
    payload = json.dumps({"text":msg}).encode()
    # User-Agent header is REQUIRED — Cloudflare's bot filter blocks Python's default
    # `Python-urllib/<ver>` UA with error 1010 (Forbidden). Any custom UA passes.
    # Identified Session 96, 2026-05-20 as the silent cause of the long-running 403s.
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type":"application/json", "User-Agent":"agent-health-check/1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            print(f"[telegram] Sent. Status: {r.status}")
    except Exception as e:
        print(f"[telegram] Failed: {e}")
        try:
            with open("/tmp/health_check_notify_fail.log", "a") as f:
                from datetime import datetime, timezone
                ts = datetime.now(timezone.utc).isoformat()
                f.write(f"\n--- {ts} ---\n{msg}\n")
        except: pass
