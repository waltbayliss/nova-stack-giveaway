def compute_diff(current, previous_state):
    if previous_state is None:
        for r in current.values():
            r["trend"] = "NEW"
        return current
    prev = previous_state.get("results", {})
    for check_id, result in current.items():
        curr = result.get("status", "FAIL")
        prev_status = prev.get(check_id)
        if prev_status is None:
            result["trend"] = "NEW"
        elif curr == "PASS" and prev_status != "PASS":
            result["trend"] = "RECOVERED"
        elif curr in ("FAIL", "PARTIAL") and prev_status == "PASS":
            result["trend"] = "REGRESSION"
        elif curr in ("FAIL", "PARTIAL") and prev_status in ("FAIL", "PARTIAL"):
            result["trend"] = "ONGOING"
        elif curr == "TIMEOUT":
            result["trend"] = "TIMEOUT"
        else:
            result["trend"] = "STABLE"
    return current
