import asyncio, json, os, urllib.request, urllib.error
from datetime import datetime, timezone, timedelta

NOTION_TOKEN = os.environ.get("NOTION_TOKEN","")
NOTION_BASE = "https://api.notion.com/v1"
H = {"Authorization":"Bearer "+NOTION_TOKEN,"Content-Type":"application/json","Notion-Version":"2022-06-28"}

async def run_check(check_id, config):
    loop = asyncio.get_event_loop()
    ctype = config.get("check","")
    db_id = config.get("database_id","")
    if not NOTION_TOKEN: return {"status":"SKIP","detail":"NOTION_TOKEN not set"}
    if not db_id: return {"status":"SKIP","detail":"database_id not configured"}
    if ctype=="today_page_exists":
        # Container is a PAGE with child brief pages (not a database) — fixed Session 96.
        return await loop.run_in_executor(None, _today_child_page, db_id)
    elif ctype=="rows_created_today":
        return await loop.run_in_executor(None, _rows_today, db_id)
    return {"status":"SKIP","detail":f"Unknown check: {ctype}"}

def _query(db_id, payload):
    url = f"{NOTION_BASE}/databases/{db_id}/query"
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers=H, method="POST")
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())

def _list_children(page_id):
    """List immediate children of a page via the blocks API. Paginates if needed."""
    children = []
    cursor = None
    while True:
        url = f"{NOTION_BASE}/blocks/{page_id}/children?page_size=100"
        if cursor:
            url += f"&start_cursor={cursor}"
        req = urllib.request.Request(url, headers=H, method="GET")
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        children.extend(data.get("results", []))
        if not data.get("has_more"):
            break
        cursor = data.get("next_cursor")
    return children

def _today_child_page(container_page_id):
    """
    Check the Daily Briefs container PAGE has a child page for today.
    Brief pages are named "DD-MM-YYYY Daily Brief" (Brisbane date, not UTC) — match
    today AND yesterday-UTC to account for the AEST/UTC offset (the 7am AEST brief
    fires at 21:00 UTC the prior day).
    """
    # Two candidate date forms — the brief fires at 21:00 UTC (7am AEST next day),
    # so "today" in the brief's title may be tomorrow in UTC. Accept either.
    now_utc = datetime.now(timezone.utc)
    candidates = {
        now_utc.strftime("%d-%m-%Y"),
        (now_utc + timedelta(days=1)).strftime("%d-%m-%Y"),
    }
    try:
        children = _list_children(container_page_id)
        for c in children:
            if c.get("type") != "child_page":
                continue
            title = c.get("child_page", {}).get("title", "")
            for d in candidates:
                if title.startswith(d):
                    return {"status":"PASS","detail":f"Found brief: {title}"}
        return {"status":"FAIL","detail":f"No brief page matching any of {sorted(candidates)} in container"}
    except Exception as e:
        return {"status":"PARTIAL","detail":f"Notion children list failed: {e}"}

def _rows_today(db_id):
    """
    Count rows created today in the given database. Uses the TIMESTAMP filter
    (`timestamp: created_time`), NOT a property filter — the system-managed
    `created_time` is not a regular property. The old property-filter form
    returned HTTP 400 across all runs.
    """
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    try:
        result = _query(db_id, {
            "filter": {
                "timestamp": "created_time",
                "created_time": {"on_or_after": f"{today}T00:00:00Z"},
            },
            "page_size": 100,
        })
        count = len(result.get("results", []))
        return {"status":"PASS" if count>0 else "PARTIAL","detail":f"{count} rows created today"}
    except Exception as e:
        return {"status":"PARTIAL","detail":f"Notion query failed: {e}"}
