import asyncio, os, platform, subprocess

IS_LINUX = platform.system()=="Linux"
IS_MAC = platform.system()=="Darwin"

async def run_check(check_id, config):
    ctype = config.get("type","process")
    if ctype=="systemd_journal":
        return await _check_journal(config)
    if IS_LINUX:
        return await _check_linux(config)
    elif IS_MAC:
        return await _check_mac(config)
    return {"status":"SKIP","detail":f"Unsupported platform: {platform.system()}"}

async def _check_linux(config):
    service = config.get("systemd_service","")
    if not service:
        return {"status":"SKIP","detail":"No systemd_service configured"}
    try:
        import dbus_next
        return await _check_dbus(service)
    except ImportError:
        pass
    try:
        r = subprocess.run(["systemctl","is-active",service], capture_output=True, text=True, timeout=5)
        active = r.stdout.strip()=="active"
        return {"status":"PASS" if active else "FAIL","detail":r.stdout.strip(),"method":"subprocess"}
    except Exception as e:
        return {"status":"FAIL","detail":f"systemctl failed: {e}"}

async def _check_dbus(service):
    try:
        from dbus_next.aio import MessageBus
        from dbus_next import BusType
        bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
        intr = await bus.introspect("org.freedesktop.systemd1","/org/freedesktop/systemd1")
        proxy = bus.get_proxy_object("org.freedesktop.systemd1","/org/freedesktop/systemd1",intr)
        mgr = proxy.get_interface("org.freedesktop.systemd1.Manager")
        unit_path = await mgr.call_get_unit(f"{service}.service")
        intr2 = await bus.introspect("org.freedesktop.systemd1",unit_path)
        unit = bus.get_proxy_object("org.freedesktop.systemd1",unit_path,intr2)
        iface = unit.get_interface("org.freedesktop.systemd1.Unit")
        state = await iface.get_active_state()
        bus.disconnect()
        return {"status":"PASS" if state=="active" else "FAIL","detail":f"ActiveState: {state}","method":"dbus-next"}
    except Exception:
        r = subprocess.run(["systemctl","is-active",service], capture_output=True, text=True, timeout=5)
        return {"status":"PASS" if r.stdout.strip()=="active" else "FAIL","detail":r.stdout.strip(),"method":"fallback"}

async def _check_mac(config):
    sid = config.get("service_id","")
    if not sid: return {"status":"SKIP","detail":"No service_id"}
    try:
        r = subprocess.run(["launchctl","list",sid], capture_output=True, text=True, timeout=5)
        return {"status":"PASS" if r.returncode==0 else "FAIL","detail":f"launchctl {sid}: {"found" if r.returncode==0 else "not found"}"}
    except Exception as e: return {"status":"FAIL","detail":f"launchctl failed: {e}"}

async def _check_journal(config):
    service = config.get("service","")
    hours = config.get("max_age_hours",26)
    if not service: return {"status":"SKIP","detail":"No service configured"}
    try:
        r = subprocess.run(["journalctl","-u",f"{service}.service","--since",f"{hours} hours ago","-n","1","--no-pager"], capture_output=True, text=True, timeout=10)
        ran = bool(r.stdout.strip())
        return {"status":"PASS" if ran else "FAIL","detail":f"Service {service} {"ran" if ran else "NOT run"} within {hours}h"}
    except Exception as e: return {"status":"FAIL","detail":f"journalctl failed: {e}"}
