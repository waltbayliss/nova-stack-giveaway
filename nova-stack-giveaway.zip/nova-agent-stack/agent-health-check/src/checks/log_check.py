import asyncio, glob
from datetime import datetime, timezone, timedelta
from pathlib import Path

async def run_check(check_id, config):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _scan, config)

def _scan(config):
    pattern = config.get("log_pattern","")
    error_pat = config.get("error_pattern","ERROR")
    hours = config.get("window_hours",24)
    if not pattern: return {"status":"SKIP","detail":"No log_pattern configured"}
    cutoff = datetime.now(timezone.utc)-timedelta(hours=hours)
    files = glob.glob(pattern)
    if not files: return {"status":"PASS","detail":f"No log files at {pattern}"}
    errors = []
    for f in files:
        try:
            mtime = datetime.fromtimestamp(Path(f).stat().st_mtime, tz=timezone.utc)
            if mtime < cutoff: continue
            with open(f,"r",errors="ignore") as fh:
                for i,line in enumerate(fh):
                    if error_pat in line:
                        errors.append(f"{Path(f).name}:{i+1}: {line.strip()[:80]}")
                        if len(errors)>=3: break
        except Exception as e: errors.append(f"Could not read {f}: {e}")
    if errors: return {"status":"FAIL","detail":f"{len(errors)} ERROR(s) in last {hours}h: {errors[0]}"}
    return {"status":"PASS","detail":f"No errors in {len(files)} log file(s) (last {hours}h)"}
