import asyncio, os, urllib.request

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

async def run_check(check_id, config):
    ctype = config.get("type","http")
    if ctype=="gdrive":
        return {"status":"SKIP","detail":"GDrive check requires Google service account (see .env.example)"}
    return await _ping(config)

async def _ping(config):
    url = config.get("url","")
    expected = config.get("expected_status",200)
    timeout_s = config.get("timeout_s",6)
    if not url: return {"status":"SKIP","detail":"No URL configured"}
    if HAS_HTTPX:
        try:
            async with httpx.AsyncClient(timeout=timeout_s) as client:
                r = await client.get(url)
                ok = r.status_code==expected
                return {"status":"PASS" if ok else "FAIL","detail":f"HTTP {r.status_code} (expected {expected})"}
        except httpx.TimeoutException:
            return {"status":"TIMEOUT","detail":f"Timed out after {timeout_s}s"}
        except Exception as e:
            return {"status":"FAIL","detail":f"HTTP check failed: {e}"}
    else:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _urllib_ping, url, expected)

def _urllib_ping(url, expected):
    try:
        with urllib.request.urlopen(url, timeout=6) as r:
            ok = r.status==expected
            return {"status":"PASS" if ok else "FAIL","detail":f"HTTP {r.status}"}
    except Exception as e: return {"status":"FAIL","detail":str(e)}
