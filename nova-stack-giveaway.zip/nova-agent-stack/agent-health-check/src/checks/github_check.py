import asyncio, json, os, urllib.request, urllib.error
from functools import lru_cache
from datetime import datetime, timezone

@lru_cache(maxsize=1)
def _cached(cache_key):
    token = os.environ.get("GITHUB_PERSONAL_ACCESS_TOKEN","")
    if not token: return {"status":"SKIP","detail":"GITHUB_PERSONAL_ACCESS_TOKEN not set"}
    headers = {"Authorization":f"token {token}","Accept":"application/vnd.github.v3+json"}
    req = urllib.request.Request("https://api.github.com/rate_limit", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read())
            core = data.get("resources",{}).get("core",{})
            remaining = core.get("remaining",0)
            limit = core.get("limit",5000)
            pct = (remaining/limit*100) if limit else 0
            if remaining==0: return {"status":"FAIL","detail":f"Rate limit exhausted (0/{limit})"}
            if pct<20: return {"status":"PARTIAL","detail":f"Rate limit low: {remaining}/{limit} ({pct:.0f}%)"}
            return {"status":"PASS","detail":f"Token valid. Rate: {remaining}/{limit} ({pct:.0f}%)"}
    except urllib.error.HTTPError as e:
        if e.code==401: return {"status":"FAIL","detail":"GitHub token invalid (401) - rotate PAT"}
        return {"status":"FAIL","detail":f"GitHub API HTTP {e.code}"}
    except Exception as e:
        return {"status":"FAIL","detail":f"GitHub check failed: {e}"}

async def run_check(check_id, config):
    ttl = config.get("cache_ttl_min",60)
    window = int(datetime.now(timezone.utc).timestamp()/(ttl*60))
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _cached, f"github_{window}")
