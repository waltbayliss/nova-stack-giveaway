import asyncio, importlib, random
from enum import Enum

class CheckStatus(Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    TIMEOUT = "TIMEOUT"
    SKIP = "SKIP"
    PARTIAL = "PARTIAL"

STATUS_EMOJI = {"PASS":"OK","FAIL":"FAIL","TIMEOUT":"TIMEOUT","SKIP":"SKIP","PARTIAL":"PARTIAL"}

CHECK_MAP = {
    "process":"checks.process_check",
    "process_and_log":"checks.process_check",
    "notion":"checks.notion_check",
    "github_api":"checks.github_check",
    "http":"checks.http_check",
    "gdrive":"checks.http_check",
    "log_scan":"checks.log_check",
    "systemd_journal":"checks.process_check",
}

async def _with_backoff(fn, check_id, cfg, attempts=3, base=1.0, maxd=8.0):
    last = None
    for i in range(attempts):
        try:
            return await fn(check_id, cfg)
        except Exception as e:
            last = e
            if i < attempts-1:
                d = min(base*(2**i)+random.uniform(-0.5,0.5), maxd)
                await asyncio.sleep(max(0.1,d))
    return {"status":"FAIL","detail":f"Failed after {attempts} attempts: {last}"}

async def run_single_check(check_id, cfg):
    ctype = cfg.get("type","unknown")
    timeout = cfg.get("timeout_s",10)
    mod_name = CHECK_MAP.get(ctype)
    if not mod_name:
        return {"status":"SKIP","detail":f"Unknown check type: {ctype}"}
    try:
        mod = importlib.import_module(mod_name)
        return await asyncio.wait_for(_with_backoff(mod.run_check, check_id, cfg), timeout=timeout)
    except asyncio.TimeoutError:
        return {"status":"TIMEOUT","detail":f"Timed out after {timeout}s"}
    except Exception as e:
        return {"status":"FAIL","detail":f"Check crashed: {type(e).__name__}: {e}"}

async def run_all_checks(config, registry):
    checks = config.get("checks",{})
    tasks = {cid: run_single_check(cid, cfg) for cid, cfg in checks.items()}
    results_list = await asyncio.gather(*tasks.values(), return_exceptions=True)
    results = {}
    EMOJI = {"PASS":"✅","FAIL":"❌","TIMEOUT":"⏱️","SKIP":"⏭️","PARTIAL":"⚠️"}
    for check_id, result in zip(tasks.keys(), results_list):
        if isinstance(result, Exception):
            results[check_id] = {"status":"FAIL","detail":str(result),"emoji":"❌"}
        else:
            result["emoji"] = EMOJI.get(result.get("status","FAIL"),"❌")
            results[check_id] = result
    return results
