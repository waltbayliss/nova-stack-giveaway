import os, subprocess, glob, platform
from pathlib import Path

IS_LINUX = platform.system() == "Linux"
IS_MAC = platform.system() == "Darwin"

def _restart_linux(service):
    try:
        r = subprocess.run(["systemctl","restart",service], capture_output=True, text=True, timeout=15)
        return r.returncode==0, f"systemctl restart {service}: {"OK" if r.returncode==0 else r.stderr.strip()[:50]}"
    except Exception as e:
        return False, f"restart failed: {e}"

def _restart_mac(sid):
    try:
        plist = f"{os.path.expanduser(chr(126))}/Library/LaunchAgents/{sid}.plist"
        if not Path(plist).exists():
            return False, f"plist not found: {plist}"
        subprocess.run(["launchctl","unload",plist], capture_output=True, timeout=10)
        r = subprocess.run(["launchctl","load",plist], capture_output=True, text=True, timeout=10)
        return r.returncode==0, f"launchctl reload {sid}"
    except Exception as e:
        return False, f"launchctl failed: {e}"

def _cleanup_locks(patterns):
    deleted = []
    for pat in patterns:
        for f in glob.glob(pat):
            try: os.unlink(f); deleted.append(f)
            except: pass
    return deleted

def attempt_fixes(results, config):
    fix_log = []
    checks = config.get("checks",{})
    rem = config.get("remediation",{})
    safe = rem.get("safe_restart_services",[])
    patterns = rem.get("temp_cleanup_patterns",[])
    for check_id, result in results.items():
        if result.get("status")=="PASS": continue
        cfg = checks.get(check_id,{})
        if cfg.get("auto_fix") != "restart": continue
        sid = cfg.get("service_id","")
        svc = cfg.get("systemd_service","")
        if sid not in safe and svc not in safe:
            fix_log.append(f"SKIP restart {check_id}: not in safe list")
            continue
        if IS_LINUX and svc:
            ok, msg = _restart_linux(svc)
        elif IS_MAC and sid:
            ok, msg = _restart_mac(sid)
        else:
            fix_log.append(f"SKIP {check_id}: no matching service for platform")
            continue
        fix_log.append(f"AUTO-FIX {check_id}: {msg}")
        if ok:
            result["auto_fixed"] = True
            result["fix_detail"] = msg
    deleted = _cleanup_locks(patterns)
    if deleted:
        fix_log.append(f"AUTO-FIX stale_locks: deleted {deleted}")
    return fix_log
