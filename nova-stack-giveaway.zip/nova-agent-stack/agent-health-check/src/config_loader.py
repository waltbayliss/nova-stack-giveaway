#!/usr/bin/env python3
import os, re, yaml
from pathlib import Path

def _expand_env(obj):
    if isinstance(obj, str):
        return re.sub(r"\$\{([^}]+)\}", lambda m: os.environ.get(m.group(1), m.group(0)), obj)
    elif isinstance(obj, dict):
        return {k: _expand_env(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_expand_env(i) for i in obj]
    return obj

def load_config(path="config.yaml"):
    p = Path(__file__).parent.parent / path
    if not p.exists():
        raise FileNotFoundError(f"config.yaml not found: {p}")
    with open(p) as f:
        raw = yaml.safe_load(f)
    return _expand_env(raw)
