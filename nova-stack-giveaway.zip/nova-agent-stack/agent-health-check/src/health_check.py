import asyncio, json, os, sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
from config_loader import load_config
from registry_reader import fetch_registry
from check_runner import run_all_checks
from trend_detector import compute_diff
from auto_fix import attempt_fixes
from telegram_notify import send_notification
from wiki_writer import write_health_log, write_state_json

LOCK = "/tmp/health_check.lock"

def acquire_lock():
    if Path(LOCK).exists():
        print(f"[health_check] Lock exists. Concurrent run - exiting.")
        sys.exit(0)
    Path(LOCK).write_text(str(os.getpid()))

def release_lock():
    try: Path(LOCK).unlink(missing_ok=True)
    except Exception as e: print(f"[health_check] Warning: cannot remove lock: {e}")

def compute_rating(results):
    fails = sum(1 for v in results.values() if v=="FAIL")
    partial = sum(1 for v in results.values() if v in ("PARTIAL","TIMEOUT"))
    if fails>=2: return "Critical"
    if fails==1 or partial>=3: return "Degrading"
    if partial>=1 and fails==0: return "Needs Attention"
    return "Healthy"

async def main():
    acquire_lock()
    try:
        run_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        print(f"[health_check] Starting run for {run_date}")
        config = load_config("config.yaml")
        registry = fetch_registry(config)
        results = await run_all_checks(config, registry)
        prev_state = None
        try:
            cache = Path(__file__).parent.parent / "health-state-cache.json"
            if cache.exists():
                prev_state = json.loads(cache.read_text())
        except: pass
        annotated = compute_diff(results, prev_state)
        fix_log = attempt_fixes(annotated, config)
        rating = compute_rating({k: v["status"] for k,v in annotated.items()})
        print(f"[health_check] Rating: {rating}")
        await send_notification(annotated, rating, run_date, fix_log, config)
        state = {"run_date":run_date,"results":{k:v["status"] for k,v in annotated.items()},"rating":rating}
        write_health_log(annotated, rating, run_date, fix_log, config)
        write_state_json(state, config)
        try:
            cache = Path(__file__).parent.parent / "health-state-cache.json"
            cache.write_text(json.dumps(state))
        except: pass
        Path("/home/walt/agents/.heartbeats/agent-health-check").write_text(datetime.now(timezone.utc).isoformat())
        print(f"[health_check] Done. Rating: {rating}")
    finally:
        release_lock()

if __name__=="__main__":
    asyncio.run(main())
