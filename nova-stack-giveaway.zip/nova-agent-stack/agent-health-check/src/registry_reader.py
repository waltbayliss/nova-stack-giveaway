import os, urllib.request, urllib.error, json, base64

def fetch_registry(config):
    token = os.environ.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    wiki_repo = config.get("wiki_write", {}).get("walts_wiki_repo", "waltbayliss/walts-wiki")
    if not token:
        print("[registry_reader] No token - using config.yaml")
        return {}
    url = f"https://api.github.com/repos/{wiki_repo}/contents/Walt%27s%20Wiki%2FMaster%20Wiki%2FAGENT-REGISTRY.md"
    headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
            content = base64.b64decode(data["content"]).decode()
            agents = {}
            for line in content.splitlines():
                if line.startswith("| agent-"):
                    name = line.split("|")[1].strip().strip("*")
                    agents[name] = True
            print(f"[registry_reader] Loaded {len(agents)} agents")
            return agents
    except Exception as e:
        print(f"[registry_reader] Failed: {e} - using config fallback")
        return {}
