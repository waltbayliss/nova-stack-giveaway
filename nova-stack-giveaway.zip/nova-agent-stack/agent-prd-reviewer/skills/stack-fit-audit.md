# Skill — stack-fit-audit

## Purpose
Verify the proposed agent integrates cleanly with Walt's existing stack before the builder starts.

## Steps
1. Read `walts-wiki/Master Wiki/master-context.md` (GitHub: waltbayliss/walts-wiki) for current agent roster and environment state
2. Check MCP availability: for each MCP required by the proposed agent, confirm it's already installed in the stack
3. Check .env coverage: for each API key required, confirm it's in the shared `.env` at `my-ai-team/.env`
4. Check for duplication: does this agent overlap significantly with an existing active agent?
5. Check cross-agent dependencies: does this agent receive from or feed into another agent? Is that handoff defined?

## Flags to Raise
- **Missing MCP:** "[MCP name] is not installed — needs adding before build"
- **Missing .env key:** "[KEY_NAME] not in shared .env — needs adding"
- **Duplication risk:** "This overlaps with [existing-agent] in [function area] — confirm scope before build"
- **Undefined handoff:** "This agent receives output from [agent] but the handoff format is not defined"

## Output Format
```
**Stack Fit:** CLEAN / GAPS FOUND

**MCP gaps:**
- [list or "None"]

**ENV gaps:**
- [list or "None"]

**Duplication risk:**
- [list or "None"]

**Cross-agent handoffs:**
- [list or "All defined"]
```
