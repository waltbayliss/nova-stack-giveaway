# Skill — ai-improvement-pass

## Purpose
Use OpenRouter to generate concrete, implementable improvements to the PRD before the builder starts.

## Model Selection
- Standard PRD (1–6 functions, 1–3 integrations): `claude-sonnet-4-6`
- Complex PRD (7+ functions OR 4+ integrations): `claude-opus-4-7`
- Route via agent-openrouter-optimizer before dispatch

## Prompt Template
```
You are reviewing a brief for an AI agent being built for Walt Bayliss's personal AI team.

Agent purpose: [one-liner]
Functions: [numbered list]
Integrations: [list]
Trigger: [how it's invoked]

Answer these 4 questions. Be specific and implementable — not generic advice:

1. What important features or functions are missing from this design?
2. What architectural decisions here will cause problems at scale or under failure conditions?
3. What security risks are not addressed in this brief?
4. What would make this agent 2× more useful without doubling the build complexity?

For each finding: state the issue + the specific fix.
```

## Steps
1. Select model based on PRD complexity
2. Send prompt via OpenRouter MCP (`mcp__openrouter__chat_completion`)
3. Parse response into 4 categories: Missing Features / Architectural Issues / Security Gaps / Improvement Ideas
4. Filter: keep suggestions that are specific and buildable; discard generic advice
5. Add all accepted suggestions to the upgraded PRD under an "Additions from Review" section

## Output
List of concrete additions, each with: what was added + why.
