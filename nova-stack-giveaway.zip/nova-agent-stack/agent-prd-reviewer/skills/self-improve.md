# SELF-IMPROVEMENT LOOP — Skill Protocol

This skill executes at the end of EVERY agent run, regardless of trigger (Nova routing, timer, Telegram, CLI, webhook). It is non-negotiable. A run is not complete until this protocol has fired.

---

## STEP 1 — Write Raw Capture

Create file: `wiki/Raw/{YYYY-MM-DD}-{task-slug}-raw.md`

Use this format:

```
# Raw Capture — {task-slug} — {YYYY-MM-DD}

**Trigger:** [how this run was initiated — Nova routing / timer / CLI / webhook]
**Input:** [what was asked, or what data arrived]
**Actions taken:** [tools called, APIs hit, decisions made — brief bullet list]
**Output:** [what was produced or delivered]
**Errors / surprises:** [anything unexpected, any retry, any fallback]
**Duration:** [approximate]
**Notes:** [anything else worth capturing]
```

---

## STEP 2 — Reflect

Read the raw capture you just wrote. Then read your PURPOSE from your CLAUDE.md.

Answer these 5 questions:

1. **Alignment** — Was this run aligned with my stated purpose?
2. **Efficiency** — Was this the most direct path? Is there a shorter route?
3. **Prior pattern?** — Have I done something similar before? Check agent-memory.md.
4. **Prevention** — Did anything go wrong that a rule could prevent next time?
5. **Feedback** — Did I receive any explicit or implicit feedback from Walt or Nova?

---

## STEP 3 — Act on Reflection

**Nothing significant:** done.

**New observation, unconfirmed:** add `[WATCH] {observation}` to bottom of raw file. Don't update memory yet.

**Pattern confirmed 3+ times:** update `agent-memory.md`:
```
[{DATE}] PATTERN: {what} | RULE: {change} | CONFIRMED: {N}
```

**Walt gave explicit feedback:** update `agent-memory.md` immediately (no 3x threshold):
```
[{DATE}] WALT FEEDBACK: {what} | RULE: {change}
```

**Hard rule change warranted:** write proposal to `pending-rules.md` AND to `nova-assistant/pending-agent-rules/{agent-name}.md`. NEVER write to CLAUDE.md directly.

---

## STEP 4 — Wiki Synthesis Check

If 10+ unprocessed Raw/ files: flag in pending-rules.md and nova-assistant/pending-agent-rules/{agent-name}.md for Nova to run synthesis.

---

## HARD RULES

1. Fires after EVERY run. No exceptions.
2. Raw captures are append-only.
3. Never write to CLAUDE.md directly.
4. nova-assistant/pending-agent-rules/ is the central inbox.
5. Graduation path: Raw → agent-memory.md → pending-rules.md → CLAUDE.md (Nova only).
