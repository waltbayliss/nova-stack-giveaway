# Skill — prior-art-check

## Purpose
Check whether this agent concept already exists as an open-source tool or GitHub repo before building from scratch.

## Steps
1. Extract the core concept from the PRD (e.g., "AI-powered PRD quality reviewer", "automated spec challenger")
2. Run Perplexity search: "[concept] open source tool GitHub"
3. Run GitHub Search API: keywords from the agent's function list (e.g., "prd review automation", "spec challenger AI")
4. Assess results by overlap percentage:
   - Strong match (>70% overlap with agent's functions): recommend fork/adapt + link to repo
   - Partial match (30–70%): note as reference material, build from scratch with reference
   - No match (<30%): "Start from scratch — no prior art found"
5. Add finding to review report and upgraded PRD

## Perplexity Query Format
```
Is there an existing open-source tool or GitHub repository that [does X]?
Include: repo name, URL, last activity, tech stack, license.
```

## Output Format
```
**Prior Art:** [Start from scratch / Fork/adapt: <repo-url>]
**Overlap:** [%]
**Reason:** [one sentence]
**Reference repos (if any):** [list]
```

## Note
Walt defaults to "start from scratch" unless the fork is >80% aligned AND actively maintained (commit in last 6 months).
