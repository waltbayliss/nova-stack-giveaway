# Skill — parse-prd

## Purpose
Fully parse and understand a source PRD brief before the 9-point review begins.

## Steps
1. Read the full brief from GitHub: `waltbayliss/nova-assistant/pending-builds/<slug>.md`
2. Extract and record:
   - One-line purpose
   - Agent name + folder path
   - All functions listed (count them)
   - Integrations required (list each)
   - Trigger mechanism (auto / on-demand / cron / webhook)
   - Pipeline position (if stated)
   - Wiki-write definition (if present — note if absent)
3. Summarise understanding aloud: "This agent [purpose]. It has [N] functions. It connects to [integrations]. It is triggered by [trigger]. Wiki-write [is / is NOT] defined."
4. Flag immediately if:
   - One-liner is vague ("helps with things")
   - Function list is empty or has fewer than 3 items
   - No integrations are defined
   - Trigger is undefined

## Output
A structured summary carried into all remaining review points.
