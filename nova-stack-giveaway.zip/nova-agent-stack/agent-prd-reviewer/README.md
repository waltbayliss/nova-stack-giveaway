# agent-prd-reviewer

PRD quality gate for Walt Bayliss's AI agent build pipeline. Sits at Step 3 — after intake, before builder. Takes a raw agent brief, runs a 9-point review, and returns an upgraded PRD ready for agent-builder.

## What it does
- Parses and understands the source brief
- AI improvement pass (OpenRouter Sonnet/Opus)
- Challenges weak assumptions
- Prior art check (Perplexity + GitHub Search)
- Stack fit audit against Walt's Wiki
- Scope check (one agent or two?)
- Failure mode mapping
- Wiki-write requirement enforcement (hard rule)
- Returns complete upgraded PRD

## How to invoke
```bash
cd my-ai-team/agent-prd-reviewer
claude
```
Then: `"Review PRD for [agent-name]"`

Or Nova auto-invokes post-intake.

## Pipeline position
```
1. Intake interview (Nova)
2. PRD written → pending-builds/<slug>.md
3. → agent-prd-reviewer (this agent)
4. Nova approval gate
5. agent-builder
6. agent-code-reviewer
7. agent-security
8. Register with Nova
```

## Integrations
- GitHub MCP — read briefs, write upgraded PRDs + wiki entries
- OpenRouter — AI improvement pass (Sonnet/Opus)
- Perplexity API — prior art research
- walts-wiki — stack context + review archive
