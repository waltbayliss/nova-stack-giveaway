# PRD — agent-prd-reviewer

## Purpose
Takes Walt's raw agent brief post-intake and returns an upgraded PRD ready for agent-builder. Challenges assumptions, adds missing features, checks prior art, audits stack fit, maps failure modes, and enforces the wiki-write requirement.

## Pipeline Position
Step 3 of 8 in the standard build pipeline:
1. Intake interview (Nova)
2. PRD written (Nova → `pending-builds/<slug>.md`)
3. → **agent-prd-reviewer** (this agent)
4. Nova approval gate (Walt confirms upgraded PRD)
5. agent-builder
6. agent-code-reviewer
7. agent-security
8. Register with Nova

## Features

### F1 — Parse PRD
Input: `pending-builds/<slug>.md` from GitHub
Output: Structured understanding of agent purpose, scope, inputs, outputs

### F2 — AI Improvement Pass
Uses OpenRouter (Sonnet by default, Opus for complex PRDs — 7+ functions or 4+ integrations) to generate:
- Missing features
- Better architectural approaches
- Security gaps not in original brief
- Integration opportunities

### F3 — Challenge Assumptions
Reviews spec for:
- Vague trigger definitions
- Missing error handling
- Unclear success criteria
- "This will break in the real world" scenarios

### F4 — Prior Art Check
- Perplexity API: real-world context, existing solutions
- GitHub Search API: repos to fork/adapt instead of building from scratch
- Output: "Start from scratch" or "Fork/adapt [repo-url]"

### F5 — Stack Fit Audit
Cross-checks against Walt's Wiki master-context.md:
- Clean integration with existing agents?
- Missing MCPs or .env keys?
- Duplication with existing agents?

### F6 — Scope Check
- Is this one agent or should it be two?
- Flag feature bloat before builder runs
- Flag under-scoping that leads to immediate re-builds

### F7 — Failure Mode Mapping
- API failure scenarios for every listed integration
- Bad input / upstream garbage handling
- Retry/timeout/dead-letter requirements

### F8 — Wiki-Write Requirement (Hard Rule)
Every agent must define its wiki-write. If missing: BLOCKING flag + auto-add to upgraded PRD.
Required format: `walts-wiki/[path]/YYYY-MM-DD-[output].md`

### F9 — Upgraded PRD Output
Complete rewritten document written to GitHub as `pending-builds/<slug>-reviewed.md`.
Must be demonstrably better than source brief.

## Invocation
- **Auto:** Nova passes PRD file path post-intake
- **On-demand:** "Review PRD for [agent-name]" / "PRD review — [agent-name]"

## Success Criteria
- Upgraded PRD is better than source brief
- All 9 review points completed
- No BLOCKING items without resolution or explicit Nova escalation
- Review record written to Walt's Wiki

## Inputs
- `pending-builds/<slug>.md` — source brief (GitHub: waltbayliss/nova-assistant)
- `walts-wiki/Master Wiki/master-context.md` — stack context

## Outputs
- `pending-builds/<slug>-reviewed.md` — upgraded PRD (GitHub: waltbayliss/nova-assistant)
- `walts-wiki/Agent Builds/PRD Reviews/YYYY-MM-DD-<agent>-review.md` — review record
