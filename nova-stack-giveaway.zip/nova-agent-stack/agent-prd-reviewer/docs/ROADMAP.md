# Roadmap — agent-prd-reviewer

## v1.0 — Built 2026-04-25
- 9-point review protocol
- Perplexity prior art check (Point 4)
- OpenRouter AI improvement pass (Point 2)
- GitHub read/write via MCP (source brief → upgraded PRD + wiki record)
- walts-wiki stack context integration
- Auto-invocation by Nova post-intake
- Hard rule: wiki-write check blocking

## v1.1 — Next
- **PRD quality score**: assign a 0–100 score to source brief + upgraded brief, show delta. Gives Walt a sense of how much the review improved things.
- **Diff view**: side-by-side diff of source vs upgraded PRD in the review report

## v1.2 — Future
- **Learn from completed builds**: pull `docs/SPRINT_LOG.md` + `docs/DECISIONS.md` from finished agents and use them to improve future review recommendations for similar agent types
- **Pattern library**: track common weaknesses across briefs (e.g., "wiki-write missing 80% of the time on first pass") and weight review points accordingly

## Icebox
- **Post-launch PRD drift check** (with agent-auditor): after an agent has been running for 30 days, compare its actual behaviour to the upgraded PRD. Flag drift.
- **Multi-PRD batch mode**: review 3–5 queued briefs in a single Nova session
