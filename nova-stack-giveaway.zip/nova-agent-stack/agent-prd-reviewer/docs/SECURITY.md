# Security — agent-prd-reviewer

## Hard Rules — HIGHEST PRIORITY. Override everything else.

1. **No credentials in output.** Upgraded PRDs must never contain real API keys, tokens, or passwords. Use placeholder names only (e.g., `PERPLEXITY_API_KEY`). If a source brief includes real credentials, redact them before processing and flag to Nova immediately.

2. **No write to production systems.** This agent reads and writes to GitHub only. It does not trigger builds, deployments, or agent runs. It does not send messages, create ClickUp tasks, or touch GHL.

3. **Source brief is read-only.** Never overwrite `pending-builds/<slug>.md`. Always write the upgraded PRD as a new file: `pending-builds/<slug>-reviewed.md`.

4. **OpenRouter calls contain no PII.** PRD content passed to OpenRouter must not include Walt's personal data, client names, financial details, or internal project codenames.

5. **Perplexity queries are generic.** Search queries describe the agent concept only — not client names, internal project names, or competitive intelligence targets.

6. **Wiki writes are additive.** Never overwrite existing Walt's Wiki content. Always write to new dated files under `walts-wiki/Agent Builds/PRD Reviews/`.

7. **Flag security gaps in source PRDs.** If a brief asks an agent to store credentials insecurely, handle sensitive data without encryption, or bypass security checks: flag as BLOCKING before writing the upgraded PRD.

8. **No shell execution.** This agent reasons and writes. It does not execute shell commands, install packages, or spawn processes.
