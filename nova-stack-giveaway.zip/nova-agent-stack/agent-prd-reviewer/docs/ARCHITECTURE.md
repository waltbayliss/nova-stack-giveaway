# Architecture — agent-prd-reviewer

## Type
Inline reviewer — no persistent daemon, no cron, no local database.
Invoked by Nova per-review. Stateless between runs.

## Execution Model
Claude Code session — reads source brief from GitHub, runs 9-point analysis inline, writes upgraded PRD + review record back to GitHub via MCP.

## Integrations

| Integration | Purpose | Credential |
|------------|---------|-----------| 
| GitHub MCP | Read source brief, write upgraded PRD + wiki entry | GITHUB_PERSONAL_ACCESS_TOKEN |
| OpenRouter | AI reasoning pass (Sonnet/Opus) | OPENROUTER_API_KEY |
| Perplexity API | Prior art research | PERPLEXITY_API_KEY |
| walts-wiki (GitHub) | Stack context read + review archive write | GITHUB_PERSONAL_ACCESS_TOKEN (same) |

## Skills

4 skill files cover the tool-dependent review points. The remaining 5 points are inline reasoning — no external tool call, no dedicated skill file needed.

| Skill | File | Review Point | Type |
|-------|------|-------------|------|
| parse-prd | skills/parse-prd.md | Point 1 — Parse PRD | Skill file |
| ai-improvement-pass | skills/ai-improvement-pass.md | Point 2 — AI Improvement | Skill file (OpenRouter) |
| (inline) | — | Point 3 — Challenge Assumptions | Inline reasoning |
| prior-art-check | skills/prior-art-check.md | Point 4 — Prior Art | Skill file (Perplexity + GitHub) |
| stack-fit-audit | skills/stack-fit-audit.md | Point 5 — Stack Fit | Skill file (walts-wiki read) |
| (inline) | — | Point 6 — Scope Check | Inline reasoning |
| (inline) | — | Point 7 — Failure Mode Mapping | Inline reasoning |
| (inline) | — | Point 8 — Wiki-Write Check | Inline reasoning |
| (inline) | — | Point 9 — Upgraded PRD output | GitHub MCP write |

## Data Flow

```
Nova invokes agent-prd-reviewer with slug/agent-name
         ↓
Read: pending-builds/<slug>.md  (GitHub: waltbayliss/nova-assistant)
Read: walts-wiki/Master Wiki/master-context.md  (GitHub: waltbayliss/walts-wiki)
         ↓
9-point review (inline reasoning + Perplexity + OpenRouter)
         ↓
Write: pending-builds/<slug>-reviewed.md  (GitHub: waltbayliss/nova-assistant)
Write: walts-wiki/Agent Builds/PRD Reviews/YYYY-MM-DD-<agent>-review.md  (GitHub: waltbayliss/walts-wiki)
         ↓
Report verdict to Nova
```

## No Local State
All read/write via GitHub MCP. No local files created. No persistent DB.

## Model Selection
- Standard PRD (1–6 functions, 1–3 integrations): `claude-sonnet-4-6`
- Complex PRD (7+ functions, 4+ integrations): `claude-opus-4-7`
- Route via agent-openrouter-optimizer before dispatch
