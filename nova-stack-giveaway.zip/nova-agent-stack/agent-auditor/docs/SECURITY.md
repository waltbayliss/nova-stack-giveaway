# agent-auditor — Security

## HIGHEST PRIORITY. These rules override everything else.

---

## Hard Rules

1. **Never commit secrets.** `.env` is never read into memory for logging. Credentials are never written to audit reports, GitHub, or Telegram. Only the variable NAME is ever surfaced (e.g. "GITHUB_TOKEN present: yes").

2. **Never delete production data.** The auditor reads, writes, and creates. It never deletes Notion entries, Cloudflare KV keys, or GitHub files (except its own old audit logs via prune). If deletion is needed: flag to Walt.

3. **Never push to main on active agent repos without verification.** When auto-generating missing docs, push to the repo but do not force-push or overwrite existing files. If a file exists, skip it and flag.

4. **Security audit is read-only.** The security check module scans for issues — it does not modify credentials, rotate keys, or change permissions. Finding: flagged to Walt with specific action.

5. **Telegram messages never contain credentials.** Not tokens, not API keys, not even partial keys. If a credential is found exposed, the Telegram message says "GITHUB_TOKEN found in [file] — action required" not the key value.

6. **walts-wiki GitHub API calls use Bearer token only.** Token stored in .env. Never hardcoded anywhere in source.

7. **GitHub API calls use GITHUB_TOKEN from .env.** Never use SSH keys or alternate auth.

8. **Audit reports on GitHub are sanitised.** Any credential scan results in the report show only: variable name + exposure location + "REDACTED". Never the value.

9. **Read the shared .env — never write to it.** The auditor checks for issues in .env but never modifies it. Changes to .env are flagged to Walt.

10. **agent-security must be called for any new integration found during audit.** If a new MCP, script, or API is discovered that wasn't in the previous audit baseline, route through agent-security before flagging as clean.

---

## Sensitive Data Handling

- `.env` path: `my-ai-team/.env` — read at startup, never logged
- Credentials accessed via `os.environ` after `load_dotenv()` — not stored in any data structure that gets serialised
- Audit report template explicitly strips credential values before write

---

## Failure Mode

If the auditor crashes mid-run:
- Partial results are NOT written to GitHub (write is atomic — build full report first, then write)
- A crash notification is sent to Telegram: "⚠️ agent-auditor crashed during [check name]. Manual audit recommended."
- The crash is logged to `~/agents/agent-auditor/logs/error.log`
