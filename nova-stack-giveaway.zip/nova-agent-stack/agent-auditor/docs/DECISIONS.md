# DECISIONS.md

*(Real entries removed for public distribution. This file exists in the real structure as the log of key technical decisions and why they were made — the shape is real, the history in it is not.)*
