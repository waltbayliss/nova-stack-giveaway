# agent-auditor — Roadmap

## Phase 1 — MVP (current build)
- [x] All 9 check modules implemented
- [x] Auto-fix: missing docs, stale wiki, unregistered agents
- [x] Reports: GitHub timestamped + walts-wiki GitHub + Telegram
- [x] LaunchAgent: Sunday midnight AEST

## Phase 2 — Intelligence Layer
- [ ] Trend detection: compare this week's audit against last 3 weeks — flag if same issue repeats
- [ ] Agent performance scoring: each agent gets a health score (0-100) based on doc completeness, wiki freshness, run success rate
- [ ] Improvement suggestions: "agent-video-editor has run 12 times with no wiki-write — recommend adding completion log"

## Phase 3 — Expanded Coverage
- [ ] Monitor GHL pipeline health (conversations, opportunities going stale)
- [ ] YouTube Content Tracker audit (ideas sitting as "Idea" >30 days with no progress)
- [ ] Revenue tracking pulse — check if [Prior Venture] pipeline is moving
- [ ] Agent-to-agent handoff audit (video-editor → seo-writer handoff actually firing?)

## Phase 4 — Self-Improvement
- [ ] After 4 consecutive weeks of same FLAG: escalate to Walt with proposed agent build to fix it permanently
- [ ] Feed audit findings back into agent-builder as "lessons learned" — future agents avoid known issues
- [ ] Auto-PR for missing docs instead of direct push (when agent repos have branch protection)
