# agent-auditor — Product Requirements Document

**Version:** 1.0
**Date:** 2026-04-21
**Owner:** Walt Bayliss
**Status:** Active

---

## Overview

agent-auditor is the weekly health check and continuous improvement engine for Walt's entire AI agent stack. It runs every Sunday at midnight AEST without human intervention. It scans everything, fixes what it can autonomously, flags what it cannot, and always leaves the system in better shape than it found it.

**The core contract:** If agent-auditor runs and nothing improves, it has failed.

---

## Problem Being Solved

As the agent team grows and agents run autonomously, three categories of drift accumulate:

1. **Documentation drift** — agents get built or updated but their docs fall behind. The 9-doc protocol gets skipped. Wiki files go stale.
2. **Registry drift** — agents exist on disk that Nova doesn't know about. Agents are registered that no longer exist.
3. **Process drift** — automated jobs fail silently. Wiki context ages out. Security assumptions erode.

Without a regular audit, Walt discovers these problems at the worst moment — when he needs an agent to work and it doesn't, or when Nova boots with context that's weeks out of date.

---

## MVP Feature Set

### Feature 1: Full Agent Folder Scan
- Scan ALL subfolders of `my-ai-team/` — not just registered agents
- Check each against the 9-doc protocol
- Auto-generate and push missing docs to GitHub
- Compare against AGENT-REGISTRY — register unknown agents, flag missing ones

### Feature 2: Wiki Freshness & Update
- Check master-context.md age — rewrite it if stale
- Update "Last 7 Days" and "Active Projects" sections
- Write per-agent wiki master-context files where missing
- Push all updates to walts-wiki GitHub

### Feature 3: Infrastructure Health
- walts-wiki GitHub API alive
- walts-wiki GitHub repo git sync current
- LaunchAgents loaded and running
- Cloudflare Workers responding
- Daily brief sent in last 24h (KV check)

### Feature 4: Content Pipeline Check
- GDrive /upload: no videos stuck >2h
- GDrive /done: output landing correctly
- Silent error detection on agent-video-editor logs

### Feature 5: Notion Visibility
- All key DBs reachable (Tasks, Daily Briefs, YouTube Tracker, Agents To Build, AI Possibilities, Products for Sale)
- Agents queued at Status: Now >48h unactioned → flag
- Tasks at Ai Queued >7 days stale → flag

### Feature 6: Security Audit
- Scan .env for exposed or duplicated credentials
- Check GitHub repos for accidental secret commits (recent pushes)
- Scan Cloudflare KV for unexpected keys
- Run agent-security on any new integrations added since last audit

### Feature 7: Silent Error Detection
- Parse Cloudflare Worker logs for errors in last 7 days
- Check agent-video-editor run log for failed jobs
- Check nova-telegram Worker for error responses

### Feature 8: Reporting
- Timestamped audit report → `waltbayliss/nova-assistant/wiki/Output/audits/YYYY-MM-DDTHHMM-audit.md`
- walts-wiki GitHub: `Walt's Wiki/Nova HQ/Raw/YYYY-MM-DD-weekly-audit.md`
- walts-wiki GitHub: updated master-context.md
- Telegram: ✅ one-liner if clean / ⚠️ numbered flag list if action needed

---

## Success Criteria

- Runs every Sunday without manual intervention
- Zero doc-missing agents after first run
- master-context.md never more than 8 days old
- Audit report always available in GitHub for next Claude Code session to read
- If action required: Walt receives specific, actionable Telegram message within 5 minutes of audit completing
