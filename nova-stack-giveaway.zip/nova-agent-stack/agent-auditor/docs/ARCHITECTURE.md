# agent-auditor — Architecture

**Version:** 1.0
**Date:** 2026-04-21

---

## Runtime

**Type:** Python script, Mac LaunchAgent
**Schedule:** Every Sunday at midnight AEST (Sunday 14:00 UTC)
**LaunchAgent ID:** `com.walt.agent-auditor`
**Python:** `/opt/homebrew/bin/python3`

Why LaunchAgent (not Cloudflare Worker): agent-auditor needs direct filesystem access to scan `my-ai-team/` folders, read local logs, and check LaunchAgent status. A cloud worker cannot do this.

---

## Folder Structure

```
agent-auditor/
├── CLAUDE.md
├── README.md
├── agent-memory.md
├── .env.example
├── requirements.txt
├── com.walt.agent-auditor.plist
├── docs/
│   ├── PRD.md
│   ├── ARCHITECTURE.md
│   ├── SOUL.md
│   ├── SECURITY.md
│   ├── ROADMAP.md
│   ├── DECISIONS.md
│   └── SPRINT_LOG.md
├── skills/
│   ├── weekly-audit.md
│   └── auto-fix.md
├── wiki/
│   ├── Raw/
│   ├── Wiki/
│   ├── Output/
│   └── Master/
│       └── master-context.md
└── src/
    ├── main.py              ← orchestrator: runs checks, collects results, calls fixes, reports
    ├── config.py            ← loads .env, constants (paths, DB IDs, thresholds)
    ├── reporter.py          ← writes to Telegram, GitHub (audit log), walts-wiki
    ├── checks/
    │   ├── __init__.py
    │   ├── wiki_freshness.py       ← master-context age, walts-wiki commits, nova-memory
    │   ├── agent_scanner.py        ← scans all my-ai-team folders, 9-doc compliance
    │   ├── registry_sync.py        ← AGENT-REGISTRY vs actual folders on disk
    │   ├── infrastructure_health.py ← walts-wiki GitHub API, LaunchAgents, Cloudflare, GDrive
    │   ├── notion_health.py        ← DB reachability, queued agents, stale tasks
    │   ├── content_pipeline.py     ← video pipeline, /upload stuck check
    │   ├── security_audit.py       ← .env scan, GitHub secret check, KV scan
    │   └── silent_errors.py        ← Cloudflare logs, video-editor logs
    └── fixes/
        ├── __init__.py
        ├── doc_generator.py        ← auto-generates missing 9-doc files with real content
        ├── wiki_updater.py         ← rewrites master-context.md, updates Last 7 Days
        └── registry_fixer.py      ← adds missing agents to AGENT-REGISTRY
```

---

## Check → Fix → Report Flow

```
main.py
  │
  ├── Run all checks (sequential, collect CheckResult objects)
  │     Each check returns: name, status (PASS/FIXED/FLAG/ERROR), detail, action_required
  │
  ├── For each FIXABLE result → call corresponding fix module
  │     Fix updates files, pushes to GitHub, records what was done
  │
  ├── Write audit report
  │     → GitHub: nova-assistant/wiki/Output/audits/YYYY-MM-DDTHHMM-audit.md
  │     → walts-wiki: update master-context.md
  │
  └── Send Telegram
        PASS only → "✅ Weekly audit complete. N checks passed. Wiki updated."
        Fixes applied → "✅ N issues found, M fixed automatically."
        FLAGS remain → "⚠️ N items need your attention:\n1. ...\n2. ..."
```

---

## CheckResult Schema

```python
@dataclass
class CheckResult:
    name: str
    status: str        # "PASS" | "FIXED" | "FLAG" | "ERROR"
    detail: str        # what was found
    fix_applied: str   # what was done (if FIXED)
    action_required: str  # what Walt needs to do (if FLAG)
```

---

## External Services

| Service | How accessed | Purpose |
|---------|-------------|---------|
| Local filesystem | Direct Python `os`/`pathlib` | Scan my-ai-team/, read logs |
| GitHub API | REST (GITHUB_TOKEN) | Check repos, push fixes, write audit log |
| walts-wiki GitHub API | REST (GITHUB_TOKEN) | Write wiki entries, update master-context.md |
| Notion API | REST (NOTION_TOKEN) | Check DB reachability, query entries |
| Cloudflare API | REST (CF_API_TOKEN) | Check Worker KV state |
| Telegram Bot API | REST (TELEGRAM_BOT_TOKEN) | Send audit report |
| LaunchAgent | `launchctl list` subprocess | Check running agents |
| agent-security | Python subprocess | Security scan new integrations |

---

## Wiki Write

| Output | Path | Trigger |
|--------|------|---------|
| Timestamped audit log | `nova-assistant/wiki/Output/audits/YYYY-MM-DDTHHMM-audit.md` | Every run |
| walts-wiki audit entry | `Walt's Wiki/Nova HQ/Raw/YYYY-MM-DD-weekly-audit.md` | Every run |
| master-context.md refresh | `walts-wiki: Walt's Wiki/Master Wiki/master-context.md` | Every run |
| Missing agent docs | Each agent's GitHub repo | When 9-doc gaps found |

---

## Environment Variables

See `.env.example` for full list. Reads from shared `my-ai-team/.env`.
