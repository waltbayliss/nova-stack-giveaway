# agent-auditor

**Nova's immune system.** Weekly autonomous health check across the entire AI agent stack.

Runs every Sunday at midnight AEST. Scans everything. Fixes what it can. Flags what it can't. Always updates the wiki.

---

## What It Does

28 checks across 5 categories:

| Category | What's Checked |
|----------|---------------|
| **Wiki Freshness** | master-context.md age, walts-wiki commits, daily journal entries, nova-memory staleness |
| **Agent Compliance** | All agent folders vs 9-doc protocol, AGENT-REGISTRY gaps, wiki-write presence |
| **Infrastructure Health** | walts-wiki GitHub reachability, LaunchAgents, daily brief delivery, nova-telegram |
| **Notion Visibility** | All 6 DBs reachable, stale queued agents, stale AI tasks |
| **Security Audit** | .env completeness, GitHub secret scan (last 5 commits), Cloudflare KV key audit |

## Auto-Fixes

Where it finds issues it can safely resolve, it acts:
- **Missing docs** (any of 9-doc protocol): generates stub from CLAUDE.md, pushes to agent's GitHub repo
- **Missing wiki/ structure**: creates Raw/Wiki/Output/Master dirs + master-context.md stub
- **Stale master-context.md**: full rewrite with current agent roster + latest sprint summary

## Flags to Walt

Anything with blast radius goes to Telegram with a specific action:
- Infrastructure offline (walts-wiki GitHub API, Cloudflare Workers)
- Possible credential exposure in GitHub commits
- Agents not wired to Nova
- Notion agent queue stale >48h

## Output

| Destination | What |
|-------------|------|
| **GitHub** | Timestamped report at `waltbayliss/nova-assistant/wiki/Output/audits/YYYY-MM-DDTHHMM-audit.md` |
| **walts-wiki GitHub** | `Walt's Wiki/Nova HQ/Raw/YYYY-MM-DD-weekly-audit.md` via `waltbayliss/walts-wiki` |
| **Telegram** | Summary notification with flag count + auto-fix count |
| **Local log** | `~/agents/agent-auditor/logs/run.log` |

---

## Structure

```
agent-auditor/
├── CLAUDE.md                  ← Operating system
├── agent-memory.md            ← Run history and thresholds
├── requirements.txt
├── .env.example               ← Variable names (no values)
├── com.walt.agent-auditor.plist ← Mac LaunchAgent
├── docs/
│   ├── PRD.md, ARCHITECTURE.md, SOUL.md, SECURITY.md
│   ├── ROADMAP.md, DECISIONS.md, SPRINT_LOG.md
├── src/
│   ├── main.py                ← Orchestrator
│   ├── config.py              ← All constants from .env
│   ├── reporter.py            ← Build report + write all outputs
│   ├── checks/
│   │   ├── wiki_freshness.py
│   │   ├── agent_scanner.py
│   │   ├── infrastructure_health.py
│   │   ├── notion_health.py
│   │   ├── security_audit.py
│   │   └── silent_errors.py
│   └── fixes/
│       ├── doc_generator.py
│       └── wiki_updater.py
├── skills/
│   ├── weekly-audit.md
│   └── auto-fix.md
└── wiki/Raw/ Wiki/ Output/ Master/
```

---

## Schedule

**LaunchAgent:** `com.walt.agent-auditor`  
**Schedule:** Sunday 14:00 UTC (midnight AEST)  
**Manual run:** `/opt/homebrew/bin/python3 src/main.py`

---

## Setup

```bash
# 1. Install dependencies
pip3 install -r requirements.txt

# 2. Credentials live in shared my-ai-team/.env — no separate setup needed

# 3. Install LaunchAgent (already done by Nova)
cp com.walt.agent-auditor.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.walt.agent-auditor.plist
```

---

*Built by Nova — Session 20, 2026-04-21*
