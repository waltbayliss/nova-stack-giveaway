# Skill: Weekly Audit

## Trigger
- Mac LaunchAgent: com.walt.agent-auditor, Sunday 14:00 UTC (midnight AEST)
- Manual: `/opt/homebrew/bin/python3 src/main.py`

## Execution Flow

```
1. run_checks()          → 28 checks across 5 modules
2. apply_auto_fixes()    → doc stubs, wiki rewrite
3. reporter.write_all()  → GitHub timestamped + walts-wiki GitHub + Telegram
4. update_agent_memory() → append run summary to agent-memory.md
```

## Check Modules

| Module | File | Checks |
|--------|------|--------|
| Wiki Freshness | checks/wiki_freshness.py | master-context age, walts-wiki commits, daily journal, nova-memory |
| Agent Scanner | checks/agent_scanner.py | 9-doc compliance, registry gaps, wiki-write presence |
| Infrastructure | checks/infrastructure_health.py | walts-wiki GitHub API, git sync, LaunchAgents, brief sent, nova-telegram |
| Notion Health | checks/notion_health.py | DB reachability, stale agents queue, stale tasks |
| Security Audit | checks/security_audit.py | .env completeness, GitHub secret scan, Cloudflare KV |

## Status Values

| Status | Meaning |
|--------|---------|
| PASS | Check passed, no action needed |
| FIXED | Issue found and auto-remediated |
| FLAG | Issue found, requires Walt's manual action |
| ERROR | Check module itself failed to run |

## Telegram Output Format

**Clean run:**
> ✅ *Weekly audit complete.* N checks passed. N issue(s) auto-fixed. Wiki updated. Stack healthy.

**Issues found:**
> ✅ *Weekly audit complete.* N passed, N auto-fixed.
> ⚠️ *N item(s) need your attention:*
> 1. [action required]

## Thresholds

| Check | FLAG Threshold |
|-------|---------------|
| master-context.md age | >7 days since last commit |
| walts-wiki commits | None in past 7 days |
| nova-memory.md age | >14 days since last commit |
| Notion stale queued agent | Status: Now for >48h |
| Notion stale AI task | Ai Queued for >7 days |
| walts-wiki GitHub uncommitted files | >5 files |
