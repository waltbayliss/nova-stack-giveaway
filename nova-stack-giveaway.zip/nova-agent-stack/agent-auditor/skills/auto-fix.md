# Skill: Auto-Fix

## What Can Be Auto-Fixed

| Issue Type | Fix Module | What Happens |
|------------|-----------|-------------|
| Missing doc file (any of 9) | fixes/doc_generator.py | Template generated from CLAUDE.md, written locally + pushed to agent's GitHub repo |
| Missing wiki/ structure | fixes/doc_generator.py | Raw/Wiki/Output/Master dirs + .gitkeep + master-context.md stub created |
| Stale master-context.md | fixes/wiki_updater.py | Full rewrite with current agent roster + sprint summary, pushed to walts-wiki GitHub |

## What Cannot Be Auto-Fixed (FLAGS only)

| Issue | Why Manual |
|-------|-----------|
| GitHub API unreachable | Requires checking token permissions or network |
| nova-telegram worker down | Requires Cloudflare deployment |
| Agent not wired to Nova | Requires deliberate routing decision |
| .env credential blank/placeholder | Could break things if wrong value filled |
| Possible credential in GitHub commit | Requires key rotation — security critical |
| Unexpected Cloudflare KV keys | Could be legitimate — Walt reviews first |
| Notion DB unreachable | Could be API issue or token expiry |

## Doc Generator Logic (fixes/doc_generator.py)

1. Read agent's CLAUDE.md to extract one-line purpose
2. For each missing doc: apply template, write locally, push to `waltbayliss/{agent-name}` on GitHub
3. **Never overwrite** existing files — checks SHA before PUT; skips if file already exists on GitHub
4. For wiki/ structure: create Raw/Wiki/Output/Master dirs with .gitkeep + master-context.md stub

## Wiki Rewrite Logic (fixes/wiki_updater.py)

1. Fetch AGENT-REGISTRY.md from local disk for current roster
2. Fetch SPRINT_LOG.md from nova-assistant GitHub for latest session summary
3. Build new master-context.md content (full canonical structure)
4. Push to walts-wiki GitHub (with SHA for update)
5. Confirm write success — log result to audit report

## Safety Rules

1. Never delete any file — only create or update
2. Never overwrite docs that already exist on GitHub
3. Security findings must be FLAGged, never auto-resolved
4. master-context.md rewrite only when `r.status == "FLAG"` for that specific check
5. All fix results logged in agent-memory.md run summary
