"""
reporter.py — Write audit report to GitHub (timestamped) and walts-wiki.
Send Telegram notification.
All writes are atomic — build full report first, then write.
No Obsidian dependency — all wiki writes go directly to walts-wiki GitHub repo.
"""
import base64
import urllib.parse
import requests
from datetime import datetime, timezone
from typing import List
from dataclasses import dataclass, field

from config import (
    GITHUB_HEADERS, NOVA_ASSISTANT_REPO, WALTS_WIKI_REPO,
    TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
)


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str
    fix_applied: str = ""
    action_required: str = ""


def _github_put(repo: str, path: str, content: str, message: str) -> bool:
    encoded_path = urllib.parse.quote(path, safe="/")
    api_url = f"https://api.github.com/repos/{repo}/contents/{encoded_path}"
    sha = None
    r = requests.get(api_url, headers=GITHUB_HEADERS, timeout=10)
    if r.ok:
        sha = r.json().get("sha")
    payload = {
        "message": message,
        "content": base64.b64encode(content.encode("utf-8")).decode("ascii"),
    }
    if sha:
        payload["sha"] = sha
    r = requests.put(api_url, headers=GITHUB_HEADERS, json=payload, timeout=15)
    return r.ok


def _send_telegram(message: str) -> bool:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return False
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "Markdown"},
            timeout=10
        )
        return r.ok
    except Exception:
        return False


def build_report(results: List[CheckResult], run_dt: datetime) -> str:
    timestamp = run_dt.strftime("%Y-%m-%d %H:%M UTC")
    date_str = run_dt.strftime("%Y-%m-%d")

    passed = [r for r in results if r.status == "PASS"]
    fixed  = [r for r in results if r.status == "FIXED"]
    flagged = [r for r in results if r.status == "FLAG"]
    errors = [r for r in results if r.status == "ERROR"]

    lines = [
        f"# agent-auditor — Weekly Audit Report",
        f"**Run:** {timestamp}",
        f"**Total checks:** {len(results)} | "
        f"✅ Pass: {len(passed)} | 🔧 Fixed: {len(fixed)} | "
        f"⚠️ Flags: {len(flagged)} | ❌ Errors: {len(errors)}",
        "",
        "---",
        "",
    ]

    if fixed:
        lines += ["## 🔧 Auto-Fixed", ""]
        for r in fixed:
            lines.append(f"- **{r.name}**: {r.fix_applied or r.detail}")
        lines.append("")

    if flagged:
        lines += ["## ⚠️ Action Required", ""]
        for i, r in enumerate(flagged, 1):
            lines.append(f"### {i}. {r.name}")
            lines.append(f"**Found:** {r.detail}")
            if r.action_required:
                lines.append(f"**Action:** {r.action_required}")
            lines.append("")

    if errors:
        lines += ["## ❌ Check Errors", ""]
        for r in errors:
            lines.append(f"- **{r.name}**: {r.detail}")
        lines.append("")

    lines += ["## ✅ All Passing Checks", ""]
    for r in passed:
        lines.append(f"- {r.name}: {r.detail}")

    return "\n".join(lines)


def build_telegram_message(results: List[CheckResult]) -> str:
    fixed  = [r for r in results if r.status == "FIXED"]
    flagged = [r for r in results if r.status == "FLAG"]
    errors = [r for r in results if r.status == "ERROR"]
    passed = [r for r in results if r.status == "PASS"]

    if not flagged and not errors:
        msg = f"✅ *Weekly audit complete.* {len(passed)} checks passed."
        if fixed:
            msg += f" {len(fixed)} issue(s) auto-fixed."
        msg += " Wiki updated. Stack healthy."
        return msg

    msg = f"✅ *Weekly audit complete.* {len(passed)} passed, {len(fixed)} auto-fixed."
    if flagged or errors:
        msg += f"\n\n⚠️ *{len(flagged) + len(errors)} item(s) need your attention:*"
        for i, r in enumerate(flagged + errors, 1):
            action = r.action_required or r.detail
            msg += f"\n{i}. {action[:120]}"
    return msg


def write_all(results: List[CheckResult]) -> dict:
    run_dt = datetime.now(timezone.utc)
    report = build_report(results, run_dt)
    date_str = run_dt.strftime("%Y-%m-%d")
    timestamp_str = run_dt.strftime("%Y-%m-%dT%H%M")

    outcomes = {}

    # 1. GitHub timestamped audit log (for next Claude Code session)
    github_path = f"wiki/Output/audits/{timestamp_str}-audit.md"
    outcomes["github"] = _github_put(
        NOVA_ASSISTANT_REPO, github_path, report,
        f"audit: weekly report {date_str}"
    )

    # 2. walts-wiki audit entry (replaces former Obsidian write)
    wiki_path = f"Walt's Wiki/Nova HQ/Raw/{date_str}-weekly-audit.md"
    outcomes["walts_wiki"] = _github_put(
        WALTS_WIKI_REPO, wiki_path, report,
        f"audit: weekly report {date_str}"
    )

    # 3. Telegram
    telegram_msg = build_telegram_message(results)
    outcomes["telegram"] = _send_telegram(telegram_msg)

    return outcomes


def send_crash_notification(error_msg: str) -> None:
    msg = f"⚠️ *agent-auditor crashed*\n\n{error_msg[:300]}\n\nManual audit recommended."
    _send_telegram(msg)
