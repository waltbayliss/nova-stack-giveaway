"""
config.py — Load environment and define constants for agent-auditor.
Reads from shared my-ai-team/.env
Note: Obsidian REST API removed. All wiki reads/writes use walts-wiki GitHub API.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load shared .env
# .env is either at /home/walt/.env (VPS) or ../../../.env (Mac my-ai-team root)
_ENV_PATH_VPS = Path.home() / ".env"
_ENV_PATH_MAC = Path(__file__).parent.parent.parent / ".env"
_ENV_PATH = _ENV_PATH_VPS if _ENV_PATH_VPS.exists() else _ENV_PATH_MAC
load_dotenv(_ENV_PATH)

# --- GitHub ---
GITHUB_TOKEN = os.environ["GITHUB_PERSONAL_ACCESS_TOKEN"]
GITHUB_HEADERS = {
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json",
    "User-Agent": "agent-auditor",
}

# --- Notion ---
NOTION_TOKEN = os.environ.get("NOTION_TOKEN", "")
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_TOKEN}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json",
}
NOTION_DB_IDS = {
    "tasks":            os.environ.get("NOTION_TASKS_DB_ID", "[REDACTED-ID]"),
    "daily_briefs":     os.environ.get("NOTION_DAILY_BRIEFS_CONTAINER_ID", "[REDACTED-ID]"),
    "youtube_tracker":  os.environ.get("NOTION_YOUTUBE_TRACKER_DB_ID", ""),
    "agents_to_build":  os.environ.get("NOTION_AGENTS_TO_BUILD_DB_ID", "[REDACTED-ID]"),
    "ai_possibilities": os.environ.get("NOTION_AI_POSSIBILITIES_DB_ID", "[REDACTED-ID]"),
    "products_for_sale":os.environ.get("NOTION_PRODUCTS_FOR_SALE_DB_ID", "[REDACTED-ID]"),
}

# --- Telegram ---
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
# Telegram webhook-style URL (derived from bot token)
NOVA_TELEGRAM_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"

# --- Cloudflare ---
CF_API_TOKEN = os.environ.get("CLOUDFLARE_API_TOKEN", "")
CF_ACCOUNT_ID = os.environ.get("CLOUDFLARE_ACCOUNT_ID", "")
BRIEF_KV_NAMESPACE_ID = os.environ.get("BRIEF_KV_NAMESPACE_ID", "[REDACTED-ID]")

# --- Paths ---
MY_AI_TEAM_PATH = Path(os.environ.get(
    "MY_AI_TEAM_PATH",
    str(Path.home() / "agents")  # VPS default; Mac uses Google Drive path
))
GDRIVE_UPLOAD_PATH = Path(os.environ.get("GDRIVE_UPLOAD_PATH", ""))
GDRIVE_DONE_PATH   = Path(os.environ.get("GDRIVE_DONE_PATH", ""))
VIDEO_EDITOR_LOG   = Path(os.environ.get("VIDEO_EDITOR_LOG_PATH",
    str(Path.home() / "agents/agent-video-editor/logs/run.log")))
AGENT_AUDITOR_LOG  = Path.home() / "agents/agent-auditor/logs"

# --- Repos ---
NOVA_ASSISTANT_REPO = "waltbayliss/nova-assistant"
WALTS_WIKI_REPO     = "waltbayliss/walts-wiki"

# --- Thresholds (days unless stated) ---
MASTER_CONTEXT_MAX_AGE_DAYS = 7
WALTS_WIKI_MAX_STALE_DAYS   = 7
VIDEO_STUCK_HOURS           = 2
AGENT_QUEUED_NOW_HOURS      = 48
TASK_AI_QUEUED_DAYS         = 7
BRIEF_NOT_SENT_HOURS        = 24

# --- 9-doc protocol ---
REQUIRED_DOCS = [
    "CLAUDE.md",
    "agent-memory.md",
    ".env.example",
    "docs/PRD.md",
    "docs/ARCHITECTURE.md",
    "docs/SOUL.md",
    "docs/SECURITY.md",
    "docs/ROADMAP.md",
    "docs/DECISIONS.md",
    "docs/SPRINT_LOG.md",
]
REQUIRED_WIKI_DIRS = ["wiki/Raw", "wiki/Wiki", "wiki/Output", "wiki/Master"]
REQUIRED_WIKI_MASTER = "wiki/Master/master-context.md"

# Agents exempt from 9-doc protocol (infrastructure, not AI agents)
EXEMPT_FOLDERS = {"nova-telegram", ".git", "__pycache__", "node_modules"}
