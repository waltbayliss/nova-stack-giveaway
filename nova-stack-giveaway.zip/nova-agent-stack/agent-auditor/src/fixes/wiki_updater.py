"""
wiki_updater.py — Rewrite master-context.md when stale.
Updates Last 7 Days section, agent roster, active project list.
Pushes to walts-wiki GitHub repo via API. No Obsidian dependency.
"""
import base64
import requests
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from config import (
    GITHUB_HEADERS, WALTS_WIKI_REPO, NOVA_ASSISTANT_REPO,
    MY_AI_TEAM_PATH
)

MASTER_CONTEXT_PATH = "Walt's Wiki/Master Wiki/master-context.md"


def _get_github_file(repo: str, path: str) -> tuple[Optional[str], Optional[str]]:
    """Returns (content, sha) or (None, None)."""
    encoded_path = requests.utils.quote(path, safe="/")
    r = requests.get(
        f"https://api.github.com/repos/{repo}/contents/{encoded_path}",
        headers=GITHUB_HEADERS, timeout=10
    )
    if r.ok:
        data = r.json()
        content = base64.b64decode(data["content"]).decode("utf-8", "replace")
        return content, data["sha"]
    return None, None


def _put_github_file(repo: str, path: str, content: str, sha: Optional[str], message: str) -> bool:
    encoded_path = requests.utils.quote(path, safe="/")
    encoded_content = base64.b64encode(content.encode("utf-8")).decode("ascii")
    payload = {"message": message, "content": encoded_content}
    if sha:
        payload["sha"] = sha
    r = requests.put(
        f"https://api.github.com/repos/{repo}/contents/{encoded_path}",
        headers=GITHUB_HEADERS, json=payload, timeout=15
    )
    return r.ok


def _get_sprint_log_summary() -> str:
    """Pull the latest session summary from nova-assistant SPRINT_LOG."""
    content, _ = _get_github_file(NOVA_ASSISTANT_REPO, "docs/SPRINT_LOG.md")
    if not content:
        return "Sprint log unavailable."
    # Find latest session heading
    lines = content.split("\n")
    for i, line in enumerate(lines):
        if line.startswith("## Session") and "Status" in "\n".join(lines[i:i+5]):
            # Return first 3 lines of this session
            return " ".join(l.strip() for l in lines[i:i+4] if l.strip())[:300]
    return "See nova-assistant/docs/SPRINT_LOG.md"


def _get_active_agents_list() -> str:
    """Read AGENT-REGISTRY.md from local disk for current agent list."""
    registry_path = MY_AI_TEAM_PATH / "nova-assistant" / "docs" / "AGENT-REGISTRY.md"
    if not registry_path.exists():
        return "See AGENT-REGISTRY.md"
    content = registry_path.read_text(encoding="utf-8", errors="ignore")
    # Extract active agents table rows
    lines = []
    in_table = False
    for line in content.split("\n"):
        if "## Active Agents" in line:
            in_table = True
        if in_table and line.startswith("| ") and "agent-" in line.lower():
            parts = [p.strip() for p in line.split("|") if p.strip()]
            if parts:
                lines.append(f"- {parts[0]}")
        if in_table and line.startswith("## ") and "Active" not in line:
            break
    return "\n".join(lines[:15]) or "See AGENT-REGISTRY.md"


def update_master_context_last_7_days(new_line: str) -> bool:
    """Prepend one line to the Last 7 Days section in master-context.md."""
    content, sha = _get_github_file(WALTS_WIKI_REPO, MASTER_CONTEXT_PATH)
    if not content:
        return False

    MARKER = "## Last 7 Days (auto-updated by brief)"
    FOOTER = "\n_Updated by agent-daily-brief each morning. Most recent first._\n"
    marker_idx = content.find(MARKER)

    if marker_idx == -1:
        content += f"\n\n{MARKER}{FOOTER}\n{new_line}\n"
    else:
        before = content[:marker_idx + len(MARKER)]
        after = content[marker_idx + len(MARKER):]
        existing = [l for l in after.split("\n") if l.startswith("- **")][:6]
        content = before + FOOTER + "\n" + new_line + "\n" + "\n".join(existing) + "\n"

    return _put_github_file(
        WALTS_WIKI_REPO, MASTER_CONTEXT_PATH, content, sha,
        f"wiki: audit updated master-context Last 7 Days — {datetime.now(timezone.utc).strftime('%Y-%m-%d')}"
    )


def rewrite_master_context() -> bool:
    """Full rewrite of master-context.md with current state."""
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    agents_list = _get_active_agents_list()
    sprint_summary = _get_sprint_log_summary()

    new_content = f"""# Walt's Wiki — Master Context
<!-- Auto-loaded by Nova at every boot. Updated by: session closes + agent-daily-brief + agent-auditor. -->
<!-- Last updated: {today} — by agent-auditor (weekly rewrite) -->

---

## Who Walt Is

- **Walt Bayliss** — entrepreneur, co-founder of [Prior Venture] ([Prior Venture]) with [Colleague]
- Based: Gold Coast, Queensland, Australia
- **North star:** $1M/year personal income + genuine personal freedom
- Previously: [Prior Company] (75 staff, acquired by Dakota 2026). AixUp sold.
- Philosophy: "Don't just replicate, innovate." / "Make a dent in the universe."
- Works Saturdays as regular work days
- Voice: direct, entrepreneurial, action-oriented, no fluff

---

## Current Business Focus

### [Prior Venture] ([Prior Venture])
- Co-founder with [Colleague]. [prior-venture-site]
- Model: deploy AI agents across client departments → guaranteed $50K+ savings
- Targeting Australian enterprise clients. Big target: PSA.com.au (multi-six-figure)

### Personal Income System (WaltBayliss.com)
- Autonomous company vision: AI CEO, Walt as sole shareholder
- Revenue streams: digital products, templates, courses, giveaways

---

## Active Agent Team (auto-updated {today})

{agents_list}

---

## Latest Sprint Activity

{sprint_summary}

---

## Key Infrastructure

| System | Details |
|--------|---------|
| Nova Telegram | https://nova-telegram.waltbayliss.workers.dev |
| Daily Brief | Cloudflare cron 21:00 UTC (7am AEST) → Notion + Telegram |
| walts-wiki GitHub | waltbayliss/walts-wiki — primary wiki store (no Obsidian) |
| nova-assistant GitHub | waltbayliss/nova-assistant |
| Notion HQ | [NOTION-PAGE-ID] |
| Telegram chat ID | [TELEGRAM-CHAT-ID] |

---

## How This File Gets Updated

| Trigger | Who | What |
|---------|-----|------|
| Session close | Nova (manual) | Active projects, decisions, agent roster |
| 7am brief run | agent-daily-brief | Last 7 Days section |
| Sunday midnight | agent-auditor | Full rewrite — this is one of those |

---

## Last 7 Days (auto-updated by brief)

_Updated by agent-daily-brief each morning. Most recent first._

- **{today}:** Weekly audit by agent-auditor. master-context.md rewritten.

"""

    _, sha = _get_github_file(WALTS_WIKI_REPO, MASTER_CONTEXT_PATH)
    github_ok = _put_github_file(
        WALTS_WIKI_REPO, MASTER_CONTEXT_PATH, new_content, sha,
        f"wiki: agent-auditor full rewrite of master-context.md — {today}"
    )
    return github_ok
