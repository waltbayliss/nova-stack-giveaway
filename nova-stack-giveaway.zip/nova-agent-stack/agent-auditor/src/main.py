"""
main.py — agent-auditor orchestrator.

Runs every Sunday midnight AEST via Mac LaunchAgent com.walt.agent-auditor.
Can also be triggered manually: /opt/homebrew/bin/python3 src/main.py

Flow:
  1. Run all checks → collect CheckResult list
  2. Apply auto-fixes for fixable issues
  3. Build full audit report (atomic)
  4. Write to GitHub (timestamped) + walts-wiki GitHub
  5. Send Telegram notification
  6. Append run summary to runtime-journal.md (gitignored)
"""
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

# Ensure src/ is on path
sys.path.insert(0, str(Path(__file__).parent))

import reporter
from reporter import CheckResult

# --- Log setup ---
LOG_DIR = Path.home() / "agents" / "agent-auditor" / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "run.log"


def log(msg: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def run_checks() -> list[CheckResult]:
    """Run all check modules. Each returns List[CheckResult]."""
    from checks import wiki_freshness, agent_scanner, infrastructure_health, notion_health, security_audit, silent_errors
    all_results: list[CheckResult] = []

    modules = [
        ("wiki_freshness", wiki_freshness),
        ("agent_scanner", agent_scanner),
        ("infrastructure_health", infrastructure_health),
        ("notion_health", notion_health),
        ("security_audit", security_audit),
        ("silent_errors", silent_errors),
    ]

    for name, module in modules:
        log(f"Running check module: {name}")
        try:
            results = module.run_all()
            # Normalise to reporter.CheckResult
            for r in results:
                all_results.append(CheckResult(
                    name=r.name, status=r.status, detail=r.detail,
                    fix_applied=getattr(r, "fix_applied", ""),
                    action_required=getattr(r, "action_required", "")
                ))
            passes = sum(1 for r in results if r.status == "PASS")
            flags  = sum(1 for r in results if r.status == "FLAG")
            log(f"  {name}: {len(results)} checks — {passes} pass, {flags} flag")
        except Exception as e:
            log(f"  ERROR in {name}: {e}")
            all_results.append(CheckResult(
                name=f"{name} module", status="ERROR",
                detail=f"Module crashed: {traceback.format_exc(limit=3)}"
            ))

    return all_results


def apply_auto_fixes(results: list[CheckResult]) -> list[CheckResult]:
    """Apply auto-fixes for doc compliance and wiki staleness issues."""
    from checks.agent_scanner import scan_agent_folders, AgentAudit
    from fixes.doc_generator import generate_missing_docs
    from fixes.wiki_updater import rewrite_master_context

    # Fix 1: Missing docs on agents
    audits = scan_agent_folders()
    for audit in audits:
        if audit.missing_docs or audit.missing_wiki_dirs or audit.missing_wiki_master:
            log(f"Auto-fixing docs for {audit.folder_name}...")
            fix_results = generate_missing_docs(
                audit.folder_name, audit.path,
                audit.missing_docs, audit.missing_wiki_dirs, audit.missing_wiki_master
            )
            for fr in fix_results:
                if fr.status == "FIXED":
                    # Replace FLAG with FIXED in results
                    for r in results:
                        if audit.folder_name in r.name and "compliance" in r.name:
                            r.status = "FIXED"
                            r.fix_applied = fr.detail
                            break
                    log(f"  Fixed: {fr.agent_name} / {fr.doc}")

    # Fix 2: Stale master-context.md
    for r in results:
        if r.name == "master-context.md age" and r.status == "FLAG":
            log("Auto-fixing: rewriting stale master-context.md...")
            success = rewrite_master_context()
            if success:
                r.status = "FIXED"
                r.fix_applied = "master-context.md rewritten with current agent roster + sprint summary."
            else:
                r.detail += " (rewrite attempted but failed)"

    return results


def write_runtime_journal(results: list[CheckResult], run_dt: datetime) -> None:
    """Append a run summary to runtime-journal.md (gitignored).

    Note: this used to write to agent-memory.md but that's a tracked file —
    agents must never write to tracked files at runtime
    (see @skills/claude-md-quality.md principle 10).
    """
    journal_path = Path(__file__).parent.parent / "runtime-journal.md"
    date_str = run_dt.strftime("%Y-%m-%d %H:%M UTC")
    passed = sum(1 for r in results if r.status == "PASS")
    fixed  = sum(1 for r in results if r.status == "FIXED")
    flagged = sum(1 for r in results if r.status in ("FLAG", "ERROR"))
    entry = f"\n\n## Run: {date_str}\n- {passed} passed, {fixed} fixed, {flagged} flagged\n"
    if flagged:
        flags = [r for r in results if r.status in ("FLAG", "ERROR")]
        for f in flags[:5]:
            entry += f"- ⚠️ {f.name}: {f.action_required or f.detail}\n"
    with open(journal_path, "a") as f:
        f.write(entry)


def main() -> None:
    run_dt = datetime.now(timezone.utc)
    log("=" * 60)
    log(f"agent-auditor started — {run_dt.strftime('%Y-%m-%d %H:%M UTC')}")
    log("=" * 60)

    try:
        # Step 1: Run all checks
        results = run_checks()
        log(f"Checks complete: {len(results)} total")

        # Step 2: Apply auto-fixes
        results = apply_auto_fixes(results)

        # Step 3 & 4: Build report and write all outputs (atomic)
        log("Writing audit report...")
        outcomes = reporter.write_all(results)
        log(f"Write outcomes: {outcomes}")

        # Step 5: Append run summary to runtime-journal.md (gitignored)
        write_runtime_journal(results, run_dt)

        passed = sum(1 for r in results if r.status == "PASS")
        fixed  = sum(1 for r in results if r.status == "FIXED")
        flagged = sum(1 for r in results if r.status in ("FLAG", "ERROR"))
        log(f"Run complete — {passed} pass | {fixed} fixed | {flagged} flagged")

        from pathlib import Path
        Path("/home/walt/agents/.heartbeats/agent-auditor").write_text(datetime.now(timezone.utc).isoformat())

    except Exception as e:
        tb = traceback.format_exc()
        log(f"FATAL ERROR: {e}\n{tb}")
        reporter.send_crash_notification(f"{e}\n\n{tb[:500]}")
        sys.exit(1)


if __name__ == "__main__":
    main()
