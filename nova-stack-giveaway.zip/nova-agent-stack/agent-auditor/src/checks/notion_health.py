"""
notion_health.py — Check all key Notion DBs are reachable, flag stale queued agents and tasks.
"""
import requests
from datetime import datetime, timezone, timedelta
from typing import List
from dataclasses import dataclass

from config import (
    NOTION_TOKEN, NOTION_HEADERS, NOTION_DB_IDS,
    AGENT_QUEUED_NOW_HOURS, TASK_AI_QUEUED_DAYS
)


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str
    fix_applied: str = ""
    action_required: str = ""


def check_db_reachability() -> List[CheckResult]:
    results = []
    for db_name, db_id in NOTION_DB_IDS.items():
        if not db_id:
            results.append(CheckResult(
                f"Notion DB: {db_name}", "FLAG",
                f"DB ID for {db_name} not set in .env.",
                action_required=f"Add NOTION_{db_name.upper()}_DB_ID to .env"
            ))
            continue
        try:
            r = requests.post(
                f"https://api.notion.com/v1/databases/{db_id}/query",
                headers=NOTION_HEADERS,
                json={"page_size": 1},
                timeout=10
            )
            if r.ok:
                results.append(CheckResult(
                    f"Notion DB: {db_name}", "PASS",
                    f"Notion DB '{db_name}' reachable. ✅"
                ))
            elif r.status_code == 404:
                results.append(CheckResult(
                    f"Notion DB: {db_name}", "FLAG",
                    f"Notion DB '{db_name}' not found (404). ID: {db_id}",
                    action_required=f"Verify DB ID and sharing with integration."
                ))
            else:
                results.append(CheckResult(
                    f"Notion DB: {db_name}", "FLAG",
                    f"Notion DB '{db_name}' returned {r.status_code}.",
                    action_required="Check NOTION_TOKEN and DB sharing settings."
                ))
        except Exception as e:
            results.append(CheckResult(f"Notion DB: {db_name}", "ERROR", str(e)))
    return results


def check_stale_queued_agents() -> CheckResult:
    """Flag agents at Status: Now for more than AGENT_QUEUED_NOW_HOURS."""
    db_id = NOTION_DB_IDS.get("agents_to_build")
    if not db_id:
        return CheckResult("stale queued agents", "FLAG",
                           "agents_to_build DB ID not set.",
                           action_required="Set NOTION_AGENTS_TO_BUILD_DB_ID in .env")
    try:
        r = requests.post(
            f"https://api.notion.com/v1/databases/{db_id}/query",
            headers=NOTION_HEADERS,
            json={"filter": {"property": "Status", "select": {"equals": "Now"}}},
            timeout=10
        )
        if not r.ok:
            return CheckResult("stale queued agents", "FLAG", f"Query failed: {r.status_code}")

        pages = r.json().get("results", [])
        stale = []
        cutoff = datetime.now(timezone.utc) - timedelta(hours=AGENT_QUEUED_NOW_HOURS)
        for page in pages:
            created = page.get("created_time", "")
            if created:
                dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                if dt < cutoff:
                    name = page.get("properties", {}).get("Name", {}).get("title", [{}])
                    name_text = name[0].get("plain_text", "unnamed") if name else "unnamed"
                    hours = int((datetime.now(timezone.utc) - dt).total_seconds() / 3600)
                    stale.append(f"{name_text} ({hours}h)")

        if stale:
            return CheckResult(
                "stale queued agents", "FLAG",
                f"{len(stale)} agent(s) at Status: Now for >{AGENT_QUEUED_NOW_HOURS}h: {', '.join(stale)}",
                action_required="Run intake in Claude Code session."
            )
        return CheckResult("stale queued agents", "PASS",
                           "No agents stale at Status: Now. ✅")
    except Exception as e:
        return CheckResult("stale queued agents", "ERROR", str(e))


def check_stale_ai_queued_tasks() -> CheckResult:
    """Flag tasks at Ai Queued status for more than TASK_AI_QUEUED_DAYS."""
    db_id = NOTION_DB_IDS.get("tasks")
    if not db_id:
        return CheckResult("stale AI queued tasks", "FLAG",
                           "tasks DB ID not set.",
                           action_required="Set NOTION_TASKS_DB_ID in .env")
    try:
        r = requests.post(
            f"https://api.notion.com/v1/databases/{db_id}/query",
            headers=NOTION_HEADERS,
            json={"filter": {"property": "Status", "select": {"equals": "Ai Queued"}}},
            timeout=10
        )
        if not r.ok:
            return CheckResult("stale AI queued tasks", "FLAG", f"Query failed: {r.status_code}")

        pages = r.json().get("results", [])
        stale = []
        cutoff = datetime.now(timezone.utc) - timedelta(days=TASK_AI_QUEUED_DAYS)
        for page in pages:
            created = page.get("created_time", "")
            if created:
                dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                if dt < cutoff:
                    name_prop = page.get("properties", {}).get("Task Name", {}).get("title", [{}])
                    name_text = name_prop[0].get("plain_text", "unnamed") if name_prop else "unnamed"
                    days = (datetime.now(timezone.utc) - dt).days
                    stale.append(f"{name_text} ({days}d)")

        if stale:
            return CheckResult(
                "stale AI queued tasks", "FLAG",
                f"{len(stale)} task(s) Ai Queued for >{TASK_AI_QUEUED_DAYS} days: {', '.join(stale[:5])}",
                action_required="Action or re-queue these tasks in next Claude Code session."
            )
        return CheckResult("stale AI queued tasks", "PASS",
                           "No AI queued tasks overdue. ✅")
    except Exception as e:
        return CheckResult("stale AI queued tasks", "ERROR", str(e))


def run_all() -> List[CheckResult]:
    results = check_db_reachability()
    results.append(check_stale_queued_agents())
    results.append(check_stale_ai_queued_tasks())
    return results
