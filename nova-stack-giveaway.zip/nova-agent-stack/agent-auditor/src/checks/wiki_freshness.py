"""
wiki_freshness.py — Check master-context.md age, walts-wiki GitHub commits, nova-memory freshness.
"""
import requests
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field
from typing import List

from config import (
    GITHUB_HEADERS, WALTS_WIKI_REPO, NOVA_ASSISTANT_REPO,
    MASTER_CONTEXT_MAX_AGE_DAYS, WALTS_WIKI_MAX_STALE_DAYS
)


@dataclass
class CheckResult:
    name: str
    status: str          # PASS | FIXED | FLAG | ERROR
    detail: str
    fix_applied: str = ""
    action_required: str = ""


def check_master_context_age() -> CheckResult:
    """Check when master-context.md was last committed to walts-wiki."""
    url = f"https://api.github.com/repos/{WALTS_WIKI_REPO}/commits"
    try:
        r = requests.get(url, headers=GITHUB_HEADERS,
                         params={"path": "Walt's Wiki/Master Wiki/master-context.md", "per_page": 1},
                         timeout=10)
        if not r.ok:
            return CheckResult("master-context.md age", "FLAG",
                               f"Could not query GitHub commits: {r.status_code}",
                               action_required="Check GitHub token permissions.")
        commits = r.json()
        if not commits:
            return CheckResult("master-context.md age", "FLAG",
                               "master-context.md has no commits on walts-wiki.",
                               action_required="Run: push master-context.md to waltbayliss/walts-wiki")
        last_commit_date = commits[0]["commit"]["committer"]["date"]
        last_dt = datetime.fromisoformat(last_commit_date.replace("Z", "+00:00"))
        age_days = (datetime.now(timezone.utc) - last_dt).days
        if age_days > MASTER_CONTEXT_MAX_AGE_DAYS:
            return CheckResult(
                "master-context.md age", "FLAG",
                f"master-context.md is {age_days} days old (threshold: {MASTER_CONTEXT_MAX_AGE_DAYS}).",
                action_required="Auto-rewrite triggered by wiki_updater."
            )
        return CheckResult("master-context.md age", "PASS",
                           f"master-context.md updated {age_days} day(s) ago. ✅")
    except Exception as e:
        return CheckResult("master-context.md age", "ERROR", str(e))


def check_walts_wiki_commits() -> CheckResult:
    """Check if walts-wiki has had any commits in the last N days."""
    url = f"https://api.github.com/repos/{WALTS_WIKI_REPO}/commits"
    try:
        since = (datetime.now(timezone.utc) - timedelta(days=WALTS_WIKI_MAX_STALE_DAYS)).isoformat()
        r = requests.get(url, headers=GITHUB_HEADERS,
                         params={"since": since, "per_page": 1}, timeout=10)
        if not r.ok:
            return CheckResult("walts-wiki commits", "FLAG",
                               f"GitHub query failed: {r.status_code}",
                               action_required="Check GITHUB_TOKEN.")
        commits = r.json()
        if not commits:
            return CheckResult("walts-wiki commits", "FLAG",
                               f"No commits to walts-wiki in the last {WALTS_WIKI_MAX_STALE_DAYS} days.",
                               action_required="Check agent-daily-brief wiki write is running — it pushes to walts-wiki GitHub every 7am.")
        return CheckResult("walts-wiki commits", "PASS",
                           f"walts-wiki has recent commits. ✅")
    except Exception as e:
        return CheckResult("walts-wiki commits", "ERROR", str(e))


def check_daily_journal_entries() -> CheckResult:
    """Check if Daily Journal entries are being written by agent-daily-brief."""
    url = f"https://api.github.com/repos/{WALTS_WIKI_REPO}/contents/Walt%27s%20Wiki%2FDaily%20Journal%2FRaw"
    try:
        r = requests.get(url, headers=GITHUB_HEADERS, timeout=10)
        if r.status_code == 404:
            return CheckResult("daily journal entries", "FLAG",
                               "Walt's Wiki/Daily Journal/Raw/ does not exist on walts-wiki.",
                               action_required="Verify agent-daily-brief wiki write is deployed (v6c5ad5af+).")
        if not r.ok:
            return CheckResult("daily journal entries", "FLAG", f"GitHub query failed: {r.status_code}")
        files = r.json()
        if not isinstance(files, list) or not files:
            return CheckResult("daily journal entries", "FLAG",
                               "Daily Journal/Raw/ exists but is empty.",
                               action_required="Check agent-daily-brief writeBriefToWiki() is firing.")
        # Check most recent file date
        latest = sorted([f["name"] for f in files if f["name"].endswith(".md")], reverse=True)
        if not latest:
            return CheckResult("daily journal entries", "FLAG", "No .md files in Daily Journal/Raw/.")
        latest_name = latest[0]
        return CheckResult("daily journal entries", "PASS",
                           f"Daily Journal entries found. Latest: {latest_name} ✅")
    except Exception as e:
        return CheckResult("daily journal entries", "ERROR", str(e))


def check_nova_memory_freshness() -> CheckResult:
    """Check nova-memory.md last commit date."""
    url = f"https://api.github.com/repos/{NOVA_ASSISTANT_REPO}/commits"
    try:
        r = requests.get(url, headers=GITHUB_HEADERS,
                         params={"path": "nova-memory.md", "per_page": 1}, timeout=10)
        if not r.ok:
            return CheckResult("nova-memory.md freshness", "FLAG", f"GitHub query failed: {r.status_code}")
        commits = r.json()
        if not commits:
            return CheckResult("nova-memory.md freshness", "FLAG", "nova-memory.md has no commits.")
        last_date = commits[0]["commit"]["committer"]["date"]
        last_dt = datetime.fromisoformat(last_date.replace("Z", "+00:00"))
        age_days = (datetime.now(timezone.utc) - last_dt).days
        if age_days > 7:
            return CheckResult("nova-memory.md freshness", "FLAG",
                               f"nova-memory.md is {age_days} days old.",
                               action_required="Update nova-memory.md in next Claude Code session.")
        return CheckResult("nova-memory.md freshness", "PASS",
                           f"nova-memory.md updated {age_days} day(s) ago. ✅")
    except Exception as e:
        return CheckResult("nova-memory.md freshness", "ERROR", str(e))


def run_all() -> List[CheckResult]:
    return [
        check_master_context_age(),
        check_walts_wiki_commits(),
        check_daily_journal_entries(),
        check_nova_memory_freshness(),
    ]
