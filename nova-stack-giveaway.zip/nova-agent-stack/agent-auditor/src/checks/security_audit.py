"""
security_audit.py — Credential exposure scan, GitHub recent commit check,
Cloudflare KV unexpected key check.
"""
import re
import requests
from pathlib import Path
from typing import List
from dataclasses import dataclass

from config import (
    GITHUB_HEADERS, NOVA_ASSISTANT_REPO, MY_AI_TEAM_PATH,
    CF_API_TOKEN, CF_ACCOUNT_ID, BRIEF_KV_NAMESPACE_ID
)

# Patterns that look like raw credentials (never log the value, only the location)
SECRET_PATTERNS = [
    r'ghp_[A-Za-z0-9]{36}',           # GitHub PAT
    r'sk-[A-Za-z0-9]{48}',            # OpenAI key
    r'Bearer\s+[A-Za-z0-9\-_]{32,}',  # Generic Bearer
    r'eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+',  # JWT
    r'AKIA[0-9A-Z]{16}',              # AWS Access Key
]
SECRET_RE = re.compile('|'.join(SECRET_PATTERNS))

# Files always exempt from secret scanning (they SHOULD have placeholders)
EXEMPT_FILES = {".env.example", ".env.template"}

# File extensions to scan
SCAN_EXTENSIONS = {".py", ".js", ".ts", ".md", ".json", ".yaml", ".yml", ".sh"}


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str
    fix_applied: str = ""
    action_required: str = ""


def check_env_file() -> CheckResult:
    """Scan shared .env for blank or placeholder values."""
    env_path = MY_AI_TEAM_PATH / ".env"
    if not env_path.exists():
        return CheckResult(".env file", "FLAG",
                           ".env file not found at expected path.",
                           action_required="Verify MY_AI_TEAM_PATH in config.")
    issues = []
    try:
        for line in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            value = value.strip().strip('"').strip("'")
            if not value or value in ("your_value_here", "xxx", "TODO", "REPLACE_ME", ""):
                issues.append(f"{key.strip()} appears blank or placeholder")
    except Exception as e:
        return CheckResult(".env file", "ERROR", str(e))

    if issues:
        return CheckResult(".env file", "FLAG",
                           f"{len(issues)} credential(s) look unset: {'; '.join(issues[:5])}",
                           action_required="Fill in missing credentials in my-ai-team/.env")
    return CheckResult(".env file", "PASS", "All .env credentials appear set. ✅")


def check_github_recent_commits_for_secrets() -> CheckResult:
    """Scan the last 5 commits on nova-assistant for accidental secret exposure."""
    repos_to_check = ["waltbayliss/nova-assistant", "waltbayliss/walts-wiki"]
    findings = []
    for repo in repos_to_check:
        try:
            r = requests.get(
                f"https://api.github.com/repos/{repo}/commits",
                headers=GITHUB_HEADERS,
                params={"per_page": 5},
                timeout=10
            )
            if not r.ok:
                continue
            commits = r.json()
            for commit in commits:
                sha = commit.get("sha", "")[:7]
                # Get the diff for this commit
                diff_r = requests.get(
                    f"https://api.github.com/repos/{repo}/commits/{commit['sha']}",
                    headers={**GITHUB_HEADERS, "Accept": "application/vnd.github.diff"},
                    timeout=10
                )
                if diff_r.ok:
                    diff_text = diff_r.text
                    if SECRET_RE.search(diff_text):
                        findings.append(f"{repo} commit {sha}")
        except Exception:
            continue

    if findings:
        return CheckResult(
            "GitHub secret scan", "FLAG",
            f"Possible credential in commit(s): {', '.join(findings)}",
            action_required="Review these commits immediately. Rotate any exposed keys."
        )
    return CheckResult("GitHub secret scan", "PASS",
                       "No obvious credentials found in recent commits. ✅")


def check_cloudflare_kv_keys() -> CheckResult:
    """Check nova-telegram-kv for unexpected keys."""
    if not CF_API_TOKEN or not CF_ACCOUNT_ID:
        return CheckResult("Cloudflare KV audit", "FLAG",
                           "CF credentials not set — cannot check KV.",
                           action_required="Add CLOUDFLARE_API_TOKEN + CLOUDFLARE_ACCOUNT_ID to .env")
    try:
        r = requests.get(
            f"https://api.cloudflare.com/client/v4/accounts/{CF_ACCOUNT_ID}"
            f"/storage/kv/namespaces/{BRIEF_KV_NAMESPACE_ID}/keys",
            headers={"Authorization": f"Bearer {CF_API_TOKEN}"},
            timeout=10
        )
        if not r.ok:
            return CheckResult("Cloudflare KV audit", "FLAG",
                               f"KV keys query failed: {r.status_code}",
                               action_required="Check CF_API_TOKEN permissions.")

        keys = [k["name"] for k in r.json().get("result", [])]
        # Known expected key patterns
        expected_patterns = [
            r'^brief_sent_\d{4}-\d{2}-\d{2}$',
            r'^brief_items_today$',
            r'^skipped_task_ids$',
            r'^intake:.+$',
            r'^intake_queue$',
            r'^active_intake$',
            r'^history:.+$',
        ]
        unexpected = []
        for key in keys:
            if not any(re.match(p, key) for p in expected_patterns):
                unexpected.append(key)

        if unexpected:
            return CheckResult(
                "Cloudflare KV audit", "FLAG",
                f"Unexpected KV keys found: {', '.join(unexpected[:10])}",
                action_required="Review these keys in Cloudflare dashboard. Delete if not recognised."
            )
        return CheckResult("Cloudflare KV audit", "PASS",
                           f"{len(keys)} KV key(s) — all expected patterns. ✅")
    except Exception as e:
        return CheckResult("Cloudflare KV audit", "ERROR", str(e))


def run_all() -> List[CheckResult]:
    return [
        check_env_file(),
        check_github_recent_commits_for_secrets(),
        check_cloudflare_kv_keys(),
    ]
