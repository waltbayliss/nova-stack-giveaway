"""
infrastructure_health.py — walts-wiki GitHub health, LaunchAgents,
Cloudflare Worker health, GDrive pipeline.
No Obsidian dependency — checks replaced with walts-wiki GitHub API check.
"""
import subprocess
import requests
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import List
from dataclasses import dataclass

from config import (
    GITHUB_HEADERS, WALTS_WIKI_REPO,
    CF_API_TOKEN, CF_ACCOUNT_ID, BRIEF_KV_NAMESPACE_ID,
    TELEGRAM_BOT_TOKEN, GDRIVE_UPLOAD_PATH, GDRIVE_DONE_PATH,
    BRIEF_NOT_SENT_HOURS, VIDEO_STUCK_HOURS
)


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str
    fix_applied: str = ""
    action_required: str = ""


LAUNCH_AGENTS = [
    ("com.walt.agent-video-editor", "agent-video-editor"),
    ("com.walt.agent-auditor", "agent-auditor"),
]


def check_walts_wiki_github() -> CheckResult:
    """Verify walts-wiki GitHub repo is accessible and master-context.md exists."""
    try:
        r = requests.get(
            f"https://api.github.com/repos/{WALTS_WIKI_REPO}/contents/Walt%27s%20Wiki%2FMaster%20Wiki%2Fmaster-context.md",
            headers=GITHUB_HEADERS,
            timeout=10
        )
        if r.ok:
            data = r.json()
            size = data.get("size", 0)
            return CheckResult(
                "walts-wiki GitHub", "PASS",
                f"walts-wiki accessible. master-context.md exists ({size} bytes). ✅"
            )
        return CheckResult(
            "walts-wiki GitHub", "FLAG",
            f"walts-wiki API returned {r.status_code} — repo or file may be missing.",
            action_required="Check github.com/waltbayliss/walts-wiki — verify master-context.md exists."
        )
    except Exception as e:
        return CheckResult(
            "walts-wiki GitHub", "FLAG",
            f"walts-wiki GitHub unreachable: {e}",
            action_required="Check GITHUB_PERSONAL_ACCESS_TOKEN in .env and network connectivity."
        )


def check_launch_agents() -> List[CheckResult]:
    results = []
    try:
        proc = subprocess.run(
            ["launchctl", "list"],
            capture_output=True, text=True, timeout=10
        )
        loaded = proc.stdout
    except Exception as e:
        return [CheckResult("LaunchAgent check", "ERROR", str(e))]

    for agent_id, agent_name in LAUNCH_AGENTS:
        if agent_id in loaded:
            results.append(CheckResult(
                f"LaunchAgent: {agent_name}", "PASS",
                f"{agent_id} is loaded and running. ✅"
            ))
        else:
            plist_path = Path.home() / "Library" / "LaunchAgents" / f"{agent_id}.plist"
            if plist_path.exists():
                action = f"launchctl load {plist_path}"
            else:
                action = f"LaunchAgent plist not found. Re-install {agent_name}."
            results.append(CheckResult(
                f"LaunchAgent: {agent_name}", "FLAG",
                f"{agent_id} is NOT loaded.",
                action_required=action
            ))
    return results


def check_daily_brief_sent() -> CheckResult:
    """Check Cloudflare KV for today's brief_sent key."""
    if not CF_API_TOKEN or not CF_ACCOUNT_ID:
        return CheckResult("daily brief sent", "FLAG",
                           "CF_API_TOKEN or CF_ACCOUNT_ID not set — cannot check KV.",
                           action_required="Add CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID to .env")
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    url = (f"https://api.cloudflare.com/client/v4/accounts/{CF_ACCOUNT_ID}"
           f"/storage/kv/namespaces/{BRIEF_KV_NAMESPACE_ID}/values/brief_sent_{today}")
    try:
        r = requests.get(url, headers={"Authorization": f"Bearer {CF_API_TOKEN}"}, timeout=10)
        if r.ok and r.text.strip():
            return CheckResult("daily brief sent", "PASS",
                               f"Daily brief confirmed sent for {today}. ✅")
        return CheckResult("daily brief sent", "FLAG",
                           f"No brief_sent_{today} key in KV — brief may not have fired.",
                           action_required="Check agent-daily-brief Worker logs in Cloudflare dashboard.")
    except Exception as e:
        return CheckResult("daily brief sent", "ERROR", str(e))


def check_nova_telegram_worker() -> CheckResult:
    """Ping nova-telegram Worker health endpoint."""
    try:
        r = requests.get("https://nova-telegram.waltbayliss.workers.dev", timeout=10)
        if r.ok:
            return CheckResult("nova-telegram Worker", "PASS",
                               "nova-telegram Worker responding. ✅")
        return CheckResult("nova-telegram Worker", "FLAG",
                           f"nova-telegram returned {r.status_code}.",
                           action_required="Check Cloudflare dashboard for worker errors.")
    except Exception as e:
        return CheckResult("nova-telegram Worker", "FLAG",
                           f"nova-telegram unreachable: {e}",
                           action_required="Check Cloudflare Workers dashboard.")


def check_content_pipeline() -> List[CheckResult]:
    results = []

    # /upload stuck check
    if GDRIVE_UPLOAD_PATH and GDRIVE_UPLOAD_PATH.exists():
        now = datetime.now(timezone.utc)
        stuck = []
        for f in GDRIVE_UPLOAD_PATH.iterdir():
            if f.is_file() and f.suffix.lower() in (".mp4", ".mov", ".avi", ".mkv"):
                age_hours = (now - datetime.fromtimestamp(f.stat().st_mtime, tz=timezone.utc)).total_seconds() / 3600
                if age_hours > VIDEO_STUCK_HOURS:
                    stuck.append(f"{f.name} ({age_hours:.0f}h)")
        if stuck:
            results.append(CheckResult(
                "content pipeline — upload stuck", "FLAG",
                f"{len(stuck)} video(s) stuck in /upload: {', '.join(stuck)}",
                action_required="Check agent-video-editor LaunchAgent: launchctl list | grep video-editor"
            ))
        else:
            results.append(CheckResult(
                "content pipeline — upload folder", "PASS",
                "No videos stuck in /upload. ✅"
            ))
    else:
        results.append(CheckResult(
            "content pipeline — upload folder", "FLAG",
            "GDRIVE_UPLOAD_PATH not configured or does not exist.",
            action_required="Set GDRIVE_UPLOAD_PATH in .env"
        ))

    return results


def run_all() -> List[CheckResult]:
    results = [
        check_walts_wiki_github(),
        check_daily_brief_sent(),
        check_nova_telegram_worker(),
    ]
    results.extend(check_launch_agents())
    results.extend(check_content_pipeline())
    return results
