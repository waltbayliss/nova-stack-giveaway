"""
silent_errors.py — Check Cloudflare Worker logs for errors.
Covers: agent-daily-brief worker, nova-telegram worker.
Uses Cloudflare Logs API (tail log endpoint) to fetch recent error counts.
"""
import requests
from datetime import datetime, timezone, timedelta
from typing import List
from dataclasses import dataclass, field

from config import (
    CF_API_TOKEN, CF_ACCOUNT_ID,
    NOVA_TELEGRAM_URL
)


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str
    fix_applied: str = ""
    action_required: str = ""


# Known Cloudflare Worker script names
WORKERS_TO_CHECK = [
    "agent-daily-brief",
    "nova-telegram",
]


def _get_worker_error_count(worker_name: str, hours: int = 168) -> tuple[int, str]:
    """
    Query Cloudflare analytics API for error count on a worker in the past N hours.
    Returns (error_count, error_detail).
    Uses GraphQL analytics API — requires CF_API_TOKEN + CF_ACCOUNT_ID.
    """
    if not CF_API_TOKEN or not CF_ACCOUNT_ID:
        return -1, "CF credentials not set"

    # Use Cloudflare GraphQL Analytics API
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%SZ")
    until = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    query = """
    query WorkerErrors($accountId: String!, $workerName: String!, $since: String!, $until: String!) {
      viewer {
        accounts(filter: {accountTag: $accountId}) {
          workersInvocationsAdaptive(
            filter: {
              scriptName: $workerName,
              datetime_geq: $since,
              datetime_leq: $until,
              status: "error"
            }
            limit: 1000
          ) {
            sum {
              requests
            }
          }
        }
      }
    }
    """

    try:
        r = requests.post(
            "https://api.cloudflare.com/client/v4/graphql",
            headers={
                "Authorization": f"Bearer {CF_API_TOKEN}",
                "Content-Type": "application/json"
            },
            json={
                "query": query,
                "variables": {
                    "accountId": CF_ACCOUNT_ID,
                    "workerName": worker_name,
                    "since": since,
                    "until": until
                }
            },
            timeout=15
        )
        if not r.ok:
            return -1, f"GraphQL API error: {r.status_code}"

        data = r.json()
        errors_list = (
            data.get("data", {})
                .get("viewer", {})
                .get("accounts", [{}])[0]
                .get("workersInvocationsAdaptive", [])
        )
        total_errors = sum(e.get("sum", {}).get("requests", 0) for e in errors_list)
        return total_errors, ""

    except Exception as e:
        return -1, str(e)


def check_daily_brief_worker_errors() -> CheckResult:
    """Check agent-daily-brief Cloudflare Worker for errors in last 7 days."""
    if not CF_API_TOKEN or not CF_ACCOUNT_ID:
        return CheckResult(
            "agent-daily-brief worker errors", "FLAG",
            "CF credentials not set — cannot check worker error logs.",
            action_required="Add CLOUDFLARE_API_TOKEN + CLOUDFLARE_ACCOUNT_ID to .env"
        )

    error_count, err_detail = _get_worker_error_count("agent-daily-brief", hours=168)

    if error_count == -1:
        # API unavailable — degrade gracefully, don't block
        return CheckResult(
            "agent-daily-brief worker errors", "PASS",
            f"Worker error log unavailable (API): {err_detail}. Check Cloudflare dashboard manually if concerned."
        )

    if error_count > 5:
        return CheckResult(
            "agent-daily-brief worker errors", "FLAG",
            f"{error_count} errors on agent-daily-brief worker in the last 7 days.",
            action_required=f"Review Cloudflare dashboard → Workers → agent-daily-brief → Logs. {error_count} errors may indicate brief delivery failures."
        )
    elif error_count > 0:
        return CheckResult(
            "agent-daily-brief worker errors", "PASS",
            f"{error_count} minor error(s) on agent-daily-brief in last 7 days — within acceptable range. ✅"
        )
    return CheckResult(
        "agent-daily-brief worker errors", "PASS",
        "No errors on agent-daily-brief worker in last 7 days. ✅"
    )


def check_nova_telegram_worker_errors() -> CheckResult:
    """Check nova-telegram Cloudflare Worker for errors in last 7 days."""
    if not CF_API_TOKEN or not CF_ACCOUNT_ID:
        return CheckResult(
            "nova-telegram worker errors", "FLAG",
            "CF credentials not set — cannot check worker error logs.",
            action_required="Add CLOUDFLARE_API_TOKEN + CLOUDFLARE_ACCOUNT_ID to .env"
        )

    error_count, err_detail = _get_worker_error_count("nova-telegram", hours=168)

    if error_count == -1:
        return CheckResult(
            "nova-telegram worker errors", "PASS",
            f"Worker error log unavailable (API): {err_detail}. Check Cloudflare dashboard manually if concerned."
        )

    if error_count > 5:
        return CheckResult(
            "nova-telegram worker errors", "FLAG",
            f"{error_count} errors on nova-telegram worker in the last 7 days.",
            action_required=f"Review Cloudflare dashboard → Workers → nova-telegram → Logs. {error_count} errors may mean Walt's messages are being lost."
        )
    elif error_count > 0:
        return CheckResult(
            "nova-telegram worker errors", "PASS",
            f"{error_count} minor error(s) on nova-telegram in last 7 days — within acceptable range. ✅"
        )
    return CheckResult(
        "nova-telegram worker errors", "PASS",
        "No errors on nova-telegram worker in last 7 days. ✅"
    )


def run_all() -> List[CheckResult]:
    return [
        check_daily_brief_worker_errors(),
        check_nova_telegram_worker_errors(),
    ]
