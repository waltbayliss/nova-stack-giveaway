"""
agent_scanner.py — Scan ALL agent folders in my-ai-team/, check 9-doc compliance,
identify unregistered agents, detect missing wiki-write steps.
"""
import re
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Tuple

from config import (
    MY_AI_TEAM_PATH, REQUIRED_DOCS, REQUIRED_WIKI_DIRS,
    REQUIRED_WIKI_MASTER, EXEMPT_FOLDERS
)


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str
    fix_applied: str = ""
    action_required: str = ""


@dataclass
class AgentAudit:
    folder_name: str
    path: Path
    missing_docs: List[str] = field(default_factory=list)
    missing_wiki_dirs: List[str] = field(default_factory=list)
    missing_wiki_master: bool = False
    missing_wiki_write: bool = False
    has_claude_md: bool = False
    github_repo: str = ""


def _is_agent_folder(path: Path) -> bool:
    """A folder is an agent if it contains CLAUDE.md."""
    return (path / "CLAUDE.md").exists()


def _has_wiki_write(claude_md_path: Path) -> bool:
    """Check if CLAUDE.md mentions a wiki-write step."""
    try:
        content = claude_md_path.read_text(encoding="utf-8", errors="ignore")
        patterns = ["wiki", "Walt's Wiki", "walts-wiki", "wiki-write", "wiki write", "walts-wiki GitHub"]
        return any(p.lower() in content.lower() for p in patterns)
    except Exception:
        return False


def _infer_github_repo(folder_name: str) -> str:
    """Infer the expected GitHub repo name."""
    return f"waltbayliss/{folder_name}"


def scan_agent_folders() -> List[AgentAudit]:
    """Scan all subfolders of MY_AI_TEAM_PATH and audit each agent."""
    audits = []
    if not MY_AI_TEAM_PATH.exists():
        return audits

    for item in sorted(MY_AI_TEAM_PATH.iterdir()):
        if not item.is_dir():
            continue
        if item.name.startswith(".") or item.name in EXEMPT_FOLDERS:
            continue
        if not _is_agent_folder(item):
            continue

        audit = AgentAudit(
            folder_name=item.name,
            path=item,
            has_claude_md=True,
            github_repo=_infer_github_repo(item.name),
        )

        # Check required docs
        for doc in REQUIRED_DOCS:
            if not (item / doc).exists():
                audit.missing_docs.append(doc)

        # Check wiki dirs
        for wiki_dir in REQUIRED_WIKI_DIRS:
            if not (item / wiki_dir).exists():
                audit.missing_wiki_dirs.append(wiki_dir)

        # Check wiki master-context
        if not (item / REQUIRED_WIKI_MASTER).exists():
            audit.missing_wiki_master = True

        # Check wiki-write in CLAUDE.md
        audit.missing_wiki_write = not _has_wiki_write(item / "CLAUDE.md")

        audits.append(audit)

    return audits


def check_agent_doc_compliance(audits: List[AgentAudit]) -> List[CheckResult]:
    results = []
    for audit in audits:
        issues = []
        if audit.missing_docs:
            issues.append(f"Missing docs: {', '.join(audit.missing_docs)}")
        if audit.missing_wiki_dirs:
            issues.append(f"Missing wiki dirs: {', '.join(audit.missing_wiki_dirs)}")
        if audit.missing_wiki_master:
            issues.append("Missing wiki/Master/master-context.md")
        if audit.missing_wiki_write:
            issues.append("No wiki-write step in CLAUDE.md")

        if issues:
            results.append(CheckResult(
                name=f"{audit.folder_name} — 9-doc compliance",
                status="FLAG",
                detail=f"{audit.folder_name}: {'; '.join(issues)}",
                action_required=f"Auto-fix queued for {audit.folder_name}."
            ))
        else:
            results.append(CheckResult(
                name=f"{audit.folder_name} — 9-doc compliance",
                status="PASS",
                detail=f"{audit.folder_name}: fully compliant ✅"
            ))
    return results


def check_against_registry() -> Tuple[List[str], List[str]]:
    """
    Compare scanned folders against AGENT-REGISTRY.md.
    Returns (unregistered_agents, registered_but_missing).
    """
    registry_path = MY_AI_TEAM_PATH / "nova-assistant" / "docs" / "AGENT-REGISTRY.md"
    if not registry_path.exists():
        return [], []

    registry_content = registry_path.read_text(encoding="utf-8", errors="ignore")
    # Extract agent names mentioned in registry
    registered = set(re.findall(r'\|\s*(agent-[\w-]+|nova[\w-]*|[\w]+-agent)\s*\|', registry_content))

    on_disk = {
        item.name for item in MY_AI_TEAM_PATH.iterdir()
        if item.is_dir() and _is_agent_folder(item) and item.name not in EXEMPT_FOLDERS
    }

    unregistered = sorted(on_disk - registered - {"agent-auditor"})  # auditor registers itself
    registered_missing = sorted(registered - on_disk)

    return unregistered, registered_missing


def run_all() -> List[CheckResult]:
    results = []

    audits = scan_agent_folders()
    if not audits:
        results.append(CheckResult(
            "agent folder scan", "FLAG",
            f"No agent folders found at {MY_AI_TEAM_PATH}",
            action_required="Verify MY_AI_TEAM_PATH in .env"
        ))
        return results

    results.append(CheckResult(
        "agent folder scan", "PASS",
        f"Found {len(audits)} agent folder(s): {', '.join(a.folder_name for a in audits)}"
    ))

    results.extend(check_agent_doc_compliance(audits))

    unregistered, missing = check_against_registry()
    if unregistered:
        results.append(CheckResult(
            "registry sync — unregistered agents",
            "FLAG",
            f"On disk but not in AGENT-REGISTRY: {', '.join(unregistered)}",
            action_required="Auto-fix will add these to AGENT-REGISTRY."
        ))
    if missing:
        results.append(CheckResult(
            "registry sync — missing agents",
            "FLAG",
            f"In AGENT-REGISTRY but not found on disk: {', '.join(missing)}",
            action_required="Verify agent paths or remove from registry."
        ))
    if not unregistered and not missing:
        results.append(CheckResult(
            "registry sync", "PASS",
            "AGENT-REGISTRY matches disk exactly. ✅"
        ))

    return results
