*(Real content removed for public distribution — master-context.md exists here to show the wiki folder structure this agent writes to, not its actual captured history.)*
