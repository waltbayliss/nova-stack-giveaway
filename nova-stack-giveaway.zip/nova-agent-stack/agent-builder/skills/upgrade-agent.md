# Skill: Upgrade Agent

**Trigger:** Existing thin agent needs to be brought to Nova standard.

---

## Step 1 — Audit
Read all existing files. Map against Nova Standard Structure. Build gap list.

## Step 2 — Generate Missing Files
- Source of truth: existing CLAUDE.md
- Generate all missing docs with agent-specific content
- Do NOT overwrite existing files

## Step 3 — Push to GitHub
- If repo exists: push only new files
- If no repo: create (private) then push everything
- Commit: `feat: upgrade [agent-name] to Nova standard — added [list]`

## Step 4 — Update Registry
Add/update entry in Nova's `AGENT-REGISTRY.md`.

## Step 5 — Report
```
Upgrade complete: agent-[name]
Already existed: [list]
Added: [list]
GitHub: github.com/waltbayliss/agent-[name]
Registry: updated
Watch: [anything needing Walt's attention]
```
