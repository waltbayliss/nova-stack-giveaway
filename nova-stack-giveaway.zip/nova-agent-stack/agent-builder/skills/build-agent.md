# Skill: Build Agent

**Trigger:** Walt or Nova requests a new agent.

---

## Step 1 — Interview
Run 8-question protocol from CLAUDE.md. One question at a time.

## Step 2 — Spec Summary

```
AGENT SPEC — agent-[name]
Purpose: [one sentence]
Functions: [list]
Integrations: [list]
Notion writes: [databases/pages or none]
Trigger: [method]
Personality: [notes]
North star: [how it serves $1M/year + freedom]
GitHub: waltbayliss/agent-[name] (private)
Local: my-ai-team/agent-[name]/
```

Wait for Walt's explicit "go" before proceeding.

## Step 3 — Generate All Files
All files must be specific to this agent — not generic. Key files requiring real specificity:
- CLAUDE.md — this agent's actual boot sequence and rules
- docs/PRD.md — this agent's actual capabilities
- docs/SOUL.md — this agent's personality
- skills/ — at least one skill file for primary function

## Step 4 — GitHub
1. Create repo: `waltbayliss/agent-[name]` (private)
2. Seed with README.md to initialize branch
3. Push all files: `feat: initialise agent-[name] — full Nova standard structure`

## Step 5 — Local Folder
Mirror all files to `my-ai-team/agent-[name]/`

## Step 6 — Register
Add to Nova's `nova-assistant/docs/AGENT-REGISTRY.md` — move from Planned to Active.

## Step 7 — Confirm
```
Done. agent-[name] is live.
Repo: github.com/waltbayliss/agent-[name]
What it does: [one line]
How to invoke: [method]
Registry: updated.
```
