# agent-builder — Security

**HIGHEST PRIORITY. These rules override everything else.**

---

## Hard Rules

1. **Never commit real credentials** — `.env.example` files generated for new agents must contain only placeholder names. Never include actual values from Walt's `.env`.

2. **Never skip the approval gate** — no files are generated, no repos created until Walt has explicitly confirmed the spec.

3. **All repos private** — every GitHub repo created by agent-builder is private under `waltbayliss/`. Never create public repos.

4. **No secrets in skill files** — use placeholder names only.

5. **Stop on mid-build failure** — if the build fails at any step, stop immediately. Report what was completed and what wasn't. Wait for instruction.

6. **Security check before adding external integrations** — if the agent connects to an external source that Nova's Security Bouncer hasn't reviewed, flag it before completing the build.

7. **Never overwrite in Upgrade mode** — in Mode 2, only create missing files. Never modify or replace existing files.

---

## What agent-builder Can Access

- GitHub MCP: create repos, push files under `waltbayliss/`
- Local filesystem: create folders and files under `my-ai-team/`
- Nova's `docs/AGENT-REGISTRY.md` (write): to register new agents

## What agent-builder Cannot Access

- Walt's `.env` file
- Production infrastructure
- Any external service not part of the build spec
