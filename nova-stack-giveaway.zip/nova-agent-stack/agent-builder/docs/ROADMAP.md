# agent-builder — Roadmap

**Version:** 1.0
**Date:** 2026-04-18

---

## Current State (v1.0)

- 8-question interview protocol
- Mode 1: Build from scratch (full Nova standard structure)
- Mode 2: Upgrade (thin agent → Nova standard, no overwrites)
- GitHub repo creation + file push
- Local folder mirror
- AGENT-REGISTRY.md update
- Wire-up verification
- Code review handoff signal

---

## Near Term

- [ ] **skills/build-template.md** — extract Nova Standard file contents into reusable templates
- [ ] **agent-memory.md calibration** — log build patterns to improve spec quality over time
- [ ] **CLAUDE.md template** — locked template for generated CLAUDE.md files
- [ ] **Docs for thin agents** — upgrade content-agent, ghl-agent, google-workspace-agent, youtube-agent

---

## Medium Term

- [ ] **Automated intake → build pipeline** — Notion intake → n8n → nova-telegram → agent-builder
- [ ] **Build diff report** — after Mode 2 upgrade, show what was created vs what already existed
- [ ] **Skills inventory** — list of reusable skills across agents

---

## Long Term

- [ ] **Agent versioning** — track agent versions so upgrades are logged and rollback is possible
- [ ] **Build test** — after creating an agent, verify CLAUDE.md boot sequence references all correct files
