# agent-builder — Architecture

**Version:** 1.0
**Date:** 2026-04-18

---

## System Overview

agent-builder is a pure Claude Code agent — no server, no cron, no worker. It runs in a Claude Code session inside the `agent-builder/` directory and uses GitHub MCP to create repos and push files.

```
Nova / Walt
  │
  ▼
agent-builder (Claude Code session)
  │
  ├── GitHub MCP → create repo, push all files
  ├── Filesystem → create local folder mirror
  └── AGENT-REGISTRY.md → update nova-assistant
```

---

## Runtime

- **Interface:** Claude Code (local), invoked from `my-ai-team/agent-builder/`
- **Trigger:** Nova routing / Walt direct command
- **No persistent process** — session-based

---

## Nova Standard Structure (what agent-builder produces)

```
agent-[name]/
├── CLAUDE.md
├── README.md
├── agent-memory.md
├── .env.example
├── docs/
│   ├── PRD.md
│   ├── ARCHITECTURE.md
│   ├── SOUL.md
│   ├── SECURITY.md
│   ├── ROADMAP.md
│   ├── DECISIONS.md
│   └── SPRINT_LOG.md
├── skills/
│   └── [agent-specific skill files]
└── wiki/
    ├── Raw/
    ├── Wiki/
    ├── Output/
    └── Master/
        └── master-context.md
```

---

## Integrations

| Service | Purpose | How |
|---------|---------|-----|
| GitHub MCP | Create private repo, push all files | `mcp__github__create_repository`, `mcp__github__push_files` |
| Filesystem | Create local folder mirror | Write tool |
| Nova AGENT-REGISTRY.md | Register new/upgraded agent | GitHub MCP write |

---

## Build Flow (Mode 1)

```
1. 8-question interview (one at a time)
2. Full spec summary → Walt approval
3. Generate all file contents
4. Create GitHub repo: waltbayliss/agent-[name]
5. Push all files in one commit
6. Create local folder: my-ai-team/agent-[name]/
7. Update nova-assistant/docs/AGENT-REGISTRY.md
8. Wire-up verification
9. Signal to Nova: "Route to agent-code-reviewer — Pass 1"
10. Report to Walt: repo link + invocation method
```

---

## Architectural Principles

1. **Interview before building** — never generate files before Walt approves the spec
2. **Complete or nothing** — partial builds are not shipped
3. **GitHub-primary** — repo is the source of truth; local folder mirrors it
4. **Registry always updated** — no agent exists outside the registry
5. **Code review always triggered** — no agent is "done" without a review pass signal
