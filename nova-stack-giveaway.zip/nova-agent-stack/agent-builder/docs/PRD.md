# agent-builder — Product Requirements Document

**Version:** 1.0
**Date:** 2026-04-18
**Owner:** Walt Bayliss
**Status:** Active

---

## Overview

agent-builder is the construction engine of Walt's AI agent team. When a new agent is needed, Nova calls agent-builder. It interviews Walt, generates a complete spec, builds the full Nova-standard agent structure, pushes to GitHub, creates the local folder, and hands off to agent-code-reviewer. Every agent that comes out of it is complete, documented, and ready to work from day one.

---

## Target User

**Nova** — who routes new agent builds and upgrade requests here.
**Walt** — who can invoke it directly for new builds or upgrades.

---

## Core Problem

Building agents ad-hoc produces incomplete, inconsistent results. Without a structured build process, agents end up missing docs, unregistered, poorly scoped, or wired incorrectly. agent-builder solves this by enforcing a complete, repeatable process — the same every time, no exceptions.

---

## Feature Set

### Feature 1: Mode 1 — Build (new agent from scratch)
- 8-question interview, one question at a time
- Full spec summary for Walt's approval before any building begins
- Generates all files: CLAUDE.md, README.md, agent-memory.md, .env.example, 7 docs, skills/, wiki/
- Creates GitHub repo: `waltbayliss/agent-[name]` (private)
- Creates local folder: `my-ai-team/agent-[name]/`
- Updates Nova's AGENT-REGISTRY.md
- Signals code review to Nova on completion

### Feature 2: Mode 2 — Upgrade (thin agent → Nova standard)
- Audits existing agent against Nova Standard Structure
- Generates all missing docs without overwriting existing files
- Pushes complete structure to GitHub
- Updates Nova's AGENT-REGISTRY.md
- Reports: what existed, what was created, what to watch

### Feature 3: Full Wire-Up Check
Before declaring any build complete, verifies:
- Agent is listed in AGENT-REGISTRY.md with status `active`
- Nova's CLAUDE.md routing references the agent
- `.env.example` lists every required variable
- Local folder mirrors GitHub exactly

### Feature 4: Code Review Handoff
Every build ends with a signal to Nova: "Build complete. Route [agent-name] to agent-code-reviewer for Pass 1." A build is not complete without this signal.

---

## Out of Scope
- agent-builder does not deploy Cloudflare Workers or run infrastructure
- It does not execute the agents it builds
- It does not manage credentials (only .env.example placeholders)
- It does not run code review — that is agent-code-reviewer's job
