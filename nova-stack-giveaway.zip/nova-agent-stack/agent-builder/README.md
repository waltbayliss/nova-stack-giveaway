# Agent Builder

The construction engine for Walt's AI team. Builds new agents to the Nova standard — reliably, completely, every time.

---

## What It Does

- **Builds** new agents via structured interview → full 8-doc structure → GitHub repo → Nova registration
- **Upgrades** existing thin agents to Nova standard
- **Maintains** the quality bar across the entire AI team

---

## How to Invoke

### Via Nova (primary)
Tell Nova you need a new agent. Nova routes the request here.

### Standalone
```bash
cd my-ai-team/agent-builder
claude
```
Then say: "Build mode" (new agent) or "Upgrade mode" (existing agent).

---

## Output — Every Build Produces

- Private GitHub repo: `waltbayliss/agent-[name]`
- Local folder: `my-ai-team/agent-[name]/`
- All 8 docs + CLAUDE.md + README + memory + skills + wiki
- Entry in Nova's `AGENT-REGISTRY.md`
- Confirmation to Walt with repo link

---

## The 8 Required Docs

| Doc | Purpose |
|-----|---------|
| PRD.md | What the agent is and does |
| ARCHITECTURE.md | How it's structured and connected |
| SOUL.md | Personality, purpose, voice |
| SECURITY.md | Hard rules — overrides everything |
| ROADMAP.md | What's being built and when |
| DECISIONS.md | Key decisions log |
| SPRINT_LOG.md | Session-by-session progress |
| AGENT-REGISTRY entry | Registered with Nova |

---

*Built by Nova | Walt Bayliss AI Team | 2026*
