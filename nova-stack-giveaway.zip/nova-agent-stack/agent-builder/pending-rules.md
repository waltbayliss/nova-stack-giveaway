# pending-rules.md

*(Real entries removed for public distribution. This file exists in the real structure as the queue of proposed CLAUDE.md rule changes awaiting approval — the shape is real, the history in it is not.)*
