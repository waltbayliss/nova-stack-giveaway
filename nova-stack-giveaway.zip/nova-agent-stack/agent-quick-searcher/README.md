# agent-quick-searcher

Pre-build research engine for Walt's AI team. Searches GitHub and Perplexity before every new agent build — so every build starts from the best available base in the world, not from zero.

## What It Does

- Searches GitHub (Search API) + Perplexity for existing implementations matching the agent brief
- Assesses quality of each find (1–5 score with reasoning)
- Surfaces specific suggestions: use as-is, adapt, or mine for ideas
- Routes viable repos to agent-security for vetting
- Logs all findings to Walt's Wiki for future reference

## Trigger

Nova routes automatically before every new agent build. Walt can also trigger directly.

## Integrations

- GitHub Search API (`api.github.com/search/repositories`)
- Perplexity API
- agent-security (vetting gate)
- walts-wiki GitHub (findings log)

## Part of Walt's AI Team

Managed by Nova. See `my-ai-team/` for the full stack.
