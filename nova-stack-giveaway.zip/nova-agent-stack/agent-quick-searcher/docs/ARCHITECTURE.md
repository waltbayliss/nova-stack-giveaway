# agent-quick-searcher — Architecture

## Stack

| Layer | Technology |
|-------|----------|
| Runtime | Python 3.9+ |
| GitHub search | GitHub REST API v3 (`requests`) |
| Perplexity search | Perplexity API (`requests`) |
| Synthesis | Pure Python (no LLM required — rule-based scoring) |
| CLI | `argparse` — `python3 src/cli.py --name X --purpose Y` |
| Wiki write | GitHub MCP tool (`mcp__github__create_or_update_file`) |
| Env | Shared `.env` at `my-ai-team/.env` — loaded via `python-dotenv` |

---

## File Structure

```
agent-quick-searcher/
├── CLAUDE.md                  ← Boot sequence + operating rules
├── agent-memory.md            ← Learnings + search patterns
├── .env.example               ← Required env vars
├── docs/
│   ├── SECURITY.md            ← Hard rules (loaded first)
│   ├── PRD.md                 ← What this agent does
│   ├── ARCHITECTURE.md        ← This file
│   ├── SOUL.md                ← Personality + purpose
│   ├── SPRINT_LOG.md          ← Session history
│   ├── DECISIONS.md           ← Code review findings
│   └── ROADMAP.md             ← Planned improvements
├── skills/
│   ├── github-search.md       ← GitHub Search API patterns
│   └── perplexity-search.md   ← Perplexity query patterns
├── src/
│   ├── __init__.py
│   ├── github_search.py       ← GitHub Search API wrapper
│   ├── perplexity_search.py   ← Perplexity API wrapper
│   ├── synthesiser.py         ← Combine + score + recommend
│   └── cli.py                 ← Entry point
└── wiki/
    ├── Raw/                   ← Raw search outputs
    ├── Wiki/                  ← Processed/formatted
    ├── Output/                ← Final reports
    └── Master/                ← Reference library
```

---

## Data Flow

```
Nova: "quick-search agent-seo-writer — reads transcript → SEO package"
          ↓
    cli.py --name agent-seo-writer --purpose "reads transcript → SEO package"
          ↓
    github_search.py  ←→  api.github.com/search/repositories
          ↓
    perplexity_search.py  ←→  api.perplexity.ai/chat/completions
          ↓
    synthesiser.py (combine + score + recommend)
          ↓
    wiki_write (→ walts-wiki GitHub)
          ↓
    findings report → Nova (stdout / returned string)
          ↓
    [if HIGH RELEVANCE] → Nova flags to agent-security
```

---

## GitHub Search Strategy

Keywords derived from agent name + purpose:
- Strip "agent-" prefix
- Split on hyphens + spaces
- Combine: `[keyword1] [keyword2] agent python` 
- Secondary: `AI [keyword] automation`

Sort by: stars DESC. Limit: 10 results.

HIGH RELEVANCE threshold: `stars >= 100 AND pushed_at within 180 days`

---

## Perplexity Query Template

```
"What existing open-source implementations exist for [purpose]? 
Include GitHub repos, PyPI packages, or CLI tools. 
Focus on: what they do well, common pitfalls, and key features.
Be specific — name actual repos and tools, not generalities."
```

Model: `sonar` (fast, web-grounded, low cost)

---

## Environment Variables

Loaded from shared `.env` at `my-ai-team/.env`:

```
GITHUB_PERSONAL_ACCESS_TOKEN=...
PERPLEXITY_API_KEY=...
```

---

## Invocation

```bash
cd my-ai-team/agent-quick-searcher
python3 src/cli.py --name "agent-seo-writer" --purpose "reads transcript, outputs SEO title/description/tags"
```

Returns structured markdown report to stdout.

---

## Error Handling

| Scenario | Behaviour |
|----------|----------|
| GitHub API rate limit | Wait 60s, retry once. If still failing, continue with Perplexity only. |
| Perplexity API error | Continue with GitHub only. Note in report. |
| Zero GitHub results | Report "No matches on GitHub" — not an error. |
| Zero Perplexity results | Report "No Perplexity matches" — not an error. |
| Both fail | Report error to Nova. Do not block the build. |
