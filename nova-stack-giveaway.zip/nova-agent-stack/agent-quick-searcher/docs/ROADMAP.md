# agent-quick-searcher — Roadmap

## v1.0 — Live (2026-04-26)

- GitHub Search API (top 10 repos, HIGH RELEVANCE flagging)
- Perplexity sonar search
- Rule-based synthesis + scoring
- Wiki-write to walts-wiki Agent Research/Raw/
- CLI: `python3 src/cli.py --name X --purpose Y`

---

## v1.1 — Next

- [ ] Add npm/PyPI search alongside GitHub (for non-repo packages)
- [ ] Cache search results locally (avoid repeat API calls for same agent name)
- [ ] Telegram notification to Walt when HIGH RELEVANCE repos found

---

## v1.2 — Future

- [ ] Agent-builder integration: auto-call quick-search as Step 1 of build interview
- [ ] Historical comparison: "we searched this before — here's what changed"
- [ ] Starred repo tracking: maintain a curated shortlist of useful found repos

---

## Won't Do

- Code extraction from found repos (security + scope)
- Auto-install or auto-adapt found repos (agent-security gate is mandatory)
- LLM-powered synthesis (rule-based is faster and cheaper for this task)
