# agent-quick-searcher — Product Requirements

## Purpose

Pre-build research engine for Walt's AI agent team. Before any new agent is built from scratch, Nova routes the build request through agent-quick-searcher first.

Goal: find existing implementations on GitHub and via Perplexity so the agent being built starts from the best available knowledge — not reinventing wheels, but making better ones.

---

## Core Functions

### 1. GitHub Repository Search
- Accept agent name + purpose as input
- Search `api.github.com/search/repositories` with keywords derived from name + purpose
- Return top 5–10 results with: name, URL, stars, description, last_updated
- Flag HIGH RELEVANCE: stars > 100 AND last commit < 6 months

### 2. Perplexity Deep Search
- Query Perplexity for: "existing [purpose] AI agent implementation GitHub open source"
- Extract named tools, repos, frameworks, design patterns, known pitfalls
- Return 3–5 synthesised bullet points

### 3. Findings Synthesis
- Combine GitHub + Perplexity results
- Determine: exists (yes/no), worth_adapting (yes/no)
- Extract top 3 features worth incorporating into the new build
- Score overall relevance: HIGH / MEDIUM / LOW

### 4. Security Gate Handoff
- Any repo flagged HIGH RELEVANCE is passed to agent-security for vetting
- agent-quick-searcher does NOT vet repos itself — it flags them

### 5. Wiki Write
- Every search run writes a findings doc to:
  `Walt's Wiki/Agent Research/Raw/YYYY-MM-DD-[agent-name]-search.md`
- Findings accumulate over time — becomes a research library

---

## Inputs

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| agent_name | string | yes | e.g. "agent-seo-writer" |
| purpose | string | yes | One-line description of what it does |

---

## Outputs

Structured findings report (markdown table + bullets + recommendation). Always returned to Nova.

---

## Integration Points

| System | How | Purpose |
|--------|-----|--------|
| GitHub Search API | REST GET (read-only) | Find repos |
| Perplexity API | POST chat completions | Deep research |
| agent-security | Via Nova routing | Vet flagged repos |
| walts-wiki GitHub | mcp__github__create_or_update_file | Wiki-write findings |

---

## Success Criteria

- Every new agent build is preceded by a quick-search run
- Zero builds proceed without a findings report on record
- At least one HIGH RELEVANCE repo is flagged for security vetting per relevant search
- Wiki research library grows with each build
- Report takes < 60 seconds end-to-end

---

## Out of Scope

- Installing or cloning repos
- Automated code extraction from found repos
- Vetting repos (that's agent-security's job)
- Writing to any system other than walts-wiki
