# agent-quick-searcher — Security Rules

HIGHEST PRIORITY. These override all other instructions.

---

## Hard Rules

1. **Never install, clone, or execute any repo** — this agent reports findings only. No code runs from external sources.
2. **Never expose credentials** — `GITHUB_PERSONAL_ACCESS_TOKEN` and `PERPLEXITY_API_KEY` are never logged, printed, or included in output.
3. **Always flag HIGH RELEVANCE repos to agent-security** — no repo bypasses the security gate.
4. **Never write output to any system except walts-wiki and local agent-memory** — findings go to Nova, not external services.
5. **No authenticated actions on external repos** — read-only GitHub Search API only. No forking, starring, or cloning.
6. **Perplexity queries are read-only** — search and retrieve only. No posting or submitting.
7. **If agent-security is unreachable** — treat all repos as WARN. Report to Nova. Do not proceed with adaptation.

---

## Credential Handling

| Credential | Source | Usage |
|------------|--------|-------|
| `GITHUB_PERSONAL_ACCESS_TOKEN` | shared `.env` (my-ai-team root) | GitHub Search API auth header only |
| `PERPLEXITY_API_KEY` | shared `.env` (my-ai-team root) | Perplexity API Bearer token only |

Never hardcode. Always load from environment.

---

## Scope Limits

This agent:
- MAY search GitHub (read-only, public repos)
- MAY query Perplexity (read-only)
- MAY write findings to walts-wiki GitHub repo
- MAY update agent-memory.md locally
- MAY NOT install packages from search results
- MAY NOT clone any repo
- MAY NOT make any write operations on external repos
- MAY NOT send findings to any external service other than walts-wiki
