#!/usr/bin/env python3
"""
agent-quick-searcher CLI

Usage:
    python3 src/cli.py --name "agent-seo-writer" --purpose "reads video transcript, outputs SEO title/description/tags"
"""
import argparse
import os
import sys
from pathlib import Path
from datetime import datetime

# Load .env from shared my-ai-team root
try:
    from dotenv import load_dotenv
    env_path = Path(__file__).resolve().parents[2] / ".env"
    load_dotenv(dotenv_path=env_path)
except ImportError:
    pass

sys.path.insert(0, str(Path(__file__).parent))
import github_search
import perplexity_search
import synthesiser


def main():
    parser = argparse.ArgumentParser(description="Quick search before an agent build")
    parser.add_argument("--name", required=True, help="Agent name, e.g. agent-seo-writer")
    parser.add_argument("--purpose", required=True, help="One-line purpose description")
    parser.add_argument("--no-wiki", action="store_true", help="Skip wiki-write step")
    args = parser.parse_args()

    gh_token = os.environ.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    pplx_key = os.environ.get("PERPLEXITY_API_KEY", "")

    if not gh_token:
        print("WARNING: GITHUB_PERSONAL_ACCESS_TOKEN not set — GitHub search will fail.", file=sys.stderr)
    if not pplx_key:
        print("WARNING: PERPLEXITY_API_KEY not set — Perplexity search will be skipped.", file=sys.stderr)

    print(f"\nSearching for existing implementations of: {args.name}")
    print(f"Purpose: {args.purpose}\n")

    print("→ GitHub search...")
    gh_data = github_search.search(args.name, args.purpose, gh_token) if gh_token else {"results": [], "query": "", "error": "No token"}

    print("→ Perplexity search...")
    pplx_data = perplexity_search.search(args.purpose, pplx_key) if pplx_key else {"content": "", "error": "No API key"}

    print("→ Synthesising...\n")
    synthesis = synthesiser.synthesise(gh_data, pplx_data, args.name)
    report = synthesiser.format_report(synthesis)

    print(report)

    if synthesis["security_flag"]:
        print("\n⚠️  HIGH RELEVANCE repos found — flag these to Nova for agent-security vetting before proceeding.")

    if not args.no_wiki:
        _wiki_write(args.name, report)

    return report


def _wiki_write(agent_name: str, report: str):
    """Write findings to walts-wiki via GitHub API."""
    token = os.environ.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    if not token:
        print("\nSkipping wiki-write — no GitHub token.", file=sys.stderr)
        return

    import requests
    import base64

    date_str = datetime.now().strftime("%Y-%m-%d")
    slug = agent_name.lower().replace(" ", "-")
    path = f"Walt's Wiki/Agent Research/Raw/{date_str}-{slug}-search.md"
    url = f"https://api.github.com/repos/waltbayliss/walts-wiki/contents/{requests.utils.quote(path)}"

    content_b64 = base64.b64encode(report.encode()).decode()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    sha = None
    r = requests.get(url, headers=headers, timeout=10)
    if r.status_code == 200:
        sha = r.json().get("sha")

    payload = {
        "message": f"feat: quick-search findings for {agent_name} ({date_str})",
        "content": content_b64,
    }
    if sha:
        payload["sha"] = sha

    r = requests.put(url, headers=headers, json=payload, timeout=15)
    if r.status_code in (200, 201):
        print(f"\n✓ Wiki write: {path}")
    else:
        print(f"\nWiki write failed: {r.status_code} {r.text[:200]}", file=sys.stderr)


if __name__ == "__main__":
    main()
