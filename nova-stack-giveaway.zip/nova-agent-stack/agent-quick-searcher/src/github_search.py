import os
import time
import requests
from datetime import datetime, timezone


def _relevance(stars: int, pushed_at: str) -> str:
    try:
        pushed = datetime.fromisoformat(pushed_at.replace("Z", "+00:00"))
        days_since = (datetime.now(timezone.utc) - pushed).days
    except Exception:
        days_since = 999
    if stars >= 100 and days_since <= 180:
        return "HIGH"
    if stars >= 20 or days_since <= 365:
        return "MEDIUM"
    return "LOW"


def _build_query(agent_name: str, purpose: str) -> str:
    name_part = agent_name.replace("agent-", "").replace("-", " ")
    purpose_words = [w for w in purpose.split() if len(w) > 4][:3]
    keywords = f"{name_part} {' '.join(purpose_words)} python".strip()
    return keywords


def search(agent_name: str, purpose: str, token: str) -> dict:
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
    }
    query = _build_query(agent_name, purpose)
    params = {"q": query, "sort": "stars", "order": "desc", "per_page": 10}

    for attempt in range(2):
        try:
            r = requests.get(
                "https://api.github.com/search/repositories",
                headers=headers,
                params=params,
                timeout=15,
            )
            if r.status_code in (403, 429) and attempt == 0:
                time.sleep(60)
                continue
            r.raise_for_status()
            items = r.json().get("items", [])
            break
        except Exception as e:
            if attempt == 1:
                return {"error": str(e), "results": [], "query": query}
            time.sleep(5)

    results = []
    for item in items:
        rel = _relevance(item.get("stargazers_count", 0), item.get("pushed_at", ""))
        results.append({
            "name": item["full_name"],
            "url": item["html_url"],
            "stars": item.get("stargazers_count", 0),
            "description": (item.get("description") or "")[:200],
            "last_updated": (item.get("pushed_at") or "")[:10],
            "relevance": rel,
        })

    return {"results": results, "query": query, "total": len(results)}
