from typing import Any


def synthesise(github_data: dict, perplexity_data: dict, agent_name: str) -> dict:
    gh_results = github_data.get("results", [])
    perplexity_text = perplexity_data.get("content", "")

    high_relevance = [r for r in gh_results if r["relevance"] == "HIGH"]
    medium_relevance = [r for r in gh_results if r["relevance"] == "MEDIUM"]

    exists = len(gh_results) > 0 or bool(perplexity_text.strip())
    worth_adapting = len(high_relevance) > 0

    if high_relevance:
        overall_score = "HIGH"
    elif medium_relevance or perplexity_text:
        overall_score = "MEDIUM"
    else:
        overall_score = "LOW"

    security_flag = [r["url"] for r in high_relevance]

    return {
        "agent_name": agent_name,
        "exists": exists,
        "worth_adapting": worth_adapting,
        "overall_score": overall_score,
        "github_results": gh_results,
        "perplexity_summary": perplexity_text,
        "security_flag": security_flag,
        "github_query": github_data.get("query", ""),
        "github_error": github_data.get("error"),
        "perplexity_error": perplexity_data.get("error"),
    }


def format_report(synthesis: dict) -> str:
    s = synthesis
    lines = [
        f"## Quick Search: {s['agent_name']}",
        "",
        f"**Exists:** {'Yes' if s['exists'] else 'No'}",
        f"**Worth adapting:** {'Yes' if s['worth_adapting'] else 'No'}",
        f"**Relevance score:** {s['overall_score']}",
        "",
        "### GitHub Findings",
    ]

    if s.get("github_error"):
        lines.append(f"_GitHub search error: {s['github_error']}_")
    elif not s["github_results"]:
        lines.append("_No matches found on GitHub._")
    else:
        lines.append("| Repo | Stars | Last Active | Relevance | Description |")
        lines.append("|------|-------|-------------|-----------|-------------|")
        for r in s["github_results"]:
            lines.append(
                f"| [{r['name']}]({r['url']}) | {r['stars']} | {r['last_updated']} | {r['relevance']} | {r['description'][:80]} |"
            )

    lines += ["", "### Perplexity Findings"]
    if s.get("perplexity_error"):
        lines.append(f"_Perplexity search error: {s['perplexity_error']}_")
    elif not s["perplexity_summary"]:
        lines.append("_No results returned from Perplexity._")
    else:
        lines.append(s["perplexity_summary"])

    lines += ["", "### Repos Flagged for Security Vetting"]
    if s["security_flag"]:
        for url in s["security_flag"]:
            lines.append(f"- {url} — HIGH RELEVANCE (stars ≥100, active within 180 days)")
    else:
        lines.append("_None — no HIGH RELEVANCE repos found._")

    lines += ["", "### Recommendation"]
    if s["worth_adapting"]:
        lines.append(
            f"HIGH RELEVANCE repos found. Route flagged repos through agent-security before proceeding. "
            f"Review features to incorporate before agent-builder run."
        )
    elif s["exists"]:
        lines.append(
            "Existing implementations found but none meet HIGH RELEVANCE threshold. "
            "Review Perplexity findings for useful patterns, then build from scratch."
        )
    else:
        lines.append(
            "No strong existing implementations found. Build from scratch — clear field."
        )

    return "\n".join(lines)
