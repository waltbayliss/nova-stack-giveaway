import requests


QUERY_TEMPLATE = """What existing open-source implementations exist for: {purpose}?

I'm looking for GitHub repos, Python packages, or CLI tools that do this.
Please include:
1. The actual repo/package name and URL if known
2. What it does well
3. Any known limitations or common issues
4. Key features worth incorporating into a new implementation

Be specific — name actual repos, not general frameworks. Keep the response under 400 words."""


def search(purpose: str, api_key: str) -> dict:
    query = QUERY_TEMPLATE.format(purpose=purpose)
    payload = {
        "model": "sonar",
        "messages": [{"role": "user", "content": query}],
        "max_tokens": 800,
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        r = requests.post(
            "https://api.perplexity.ai/chat/completions",
            headers=headers,
            json=payload,
            timeout=30,
        )
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"]
        return {"content": content, "error": None}
    except Exception as e:
        return {"content": "", "error": str(e)}
