# Skill: GitHub Search

## Purpose
Search GitHub for repos matching an agent name + purpose. Return top 10, score by relevance.

---

## API Details

**Endpoint:** `GET https://api.github.com/search/repositories`

**Auth:** `Authorization: Bearer $GITHUB_PERSONAL_ACCESS_TOKEN`

**Key params:**
- `q` — search query (see keyword strategy below)
- `sort` — `stars`
- `order` — `desc`
- `per_page` — `10`

---

## Keyword Strategy

Given `agent_name` and `purpose`:

1. Strip "agent-" prefix from name
2. Split name on hyphens → keyword list
3. Add top 2–3 nouns from purpose
4. Build query: `[keyword1] [keyword2] python`
5. Secondary query (if < 3 results): `AI [keyword1] automation`

**Example:**
- Input: `agent-seo-writer`, `reads video transcript, outputs SEO metadata`
- Keywords: `seo writer transcript python`
- Query: `seo writer transcript python`

---

## Response Parsing

For each result, extract:
```python
{
    "name": item["full_name"],
    "url": item["html_url"],
    "stars": item["stargazers_count"],
    "description": item["description"] or "",
    "last_updated": item["pushed_at"][:10],  # YYYY-MM-DD
    "relevance": "HIGH" if stars >= 100 and days_since_push <= 180 else "MEDIUM" or "LOW"
}
```

---

## HIGH RELEVANCE Criteria

Both conditions must be true:
- `stargazers_count >= 100`
- `pushed_at` within last 180 days

Any HIGH RELEVANCE repo is flagged to Nova for agent-security vetting.

---

## Rate Limits

- Authenticated: 30 requests/min search, 5000 requests/hour general
- On 403/429: wait 60s, retry once
- On continued failure: return partial results, note in report

---

## Example Call

```python
import requests, os
headers = {"Authorization": f"Bearer {os.environ['GITHUB_PERSONAL_ACCESS_TOKEN']}"}
params = {"q": "seo writer transcript python", "sort": "stars", "order": "desc", "per_page": 10}
r = requests.get("https://api.github.com/search/repositories", headers=headers, params=params)
results = r.json()["items"]
```
