# Skill: Perplexity Search

## Purpose
Query Perplexity for web-grounded research on existing implementations of an agent's purpose.

---

## API Details

**Endpoint:** `POST https://api.perplexity.ai/chat/completions`

**Auth:** `Authorization: Bearer $PERPLEXITY_API_KEY`

**Model:** `sonar` — web-grounded, fast, low cost

---

## Query Template

```
What existing open-source implementations exist for: [purpose]?
I'm looking for GitHub repos, Python packages, or CLI tools that do this.
Please include:
1. The actual repo/package name and URL if known
2. What it does well
3. Any known limitations or common issues
4. Key features worth incorporating into a new implementation

Be specific — name actual repos, not general frameworks.
```

---

## Response Parsing

Extract from the text response:
- Named repos (look for `github.com/` URLs or `pip install` mentions)
- Feature descriptions (what it does well)
- Pitfalls or limitations
- Any design patterns mentioned

Return as 3–5 bullet points.

---

## Example Call

```python
import requests, os

payload = {
    "model": "sonar",
    "messages": [
        {
            "role": "user",
            "content": f"What existing open-source implementations exist for: {purpose}? ..."
        }
    ],
    "max_tokens": 800
}
headers = {
    "Authorization": f"Bearer {os.environ['PERPLEXITY_API_KEY']}",
    "Content-Type": "application/json"
}
r = requests.post("https://api.perplexity.ai/chat/completions", headers=headers, json=payload)
content = r.json()["choices"][0]["message"]["content"]
```

---

## Notes

- `sonar` is web-grounded — it reads real pages, returns real URLs
- Max 800 tokens is enough for a concise findings summary
- If Perplexity fails (5xx), log the error and continue with GitHub-only report
- Never use `sonar-pro` for this task — `sonar` is sufficient and cheaper
