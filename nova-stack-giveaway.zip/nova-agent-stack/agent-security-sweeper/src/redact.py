"""Credential redaction utilities.

Format: first 12 chars + '***'. Applied everywhere except the VPS-local
findings/sweep-YYYY-MM-DD.md detail file.
"""

import re

_HIGH_ENTROPY = re.compile(r"[A-Za-z0-9_\-+/=]{16,}")


def redact_value(value: str, keep: int = 12) -> str:
    """Return first `keep` chars suffixed with `***`. Example:
    redact_value('EXAMPLEKEYV1AAAAAAAAAA') -> 'EXAMPLEKEYV1***'.
    """
    if value is None:
        return None
    s = str(value)
    if len(s) <= keep:
        return s + "***"
    return s[:keep] + "***"


def redact_text(text: str) -> str:
    """Redact any long token-like substring inside a free text block.

    Conservative: only redacts strings of 16+ chars from the token charset.
    """
    def _sub(m):
        return redact_value(m.group(0))
    return _HIGH_ENTROPY.sub(_sub, text)
