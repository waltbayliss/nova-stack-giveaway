"""GitHub Contents API writer — append/update files on
waltbayliss/nova-assistant and waltbayliss/walts-wiki via curl-equivalent.

Canonical VPS pattern per /home/walt/CLAUDE.md (GitHub MCP is broken on VPS).
"""

from __future__ import annotations

import base64
import json
import os
import urllib.request
import urllib.error
from typing import Optional


def _token() -> str:
    tok = os.environ.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    if tok:
        return tok
    # Fall back to /home/walt/.env
    try:
        with open("/home/walt/.env", "r") as fh:
            for line in fh:
                if line.startswith("GITHUB_PERSONAL_ACCESS_TOKEN="):
                    return line.split("=", 1)[1].strip()
    except OSError:
        pass
    return ""


def _api(method: str, url: str, data: Optional[dict] = None) -> tuple[int, dict]:
    body = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"token {_token()}",
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json",
        },
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode() or "{}")
        except Exception:
            payload = {}
        return e.code, payload


def get_file(owner: str, repo: str, path: str) -> tuple[Optional[str], Optional[str]]:
    """Return (decoded_content, sha) for a file, or (None, None) if missing."""
    from urllib.parse import quote
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{quote(path)}"
    status, payload = _api("GET", url)
    if status == 200 and "content" in payload:
        try:
            content = base64.b64decode(payload["content"]).decode()
        except Exception:
            content = ""
        return content, payload.get("sha")
    return None, None


def put_file(owner: str, repo: str, path: str, content: str, message: str) -> tuple[bool, str]:
    """Create or update a file. Returns (ok, detail)."""
    from urllib.parse import quote
    existing, sha = get_file(owner, repo, path)
    encoded = base64.b64encode(content.encode()).decode()
    body = {"message": message, "content": encoded}
    if sha:
        body["sha"] = sha
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{quote(path)}"
    status, payload = _api("PUT", url, body)
    if 200 <= status < 300:
        return True, f"ok:{status}"
    return False, f"err:{status}:{payload.get('message','')}"


def append_to_file(owner: str, repo: str, path: str, addition: str, message: str) -> tuple[bool, str]:
    """Append text to an existing GitHub file (or create with addition if missing)."""
    existing, sha = get_file(owner, repo, path)
    if existing is None:
        new_content = addition
    else:
        if not existing.endswith("\n"):
            existing += "\n"
        new_content = existing + addition
    return put_file(owner, repo, path, new_content, message)
