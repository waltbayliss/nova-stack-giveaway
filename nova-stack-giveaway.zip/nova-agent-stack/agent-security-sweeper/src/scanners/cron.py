"""Cron job inventory + drift detection.

Lists walt's crontab and /etc/cron.* entries. Baseline diff at orchestrator
level alerts on any new entry.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash

ETC_CRON_DIRS = [
    "/etc/cron.d",
    "/etc/cron.daily",
    "/etc/cron.hourly",
    "/etc/cron.weekly",
    "/etc/cron.monthly",
]


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        # User crontab
        try:
            proc = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=10)
        except FileNotFoundError:
            proc = None
        if proc and proc.returncode == 0:
            for line in (proc.stdout or "").splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                out.append(Finding(
                    severity="MEDIUM",
                    scanner="cron",
                    target="walt@crontab",
                    description=f"crontab entry: {line[:160]}",
                ))

        # System cron dirs (readable subset)
        for d in ETC_CRON_DIRS:
            if not os.path.isdir(d):
                continue
            for f in Path(d).glob("*"):
                if not f.is_file():
                    continue
                try:
                    out.append(Finding(
                        severity="LOW",
                        scanner="cron",
                        target=str(f),
                        description="system cron entry present",
                    ))
                except OSError:
                    continue
    except Exception as e:
        out.append(scanner_crash("cron", e))
    return out
