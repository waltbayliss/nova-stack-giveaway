"""Filesystem secrets scan.

Wraps detect-secrets via subprocess. Scope: /home/walt/agents/,
/home/walt/.claude/, dotfiles. v1 uses detect-secrets default plugins
(AWS, GitHub, Slack, Stripe, JWT, private keys, high-entropy). The
1,600-regex secrets-patterns-db ruleset is deferred to v2 — see
docs/ROADMAP.md for the planned wiring.

.env files are excluded from 'leaked' findings (expected presence). Their
chmod is checked by perms.py.
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash
from ..redact import redact_value

SCAN_ROOTS = [
    "/home/walt/agents",
    "/home/walt/.claude",
    "/home/walt/CLAUDE.md",
]
DOTFILES = [
    "/home/walt/.bashrc",
    "/home/walt/.profile",
    "/home/walt/.zshrc",
]

# Files always excluded — .env contents are expected, not leaks.
ENV_FILENAMES = {".env", ".env.local", ".env.example"}


def _run_detect_secrets(path: str) -> dict:
    """Run `detect-secrets scan` on a path. Returns the parsed JSON or {}."""
    try:
        proc = subprocess.run(
            ["detect-secrets", "scan", path, "--all-files"],
            capture_output=True, text=True, timeout=120,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return {}
    if proc.returncode != 0:
        return {}
    try:
        return json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        return {}


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        for root in SCAN_ROOTS + DOTFILES:
            if not os.path.exists(root):
                continue
            data = _run_detect_secrets(root)
            results = data.get("results", {}) if isinstance(data, dict) else {}
            for rel_path, hits in results.items():
                abs_path = os.path.join(root, rel_path) if os.path.isdir(root) else rel_path
                filename = os.path.basename(abs_path)
                if filename in ENV_FILENAMES:
                    continue
                for hit in hits:
                    line = hit.get("line_number")
                    secret_type = hit.get("type", "unknown")
                    hashed = hit.get("hashed_secret", "")
                    out.append(Finding(
                        severity="HIGH",
                        scanner="filesystem",
                        target=abs_path,
                        line_ref=f"L{line}" if line else None,
                        description=f"detect-secrets: {secret_type}",
                        redacted_value=redact_value(hashed) if hashed else None,
                        full_value=hashed or None,
                    ))
    except Exception as e:
        out.append(scanner_crash("filesystem", e))
    return out
