"""Process audit.

Flags long-running processes owned by walt that are NOT in the
known_good_processes substring allowlist.
"""

from __future__ import annotations

import yaml
from pathlib import Path

from ..finding import Finding, scanner_crash

ALLOWLIST_PATH = Path(__file__).resolve().parent.parent / "allowlist.yml"


def _known_substrings() -> list[str]:
    try:
        with open(ALLOWLIST_PATH, "r") as fh:
            data = yaml.safe_load(fh) or {}
        return list(data.get("known_good_processes") or [])
    except Exception:
        return []


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        try:
            import psutil
        except ImportError:
            out.append(Finding(severity="MEDIUM", scanner="processes", target="psutil", description="psutil not installed"))
            return out

        allow = _known_substrings()
        for proc in psutil.process_iter(attrs=["pid", "username", "name", "cmdline", "create_time"]):
            try:
                info = proc.info
                if info.get("username") != "walt":
                    continue
                cmd = " ".join(info.get("cmdline") or [info.get("name") or ""])
                if not cmd:
                    continue
                if any(sub in cmd for sub in allow):
                    continue
                # uptime > 1h heuristic
                import time
                uptime = time.time() - (info.get("create_time") or time.time())
                if uptime < 3600:
                    continue
                out.append(Finding(
                    severity="MEDIUM",
                    scanner="processes",
                    target=f"pid {info.get('pid')}",
                    description=f"unfamiliar long-running process: {cmd[:120]}",
                ))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except Exception as e:
        out.append(scanner_crash("processes", e))
    return out
