"""VPS 20-item security checklist.

Pure Python + subprocess. No external dependencies.

Items:
  1. Kernel + distro (LOW info)
  2. Logged-in users (HIGH if unexpected)
  3. Uptime (info)
  4. Listening ports — handled in ports.py (NB: agent drift handled in #20)
  5. Disk + memory headroom (<10% free = MEDIUM)
  6. SSH config (PermitRootLogin, PasswordAuthentication)
  7. Installed packages diff vs baseline
  8. Password policy presence (informational unless missing)
  9. Null passwords (CRITICAL on any hit)
 10. World-writable files outside expected paths (count delta)
 11. SUID/SGID drift
 12. Sysctl security params
 13. Failed login spike
 14. Cron — covered in cron.py
 15. Shell assignments in /etc/passwd for system users
 16. Services running as root (informational baseline)
 17. UID 0 users other than root (CRITICAL)
 18. Password aging (chage -l) — informational
 19. Dotfile secret patterns
 20. Agent drift — git status in each /home/walt/agents/agent-*
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash

EXPECTED_USERS = {"walt", "root"}
DOTFILES = [
    "/home/walt/.bash_history",
    "/home/walt/.python_history",
    "/home/walt/.lesshst",
]


def _safe_run(cmd: list[str], timeout: int = 15) -> str:
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return proc.stdout or ""
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        # 1. Kernel + distro
        out.append(Finding(
            severity="LOW", scanner="vps", target="kernel",
            description=f"{platform.system()} {platform.release()} {platform.machine()}",
        ))

        # 2. Logged-in users
        who = _safe_run(["who"])
        users = set()
        for line in who.splitlines():
            parts = line.split()
            if parts:
                users.add(parts[0])
        for u in users:
            if u not in EXPECTED_USERS:
                out.append(Finding(
                    severity="HIGH", scanner="vps", target=f"user:{u}",
                    description="unexpected logged-in user",
                ))

        # 5. Disk + memory
        try:
            usage = shutil.disk_usage("/")
            free_pct = usage.free * 100 / usage.total
            if free_pct < 10:
                out.append(Finding(
                    severity="MEDIUM", scanner="vps", target="disk:/",
                    description=f"disk free {free_pct:.1f}% (<10%)",
                ))
        except OSError:
            pass

        # 6. SSH config
        sshd = "/etc/ssh/sshd_config"
        if os.path.exists(sshd):
            try:
                with open(sshd, "r") as fh:
                    cfg = fh.read()
                if "PermitRootLogin yes" in cfg:
                    out.append(Finding(severity="CRITICAL", scanner="vps", target=sshd,
                                       description="PermitRootLogin yes"))
                if "PasswordAuthentication yes" in cfg:
                    out.append(Finding(severity="HIGH", scanner="vps", target=sshd,
                                       description="PasswordAuthentication yes"))
            except OSError:
                pass

        # 9. Null passwords
        out_nulls = _safe_run(["sudo", "-n", "awk", "-F:", '$2 == "" { print $1 }', "/etc/shadow"])
        # If sudo -n fails (no NOPASSWD), we silently skip — not a sweeper failure.
        for u in out_nulls.splitlines():
            u = u.strip()
            if u:
                out.append(Finding(severity="CRITICAL", scanner="vps", target=f"user:{u}",
                                   description="null password"))

        # 12. Sysctl
        for key, expected in [
            ("net.ipv4.tcp_syncookies", "1"),
            ("kernel.randomize_va_space", "2"),
        ]:
            val = _safe_run(["sysctl", "-n", key]).strip()
            if val and val != expected:
                out.append(Finding(severity="MEDIUM", scanner="vps", target=f"sysctl:{key}",
                                   description=f"expected {expected}, got {val}"))

        # 13. Failed login spike
        lastb = _safe_run(["lastb", "-a", "-n", "200"])
        fail_count = sum(1 for l in lastb.splitlines() if l.strip())
        if fail_count > 50:
            out.append(Finding(severity="HIGH", scanner="vps", target="lastb",
                               description=f"{fail_count} failed login records in lastb"))

        # 15. Shells for system users in /etc/passwd
        try:
            with open("/etc/passwd", "r") as fh:
                for line in fh:
                    parts = line.strip().split(":")
                    if len(parts) < 7:
                        continue
                    user, uid, shell = parts[0], parts[2], parts[6]
                    try:
                        uid_i = int(uid)
                    except ValueError:
                        continue
                    # 17. UID 0
                    if uid_i == 0 and user != "root":
                        out.append(Finding(severity="CRITICAL", scanner="vps", target=f"user:{user}",
                                           description="UID 0 user other than root"))
                    # 15. System users with login shell
                    if uid_i < 1000 and user != "root" and shell.endswith(("bash", "sh", "zsh")):
                        out.append(Finding(severity="HIGH", scanner="vps", target=f"user:{user}",
                                           description=f"system user has login shell {shell}"))
        except OSError:
            pass

        # 19. Dotfile secret patterns
        from ..redact import redact_value
        import re
        token_re = re.compile(r"(sk-[A-Za-z0-9_\-]{16,}|ghp_[A-Za-z0-9]{20,}|sk-ant-[A-Za-z0-9_\-]{20,}|sk-or-[A-Za-z0-9_\-]{20,})")
        for d in DOTFILES:
            if not os.path.exists(d):
                continue
            try:
                with open(d, "r", errors="ignore") as fh:
                    for i, line in enumerate(fh, 1):
                        m = token_re.search(line)
                        if m:
                            val = m.group(0)
                            out.append(Finding(
                                severity="HIGH", scanner="vps", target=d, line_ref=f"L{i}",
                                description="secret pattern in dotfile",
                                redacted_value=redact_value(val),
                                full_value=val,
                            ))
            except OSError:
                continue

        # 20. Agent drift
        for d in Path("/home/walt/agents").glob("agent-*"):
            if not (d / ".git").exists():
                continue
            try:
                proc = subprocess.run(
                    ["git", "-C", str(d), "status", "--porcelain"],
                    capture_output=True, text=True, timeout=15,
                )
                if proc.stdout.strip():
                    out.append(Finding(
                        severity="MEDIUM", scanner="vps", target=str(d),
                        description="agent has uncommitted local changes (drift)",
                    ))
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue
    except Exception as e:
        out.append(scanner_crash("vps", e))
    return out
