"""File permission audit.

Sensitive files must be chmod 600. SSH authorized_keys must be 600.
World-writable files under /home/walt/ are MEDIUM each.
"""

from __future__ import annotations

import os
import stat
from pathlib import Path

from ..finding import Finding, scanner_crash

MUST_BE_600 = [
    "/home/walt/.env",
    "/home/walt/.gcp-sa-nova.json",
    "/home/walt/agents/agent-security-sweeper/.env",
    "/home/walt/.ssh/authorized_keys",
]
KEY_GLOBS = [
    "/home/walt/.ssh/id_*",
    "/home/walt/**/*.key",
    "/home/walt/**/*.pem",
]

# Exclude paths that ship test fixtures (e.g. PyPI packages bundling sample
# certs/keys). These never contain real secrets.
PATH_EXCLUDES = (
    "/site-packages/",
    "/.venv/",
    "/venv/",
    "/node_modules/",
    "/.git/",
    "/__pycache__/",
    "/.tox/",
)


def _excluded(path: str) -> bool:
    return any(seg in path for seg in PATH_EXCLUDES)


def _mode_str(path: str) -> str:
    try:
        return oct(stat.S_IMODE(os.lstat(path).st_mode))
    except OSError:
        return "?"


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        for p in MUST_BE_600:
            if not os.path.exists(p):
                continue
            actual = stat.S_IMODE(os.lstat(p).st_mode)
            if actual != 0o600:
                out.append(Finding(
                    severity="CRITICAL",
                    scanner="perms",
                    target=p,
                    description=f"expected chmod 600, found {oct(actual)}",
                ))

        # Glob-based key checks
        for pat in KEY_GLOBS:
            try:
                # Path.glob doesn't directly support ** in absolute prefix elegantly
                base = pat.split("/**", 1)[0] if "/**" in pat else os.path.dirname(pat)
                if "**" in pat:
                    suffix = pat.split("/**/", 1)[1] if "/**/" in pat else "*"
                    for f in Path(base).rglob(suffix):
                        if not f.is_file() or _excluded(str(f)):
                            continue
                        actual = stat.S_IMODE(os.lstat(f).st_mode)
                        if actual != 0o600:
                            out.append(Finding(
                                severity="HIGH",
                                scanner="perms",
                                target=str(f),
                                description=f"key/pem expected 600, found {oct(actual)}",
                            ))
                else:
                    for f in Path(os.path.dirname(pat)).glob(os.path.basename(pat)):
                        if not f.is_file() or f.name.endswith(".pub") or _excluded(str(f)):
                            continue
                        actual = stat.S_IMODE(os.lstat(f).st_mode)
                        if actual != 0o600:
                            out.append(Finding(
                                severity="HIGH",
                                scanner="perms",
                                target=str(f),
                                description=f"key expected 600, found {oct(actual)}",
                            ))
            except OSError:
                continue

        # World-writable under /home/walt/ (shallow — full scan in vps.py)
        for f in Path("/home/walt").rglob("*"):
            try:
                if not f.is_file() or _excluded(str(f)):
                    continue
                m = os.lstat(f).st_mode
                if m & stat.S_IWOTH:
                    out.append(Finding(
                        severity="MEDIUM",
                        scanner="perms",
                        target=str(f),
                        description="world-writable",
                    ))
            except OSError:
                continue
    except Exception as e:
        out.append(scanner_crash("perms", e))
    return out
