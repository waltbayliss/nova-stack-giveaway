"""AI-agent skill-file scan via agentseal (OFFLINE mode only).

GUARDRAILS (HARD):
  - Pinned agentseal==0.8.1
  - NEVER pass --upload
  - NEVER set AGENTSEAL_API_URL
  - If AGENTSEAL_API_URL is in environment → CRITICAL finding, abort scan
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        # Hard guardrail: AGENTSEAL_API_URL must be unset.
        if os.environ.get("AGENTSEAL_API_URL"):
            out.append(Finding(
                severity="CRITICAL", scanner="ai_agent_surface",
                target="env:AGENTSEAL_API_URL",
                description="AGENTSEAL_API_URL is set — guardrail violation, refusing to run",
            ))
            return out

        if shutil.which("agentseal") is None:
            out.append(Finding(
                severity="MEDIUM", scanner="ai_agent_surface",
                target="agentseal",
                description="agentseal not installed (pip install agentseal==0.8.1)",
            ))
            return out

        # Scan every agent's skills/ folder
        for d in Path("/home/walt/agents").glob("agent-*"):
            skills = d / "skills"
            if not skills.exists():
                continue
            try:
                # OFFLINE only — never --upload
                proc = subprocess.run(
                    ["agentseal", "scan", str(skills)],
                    capture_output=True, text=True, timeout=60,
                    env={**os.environ, "AGENTSEAL_API_URL": ""},  # belt-and-braces
                )
            except subprocess.TimeoutExpired:
                continue
            for line in (proc.stdout or "").splitlines():
                line = line.strip()
                if not line:
                    continue
                if any(k in line.lower() for k in ("warning", "danger", "risk", "vulnerable", "found")):
                    out.append(Finding(
                        severity="HIGH", scanner="ai_agent_surface",
                        target=str(skills),
                        description=f"agentseal: {line[:200]}",
                    ))
    except Exception as e:
        out.append(scanner_crash("ai_agent_surface", e))
    return out
