"""HTTP-side exposure scan via snallygaster (WEEKLY only).

Probes PUBLIC_HTTP_TARGETS for accidentally-exposed .env, .git/, .DS_Store,
backup files, etc. Hits = CRITICAL.
"""

from __future__ import annotations

import os
import shutil
import subprocess

from ..finding import Finding, scanner_crash


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    if mode != "weekly":
        return out
    try:
        if shutil.which("snallygaster") is None:
            out.append(Finding(
                severity="MEDIUM", scanner="http_exposure",
                target="snallygaster",
                description="snallygaster not installed (pip install snallygaster)",
            ))
            return out
        targets_env = os.environ.get("PUBLIC_HTTP_TARGETS", "[your-public-domain]")
        targets = [t.strip() for t in targets_env.split(",") if t.strip()]
        for t in targets:
            try:
                proc = subprocess.run(
                    ["snallygaster", t],
                    capture_output=True, text=True, timeout=120,
                )
            except subprocess.TimeoutExpired:
                continue
            for line in (proc.stdout or "").splitlines():
                line = line.strip()
                if not line:
                    continue
                # snallygaster prints lines like 'host: testname: details'
                if ":" in line and any(k in line.lower() for k in ("found", "exposed", "test")):
                    out.append(Finding(
                        severity="CRITICAL", scanner="http_exposure",
                        target=t,
                        description=f"snallygaster: {line[:200]}",
                    ))
    except Exception as e:
        out.append(scanner_crash("http_exposure", e))
    return out
