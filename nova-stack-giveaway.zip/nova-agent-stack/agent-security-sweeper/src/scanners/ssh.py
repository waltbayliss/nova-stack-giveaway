"""SSH audit.

  - Enumerate authorized_keys with fingerprints (each key = LOW info finding;
    additional CRITICAL Finding fires only on baseline drift via fingerprint diff)
  - Tail /var/log/auth.log (or journalctl) for unfamiliar source IPs in last 24h
"""

from __future__ import annotations

import base64
import hashlib
import os
import re
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash

AUTHKEYS = Path("/home/walt/.ssh/authorized_keys")
IP_RE = re.compile(r"from\s+(\d+\.\d+\.\d+\.\d+|[0-9a-fA-F:]+)")


def _key_fingerprint(line: str) -> str | None:
    parts = line.strip().split()
    if len(parts) < 2:
        return None
    try:
        blob = base64.b64decode(parts[1])
    except Exception:
        return None
    h = hashlib.sha256(blob).digest()
    return "SHA256:" + base64.b64encode(h).decode().rstrip("=")


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        if AUTHKEYS.exists():
            try:
                with open(AUTHKEYS, "r") as fh:
                    lines = [l for l in fh if l.strip() and not l.startswith("#")]
            except OSError:
                lines = []
            for line in lines:
                fp = _key_fingerprint(line) or "unparseable"
                comment = line.strip().split(None, 2)[-1] if len(line.strip().split()) > 2 else ""
                out.append(Finding(
                    severity="LOW",
                    scanner="ssh",
                    target="authorized_keys",
                    description=f"key present: {comment[:80]}",
                    redacted_value=fp,
                ))
        else:
            out.append(Finding(severity="LOW", scanner="ssh", target=str(AUTHKEYS), description="no authorized_keys"))

        # Tail recent SSH logins via journalctl
        try:
            proc = subprocess.run(
                ["journalctl", "-u", "ssh", "--since", "24 hours ago", "--no-pager"],
                capture_output=True, text=True, timeout=20,
            )
        except FileNotFoundError:
            proc = None
        if proc and proc.stdout:
            ips = set()
            for line in proc.stdout.splitlines():
                m = IP_RE.search(line)
                if m:
                    ips.add(m.group(1))
            for ip in ips:
                # MEDIUM default — baseline diff suppresses known IPs.
                # New IPs land in the daily log without Telegram spam from
                # benign ISP/CGNAT rotation. Walt can manually elevate to HIGH
                # by editing the baseline if a pattern emerges.
                out.append(Finding(
                    severity="MEDIUM",
                    scanner="ssh",
                    target=f"login_ip:{ip}",
                    description="ssh login source IP in last 24h",
                ))
    except Exception as e:
        out.append(scanner_crash("ssh", e))
    return out
