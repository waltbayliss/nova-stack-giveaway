"""Framework default-key scan via badsecrets (WEEKLY only).

Walks every agent src/ directory and runs badsecrets against it. Hits =
HIGH (Django SECRET_KEY=changeme, Flask demo keys, etc.).
"""

from __future__ import annotations

import subprocess
import shutil
from pathlib import Path

from ..finding import Finding, scanner_crash


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    if mode != "weekly":
        return out
    try:
        if shutil.which("badsecrets") is None:
            out.append(Finding(
                severity="MEDIUM", scanner="framework_defaults",
                target="badsecrets",
                description="badsecrets CLI not installed (pip install badsecrets)",
            ))
            return out
        for d in Path("/home/walt/agents").glob("agent-*"):
            src = d / "src"
            if not src.exists():
                continue
            try:
                proc = subprocess.run(
                    ["badsecrets", "--folder", str(src)],
                    capture_output=True, text=True, timeout=120,
                )
            except subprocess.TimeoutExpired:
                continue
            for line in (proc.stdout or "").splitlines():
                line = line.strip()
                if not line:
                    continue
                # badsecrets outputs '[+] ' for hits
                if line.startswith("[+]") or "VULNERABLE" in line.upper() or "FOUND" in line.upper():
                    out.append(Finding(
                        severity="HIGH", scanner="framework_defaults",
                        target=str(src),
                        description=f"badsecrets: {line[:180]}",
                    ))
    except Exception as e:
        out.append(scanner_crash("framework_defaults", e))
    return out
