"""Git history secrets scan.

Daily: gitleaks --no-git against every working tree under /home/walt/agents/.
Weekly: gitleaks against full history; trufflehog --only-verified.

Binaries: trufflehog + gitleaks installed via scripts/install-binaries.sh
(SHA256-verified). If a binary is missing, returns a MEDIUM finding rather
than crashing.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash
from ..redact import redact_value

AGENT_ROOT = "/home/walt/agents"
GITLEAKS_CONFIG = Path(__file__).resolve().parents[2] / "data" / "gitleaks.toml"


def _agent_dirs() -> list[Path]:
    return [p for p in Path(AGENT_ROOT).glob("agent-*") if p.is_dir() and (p / ".git").exists()]


def _gitleaks_available() -> bool:
    return shutil.which("gitleaks") is not None


def _trufflehog_available() -> bool:
    return shutil.which("trufflehog") is not None


def _run_gitleaks(path: Path, full_history: bool) -> list[dict]:
    """Run gitleaks; return list of finding dicts."""
    cmd = ["gitleaks", "detect", "--source", str(path), "--report-format", "json", "--report-path", "/dev/stdout"]
    if GITLEAKS_CONFIG.exists():
        cmd.extend(["--config", str(GITLEAKS_CONFIG)])
    if not full_history:
        cmd.append("--no-git")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except subprocess.TimeoutExpired:
        return []
    if not proc.stdout:
        return []
    # gitleaks writes JSON array to stdout; tolerate noise after
    try:
        # find first '[' and parse
        idx = proc.stdout.find("[")
        if idx < 0:
            return []
        return json.loads(proc.stdout[idx:])
    except json.JSONDecodeError:
        return []


def _run_trufflehog_verified(path: Path) -> list[dict]:
    cmd = ["trufflehog", "filesystem", str(path), "--only-verified", "--json"]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except subprocess.TimeoutExpired:
        return []
    hits = []
    for line in (proc.stdout or "").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            hits.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return hits


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        if not _gitleaks_available():
            out.append(Finding(
                severity="MEDIUM",
                scanner="git_history",
                target="gitleaks",
                description="gitleaks binary not installed — run scripts/install-binaries.sh",
            ))
        else:
            full = mode == "weekly"
            for d in _agent_dirs():
                hits = _run_gitleaks(d, full_history=full)
                for h in hits:
                    raw = h.get("Secret", "") or h.get("Match", "")
                    out.append(Finding(
                        severity="CRITICAL" if full else "HIGH",
                        scanner="git_history",
                        target=f"{d}/{h.get('File','')}",
                        line_ref=f"L{h.get('StartLine','')}" if h.get("StartLine") else None,
                        description=f"gitleaks: {h.get('RuleID','unknown')}",
                        redacted_value=redact_value(raw) if raw else None,
                        full_value=raw or None,
                    ))

        if mode == "weekly":
            if not _trufflehog_available():
                out.append(Finding(
                    severity="MEDIUM",
                    scanner="git_history",
                    target="trufflehog",
                    description="trufflehog binary not installed — run scripts/install-binaries.sh",
                ))
            else:
                for d in _agent_dirs():
                    hits = _run_trufflehog_verified(d)
                    for h in hits:
                        raw = h.get("Raw", "")
                        out.append(Finding(
                            severity="CRITICAL",  # verified = real
                            scanner="git_history",
                            target=str(d),
                            description=f"trufflehog VERIFIED: {h.get('DetectorName','unknown')}",
                            redacted_value=redact_value(raw) if raw else None,
                            full_value=raw or None,
                        ))
    except Exception as e:
        out.append(scanner_crash("git_history", e))
    return out
