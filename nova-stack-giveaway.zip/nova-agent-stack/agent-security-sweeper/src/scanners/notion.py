"""Notion credential scan.

First run (no findings/notion-first-run-complete.flag) = FULL workspace scan
of every accessible page. Subsequent runs = last-24h modified pages only.

Pipes page text through a regex-based secret detector (same patterns as
the VPS dotfile scan).
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path

from ..finding import Finding, scanner_crash
from ..redact import redact_value

FLAG_PATH = Path(__file__).resolve().parent.parent.parent / "findings" / "notion-first-run-complete.flag"

TOKEN_RE = re.compile(
    r"(sk-[A-Za-z0-9_\-]{16,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-ant-[A-Za-z0-9_\-]{20,}|sk-or-[A-Za-z0-9_\-]{20,}|secret_[A-Za-z0-9]{20,}|xoxb-[A-Za-z0-9\-]{20,}|xoxp-[A-Za-z0-9\-]{20,})"
)


def _block_text(block: dict) -> str:
    """Best-effort extraction of plain text from a Notion block dict."""
    btype = block.get("type")
    if not btype:
        return ""
    payload = block.get(btype) or {}
    rich = payload.get("rich_text") or payload.get("text") or []
    parts = []
    for r in rich:
        t = r.get("plain_text") or r.get("text", {}).get("content") or ""
        if t:
            parts.append(t)
    return " ".join(parts)


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    api_key = os.environ.get("NOTION_API_KEY", "")
    if not api_key:
        # Fall back to /home/walt/.env
        try:
            with open("/home/walt/.env", "r") as fh:
                for line in fh:
                    if line.startswith("NOTION_API_KEY="):
                        api_key = line.split("=", 1)[1].strip()
                        break
        except OSError:
            pass
    if not api_key:
        out.append(Finding(severity="MEDIUM", scanner="notion", target="env",
                           description="NOTION_API_KEY not configured"))
        return out

    try:
        try:
            from notion_client import Client
            import httpx
        except ImportError:
            out.append(Finding(severity="MEDIUM", scanner="notion", target="notion_client",
                               description="notion-client not installed"))
            return out

        # Per-request timeout — notion-client has no default; without this the
        # daily sweep hangs indefinitely on any slow Notion response.
        http_client = httpx.Client(timeout=httpx.Timeout(30.0, connect=10.0))
        client = Client(auth=api_key, client=http_client)

        # Full-run is ONLY triggered by the explicit --mode full-notion-first-run.
        # Daily mode is always 24h-delta — keeps daily wall-clock under the
        # 600s budget. The first full run is a manual one-shot:
        #   python3 src/sweep.py --mode full-notion-first-run
        full_run = mode == "full-notion-first-run"
        if not full_run and not FLAG_PATH.exists():
            out.append(Finding(
                severity="MEDIUM", scanner="notion", target="first-run",
                description=(
                    "Notion first-run-full not yet completed. Run "
                    "`python3 src/sweep.py --mode full-notion-first-run` "
                    "manually to establish the Notion baseline. Daily delta "
                    "scan running anyway — but any pre-existing secret "
                    "won't be caught until the first-run-full completes."
                ),
            ))

        # Determine the candidate page set
        pages = []
        if full_run:
            # search() with empty query returns all accessible pages
            cursor = None
            while True:
                resp = client.search(query="", filter={"property": "object", "value": "page"},
                                     start_cursor=cursor) if cursor else \
                       client.search(query="", filter={"property": "object", "value": "page"})
                pages.extend(resp.get("results", []))
                if not resp.get("has_more"):
                    break
                cursor = resp.get("next_cursor")
                if not cursor:
                    break
        else:
            cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
            cursor = None
            sort = {"direction": "descending", "timestamp": "last_edited_time"}
            done = False
            while not done:
                kwargs = {
                    "query": "",
                    "filter": {"property": "object", "value": "page"},
                    "sort": sort,
                }
                if cursor:
                    kwargs["start_cursor"] = cursor
                resp = client.search(**kwargs)
                for p in resp.get("results", []):
                    last = p.get("last_edited_time")
                    if not last:
                        continue
                    try:
                        last_dt = datetime.fromisoformat(last.replace("Z", "+00:00"))
                    except ValueError:
                        continue
                    if last_dt >= cutoff:
                        pages.append(p)
                    else:
                        # Sorted desc — first older-than-cutoff page means
                        # all subsequent are older. Stop paginating.
                        done = True
                        break
                if done or not resp.get("has_more"):
                    break
                cursor = resp.get("next_cursor")
                if not cursor:
                    break

        # Scan each page's blocks
        for page in pages:
            page_id = page.get("id")
            if not page_id:
                continue
            try:
                blocks = client.blocks.children.list(block_id=page_id).get("results", [])
            except Exception:
                continue
            for b in blocks:
                text = _block_text(b)
                if not text:
                    continue
                m = TOKEN_RE.search(text)
                if m:
                    val = m.group(0)
                    out.append(Finding(
                        severity="HIGH", scanner="notion",
                        target=f"notion:page:{page_id}",
                        description="secret pattern in Notion page",
                        redacted_value=redact_value(val),
                        full_value=val,
                    ))

        # After a successful first-run-full, drop the flag.
        if full_run and not FLAG_PATH.exists():
            FLAG_PATH.parent.mkdir(parents=True, exist_ok=True)
            FLAG_PATH.write_text(f"first run completed {datetime.now(timezone.utc).isoformat()}\n")
            try:
                os.chmod(FLAG_PATH, 0o600)
            except OSError:
                pass
    except Exception as e:
        out.append(scanner_crash("notion", e))
    return out
