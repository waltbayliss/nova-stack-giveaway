"""Tracked-config token scanner.

Detection-only sweep for live credentials committed inside tracked config
files (`.claude/settings.json`, `.claude/settings.local.json`,
`mcp-config.json`, `claude_desktop_config.json`).

Triggered by Session 76 incident: three live tokens (Notion bearer,
Cloudflare API, ClickUp PK) were committed inside
`nova-assistant/.claude/settings.json` and rode two full sweep cycles
undetected because:

  1. gitleaks default detectors don't cover Notion/Cloudflare/ClickUp
     token formats.
  2. The filesystem scanner checks .env files but not config JSON.
  3. No scanner specifically targeted tracked config files in agent repos.

This module closes that gap. It enumerates every config file path under
each git repo, asks `git ls-files` whether it's tracked, and scans the
contents for credential patterns. The "tracked" filter matters: an
untracked local file can't leak via push, so a flag on it would be noise.

One HIGH finding per match. The redacted value goes everywhere; the full
value is preserved only in the VPS-local sweep detail file via the
Finding contract.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash
from ..redact import redact_value

AGENT_ROOT = Path("/home/walt/agents")

CONFIG_FILE_NAMES = (
    ".claude/settings.json",
    ".claude/settings.local.json",
    "mcp-config.json",
    "claude_desktop_config.json",
    ".mcp.json",
)

# Credential patterns we care about for tracked-config exposure.
# Each entry: (label, compiled regex). Patterns are tuned for low FP rate
# on JSON config — they all require a distinctive prefix.
TOKEN_PATTERNS: tuple[tuple[str, re.Pattern], ...] = (
    ("notion_bearer",       re.compile(r"ntn_[A-Za-z0-9]{30,}")),
    ("cloudflare_api",      re.compile(r"cfut_[A-Za-z0-9]{30,}")),
    ("clickup_pk",          re.compile(r"pk_[0-9]+_[A-Z0-9]{20,}")),
    ("github_pat",          re.compile(r"ghp_[A-Za-z0-9]{30,}")),
    ("github_oauth",        re.compile(r"gho_[A-Za-z0-9]{30,}")),
    ("openai_key",          re.compile(r"sk-(?!or-|ant-)[A-Za-z0-9_\-]{30,}")),
    ("openai_project_key",  re.compile(r"sk-proj-[A-Za-z0-9_\-]{30,}")),
    ("anthropic_key",       re.compile(r"sk-ant-[A-Za-z0-9_\-]{30,}")),
    ("openrouter_key",      re.compile(r"sk-or-v1-[A-Za-z0-9_\-]{30,}")),
    ("perplexity_key",      re.compile(r"pplx-[A-Za-z0-9]{30,}")),
    ("slack_bot_token",     re.compile(r"xoxb-[0-9]+-[0-9]+-[A-Za-z0-9]{20,}")),
    ("aws_access_key",      re.compile(r"AKIA[0-9A-Z]{16}")),
    ("fal_key",             re.compile(r"fal_[A-Za-z0-9]{30,}")),
    ("replicate_token",     re.compile(r"r8_[A-Za-z0-9]{30,}")),
    ("google_api_key",      re.compile(r"AIza[0-9A-Za-z_\-]{30,}")),
    ("stripe_live",         re.compile(r"sk_live_[A-Za-z0-9]{20,}")),
    ("telegram_bot_token",  re.compile(r"[0-9]{8,12}:AA[A-Za-z0-9_\-]{32,}")),
)


def _git_repos() -> list[Path]:
    """Every direct child of /home/walt/agents/ that has a .git directory."""
    return [p for p in AGENT_ROOT.iterdir() if p.is_dir() and (p / ".git").exists()]


def _tracked_files(repo: Path) -> set[str]:
    """git ls-files paths (POSIX-style, relative to repo)."""
    try:
        proc = subprocess.run(
            ["git", "-C", str(repo), "ls-files"],
            capture_output=True, text=True, timeout=30, check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return set()
    if proc.returncode != 0:
        return set()
    return {line.strip() for line in proc.stdout.splitlines() if line.strip()}


def _remote_url(repo: Path) -> str | None:
    try:
        proc = subprocess.run(
            ["git", "-C", str(repo), "remote", "get-url", "origin"],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if proc.returncode != 0:
        return None
    url = proc.stdout.strip()
    return url or None


def _scan_file(repo: Path, rel_path: str, remote: str | None) -> list[Finding]:
    """Read a tracked config file and return one Finding per credential match."""
    abs_path = repo / rel_path
    try:
        text = abs_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    findings: list[Finding] = []
    lines = text.splitlines()
    for idx, line in enumerate(lines, start=1):
        for label, pat in TOKEN_PATTERNS:
            for match in pat.finditer(line):
                raw = match.group(0)
                desc = f"tracked_config: {label} in {rel_path}"
                if remote:
                    desc += f" (remote: {remote})"
                findings.append(Finding(
                    severity="HIGH",
                    scanner="tracked_config",
                    target=str(abs_path),
                    line_ref=f"L{idx}",
                    description=desc,
                    redacted_value=redact_value(raw),
                    full_value=raw,
                ))
    return findings


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        if not AGENT_ROOT.exists():
            return out
        for repo in _git_repos():
            tracked = _tracked_files(repo)
            if not tracked:
                continue
            remote = _remote_url(repo)
            for name in CONFIG_FILE_NAMES:
                if name in tracked:
                    out.extend(_scan_file(repo, name, remote))
    except Exception as e:
        out.append(scanner_crash("tracked_config", e))
    return out
