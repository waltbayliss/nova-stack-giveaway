"""GitHub repos scan.

Lists waltbayliss/* repos via API. Detects:
  - .env / *.key / *.pem / service-account*.json in default branch tree → CRITICAL
  - Public visibility on any agent-* repo not in allowlist → HIGH
"""

from __future__ import annotations

import os
import yaml
from pathlib import Path

from ..finding import Finding, scanner_crash
from ..github_writer import _api  # internal reuse


ALLOWLIST_PATH = Path(__file__).resolve().parent.parent / "allowlist.yml"
SUSPICIOUS_NAMES = (".env", ".env.local", "service-account.json", "credentials.json", "id_rsa")
SUSPICIOUS_SUFFIXES = (".key", ".pem")


def _load_public_allowlist() -> set[str]:
    try:
        with open(ALLOWLIST_PATH, "r") as fh:
            data = yaml.safe_load(fh) or {}
        return set(data.get("public_repos", []) or [])
    except Exception:
        return set()


def _list_repos() -> list[dict]:
    repos = []
    page = 1
    while True:
        url = f"https://api.github.com/user/repos?per_page=100&page={page}&affiliation=owner"
        status, payload = _api("GET", url)
        if status != 200 or not isinstance(payload, list) or not payload:
            break
        repos.extend(payload)
        if len(payload) < 100:
            break
        page += 1
    return repos


def _tree(owner: str, repo: str, ref: str) -> list[dict]:
    url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{ref}?recursive=1"
    status, payload = _api("GET", url)
    if status != 200:
        return []
    return payload.get("tree", []) if isinstance(payload, dict) else []


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        allow = _load_public_allowlist()
        repos = _list_repos()
        if not repos:
            out.append(Finding(
                severity="MEDIUM",
                scanner="github_repos",
                target="github.com/waltbayliss",
                description="repo list empty — PAT scope or network?",
            ))
            return out

        for r in repos:
            name = r.get("name", "")
            is_private = r.get("private", True)
            default_branch = r.get("default_branch", "main")
            owner = r.get("owner", {}).get("login", "waltbayliss")

            # Visibility audit
            if not is_private and name.startswith("agent-") and name not in allow:
                out.append(Finding(
                    severity="HIGH",
                    scanner="github_repos",
                    target=f"{owner}/{name}",
                    description="agent-* repo is PUBLIC and not in allowlist",
                ))

            # Tree scan
            tree = _tree(owner, name, default_branch)
            for entry in tree:
                p = entry.get("path", "")
                base = os.path.basename(p).lower()
                if (
                    base in SUSPICIOUS_NAMES
                    or any(base.endswith(suf) for suf in SUSPICIOUS_SUFFIXES)
                    or base.startswith("service-account")
                ):
                    sev = "CRITICAL" if not is_private else "HIGH"
                    out.append(Finding(
                        severity=sev,
                        scanner="github_repos",
                        target=f"{owner}/{name}:{p}",
                        description=f"suspicious filename in repo tree ({'public' if not is_private else 'private'})",
                    ))
    except Exception as e:
        out.append(scanner_crash("github_repos", e))
    return out
