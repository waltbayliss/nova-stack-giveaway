"""Listening-port audit.

Compares `ss -tlnp` output against the known_good_ports list in allowlist.yml.
New ports = HIGH.

Loopback exception: a port bound to 127.0.0.0/8 or [::1] owned by a process
whose argv matches a `known_good_processes` substring is treated as expected
noise (typical case: ephemeral Node child sockets from code-server / MCP
helpers). Public-facing ports (0.0.0.0, *, ::) are always evaluated against
the port allowlist regardless of owner.
"""

from __future__ import annotations

import re
import subprocess
import yaml
from pathlib import Path

from ..finding import Finding, scanner_crash


ALLOWLIST_PATH = Path(__file__).resolve().parent.parent / "allowlist.yml"

# Matches the listen line columns we need:
#   State Recv-Q Send-Q  Local-Address:Port  Peer-Address:Port  [users:((...))]
# Local address can be: 0.0.0.0, 127.0.0.1, 127.0.0.53%lo, [::], [::1], *
LISTEN_RE = re.compile(
    r"^LISTEN\s+\d+\s+\d+\s+(?P<local>\S+):(?P<port>\d+)\s+\S+(?:\s+users:\(\((?P<users>.+)\)\))?\s*$"
)
PROC_NAME_RE = re.compile(r'"([^"]+)"')


def _load_allowlist() -> dict:
    try:
        with open(ALLOWLIST_PATH, "r") as fh:
            return yaml.safe_load(fh) or {}
    except Exception:
        return {}


def _is_loopback(local: str) -> bool:
    if local.startswith("127."):
        return True
    if local in ("[::1]", "::1"):
        return True
    return False


def _owner_matches_known_good(users_field: str | None, known_subs: list[str]) -> bool:
    if not users_field or not known_subs:
        return False
    names = PROC_NAME_RE.findall(users_field)
    if not names:
        return False
    blob = " ".join(names)
    return any(sub in blob for sub in known_subs)


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        # Try with sudo first so we see owner info for ports held by other
        # users (ollama, systemd-resolve, docker-proxy, etc.). Fall back to
        # plain ss if sudo isn't available — those ports just won't have
        # owner data and will be evaluated against the port allowlist only.
        try:
            proc = subprocess.run(
                ["sudo", "-n", "ss", "-tlnp"],
                capture_output=True, text=True, timeout=15,
            )
            if proc.returncode != 0:
                proc = subprocess.run(["ss", "-tlnp"], capture_output=True, text=True, timeout=15)
        except FileNotFoundError:
            try:
                proc = subprocess.run(["ss", "-tlnp"], capture_output=True, text=True, timeout=15)
            except FileNotFoundError:
                out.append(Finding(severity="MEDIUM", scanner="ports", target="ss", description="ss binary missing"))
                return out

        data = _load_allowlist()
        known_ports = set(int(p) for p in (data.get("known_good_ports") or {}).keys())
        known_procs = list(data.get("known_good_processes") or [])

        # Dedupe by port — same port may appear twice (IPv4 + IPv6). If ANY
        # binding for a port is public, we evaluate it as public.
        # port -> (is_public_anywhere, any_owner_known_on_loopback)
        port_state: dict[int, dict] = {}

        for line in (proc.stdout or "").splitlines():
            m = LISTEN_RE.match(line.strip())
            if not m:
                continue
            try:
                port = int(m.group("port"))
            except ValueError:
                continue
            if port < 1 or port > 65535:
                continue
            local = m.group("local")
            users = m.group("users")
            loopback = _is_loopback(local)
            owner_known = _owner_matches_known_good(users, known_procs)
            st = port_state.setdefault(port, {"public": False, "loopback_trusted": False})
            if not loopback:
                st["public"] = True
            elif owner_known:
                st["loopback_trusted"] = True

        for port in sorted(port_state.keys()):
            if port in known_ports:
                continue
            st = port_state[port]
            # Skip iff all bindings are loopback AND at least one has a trusted owner.
            if not st["public"] and st["loopback_trusted"]:
                continue
            out.append(Finding(
                severity="HIGH",
                scanner="ports",
                target=f"tcp/{port}",
                description=f"listening port not in known_good_ports allowlist",
            ))
    except Exception as e:
        out.append(scanner_crash("ports", e))
    return out
