"""MCP config audit.

v1 — native parse only:
  Parse ~/.claude/settings.json + all .mcp.json files for literal-token
  embeds (should be ${VAR} references). Returns HIGH findings on hits.

v2 — third-party scanner integration deferred:
  The original PRD called for `mcp-audit==1.0.0` subprocess wrap. That pip
  package does not exist on PyPI (agent-builder hallucinated; agent-security
  reviewed a non-existent GitHub repo). The `_run_mcp_audit_if_available()`
  helper below remains in place but `shutil.which("mcp-audit")` will return
  None and the scanner degrades gracefully. v2: re-vet cmiretf/mcpaudit (the
  real PyPI package, different maintainer) via agent-security and re-enable.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import shutil
from pathlib import Path

from ..finding import Finding, scanner_crash
from ..redact import redact_value

MCP_CONFIG_PATHS = [
    Path("/home/walt/.claude/settings.json"),
    Path("/home/walt/.claude/settings.local.json"),
]
LITERAL_TOKEN_RE = re.compile(r"(sk-|ghp_|github_pat_|secret_|sk-ant-|sk-or-|xoxb-|xoxp-)[A-Za-z0-9_\-]{8,}")


def _run_mcp_audit_if_available() -> list[Finding]:
    out: list[Finding] = []
    if shutil.which("mcp-audit") is None:
        return out
    # Clean env block — strip any telemetry env vars the parent process may
    # have inherited. Belt-and-braces parity with ai_agent_surface.py.
    clean_env = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": os.environ.get("HOME", "/home/walt"),
        "LANG": os.environ.get("LANG", "C.UTF-8"),
    }
    try:
        proc = subprocess.run(
            ["mcp-audit", "--json"],
            capture_output=True, text=True, timeout=60,
            env=clean_env,
        )
        if not proc.stdout:
            return out
        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError:
            return out
        for item in data if isinstance(data, list) else []:
            sev = (item.get("severity") or "MEDIUM").upper()
            if sev not in ("LOW", "MEDIUM", "HIGH", "CRITICAL"):
                sev = "MEDIUM"
            out.append(Finding(
                severity=sev,
                scanner="mcp_audit",
                target=item.get("target", "mcp"),
                description=f"mcp-audit: {item.get('message','issue')}",
            ))
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return out


def _walk_mcp_configs() -> list[Path]:
    paths = [p for p in MCP_CONFIG_PATHS if p.exists()]
    for d in Path("/home/walt/agents").glob("agent-*"):
        for cand in (d / ".mcp.json", d / "mcp.json"):
            if cand.exists():
                paths.append(cand)
    return paths


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        out.extend(_run_mcp_audit_if_available())
        for cfg in _walk_mcp_configs():
            try:
                with open(cfg, "r") as fh:
                    text = fh.read()
            except OSError:
                continue
            for m in LITERAL_TOKEN_RE.finditer(text):
                val = m.group(0)
                out.append(Finding(
                    severity="HIGH",
                    scanner="mcp_audit",
                    target=str(cfg),
                    description="literal credential in MCP config (should be ${VAR})",
                    redacted_value=redact_value(val),
                    full_value=val,
                ))
    except Exception as e:
        out.append(scanner_crash("mcp_audit", e))
    return out
