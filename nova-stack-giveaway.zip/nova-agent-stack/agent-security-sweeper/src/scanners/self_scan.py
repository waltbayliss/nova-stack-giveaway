"""Self-scan (MANDATORY every daily run).

Verifies:
  1. Sweeper's own .env is chmod 600
  2. findings/ directory is chmod 700 (or stricter)
  3. requirements.txt has the exact pinned version for agentseal (mcp-audit
     pin intentionally removed in v1 — see DECISIONS.md)
  4. No --upload flag appears in any src/ file
  5. AGENTSEAL_API_URL is not set in environment
  6. iptables REJECT rules for agentseal.org and apisec.ai exist (best-effort)
  7. No credential patterns in this agent's own src/ or docs/

Any guardrail violation = CRITICAL.
"""

from __future__ import annotations

import os
import re
import stat
import subprocess
from pathlib import Path

from ..finding import Finding, scanner_crash

ROOT = Path(__file__).resolve().parent.parent.parent
REQUIREMENTS = ROOT / "requirements.txt"
ENV_FILE = ROOT / ".env"
FINDINGS_DIR = ROOT / "findings"
SRC_DIR = ROOT / "src"
DOCS_DIR = ROOT / "docs"

REQUIRED_PINS = {
    "agentseal": "0.8.1",
    # mcp-audit==1.0.0 intentionally NOT pinned in v1 — that PyPI package
    # name doesn't exist. See docs/DECISIONS.md 2026-05-12 post-Pass-2 entry.
    # Re-add when v2 wires the real third-party MCP scanner (cmiretf/mcpaudit
    # or alternative) after agent-security re-vets.
}

TOKEN_RE = re.compile(
    r"(sk-[A-Za-z0-9_\-]{16,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-ant-[A-Za-z0-9_\-]{20,}|sk-or-[A-Za-z0-9_\-]{20,})"
)


def _iptables_has_reject_for(domain: str) -> bool:
    """Best-effort check that iptables has a REJECT rule for any IP of the given domain.
    Returns True if we can't determine (sudo locked / iptables missing) — we don't
    want to spam CRITICAL when the check itself is unavailable; the install script
    handles the affirmative side."""
    try:
        proc = subprocess.run(
            ["iptables", "-S", "OUTPUT"],
            capture_output=True, text=True, timeout=10,
        )
        if proc.returncode != 0:
            return True  # can't check; assume OK
        text = proc.stdout or ""
        # Resolve domain to current IPs
        try:
            import socket
            ips = {info[4][0] for info in socket.getaddrinfo(domain, None) if info[4]}
        except (socket.gaierror, OSError):
            return True
        for ip in ips:
            if ip in text and "REJECT" in text:
                return True
        return False
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return True


def scan(mode: str = "daily") -> list[Finding]:
    out: list[Finding] = []
    try:
        # 1. .env chmod
        if ENV_FILE.exists():
            actual = stat.S_IMODE(os.lstat(ENV_FILE).st_mode)
            if actual != 0o600:
                out.append(Finding(severity="CRITICAL", scanner="self_scan",
                                   target=str(ENV_FILE),
                                   description=f".env not chmod 600 (got {oct(actual)})"))

        # 2. findings/ chmod
        if FINDINGS_DIR.exists():
            actual = stat.S_IMODE(os.lstat(FINDINGS_DIR).st_mode)
            if actual & 0o077:
                out.append(Finding(severity="CRITICAL", scanner="self_scan",
                                   target=str(FINDINGS_DIR),
                                   description=f"findings/ permissive: {oct(actual)}"))

        # 3. Pinned versions
        if REQUIREMENTS.exists():
            try:
                with open(REQUIREMENTS, "r") as fh:
                    txt = fh.read()
                for pkg, ver in REQUIRED_PINS.items():
                    pat = re.compile(rf"^{re.escape(pkg)}==([^\s]+)", re.MULTILINE)
                    m = pat.search(txt)
                    if not m:
                        out.append(Finding(
                            severity="CRITICAL", scanner="self_scan",
                            target=str(REQUIREMENTS),
                            description=f"required pin missing: {pkg}=={ver}",
                        ))
                    elif m.group(1) != ver:
                        out.append(Finding(
                            severity="CRITICAL", scanner="self_scan",
                            target=str(REQUIREMENTS),
                            description=f"{pkg} version drift: pinned {ver}, found {m.group(1)} — guardrail violation, re-audit before bumping",
                        ))
            except OSError:
                pass

        # 4. No --upload flag actually invoked in src/.
        # We detect ACTUAL invocations (the flag inside an argv-style list),
        # not the literal string in comments or docstrings discussing the
        # guardrail. Specifically: lines containing '"--upload"' or "'--upload'"
        # which is how subprocess args appear. Comments mentioning --upload
        # without quoting it as a string literal are allowed.
        upload_re = re.compile(r"""(?:["']--upload["'])""")
        for f in SRC_DIR.rglob("*.py"):
            try:
                with open(f, "r", errors="ignore") as fh:
                    for i, line in enumerate(fh, 1):
                        stripped = line.lstrip()
                        if stripped.startswith("#"):
                            continue
                        if upload_re.search(line):
                            out.append(Finding(
                                severity="CRITICAL", scanner="self_scan",
                                target=str(f), line_ref=f"L{i}",
                                description="--upload flag string literal present (guardrail violation)",
                            ))
            except OSError:
                continue

        # 5. AGENTSEAL_API_URL not in environment
        if os.environ.get("AGENTSEAL_API_URL"):
            out.append(Finding(
                severity="CRITICAL", scanner="self_scan",
                target="env:AGENTSEAL_API_URL",
                description="AGENTSEAL_API_URL is set in environment (guardrail violation)",
            ))

        # 6. iptables rules
        for domain in ("agentseal.org", "apisec.ai"):
            if not _iptables_has_reject_for(domain):
                out.append(Finding(
                    severity="CRITICAL", scanner="self_scan",
                    target=f"iptables:{domain}",
                    description=f"no OUTPUT REJECT rule for {domain} — run scripts/install-firewall-guards.sh",
                ))

        # 7. No credential patterns in own src/ or docs/.
        # We skip lines that are obviously regex-pattern definitions or comments
        # so the scanner doesn't flag itself for documenting the patterns it
        # detects.
        from ..redact import redact_value
        REGEX_DEF_HINTS = ("re.compile(", 're.compile("', "re.compile('", 'r"(', "r'(", 'r"\\b', "r'\\b")
        for base in (SRC_DIR, DOCS_DIR):
            for f in base.rglob("*"):
                if not f.is_file():
                    continue
                if f.suffix not in (".py", ".md", ".yml", ".yaml", ".txt"):
                    continue
                try:
                    with open(f, "r", errors="ignore") as fh:
                        for i, line in enumerate(fh, 1):
                            stripped = line.lstrip()
                            if stripped.startswith("#"):
                                continue
                            # Skip pattern-definition lines (regex sources)
                            if any(h in line for h in REGEX_DEF_HINTS):
                                continue
                            m = TOKEN_RE.search(line)
                            if m:
                                val = m.group(0)
                                out.append(Finding(
                                    severity="CRITICAL", scanner="self_scan",
                                    target=str(f), line_ref=f"L{i}",
                                    description="credential pattern in own source",
                                    redacted_value=redact_value(val),
                                    full_value=val,
                                ))
                except OSError:
                    continue
    except Exception as e:
        out.append(scanner_crash("self_scan", e))
    return out
