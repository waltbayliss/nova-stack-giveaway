"""Telegram notifier — calls the nova-telegram Cloudflare Worker, or falls back
to the Telegram Bot API directly using TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID
from /home/walt/.env.

Hard rule: NEVER include unredacted credential values in the message.
"""

from __future__ import annotations

import os
import json
import urllib.request
import urllib.error


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def send(message: str) -> tuple[bool, str]:
    """Send a Telegram message. Returns (ok, detail).

    Tries (in order):
      1. nova-telegram Cloudflare Worker (NOVA_TELEGRAM_WORKER_URL)
      2. Telegram Bot API direct (TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID)
    """
    worker_url = _env("NOVA_TELEGRAM_WORKER_URL")
    if worker_url:
        try:
            req = urllib.request.Request(
                worker_url,
                data=json.dumps({"text": message}).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                if 200 <= resp.status < 300:
                    return True, f"worker:{resp.status}"
                return False, f"worker:{resp.status}"
        except (urllib.error.URLError, TimeoutError) as e:
            # fall through to bot API
            last_err = f"worker_failed:{e}"
        except Exception as e:  # pragma: no cover
            last_err = f"worker_failed:{e}"
    else:
        last_err = "no_worker_url"

    token = _env("TELEGRAM_BOT_TOKEN")
    chat = _env("TELEGRAM_CHAT_ID")
    if not token or not chat:
        return False, f"{last_err}; no bot token/chat configured"

    api = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        req = urllib.request.Request(
            api,
            data=json.dumps({"chat_id": chat, "text": message}).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            if 200 <= resp.status < 300:
                return True, f"bot_api:{resp.status}"
            return False, f"bot_api:{resp.status}"
    except (urllib.error.URLError, TimeoutError) as e:
        return False, f"bot_api_failed:{e}"
    except Exception as e:
        return False, f"bot_api_failed:{e}"
