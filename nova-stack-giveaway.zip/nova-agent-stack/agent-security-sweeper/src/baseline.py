"""Baseline + diff machinery.

Per-scanner fingerprints stored in findings/baseline.json. Telegram fires
only on NEW (non-baselined) HIGH/CRITICAL findings. After each successful
run the baseline is updated with the union of (existing fingerprints +
current run fingerprints) — so once a finding has been triaged by Walt
and the sweep has run, it stops alerting.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from .finding import Finding

BASELINE_PATH = Path(__file__).resolve().parent.parent / "findings" / "baseline.json"


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_baseline() -> dict:
    """Load baseline.json. Raises ValueError if file exists but is corrupt."""
    if not BASELINE_PATH.exists():
        return {"scanners": {}, "first_seen": _utc_now()}
    try:
        with open(BASELINE_PATH, "r") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or "scanners" not in data:
            raise ValueError("baseline.json malformed: missing 'scanners' key")
        return data
    except json.JSONDecodeError as e:
        raise ValueError(f"baseline.json corrupt: {e}") from e


def mark_known(findings: Iterable[Finding], baseline: dict) -> None:
    """Mutates each Finding's baseline_known based on the loaded baseline."""
    scanners = baseline.get("scanners", {})
    for f in findings:
        known_fps = set(scanners.get(f.scanner, {}).get("fingerprints", []))
        f.baseline_known = f.fingerprint in known_fps


def save_baseline(findings: Iterable[Finding]) -> None:
    """Persist the union of existing baseline + this run's fingerprints.

    Atomic write via temp file. chmod 600 on the result.
    """
    existing = load_baseline() if BASELINE_PATH.exists() else {"scanners": {}, "first_seen": _utc_now()}
    scanners = existing.get("scanners", {})
    per_scanner: dict[str, set[str]] = {}
    for f in findings:
        per_scanner.setdefault(f.scanner, set()).add(f.fingerprint)

    for scanner_name, fps in per_scanner.items():
        prior = set(scanners.get(scanner_name, {}).get("fingerprints", []))
        merged = sorted(prior | fps)
        scanners[scanner_name] = {
            "fingerprints": merged,
            "last_updated": _utc_now(),
        }
    existing["scanners"] = scanners
    existing["last_run"] = _utc_now()

    BASELINE_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = BASELINE_PATH.with_suffix(".json.tmp")
    with open(tmp, "w") as fh:
        json.dump(existing, fh, indent=2)
    os.replace(tmp, BASELINE_PATH)
    try:
        os.chmod(BASELINE_PATH, 0o600)
    except OSError:
        pass
