#!/usr/bin/env python3
"""agent-security-sweeper — top-level orchestrator.

Usage:
  python3 src/sweep.py --mode daily
  python3 src/sweep.py --mode weekly
  python3 src/sweep.py --mode full-notion-first-run
  python3 src/sweep.py --scanner filesystem

Detection only. Never auto-remediates. Telegram only on NEW HIGH/CRITICAL.
"""

from __future__ import annotations

import argparse
import importlib
import os
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

# Wall-clock budgets — hard ceiling per run. On overrun the orchestrator
# sets partial=True, skips remaining scanners, and writes a PARTIAL summary.
# Baseline is NOT updated on a partial run (avoids missing-finding-becomes-known
# false negatives next run).
WALL_CLOCK_BUDGET_SECONDS = {"daily": 600, "weekly": 5400}

# Allow running as a script: `python3 src/sweep.py` from the repo root.
REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.finding import Finding  # noqa: E402
from src.baseline import load_baseline, mark_known, save_baseline  # noqa: E402
from src.redact import redact_text  # noqa: E402
from src import telegram  # noqa: E402
from src import github_writer  # noqa: E402

FINDINGS_DIR = REPO_ROOT / "findings"

DAILY_SCANNERS = [
    "filesystem", "git_history", "github_repos", "tracked_config", "perms",
    "mcp_audit", "ports", "processes", "ssh", "cron", "vps", "notion",
    "ai_agent_surface", "self_scan",
]
WEEKLY_EXTRA = ["framework_defaults", "http_exposure"]


def _load_dotenv():
    """Load /home/walt/.env and ./.env into os.environ (best effort)."""
    for path in ("/home/walt/.env", str(REPO_ROOT / ".env")):
        try:
            with open(path, "r") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip())
        except OSError:
            continue


def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _run_scanner(name: str, mode: str) -> list[Finding]:
    try:
        mod = importlib.import_module(f"src.scanners.{name}")
    except ImportError as e:
        return [Finding(
            severity="CRITICAL", scanner=name, target=name,
            description=f"scanner module import failed: {e}",
        )]
    try:
        return mod.scan(mode=mode) or []
    except Exception as e:
        return [Finding(
            severity="CRITICAL", scanner=name, target=name,
            description=f"scanner exception: {type(e).__name__}: {e}",
        )]


def _scanner_list(mode: str, single: str | None) -> list[str]:
    if single:
        return [single]
    if mode == "weekly":
        return DAILY_SCANNERS + WEEKLY_EXTRA
    return DAILY_SCANNERS


def _write_detail_file(findings: list[Finding], date: str, mode: str, partial: bool) -> Path:
    """Write the unredacted detail file. chmod 600. VPS-local only."""
    FINDINGS_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(FINDINGS_DIR, 0o700)
    except OSError:
        pass
    path = FINDINGS_DIR / f"sweep-{date}.md"
    counts = _counts(findings)
    lines = [
        f"# Sweep — {date} ({mode})",
        f"Run at: {_now_iso()}",
        f"Mode: {mode}",
        f"Partial: {partial}",
        f"Counts: {counts}",
        "",
        "## Findings (UNREDACTED — VPS-local only, never push)",
        "",
    ]
    for f in sorted(findings, key=lambda x: (("LOW","MEDIUM","HIGH","CRITICAL").index(x.severity), x.scanner)):
        marker = "NEW" if not f.baseline_known else "known"
        lines.append(f"- [{marker}] {f.render_line(redacted=False)}")
    path.write_text("\n".join(lines) + "\n")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def _counts(findings: list[Finding]) -> dict[str, int]:
    c = {"LOW": 0, "MEDIUM": 0, "HIGH": 0, "CRITICAL": 0, "NEW_HIGH": 0, "NEW_CRITICAL": 0, "TOTAL": 0}
    for f in findings:
        c[f.severity] += 1
        c["TOTAL"] += 1
        if not f.baseline_known and f.severity == "HIGH":
            c["NEW_HIGH"] += 1
        if not f.baseline_known and f.severity == "CRITICAL":
            c["NEW_CRITICAL"] += 1
    return c


def _build_redacted_summary(date: str, mode: str, counts: dict, findings: list[Finding], partial: bool) -> str:
    verdict = "CLEAN" if counts["NEW_HIGH"] == 0 and counts["NEW_CRITICAL"] == 0 else "DIRTY"
    if partial:
        verdict = f"{verdict} (PARTIAL)"
    parts = [
        f"## {date} — {mode} — verdict: {verdict}",
        f"Run at: {_now_iso()}",
        f"Counts: LOW={counts['LOW']} MEDIUM={counts['MEDIUM']} HIGH={counts['HIGH']} CRITICAL={counts['CRITICAL']} TOTAL={counts['TOTAL']}",
        f"NEW since baseline: HIGH={counts['NEW_HIGH']} CRITICAL={counts['NEW_CRITICAL']}",
        f"heartbeat: {_now_iso()}",
        "",
        "### NEW HIGH/CRITICAL findings (redacted)",
    ]
    new_serious = [f for f in findings if not f.baseline_known and f.severity in ("HIGH", "CRITICAL")]
    if not new_serious:
        parts.append("(none)")
    else:
        for f in new_serious:
            parts.append(f"- {f.render_line(redacted=True)}")
    parts.append("")
    return "\n".join(parts)


def _write_wiki_summary(date: str, mode: str, counts: dict, partial: bool) -> tuple[bool, str]:
    """Push per-run summary to walts-wiki (counts + verdict only — NO finding details)."""
    verdict = "CLEAN" if counts["NEW_HIGH"] == 0 and counts["NEW_CRITICAL"] == 0 else "DIRTY"
    if partial:
        verdict = f"{verdict} (PARTIAL)"
    body = (
        f"# Security Sweep — {date} ({mode})\n\n"
        f"Run at: {_now_iso()}\n"
        f"Verdict: {verdict}\n\n"
        f"## Counts\n"
        f"- LOW: {counts['LOW']}\n"
        f"- MEDIUM: {counts['MEDIUM']}\n"
        f"- HIGH: {counts['HIGH']}\n"
        f"- CRITICAL: {counts['CRITICAL']}\n"
        f"- TOTAL: {counts['TOTAL']}\n\n"
        f"## NEW vs baseline\n"
        f"- NEW HIGH: {counts['NEW_HIGH']}\n"
        f"- NEW CRITICAL: {counts['NEW_CRITICAL']}\n\n"
        f"_Finding details are on the VPS at `findings/sweep-{date}.md` (chmod 600). "
        f"Redacted summary in `nova-assistant/docs/SECURITY-SWEEP-LOG.md`._\n"
    )
    owner = os.environ.get("WIKI_REPO_OWNER", "waltbayliss")
    repo = os.environ.get("WIKI_REPO_NAME", "walts-wiki")
    path = f"Walt's Wiki/Security Sweeps/{date}-sweep-summary.md"
    return github_writer.put_file(owner, repo, path, body, f"security-sweeper: {date} summary")


def _append_github_log(date: str, mode: str, summary: str) -> tuple[bool, str]:
    """Append the redacted run summary to nova-assistant docs/SECURITY-SWEEP-LOG.md."""
    return github_writer.append_to_file(
        "waltbayliss", "nova-assistant",
        "docs/SECURITY-SWEEP-LOG.md",
        summary,
        f"security-sweeper: {date} {mode} run",
    )


def _maybe_telegram(counts: dict) -> tuple[bool, str]:
    new_high = counts["NEW_HIGH"]
    new_crit = counts["NEW_CRITICAL"]
    if new_high == 0 and new_crit == 0:
        return False, "no_new_serious"
    msg = f"🚨 Security sweeper — {new_high} NEW HIGH, {new_crit} NEW CRITICAL findings. Check SECURITY-SWEEP-LOG.md."
    return telegram.send(msg)


def main(argv=None):
    parser = argparse.ArgumentParser(description="agent-security-sweeper")
    parser.add_argument("--mode", choices=["daily", "weekly", "full-notion-first-run"], default="daily")
    parser.add_argument("--scanner", default=None, help="run a single scanner module")
    parser.add_argument("--dry-run", action="store_true", help="skip writes to GitHub/Telegram/wiki")
    args = parser.parse_args(argv)

    _load_dotenv()

    # Boot-time baseline check
    try:
        baseline = load_baseline()
    except ValueError as e:
        msg = f"⚠️ Baseline corrupted — manual repair needed: {e}"
        if not args.dry_run:
            telegram.send(msg)
        print(msg, file=sys.stderr)
        return 2

    scanners = _scanner_list(args.mode, args.scanner)
    print(f"[sweep] mode={args.mode} scanners={scanners}", file=sys.stderr)

    all_findings: list[Finding] = []
    partial = False
    budget = WALL_CLOCK_BUDGET_SECONDS.get(args.mode, 600)
    start = time.monotonic()
    for name in scanners:
        elapsed = time.monotonic() - start
        if elapsed > budget:
            partial = True
            skipped = [s for s in scanners[scanners.index(name):]]
            print(
                f"[sweep] wall-clock budget exceeded ({elapsed:.0f}s > {budget}s) — "
                f"skipping {len(skipped)} remaining: {skipped}",
                file=sys.stderr,
            )
            all_findings.append(Finding(
                severity="MEDIUM", scanner="sweep", target="orchestrator",
                description=(
                    f"wall-clock budget {budget}s exceeded after {elapsed:.0f}s; "
                    f"skipped scanners: {','.join(skipped)}"
                ),
            ))
            break
        try:
            results = _run_scanner(name, args.mode)
            print(f"[sweep] {name}: {len(results)} findings", file=sys.stderr)
            all_findings.extend(results)
        except Exception:
            partial = True
            traceback.print_exc()

    # Baseline diff
    mark_known(all_findings, baseline)

    date = _today()
    counts = _counts(all_findings)

    # 1. VPS-local unredacted detail (always)
    detail_path = _write_detail_file(all_findings, date, args.mode, partial)
    print(f"[sweep] detail: {detail_path}", file=sys.stderr)

    # 2. Build redacted summary
    summary = _build_redacted_summary(date, args.mode, counts, all_findings, partial)
    # Belt-and-braces: redact any token-shaped substring that slipped through
    summary = redact_text(summary)
    print(summary)

    if args.dry_run:
        print("[sweep] dry-run: skipping github/wiki/telegram", file=sys.stderr)
        return 0

    # 3. Append to nova-assistant log
    ok, detail = _append_github_log(date, args.mode, summary)
    print(f"[sweep] github_log: ok={ok} {detail}", file=sys.stderr)

    # 4. Wiki summary
    ok2, detail2 = _write_wiki_summary(date, args.mode, counts, partial)
    print(f"[sweep] wiki: ok={ok2} {detail2}", file=sys.stderr)

    # 5. Telegram on NEW HIGH/CRITICAL
    fired, tdetail = _maybe_telegram(counts)
    print(f"[sweep] telegram: fired={fired} {tdetail}", file=sys.stderr)

    # 6. Update baseline (only on a non-partial successful run)
    if not partial:
        save_baseline(all_findings)
        print(f"[sweep] baseline updated", file=sys.stderr)

    # 7. Write heartbeat for watchdog
    if args.mode == "daily":
        Path("/home/walt/agents/.heartbeats/agent-security-sweeper-daily").write_text(datetime.now(timezone.utc).isoformat())
    elif args.mode == "weekly":
        Path("/home/walt/agents/.heartbeats/agent-security-sweeper-weekly").write_text(datetime.now(timezone.utc).isoformat())

    return 0


if __name__ == "__main__":
    sys.exit(main())
