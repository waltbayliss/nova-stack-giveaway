"""Finding dataclass — the unit of work across scanners."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, asdict
from typing import Optional

SEVERITIES = ("LOW", "MEDIUM", "HIGH", "CRITICAL")


@dataclass
class Finding:
    """One detected issue.

    Attributes:
        severity: LOW | MEDIUM | HIGH | CRITICAL
        scanner: scanner name (e.g. 'filesystem', 'ssh')
        target: filepath, repo name, or identifier
        description: short, terse, one line
        line_ref: 'L42' style ref, optional
        redacted_value: 'sk-or-v1-abc***' form, optional
        full_value: ONLY written to VPS-local findings/sweep-*.md.
                    Never goes to GitHub, wiki, or Telegram.
        baseline_known: set by baseline diff after aggregation
    """

    severity: str
    scanner: str
    target: str
    description: str
    line_ref: Optional[str] = None
    redacted_value: Optional[str] = None
    full_value: Optional[str] = None
    baseline_known: bool = False
    fingerprint: str = field(default="", init=False)

    def __post_init__(self):
        if self.severity not in SEVERITIES:
            raise ValueError(
                f"invalid severity {self.severity!r}; must be one of {SEVERITIES}"
            )
        # Deterministic fingerprint for baseline matching.
        # NOTE: does NOT include full_value (so a baselined finding stays
        # baselined even if the value rotates around it — that's intentional
        # for things like 'authorized_keys has 3 keys'; for actual credential
        # detections the value usually appears in the target/description).
        h = hashlib.sha256()
        h.update(self.scanner.encode())
        h.update(b"|")
        h.update(self.target.encode())
        h.update(b"|")
        h.update((self.line_ref or "").encode())
        h.update(b"|")
        h.update(self.description.encode())
        self.fingerprint = h.hexdigest()

    def to_dict(self) -> dict:
        return asdict(self)

    def render_line(self, redacted: bool = True) -> str:
        """Single-line render. redacted=True hides full_value."""
        val = ""
        if redacted and self.redacted_value:
            val = f" [{self.redacted_value}]"
        elif not redacted and self.full_value:
            val = f" [{self.full_value}]"
        elif self.redacted_value:
            val = f" [{self.redacted_value}]"
        line = self.line_ref or ""
        return f"[{self.severity}] {self.scanner}: {self.description} ({self.target}{':'+line if line else ''}){val}"


def scanner_crash(scanner: str, exc: Exception) -> Finding:
    """Helper: produce a CRITICAL Finding when a scanner module crashes."""
    return Finding(
        severity="CRITICAL",
        scanner=scanner,
        target=scanner,
        description=f"scanner crashed: {type(exc).__name__}: {exc}",
    )
