# Skill — run-weekly-sweep

**Trigger phrases:** "weekly security sweep", "deep security sweep"

**Cron:** `0 19 * * 0` UTC (5am Brisbane Monday).

## Execution

```bash
cd /home/walt/agents/agent-security-sweeper
/usr/bin/python3 src/sweep.py --mode weekly
```

## Adds to daily scanner set

- `git_history` runs full history (not just working tree)
- `trufflehog --only-verified` against filesystem + GitHub repos — verified hits = CRITICAL, immediate Telegram regardless of baseline
- `framework_defaults` (badsecrets) across all agent `src/` dirs
- `http_exposure` (snallygaster) against `[your-public-domain]` and any other registered public targets

## Cost notes

TruffleHog verification is API-expensive. Run at low traffic time. Snallygaster probe is cheap but no reason to run daily.

## Output

Same channels as daily, plus weekly rollup written to walts-wiki `Walt's Wiki/Security Sweeps/YYYY-WW-weekly-rollup.md` (trends + recurring findings + baseline-drift log).
