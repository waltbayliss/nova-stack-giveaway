# Skill — run-daily-sweep

**Trigger phrases:** "run security sweep", "security sweep now", "daily security sweep"

**Cron:** `30 17 * * *` UTC (3:30am Brisbane). After agent-backup at 17:00 UTC.

## Execution

```bash
cd /home/walt/agents/agent-security-sweeper
/usr/bin/python3 src/sweep.py --mode daily
```

## Scanners run

filesystem, git_history (working tree only), github_repos, perms, mcp_audit, ports, processes, ssh, cron, vps (20-item), notion (delta or full first run), ai_agent_surface (agentseal OFFLINE), self_scan.

## Side effects

- Writes unredacted detail to `findings/sweep-YYYY-MM-DD.md` (chmod 600).
- Appends redacted summary to nova-assistant `docs/SECURITY-SWEEP-LOG.md` (curl PUT).
- Writes wiki summary to walts-wiki `Walt's Wiki/Security Sweeps/YYYY-MM-DD-sweep-summary.md`.
- Fires Telegram ONLY if NEW HIGH or NEW CRITICAL findings (vs baseline).
- Updates `findings/baseline.json` with this run's fingerprints.

## Failure handling

Any scanner crash → caught, recorded as a CRITICAL "scanner crash" Finding, sweep continues. Daily log flagged PARTIAL. Boot-time guardrail check failure (agentseal version drift, firewall rule missing, `--upload` found) → CRITICAL Telegram immediately, abort run.
