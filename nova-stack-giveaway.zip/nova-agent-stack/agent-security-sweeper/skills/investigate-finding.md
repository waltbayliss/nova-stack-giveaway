# Skill — investigate-finding

**Trigger phrase:** "investigate finding NNN" / "look up finding from YYYY-MM-DD"

## Steps

1. Read `findings/sweep-YYYY-MM-DD.md` (unredacted, VPS-local) — find the matching fingerprint.
2. Report:
   - Full scanner name + target path + line ref
   - Unredacted value (only in this context, not pushed anywhere)
   - When it was first seen (baseline timestamp)
   - Whether it's marked KNOWN (baselined) or NEW
3. Suggest investigation steps (NOT remediation):
   - For a leaked credential → "rotate this key in <provider dashboard>"
   - For an unknown SSH key → "check fingerprint against known team members"
   - For a public repo → "review repo contents, decide if it should stay public; if yes, add to `src/allowlist.yml` after manual review"
4. Detection only. Never execute remediation. Walt fixes.

## Hard rule

This skill ONLY reads. It never modifies findings files, never rotates keys, never adjusts the allowlist, never pushes anywhere.
