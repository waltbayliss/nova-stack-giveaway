#!/usr/bin/env bash
# Install pinned trufflehog + gitleaks Go binaries with SHA256 verification.
# Pinned versions chosen for v1. Re-audit before bumping.

set -euo pipefail

BIN_DIR="${HOME}/.local/bin"
mkdir -p "$BIN_DIR"

# --- gitleaks ---
GITLEAKS_VERSION="8.18.4"
GITLEAKS_ARCH="$(uname -m)"
case "$GITLEAKS_ARCH" in
    x86_64) GITLEAKS_ARCH="x64";;
    aarch64|arm64) GITLEAKS_ARCH="arm64";;
esac
GITLEAKS_URL="https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VERSION}/gitleaks_${GITLEAKS_VERSION}_linux_${GITLEAKS_ARCH}.tar.gz"
GITLEAKS_SHA256_x64="[REDACTED-ID][REDACTED-ID]"
GITLEAKS_SHA256_arm64="[REDACTED-ID][REDACTED-ID]"

# NOTE: the SHA256 values above are placeholders pinned at build time. The
# script verifies whatever is set here against the downloaded archive. If
# Walt is on a different arch or version, update both VERSION and SHA256.

if [ -x "$BIN_DIR/gitleaks" ]; then
    echo "[install-binaries] gitleaks already present at $BIN_DIR/gitleaks — skipping"
else
    echo "[install-binaries] downloading gitleaks v${GITLEAKS_VERSION} (${GITLEAKS_ARCH})"
    TMP="$(mktemp -d)"
    trap "rm -rf $TMP" EXIT
    curl -fsSL -o "$TMP/gitleaks.tar.gz" "$GITLEAKS_URL"

    # Verify SHA256 (best-effort: if unset, we WARN but proceed)
    if [ "$GITLEAKS_ARCH" = "x64" ]; then
        EXPECTED="$GITLEAKS_SHA256_x64"
    else
        EXPECTED="$GITLEAKS_SHA256_arm64"
    fi
    if [ -n "$EXPECTED" ]; then
        ACTUAL="$(sha256sum "$TMP/gitleaks.tar.gz" | awk '{print $1}')"
        if [ "$ACTUAL" != "$EXPECTED" ]; then
            echo "[install-binaries] SHA256 MISMATCH for gitleaks:"
            echo "  expected: $EXPECTED"
            echo "  actual:   $ACTUAL"
            echo "Refusing to install. Verify the release on GitHub and update the SHA in this script."
            exit 2
        fi
        echo "[install-binaries] SHA256 verified for gitleaks"
    else
        echo "[install-binaries] WARN: no SHA256 pinned for $GITLEAKS_ARCH — proceeding without verification"
    fi
    tar -xzf "$TMP/gitleaks.tar.gz" -C "$TMP"
    install -m 0755 "$TMP/gitleaks" "$BIN_DIR/gitleaks"
    echo "[install-binaries] gitleaks installed: $($BIN_DIR/gitleaks version 2>/dev/null || echo unknown)"
fi

# --- trufflehog ---
TRUFFLEHOG_VERSION="3.83.7"
TRUFFLEHOG_ARCH="$(uname -m)"
case "$TRUFFLEHOG_ARCH" in
    x86_64) TRUFFLEHOG_ARCH="amd64";;
    aarch64|arm64) TRUFFLEHOG_ARCH="arm64";;
esac
TRUFFLEHOG_URL="https://github.com/trufflesecurity/trufflehog/releases/download/v${TRUFFLEHOG_VERSION}/trufflehog_${TRUFFLEHOG_VERSION}_linux_${TRUFFLEHOG_ARCH}.tar.gz"
TRUFFLEHOG_SHA256_amd64="[REDACTED-ID][REDACTED-ID]"
TRUFFLEHOG_SHA256_arm64="[REDACTED-ID][REDACTED-ID]"

if [ -x "$BIN_DIR/trufflehog" ]; then
    echo "[install-binaries] trufflehog already present at $BIN_DIR/trufflehog — skipping"
else
    echo "[install-binaries] downloading trufflehog v${TRUFFLEHOG_VERSION} (${TRUFFLEHOG_ARCH})"
    TMP2="$(mktemp -d)"
    curl -fsSL -o "$TMP2/trufflehog.tar.gz" "$TRUFFLEHOG_URL"
    if [ "$TRUFFLEHOG_ARCH" = "amd64" ]; then
        EXPECTED="$TRUFFLEHOG_SHA256_amd64"
    else
        EXPECTED="$TRUFFLEHOG_SHA256_arm64"
    fi
    if [ -n "$EXPECTED" ]; then
        ACTUAL="$(sha256sum "$TMP2/trufflehog.tar.gz" | awk '{print $1}')"
        if [ "$ACTUAL" != "$EXPECTED" ]; then
            echo "[install-binaries] SHA256 MISMATCH for trufflehog"
            exit 2
        fi
        echo "[install-binaries] SHA256 verified for trufflehog"
    else
        echo "[install-binaries] WARN: trufflehog SHA256 not pinned — fill in after first verified download"
    fi
    tar -xzf "$TMP2/trufflehog.tar.gz" -C "$TMP2"
    install -m 0755 "$TMP2/trufflehog" "$BIN_DIR/trufflehog"
    rm -rf "$TMP2"
    echo "[install-binaries] trufflehog installed: $($BIN_DIR/trufflehog --version 2>&1 | head -1 || echo unknown)"
fi

echo "[install-binaries] done. Ensure $BIN_DIR is in your PATH."
