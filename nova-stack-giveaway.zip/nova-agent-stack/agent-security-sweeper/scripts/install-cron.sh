#!/usr/bin/env bash
# Idempotent cron install for agent-security-sweeper.
# Adds daily (3:30am Brisbane) and weekly (5am Brisbane Mon) entries to walt's crontab.

set -euo pipefail

DAILY='30 17 * * * /home/walt/agents/agent-security-sweeper/.venv/bin/python /home/walt/agents/agent-security-sweeper/src/sweep.py --mode daily >> /home/walt/agents/agent-security-sweeper/findings/cron.log 2>&1'
WEEKLY='0 19 * * 0 /home/walt/agents/agent-security-sweeper/.venv/bin/python /home/walt/agents/agent-security-sweeper/src/sweep.py --mode weekly >> /home/walt/agents/agent-security-sweeper/findings/cron.log 2>&1'

# Capture current crontab (empty if none)
EXISTING="$(crontab -l 2>/dev/null || true)"

# Strip any prior entries for this script to keep install idempotent
FILTERED="$(echo "$EXISTING" | grep -v 'agent-security-sweeper/src/sweep.py' || true)"

NEW="$(printf '%s\n%s\n%s\n' "$FILTERED" "$DAILY" "$WEEKLY" | sed '/^$/d')"

echo "$NEW" | crontab -

echo "[install-cron] crontab installed:"
crontab -l | grep agent-security-sweeper || true
echo "[install-cron] done."
