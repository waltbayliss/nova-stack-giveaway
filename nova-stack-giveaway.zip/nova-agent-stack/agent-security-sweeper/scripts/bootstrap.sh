#!/usr/bin/env bash
# Bootstrap agent-security-sweeper on a fresh VPS clone.
#
# Steps:
#   1. pip install requirements (user-local)
#   2. install pinned Go binaries (trufflehog, gitleaks)
#   3. chmod 600 findings/, ensure .env is 600 if present
#   4. optionally: install cron (--with-cron)
#   5. optionally: install firewall guards (--with-firewall, requires sudo)
#
# Default: no cron, no firewall — those need Walt's explicit nod.

set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_DIR"

WITH_CRON=0
WITH_FIREWALL=0
for arg in "$@"; do
    case "$arg" in
        --with-cron) WITH_CRON=1;;
        --with-firewall) WITH_FIREWALL=1;;
        --all) WITH_CRON=1; WITH_FIREWALL=1;;
    esac
done

echo "[bootstrap] repo: $REPO_DIR"

# 1. venv + pip install (VPS uses PEP 668; per-agent venv is the pattern)
VENV="$REPO_DIR/.venv"
if [ ! -d "$VENV" ]; then
    echo "[bootstrap] creating venv at $VENV..."
    python3 -m venv "$VENV"
fi
echo "[bootstrap] pip install requirements into venv..."
"$VENV/bin/pip" install --upgrade pip >/dev/null
"$VENV/bin/pip" install -r requirements.txt

# 2. binaries
echo "[bootstrap] install binaries..."
bash "$REPO_DIR/scripts/install-binaries.sh" || echo "[bootstrap] WARN: binary install had issues (continuing)"

# 3. permissions
mkdir -p "$REPO_DIR/findings"
chmod 700 "$REPO_DIR/findings"
if [ -f "$REPO_DIR/.env" ]; then
    chmod 600 "$REPO_DIR/.env"
fi
touch "$REPO_DIR/findings/.gitkeep"
echo "[bootstrap] findings/ chmod 700"

# 4. cron (optional)
if [ "$WITH_CRON" = "1" ]; then
    echo "[bootstrap] installing cron..."
    bash "$REPO_DIR/scripts/install-cron.sh"
else
    echo "[bootstrap] skipping cron install (pass --with-cron to enable)"
fi

# 5. firewall (optional, needs sudo)
if [ "$WITH_FIREWALL" = "1" ]; then
    echo "[bootstrap] installing firewall guards (requires sudo)..."
    sudo bash "$REPO_DIR/scripts/install-firewall-guards.sh" || echo "[bootstrap] WARN: firewall install failed (continuing)"
else
    echo "[bootstrap] skipping firewall install (pass --with-firewall to enable)"
fi

echo "[bootstrap] done."
echo ""
echo "Next steps:"
echo "  1. Smoke test:  python3 src/sweep.py --mode daily --dry-run"
echo "  2. Real run:    python3 src/sweep.py --mode daily"
echo "  3. After review, run with --with-cron --with-firewall."
