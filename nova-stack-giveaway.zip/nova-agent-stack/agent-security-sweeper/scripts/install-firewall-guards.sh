#!/usr/bin/env bash
# Install iptables OUTPUT REJECT rules for agentseal.org and apisec.ai.
# This script must be run as root (or via sudo). Idempotent.
#
# Rationale: both agentseal and mcp-audit have had telemetry concerns.
# We use the tools but block their outbound channels. See docs/SECURITY.md.
#
# Re-run this script if either domain's IP changes.

set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "[install-firewall-guards] must run as root (use sudo)"
    exit 1
fi

DOMAINS=("agentseal.org" "apisec.ai")

for DOMAIN in "${DOMAINS[@]}"; do
    echo "[install-firewall-guards] resolving $DOMAIN..."
    # IPv4 only — iptables (v4) cannot handle IPv6 addresses. ip6tables
    # would be the v6 equivalent; skipped here because agentseal and
    # apisec.ai both serve over IPv4 in practice and this VPS rarely
    # makes outbound IPv6 calls.
    IPS="$(getent ahostsv4 "$DOMAIN" 2>/dev/null | awk '{print $1}' | sort -u || true)"
    if [ -z "$IPS" ]; then
        echo "[install-firewall-guards] WARN: could not resolve $DOMAIN — skipping (re-run later)"
        continue
    fi
    for IP in $IPS; do
        # Idempotent: check existing rule first
        if iptables -C OUTPUT -d "$IP" -j REJECT 2>/dev/null; then
            echo "[install-firewall-guards] $DOMAIN ($IP) — rule already present"
        else
            iptables -A OUTPUT -d "$IP" -j REJECT
            echo "[install-firewall-guards] $DOMAIN ($IP) — REJECT rule added"
        fi
    done
done

# Persist
mkdir -p /etc/iptables
iptables-save > /etc/iptables/rules.v4
echo "[install-firewall-guards] persisted to /etc/iptables/rules.v4"
echo "[install-firewall-guards] done. Re-run if either domain's IP changes."
