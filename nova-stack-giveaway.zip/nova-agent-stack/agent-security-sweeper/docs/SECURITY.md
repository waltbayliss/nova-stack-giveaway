# SECURITY — agent-security-sweeper

This agent watches for security failures. It must itself be exemplary. These rules are HARD — they override convenience.

---

## CORE HARD RULES

1. **Detection only.** No auto-rotation, no auto-deletion, no auto-fix, no remediation commits. Ever.
2. **Redaction everywhere except VPS-local detail file.** Format: first 12 chars + `***`. The detail file at `findings/sweep-YYYY-MM-DD.md` is the ONLY place unredacted values are written, chmod 600, never pushed.
3. **`findings/` directory** is `.gitignored` and chmod 700. Detail files inside are chmod 600.
4. **Public-repo allowlist starts EMPTY.** Manual review only. Never auto-allowlist.
5. **Self-scan mandatory daily.** Sweeper scans its own `.env`, `requirements.txt`, `src/`, and verifies guardrail compliance.
6. **Baseline + diff alerting.** Telegram fires only on NEW vs baseline. Without this Walt gets spam every day.

---

## EMBEDDED-TOOL GUARDRAILS (NON-NEGOTIABLE)

Both `agentseal` and `mcp-audit` have prior telemetry concerns. We use them; we contain them.

### agentseal
- **Version:** `agentseal==0.8.1` exact pin in `requirements.txt`. Never `>=`.
- **Flags:** NEVER pass `--upload`. NEVER set `AGENTSEAL_API_URL` env var.
- **Firewall:** `scripts/install-firewall-guards.sh` adds `iptables -A OUTPUT -d <ip> -j REJECT` for current `agentseal.org` IPs, persisted via `iptables-save > /etc/iptables/rules.v4`.
- **Re-audit required** before any version bump.
- **Daily self-scan** verifies the version pin, the absence of `--upload` flags in any invocation, and the absence of `AGENTSEAL_API_URL` from environment.

### mcp-audit
- **Version:** `mcp-audit==1.0.0` exact pin.
- **Install path:** PyPI only. Never `git clone` the source repo (the cleaned demo files are not in the wheel, but the rule stands).
- **Firewall:** `iptables -A OUTPUT -d <ip> -j REJECT` for current `apisec.ai` IPs.
- **Re-audit required** before any version bump.

### Firewall rule maintenance

If either domain's IP rotates, re-run `scripts/install-firewall-guards.sh`. The script re-resolves and re-installs the rules. Walt is notified via Telegram if a sweep run detects a missing rule (sweeper checks iptables on every run as part of self-scan).

---

## FILE PERMISSIONS

| Path | Required |
|------|----------|
| `/home/walt/agents/agent-security-sweeper/.env` | 600 |
| `/home/walt/agents/agent-security-sweeper/findings/` | 700 |
| `/home/walt/agents/agent-security-sweeper/findings/*.md` | 600 |
| `/home/walt/.env` | 600 (verified by perms scanner) |
| `/home/walt/.gcp-sa-nova.json` | 600 |

---

## SCAN SCOPE LIMITS

Never scan:
- `/etc/shadow` content (only the `awk -F: '$2 == ""'` null-password check via subprocess)
- `/root/` or any other user's home directory
- Any directory not under `/home/walt/` (except the explicit checklist items in `vps.py`)

---

## OUTPUT CHANNELS — what's allowed where

| Channel | Unredacted values? | Notes |
|---------|--------------------|-------|
| `findings/sweep-YYYY-MM-DD.md` (VPS-local) | YES | chmod 600, .gitignored, never pushed |
| `nova-assistant/docs/SECURITY-SWEEP-LOG.md` (GitHub) | NO — redacted only | Counts + verdict + redacted prefixes |
| `walts-wiki/Walt's Wiki/Security Sweeps/*.md` | NO — counts only, no values | Shareable surface |
| Telegram | NO — counts only | Format: `🚨 Security sweeper — N HIGH, M CRITICAL findings. Check SECURITY-SWEEP-LOG.md.` |

---

## SUPPLY-CHAIN HARDENING

- All Python pins are exact (`==`), never `>=` or `~=`.
- Go binaries (`trufflehog`, `gitleaks`) installed via `scripts/install-binaries.sh` with SHA256 verification at pinned tag.
- `secrets-patterns-db` integration deferred to v2 — detect-secrets defaults cover v1 (`data/secrets-patterns-db/` ships placeholder README only).
- No auto-updates. Any version change requires a new build review.

---

## INCIDENT RESPONSE (if the sweeper itself finds itself compromised)

1. Self-scan flags guardrail drift → CRITICAL Telegram fires.
2. Daily log writes PARTIAL/FAIL status.
3. Walt manually reviews `findings/sweep-YYYY-MM-DD.md` for full unredacted detail.
4. The sweeper does NOT attempt remediation. Detection only.
