# ROADMAP — agent-security-sweeper

## v1 (current — 2026-05-12)

All 13 core scanners, baseline+diff alerting, daily + weekly cadence, self-scan, wiki write-back, Telegram on NEW HIGH/CRITICAL only.

## v2 (priority order)

1. **Full Notion workspace scan** beyond first run — paginated search across the entire workspace, not just last-24h modified.
2. **Dependency CVE scan** — `pip-audit` / `safety` for Python deps, `npm audit` for any Node deps. Walk every `requirements.txt` and `package.json` under `/home/walt/agents/`.
3. **Cloudflare API token audit** — read token list via CF API, flag any token older than rotation policy.
4. **MCP allowlist comparison** — compare live `~/.claude/settings.json` MCP servers against a curated allowlist. New servers = HIGH.
5. **Anomaly detection** — track file growth, disk fill rate, process count. Spike detection.
6. **OSQuery integration** (Feature Menu item 16) — structured host-state DB queries for richer detection. Deferred from v1 per Walt's approval gate.
7. **`secrets-patterns-db` integration** (Feature Menu item 2) — vendor at a reviewed commit SHA into `data/secrets-patterns-db/` and load the 1,600+ regex ruleset as detect-secrets custom plugins (or run a parallel native-regex pass in `filesystem.py`). Deferred from v1 after Pass 1 review (2026-05-12): detect-secrets defaults are sufficient for v1; lift when 30 days of baseline data shows which gaps actually matter.

## v3 (longer term)

- Active honeytoken deployment + monitoring
- Auto-rotate-suggest (still detection-only, but generates "rotate this key" PRs for Walt to merge)
- Multi-VPS support (if Walt's stack grows)
- Threat-intel feed integration (compare observed indicators against public IoC feeds)

## Will never do

- Auto-remediation in any form
- Push to non-Walt-controlled destinations
- Skip the self-scan
- Drop the baseline+diff model in favour of all-findings alerting
