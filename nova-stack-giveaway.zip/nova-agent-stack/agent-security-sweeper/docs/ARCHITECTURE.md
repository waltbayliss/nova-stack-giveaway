# ARCHITECTURE — agent-security-sweeper

## Layout

```
agent-security-sweeper/
├── CLAUDE.md
├── README.md
├── agent-memory.md
├── pending-rules.md
├── .env.example
├── requirements.txt
├── docs/                           # 8-doc Nova standard
│   ├── PRD.md
│   ├── ARCHITECTURE.md             # this file
│   ├── SOUL.md
│   ├── SECURITY.md
│   ├── ROADMAP.md
│   ├── DECISIONS.md                # includes Feature Integration Review
│   ├── SPRINT_LOG.md
│   └── agent-memory.md             # → linked, lives at repo root
├── skills/
│   ├── self-improve.md             # mandatory, fires after every run
│   ├── run-daily-sweep.md
│   ├── run-weekly-sweep.md
│   └── investigate-finding.md
├── wiki/
│   ├── Raw/                        # raw captures from self-improve
│   ├── Wiki/                       # synthesised learnings (≥3 confirms)
│   ├── Output/                     # external-facing outputs (wiki summaries)
│   └── Master/
│       └── master-context.md
├── src/
│   ├── sweep.py                    # top-level orchestrator
│   ├── finding.py                  # Finding dataclass
│   ├── baseline.py                 # baseline load/save/diff
│   ├── redact.py                   # redaction util
│   ├── github_writer.py            # curl-based log append
│   ├── telegram.py                 # nova-telegram worker call
│   ├── allowlist.yml               # known-good patterns + public-repo allowlist (EMPTY at build)
│   └── scanners/
│       ├── __init__.py
│       ├── filesystem.py
│       ├── git_history.py
│       ├── github_repos.py
│       ├── tracked_config.py       # tokens in tracked .claude/settings.json + MCP config (Session 76)
│       ├── perms.py
│       ├── mcp_audit.py
│       ├── ports.py
│       ├── processes.py
│       ├── ssh.py
│       ├── cron.py
│       ├── vps.py                  # 20-item VPS checklist
│       ├── notion.py
│       ├── framework_defaults.py   # weekly
│       ├── http_exposure.py        # weekly
│       ├── ai_agent_surface.py     # agentseal daily, OFFLINE
│       └── self_scan.py
├── scripts/
│   ├── bootstrap.sh
│   ├── install-cron.sh
│   ├── install-binaries.sh         # SHA256-verified trufflehog + gitleaks
│   └── install-firewall-guards.sh  # iptables REJECT for agentseal.org + apisec.ai
├── data/
│   └── secrets-patterns-db/        # v2 deferral (README placeholder only — detect-secrets defaults cover v1)
└── findings/                       # chmod 600, NEVER pushed (.gitignored)
    ├── baseline.json
    ├── notion-first-run-complete.flag
    └── sweep-YYYY-MM-DD.md         # daily detail file (unredacted)
```

## Data flow

```
cron (UTC)
   │
   ▼
src/sweep.py --mode {daily|weekly}
   │
   ├─ boot checks: guardrails (agentseal version, mcp-audit version,
   │   firewall rules, --upload absent, chmod 600 on findings/)
   │
   ├─ for each scanner in mode:
   │     run scan() → list[Finding]
   │     catch per-scanner exceptions, continue
   │
   ├─ aggregate findings
   ├─ diff vs baseline.json → mark each as NEW or KNOWN
   ├─ write unredacted detail → findings/sweep-YYYY-MM-DD.md (chmod 600)
   ├─ build redacted summary
   ├─ append summary to nova-assistant docs/SECURITY-SWEEP-LOG.md (curl PUT)
   ├─ write wiki summary to walts-wiki Walt's Wiki/Security Sweeps/YYYY-MM-DD-sweep-summary.md
   ├─ if NEW HIGH or NEW CRITICAL > 0: fire Telegram
   ├─ update baseline.json
   └─ run skills/self-improve.md
```

## Scanner contract

Every file in `src/scanners/` exposes:

```python
from src.finding import Finding

def scan(mode: str = "daily") -> list[Finding]:
    """
    mode: 'daily' | 'weekly' | 'full-notion-first-run'
    Returns list of Finding objects.
    Must catch its own exceptions and return a CRITICAL Finding with
    scanner-crash details rather than raising.
    """
```

## Finding dataclass

```python
@dataclass
class Finding:
    severity: str             # CRITICAL | HIGH | MEDIUM | LOW
    scanner: str              # e.g. 'filesystem', 'ssh'
    target: str               # filepath or identifier
    line_ref: str | None      # 'L42' or None
    description: str          # short, terse
    redacted_value: str | None  # 'sk-or-v1-abc***' or None
    full_value: str | None    # ONLY written to findings/sweep-*.md; redacted everywhere else
    fingerprint: str          # deterministic hash for baseline matching
    baseline_known: bool      # set by baseline diff
```

## Baseline / diff

Each scanner contributes to `findings/baseline.json`:

```json
{
  "filesystem": {
    "fingerprints": ["sha256:...", "sha256:..."],
    "last_updated": "2026-05-12T17:30:00Z"
  },
  "git_history": { ... }
}
```

Fingerprint = sha256 of `scanner|target|line_ref|description`. Telegram fires only on fingerprints not present in baseline.

## Wiki write — per-run summary (mandatory per Rule 8)

Every successful run writes:

- **File:** `walts-wiki/Walt's Wiki/Security Sweeps/YYYY-MM-DD-sweep-summary.md`
- **Content:** counts by severity, clean/dirty verdict, last-run timestamp, NO credential values
- **Trigger:** end of every `src/sweep.py` run (daily + weekly)
- **Mechanism:** curl PUT to GitHub Contents API on `waltbayliss/walts-wiki`

Weekly rollup also written: `YYYY-WW-weekly-rollup.md` (trends + recurring findings).

## External integrations

| Surface | Mechanism |
|---------|-----------|
| GitHub API | curl + PAT from `/home/walt/.env` (canonical VPS pattern) |
| Filesystem | direct read of `/home/walt/` |
| Shell tools | subprocess to `ss`, `ps`, `crontab`, `git`, `stat`, `find`, `awk`, `journalctl`, `last`, `lastb` |
| Cloudflare Worker (nova-telegram) | HTTP POST for HIGH/CRITICAL alerts |
| Notion API | `notion-client` library |
| Pinned binaries | trufflehog, gitleaks installed via `scripts/install-binaries.sh` |
| Python tools | detect-secrets, badsecrets, mcp-audit, agentseal, snallygaster (pip) |

## Failure isolation

One scanner crash does not stop the sweep. Each scanner's exception is caught, logged as a CRITICAL "scanner crash" Finding, and the orchestrator continues. PARTIAL status flagged in daily log.
