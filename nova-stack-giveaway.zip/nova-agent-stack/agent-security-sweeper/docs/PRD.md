# PRD — agent-security-sweeper

**Status:** v1, built 2026-05-12.
**Source of truth:** the upgraded PRD lives at `waltbayliss/nova-assistant/pending-builds/agent-security-sweeper-reviewed.md`. This file mirrors the binding spec for in-repo reading.

---

## Purpose (one line)

Daily autonomous security sweep across Walt's entire AI stack — VPS files, GitHub repos, agent code, configs, Notion/wiki content, processes, ports, MCP surface — using a baseline+diff model so Telegram fires ONLY on new HIGH/CRITICAL findings. Detection-only. Never auto-remediate.

---

## Why this exists (gap analysis)

- `agent-security` is a reactive bouncer at the gate. It vets new external additions but does NOT sweep existing surface area.
- `agent-auditor` is structure-focused (registry drift, doc compliance). It does NOT deep-scan for leaked secrets, vulns, or suspicious files.
- `agent-backup` protects against data loss but does NOT detect compromise.
- **Gap:** no proactive, daily, security-focused sweep of the surface area we already trust. 7-day cadence is too slow if a credential leaks. Daily catches it within 24h.

---

## Core functions (v1)

1. **Filesystem secrets scan** — `detect-secrets` (defaults — covers AWS/GitHub/Slack/Stripe/JWT/private-key/high-entropy) across `/home/walt/agents/`, `/home/walt/.claude/`, dotfiles. Baseline-driven. `secrets-patterns-db` extended ruleset deferred to v2 (defaults are sufficient for v1 — see ROADMAP).
2. **GitHub repos scan** — list `waltbayliss/*`, detect `.env`/`*.key`/`*.pem` in trees, recent-commit secret scan, public/private visibility audit (empty allowlist = any public agent-* repo is HIGH).
3. **Git history** — `gitleaks` working tree daily, full history weekly, TruffleHog `--only-verified` weekly.
4. **File permissions** — `.env`, `.gcp-sa-nova.json`, SSH keys must be 600; world-writable files flagged.
5. **MCP / config audit** — `mcp-audit` against `~/.claude/settings.json` and all `.mcp.json` files; literal token values in env blocks → HIGH.
6. **Framework-default-keys** — `badsecrets` weekly across agent `src/` dirs.
7. **VPS 20-item checklist** — pure Python: kernel, listeners, world-writable, SUID/SGID, null passwords, sysctl, SSH config, failed logins, cron, UID 0 users, services-as-root, dotfile secrets, agent drift via `git status`, etc.
8. **Ports & processes** — `ss -tlnp` diff, `ps auxf` against known-good, crontab inventory.
9. **SSH** — `authorized_keys` enumerated with fingerprints, recent SSH logins from `auth.log` checked against rolling allowlist.
10. **Notion / wiki credential scan** — `notion-client` + `detect-secrets`. First run = full workspace. Subsequent = last-24h modified pages.
11. **HTTP exposure (weekly)** — `snallygaster` against `[your-public-domain]`.
12. **Self-scan (mandatory)** — sweeper scans its own `.env`, `requirements.txt`, `src/`; verifies guardrail compliance (agentseal version, firewall rules, `--upload` absent).
13. **AI agent surface (daily)** — `agentseal` guard mode (OFFLINE, no `--upload`) against `skills/` directories.

---

## Severity rubric

| Severity | Definition | Telegram? | Log? |
|----------|------------|-----------|------|
| CRITICAL | Live credential exposed in git, world-readable, public repo, verified by TruffleHog, guardrail violation | YES, immediate | YES |
| HIGH | Plaintext credential access-restricted; unexpected port; unknown SSH key; baseline drift on high-value scanner | YES | YES |
| MEDIUM | Permission too loose; rotated old secret in history; unfamiliar process; unknown package | NO | YES |
| LOW | Informational, baseline noise, reference data | NO | YES |

**Baseline + diff:** Telegram fires only when something has changed since last run. Per-scanner `baseline.json` files maintained.

---

## Cadence

- **Daily light** — `30 17 * * *` UTC (3:30am Brisbane). All cheap scanners.
- **Weekly heavy** — `0 19 * * 0` UTC (5am Brisbane Mon). Adds: gitleaks full history, trufflehog verified, badsecrets, snallygaster.

---

## Output

- **VPS-local detail** (unredacted, chmod 600, never pushed): `findings/sweep-YYYY-MM-DD.md`
- **GitHub log (redacted):** `waltbayliss/nova-assistant/docs/SECURITY-SWEEP-LOG.md`
- **Wiki summary:** `waltbayliss/walts-wiki/Walt's Wiki/Security Sweeps/YYYY-MM-DD-sweep-summary.md`
- **Telegram (on NEW HIGH/CRITICAL only):** redacted summary

**Redaction format:** first 12 chars + `***`. Applied everywhere except VPS-local detail file.

---

## Walt-approved overrides (binding)

See `docs/DECISIONS.md` — these override anything else in this PRD where they conflict.

1. Cron: `30 17 * * *` daily, `0 19 * * 0` weekly (UTC).
2. Findings detail at `/home/walt/agents/agent-security-sweeper/findings/`, chmod 600.
3. Notion: first-run-full → flag → 24h-delta after.
4. Public-repo allowlist: starts EMPTY, manual review only.
5. agentseal: `==0.8.1`, no `--upload`, no `AGENTSEAL_API_URL`, iptables REJECT for `agentseal.org`.
6. mcp-audit: `==1.0.0`, PyPI only, iptables REJECT for `apisec.ai`.

---

## Hard rules — never do these

1. Never auto-rotate, auto-delete, or auto-fix. Detection only.
2. Never push remediation commits.
3. Never include actual credential values in SECURITY-SWEEP-LOG.md, walts-wiki, or Telegram.
4. Never scan outside Walt's expected surface (no `/etc/shadow` content, no other users' homes, no `/root/`).
5. Never exfiltrate findings off-VPS except via Telegram (summary only) and GitHub (redacted only).
6. Never skip self-scan.
7. Never auto-allowlist any public repo.

---

## Definition of done (v1)

- [x] All 13 scanner modules implemented
- [x] `src/sweep.py` orchestrator with `--mode daily | weekly | full-notion-first-run | --scanner NAME`
- [x] Baseline files initialised on first run for every baseline-driven scanner
- [x] `src/allowlist.yml` initialised EMPTY
- [x] `scripts/install-cron.sh` idempotent
- [x] `scripts/install-firewall-guards.sh` adds REJECT rules for agentseal.org + apisec.ai
- [x] `scripts/install-binaries.sh` SHA256-verifies pinned trufflehog + gitleaks
- [x] `scripts/bootstrap.sh` orchestrates pip install + binaries + firewall (optional) + cron (optional) + chmod 600 findings/
- [x] All 8 Nova-standard docs + CLAUDE.md + skills + wiki + .env.example
- [x] Self-scan runs and passes
- [x] Daily mode end-to-end smoke test
- [ ] Pass 1 + Pass 2 code review (pending)
- [ ] Registered in `docs/AGENT-REGISTRY.md` (pending sign-off)

---

## v2 backlog

1. Full Notion workspace scan beyond first run (paginated search)
2. Dependency CVE scan (`pip-audit`, `safety`, `npm audit`)
3. Cloudflare token age audit
4. MCP allowlist comparison vs live installed set
5. Anomaly detection (file growth, disk fill, abnormal process count)
6. OSQuery integration (Feature Menu item 16)
