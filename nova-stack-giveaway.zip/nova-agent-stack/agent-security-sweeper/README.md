# agent-security-sweeper

Daily autonomous security sweep across Walt's AI stack — VPS files, GitHub repos, agent code, configs, Notion content, processes, ports, MCP surface. **Detection-only. Baseline+diff alerting. Never auto-remediates.**

## Quick start

```bash
cd /home/walt/agents/agent-security-sweeper
bash scripts/bootstrap.sh                  # pip install + pinned binaries + chmod 600 on findings/
# REVIEW + APPROVE before installing firewall and cron:
sudo bash scripts/install-firewall-guards.sh   # iptables REJECT for agentseal.org + apisec.ai
bash scripts/install-cron.sh                   # idempotent cron install for walt
python3 src/sweep.py --mode daily --dry-run    # smoke test (no GitHub/Telegram writes)
python3 src/sweep.py --mode daily              # real run
```

## Modes

| Mode | Command |
|------|---------|
| Daily light | `python3 src/sweep.py --mode daily` |
| Weekly heavy | `python3 src/sweep.py --mode weekly` |
| Single scanner | `python3 src/sweep.py --scanner filesystem` |
| First Notion run | `python3 src/sweep.py --mode full-notion-first-run` |
| Dry run (no writes) | `python3 src/sweep.py --mode daily --dry-run` |

## Cron schedule (UTC)

```
30 17 * * *   /usr/bin/python3 /home/walt/agents/agent-security-sweeper/src/sweep.py --mode daily
0 19 * * 0    /usr/bin/python3 /home/walt/agents/agent-security-sweeper/src/sweep.py --mode weekly
```

3:30am Brisbane (after agent-backup at 3am). Weekly heavy on Mondays at 5am Brisbane.

## Output

- **Unredacted detail** → `/home/walt/agents/agent-security-sweeper/findings/sweep-YYYY-MM-DD.md` (chmod 600, **never pushed to GitHub**)
- **Redacted log** → `waltbayliss/nova-assistant/docs/SECURITY-SWEEP-LOG.md`
- **Wiki summary** → `waltbayliss/walts-wiki/Walt's Wiki/Security Sweeps/YYYY-MM-DD-sweep-summary.md`
- **Telegram** → fires only on NEW HIGH/CRITICAL findings vs baseline

## Embedded-tool guardrails (NON-NEGOTIABLE)

- `agentseal==0.8.1` — never `--upload`, never set `AGENTSEAL_API_URL`. Firewall: `agentseal.org` REJECTED.
- `mcp-audit==1.0.0` — PyPI install only, never `git clone`. Firewall: `apisec.ai` REJECTED.
- Re-audit before any version bump.

## Public-repo allowlist

`src/allowlist.yml` starts **EMPTY**. Any new intentionally-public repo must be manually reviewed and explicitly added. Never auto-allowlist. If a public repo is found without an allowlist entry → HIGH severity.

## Firewall rule maintenance

If `agentseal.org` or `apisec.ai` IPs change, re-run `scripts/install-firewall-guards.sh`. See `docs/SECURITY.md` for rationale.

## Self-scan

Every daily run scans this agent's own `.env`, `requirements.txt`, and `src/`. Any guardrail drift = CRITICAL → Telegram.
