# secrets-patterns-db (vendored)

This directory will hold the vendored `secrets-patterns-db` ruleset pinned at a specific commit SHA, loaded by `src/scanners/filesystem.py` as a detect-secrets custom plugin.

## How to vendor (one-time, manual review required)

```bash
cd data/
git clone https://github.com/mazen160/secrets-patterns-db.git
cd secrets-patterns-db
# Pin to a reviewed commit. Update the line below after security review.
git checkout <REVIEWED_COMMIT_SHA>
rm -rf .git

*(Real entries removed for public distribution — this file's role in the structure is preserved, its history is not.)*
