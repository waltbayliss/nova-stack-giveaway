# Skill: Model Routing
## agent-openrouter-optimizer

This skill defines the full logic for complexity scoring and model selection. It is the core operational skill of the optimizer.

---

## Complexity Scoring

### Step 1: Establish base score from task keywords

Scan the task description for signal words:

**Score 1 (Trivial)** — signals: `format`, `convert`, `replace`, `echo`, `lookup`, `list all`, `count`, `what is`, `when is`, `who is`, `translate`

**Score 2 (Simple)** — signals: `summarise`, `summarize`, `extract`, `classify`, `categorise`, `tag`, `identify`, `find`, `compare two`, `bullet points`

**Score 3 (Medium)** — signals: `draft`, `write a`, `create a`, `explain`, `describe`, `outline`, `analyse`, `analyze`, `review`, `improve`, `suggest`, `multi-step`

**Score 4 (Moderately Complex)** — signals: `design`, `evaluate`, `assess`, `plan`, `strategy`, `architecture`, `implement`, `build`, `develop`, `debug`, `refactor`, `optimise`, `optimize`, `code`

**Score 5 (Complex)** — signals: `reason through`, `deeply analyse`, `comprehensive`, `long document`, `entire codebase`, `across multiple`, `synthesise`, `synthesize`, `argue`, `make the case`, `first principles`

### Step 2: Apply context token modifier

| Context Token Count | Score Modifier |
|---------------------|----------------|
| < 500 | -1 (minimum 1) |
| 500 – 2,000 | +0 |
| 2,001 – 4,000 | +1 |
| 4,001 – 8,000 | +1 |
| > 8,000 | +2 (maximum 5) |

### Step 3: Apply agent minimum tier

Certain agents in the Nova ecosystem carry a minimum model tier:

| Agent ID | Minimum Score |
|----------|---------------|
| `agent-strategist` | 4 |
| `agent-coder` | 4 |
| `agent-architect` | 4 |
| `agent-researcher` | 3 |
| `agent-writer` | 3 |
| `agent-summariser` | 2 |
| `agent-formatter` | 1 |
| `nova-assistant` | 3 |

For agents not listed, no minimum applies.

### Step 4: Apply explicit override

If `min_model_tier` is passed in the route request, the final score is:
```
final_score = max(base_score + context_modifier, agent_minimum, min_model_tier)
final_score = min(final_score, 5)  # cap at 5
```

---

## Model Selection

Given `final_score`, select the model:

```python
def select_model(score: int, ollama_available: bool) -> RoutingDecision:
    if score <= 2:
        if ollama_available:
            return RoutingDecision(
                model=OLLAMA_DEFAULT_MODEL,
                provider="ollama",
                reason=f"Score {score}: trivial/simple task, Ollama local"
            )
        else:
            return RoutingDecision(
                model="anthropic/claude-haiku-4-5-20251001",
                provider="openrouter",
                reason=f"Score {score}: Ollama unavailable, falling back to Haiku",
                fallback=True
            )
    
    elif score == 3:
        return RoutingDecision(
            model="anthropic/claude-haiku-4-5-20251001",
            provider="openrouter",
            reason="Score 3: medium complexity, Haiku sufficient"
        )
    
    elif score == 4:
        return RoutingDecision(
            model="anthropic/claude-sonnet-4-6",
            provider="openrouter",
            reason="Score 4: moderately complex, Sonnet required"
        )
    
    elif score == 5:
        return RoutingDecision(
            model="anthropic/claude-opus-4-6",
            provider="openrouter",
            reason="Score 5: complex reasoning, Opus required"
        )
```

---

## Cost Estimation

Pre-call cost estimate (used for logging and alert checking):

```python
# Approximate pricing per 1M tokens (input/output), update when OpenRouter prices change
MODEL_PRICING = {
    "ollama_local": {"input": 0.0, "output": 0.0},
    "anthropic/claude-haiku-4-5-20251001": {"input": 0.80, "output": 4.00},
    "anthropic/claude-sonnet-4-6": {"input": 3.00, "output": 15.00},
    "anthropic/claude-opus-4-6": {"input": 15.00, "output": 75.00},
    "openai/gpt-4o": {"input": 2.50, "output": 10.00},
    "google/gemini-flash-1.5": {"input": 0.075, "output": 0.30},
}

def estimate_cost(model: str, tokens_in: int, tokens_out_estimate: int) -> float:
    pricing = MODEL_PRICING.get(model, {"input": 0.01, "output": 0.01})
    input_cost = (tokens_in / 1_000_000) * pricing["input"]
    output_cost = (tokens_out_estimate / 1_000_000) * pricing["output"]
    return round(input_cost + output_cost, 6)
```

---

## Routing Examples

| Task | Tokens | Agent | Score | Model Selected |
|------|--------|-------|-------|----------------|
| "Format this CSV as a table" | 200 | `agent-formatter` | 1 | Ollama |
| "Summarise this article" | 800 | `agent-summariser` | 2 | Ollama |
| "Draft a reply to this email" | 600 | `agent-writer` | 3 | Claude Haiku |
| "Analyse this codebase for security issues" | 4500 | `agent-coder` | 5 | Claude Opus |
| "Write a 500-word blog post on AI trends" | 300 | `agent-writer` | 3 | Claude Haiku |
| "Design the database schema for Nova" | 1200 | `agent-architect` | 4 | Claude Sonnet |
| "Explain quantum entanglement simply" | 100 | any | 3 | Claude Haiku |

---

## Edge Cases

**Empty task description:** Default to score 3 (safer to over-provision than under-provision on unknown tasks).

**Very long context (>100k tokens):** Force score 5, use Opus. Only Opus has the context window for this.

**Score ties between agent minimum and heuristic:** Always take the higher score. When in doubt, route up.

**Task type = "code":** Add +1 to the heuristic score. Code generation is consistently harder than it looks from the description alone.
