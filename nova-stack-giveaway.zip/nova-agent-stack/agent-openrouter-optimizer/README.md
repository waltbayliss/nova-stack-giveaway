# agent-openrouter-optimizer

> Nova middleware router. Classifies task complexity (1–5), selects the optimal model from the priority chain, injects it at runtime. Agents are model-agnostic — the optimizer decides the model.

---

## What It Does

Every time Nova dispatches a task to a downstream agent, the request passes through this optimizer first:

1. **Classify** — analyse the task intent and assign a complexity score (1–5)
2. **Route** — map score + task type to the optimal model in the priority chain
3. **Inject** — return the selected model config to Nova for runtime injection
4. **Log** — record agent, model, tokens in/out, cost, latency, and complexity score
5. **Alert** (when needed) — surface cost spikes, fallbacks, or Ollama outages to Nova

---

## Priority Chain

| Priority | Model | Use Case |
|----------|-------|----------|
| 1 (cheapest) | Ollama local | Complexity 1–2: trivial tasks, free |
| 2 | Claude Haiku / Gemini Flash | Complexity 3: fast cloud tasks |
| 3 | Claude Sonnet | Complexity 3–4: moderate reasoning |
| 4 | Claude Opus / GPT-4o | Complexity 4–5: heavy reasoning |
| Fallback | Cloud escalation | Ollama down or slow → auto-escalate |

---

## How to Invoke

Nova calls the optimizer before every agent task dispatch:

```python
# Nova calls the optimizer
result = optimizer.route(
    task_description="Summarise this document and extract key action items",
    agent_id="agent-summariser",
    context_tokens=1200
)

# result contains:
# {
#   "model": "claude-haiku-4-5-20251001",
#   "provider": "openrouter",
#   "complexity_score": 3,
#   "routing_reason": "Medium complexity summarisation task",
#   "estimated_cost_usd": 0.0008
# }
```

---

## Environment Variables

See `.env.example` for all required secrets. Copy to `.env` and populate before running.

```bash
cp .env.example .env
# populate with your actual keys
```

---

## Project Docs

Full documentation lives in `/docs`:

| File | Contents |
|------|----------|
| `docs/PRD.md` | Product requirements, full capability spec |
| `docs/ARCHITECTURE.md` | System design, routing logic, data flow |
| `docs/SOUL.md` | Personality, values, decision principles |
| `docs/SECURITY.md` | Hard rules, secret management |
| `docs/ROADMAP.md` | Phase 1–3 plan |
| `docs/DECISIONS.md` | Technical decision log |
| `docs/SPRINT_LOG.md` | Session history |

---

## North Star

> Do more without spending more. Every token saved is margin gained. Quality is non-negotiable — route to the RIGHT model, not just cheapest. Balance = faster path to $1M/year.

---

*Part of the Nova agent ecosystem — [waltbayliss/nova-assistant](https://github.com/waltbayliss/nova-assistant)*
