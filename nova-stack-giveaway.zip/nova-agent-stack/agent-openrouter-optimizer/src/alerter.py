"""
Alert evaluator for the OpenRouter Optimizer.

Centralises all threshold-checking logic that was previously scattered across
optimizer.py. Produces a structured list of alert objects that optimizer.py
can print with the [NOVA-ALERT] prefix, and formats them into Telegram-ready
messages for Nova to forward to Walt.

Alert levels:
    warn     — approaching a threshold (≥ 80% of limit). Worth watching.
    critical — threshold breached. Action required.

Alert structure:
    {
        "level":   "warn" | "critical",
        "metric":  str,       # machine-readable metric name
        "message": str,       # human-readable description
        "value":   float,     # current metric value
        "threshold": float,   # the limit that was (or is near) being crossed
    }

Public API:
    check_alerts(stats, thresholds, context)  → list[dict]
    format_for_nova(alerts)                   → str
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from . import optimizer_memory as _memory

# ---------------------------------------------------------------------------
# Default thresholds (all overridable via the thresholds dict argument)
# ---------------------------------------------------------------------------

_DEFAULTS: Dict[str, float] = {
    "cost_daily_usd":        5.00,
    "cost_single_usd":       0.50,
    "fallback_rate_pct":     30.0,
    "min_quality_score":     2.5,   # avg quality below this → alert
    "ollama_failure_streak": 3.0,   # consecutive failures (passed via context)
}

# Fraction of a threshold that triggers a "warn" vs "critical"
_WARN_FRACTION = 0.80


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _threshold(key: str, overrides: Dict[str, float]) -> float:
    return overrides.get(key, _DEFAULTS[key])


def _check_cost_daily(
    daily_cost: float,
    current_call_cost: float,
    limit: float,
) -> Optional[Dict[str, Any]]:
    projected = daily_cost + current_call_cost
    if projected <= 0:
        return None
    pct = projected / limit
    if pct >= 1.0:
        return {
            "level": "critical",
            "metric": "daily_cost_usd",
            "message": (
                f"Daily spend has exceeded ${limit:.2f} — "
                f"current total ${projected:.4f}"
            ),
            "value": round(projected, 4),
            "threshold": limit,
        }
    if pct >= _WARN_FRACTION:
        return {
            "level": "warn",
            "metric": "daily_cost_usd",
            "message": (
                f"Daily spend at ${projected:.4f} "
                f"({pct:.0%} of ${limit:.2f} limit)"
            ),
            "value": round(projected, 4),
            "threshold": limit,
        }
    return None


def _check_single_call_cost(
    current_call_cost: float,
    limit: float,
    agent_name: str,
    model: str,
) -> Optional[Dict[str, Any]]:
    if current_call_cost <= 0:
        return None
    if current_call_cost > limit:
        return {
            "level": "critical",
            "metric": "single_call_cost_usd",
            "message": (
                f"Single call cost ${current_call_cost:.4f} — "
                f"{agent_name} using {model}"
            ),
            "value": round(current_call_cost, 4),
            "threshold": limit,
        }
    return None


def _check_fallback_rate(
    rate_pct: float,
    total_calls: int,
    limit: float,
) -> Optional[Dict[str, Any]]:
    # Don't alert on tiny sample sizes — noise, not signal
    if total_calls < 5:
        return None
    pct_of_limit = rate_pct / limit if limit > 0 else 0
    if pct_of_limit >= 1.0:
        return {
            "level": "critical",
            "metric": "fallback_rate_pct",
            "message": (
                f"Fallback rate is {rate_pct:.1f}% "
                f"(limit {limit:.0f}%) — check Ollama health"
            ),
            "value": rate_pct,
            "threshold": limit,
        }
    if pct_of_limit >= _WARN_FRACTION:
        return {
            "level": "warn",
            "metric": "fallback_rate_pct",
            "message": (
                f"Fallback rate climbing: {rate_pct:.1f}% "
                f"(limit {limit:.0f}%)"
            ),
            "value": rate_pct,
            "threshold": limit,
        }
    return None


def _check_ollama_streak(
    streak: int,
    limit: float,
) -> Optional[Dict[str, Any]]:
    if streak <= 0:
        return None
    if streak >= limit:
        return {
            "level": "critical",
            "metric": "ollama_failure_streak",
            "message": (
                f"Ollama appears to be down — "
                f"{int(streak)} consecutive failures, all tasks routing to cloud"
            ),
            "value": float(streak),
            "threshold": limit,
        }
    return None


def _check_quality_trend(
    min_quality: float,
) -> Optional[Dict[str, Any]]:
    """
    Pull the recent quality average from optimizer_memory and alert if it has
    fallen below the minimum threshold.
    """
    avg = _memory.get_recent_quality_avg(window=20)
    if avg is None:
        return None  # no outcome data yet
    if avg < min_quality:
        return {
            "level": "warn" if avg >= min_quality * 0.85 else "critical",
            "metric": "quality_score_avg",
            "message": (
                f"Recent output quality avg is {avg:.1f}/5 "
                f"(below threshold {min_quality:.1f}) — "
                "review routing assignments"
            ),
            "value": avg,
            "threshold": min_quality,
        }
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check_alerts(
    stats: Dict[str, Any],
    thresholds: Dict[str, float],
    context: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    Evaluate all alert conditions against current stats and return every
    triggered alert as a list. Returns an empty list if all clear.

    Args:
        stats:      Daily summary dict from logger.get_stats(). Expected keys:
                        total_cost_usd, fallback_rate_pct, total_calls.
        thresholds: Override dict for any threshold in _DEFAULTS.
                    Typically built from env vars in optimizer.py.
        context:    Optional per-call context dict. Expected keys:
                        current_call_cost (float): estimated cost of this call.
                        agent_name (str): calling agent.
                        model (str): model selected for this call.
                        ollama_failure_streak (int): consecutive Ollama failures.

    Returns:
        List of alert dicts, ordered: critical first, then warn.
        Each dict has: level, metric, message, value, threshold.
    """
    ctx = context or {}
    alerts: List[Dict[str, Any]] = []

    daily_cost = float(stats.get("total_cost_usd", 0.0))
    fallback_rate = float(stats.get("fallback_rate_pct", 0.0))
    total_calls = int(stats.get("total_calls", 0))
    current_call_cost = float(ctx.get("current_call_cost", 0.0))
    agent_name = str(ctx.get("agent_name", "unknown"))
    model = str(ctx.get("model", "unknown"))
    ollama_streak = float(ctx.get("ollama_failure_streak", 0))

    # Single-call cost spike (checked before daily total — more urgent)
    a = _check_single_call_cost(
        current_call_cost,
        _threshold("cost_single_usd", thresholds),
        agent_name,
        model,
    )
    if a:
        alerts.append(a)

    # Daily spend
    a = _check_cost_daily(
        daily_cost,
        current_call_cost,
        _threshold("cost_daily_usd", thresholds),
    )
    if a:
        alerts.append(a)

    # Fallback rate
    a = _check_fallback_rate(
        fallback_rate,
        total_calls,
        _threshold("fallback_rate_pct", thresholds),
    )
    if a:
        alerts.append(a)

    # Ollama consecutive failure streak
    a = _check_ollama_streak(
        ollama_streak,
        _threshold("ollama_failure_streak", thresholds),
    )
    if a:
        alerts.append(a)

    # Quality score trend (reads from optimizer_memory — non-blocking)
    try:
        a = _check_quality_trend(_threshold("min_quality_score", thresholds))
        if a:
            alerts.append(a)
    except Exception:
        pass  # never let a memory read failure block alert processing

    # Sort: critical first
    alerts.sort(key=lambda x: 0 if x["level"] == "critical" else 1)
    return alerts


def format_for_nova(alerts: List[Dict[str, Any]]) -> str:
    """
    Format a list of alert dicts into a clean Telegram message for Nova to
    forward to Walt. Returns an empty string if no alerts.

    Critical alerts are prefixed with 🔴, warnings with 🟡.

    Args:
        alerts: List of alert dicts from check_alerts().

    Returns:
        Telegram-ready plain-text string, or "" if alerts is empty.
    """
    if not alerts:
        return ""

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines: List[str] = [f"⚠️ *Nova Optimizer Alerts* — {now}", ""]

    for alert in alerts:
        icon = "🔴" if alert["level"] == "critical" else "🟡"
        lines.append(f"{icon} {alert['message']}")

    lines.append("")
    lines.append(f"_{len(alerts)} alert(s) — review optimizer dashboard_")

    return "\n".join(lines)
