"""
Call logger for the OpenRouter Optimizer.

Every routing decision is written to a local append-only JSONL file at
~/.nova/optimizer_log.jsonl (overridable via LOG_FILE_PATH env var).

The file is the source of truth for cost tracking and alert checks.
Notion is a secondary destination — handled separately in notion_writer.py.

Log entry schema:
    call_id             — UUID (primary key)
    timestamp           — ISO 8601 UTC string
    agent_name          — Calling agent identifier
    task_type           — Optional task type hint
    task_complexity     — Score 1–5
    model_selected      — Model identifier string
    provider            — "ollama" | "openrouter"
    tokens_in           — Input token count (pre-call estimate or actual)
    tokens_out          — Output token count (0 until log_completion() called)
    cost_usd            — Estimated or actual cost
    latency_ms          — End-to-end latency (0 until log_completion() called)
    fallback_used       — bool
    fallback_reason     — str | null
    alert_triggered     — bool
    notes               — Rationale string from scorer
"""
from __future__ import annotations

import json
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import get

# ---------------------------------------------------------------------------
# Log file location
# ---------------------------------------------------------------------------

_DEFAULT_LOG_PATH = Path.home() / ".nova" / "optimizer_log.jsonl"
LOG_FILE_PATH = Path(get("LOG_FILE_PATH") or str(_DEFAULT_LOG_PATH))


def _ensure_dir() -> None:
    """Create the log directory if it does not exist."""
    LOG_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Write / update
# ---------------------------------------------------------------------------

def write(entry: Dict[str, Any]) -> str:
    """
    Append a routing decision entry to the JSONL log.

    A call_id and timestamp are injected automatically if not already present.

    Args:
        entry: Routing decision fields (see module docstring for schema).

    Returns:
        call_id (str): UUID assigned to this log entry.
    """
    _ensure_dir()

    if "call_id" not in entry:
        entry["call_id"] = str(uuid.uuid4())
    if "timestamp" not in entry:
        entry["timestamp"] = _utc_now()

    with open(LOG_FILE_PATH, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")

    return entry["call_id"]


def update(call_id: str, updates: Dict[str, Any]) -> bool:
    """
    Merge updated fields into an existing log entry identified by call_id.

    This rewrites the entire file. It is intended for the low-frequency
    post-execution update (tokens_out + latency_ms), not high-throughput use.

    Args:
        call_id: UUID of the entry to update.
        updates: Fields to merge into the existing entry.

    Returns:
        True if the entry was found and updated, False if not found.
    """
    _ensure_dir()
    if not LOG_FILE_PATH.exists():
        return False

    lines = LOG_FILE_PATH.read_text(encoding="utf-8").splitlines()
    found = False
    new_lines: List[str] = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        try:
            record = json.loads(stripped)
        except json.JSONDecodeError:
            new_lines.append(stripped)
            continue
        if record.get("call_id") == call_id:
            record.update(updates)
            found = True
        new_lines.append(json.dumps(record))

    LOG_FILE_PATH.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    return found


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

def _read_all() -> List[Dict[str, Any]]:
    """Read and parse every entry in the log. Returns an empty list if absent."""
    if not LOG_FILE_PATH.exists():
        return []

    records: List[Dict[str, Any]] = []
    for line in LOG_FILE_PATH.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

def get_stats(day: Optional[str] = None) -> Dict[str, Any]:
    """
    Return a summary of routing decisions for a given UTC day.

    Designed to be called frequently (e.g. on every routing decision for
    alert checking) so it must be fast. File size grows ~200 bytes per call;
    at 1000 calls/day the file stays well under 1 MB.

    Args:
        day: ISO date string "YYYY-MM-DD". Defaults to today (UTC).

    Returns:
        Dict with:
            date (str):                   The day summarised.
            total_calls (int):            Number of routing decisions.
            total_cost_usd (float):       Sum of cost_usd across all entries.
            fallback_count (int):         Entries where fallback_used is True.
            fallback_rate_pct (float):    fallback_count / total_calls * 100.
            model_distribution (dict):    {model_string: call_count}.
            alert_triggered_count (int):  Entries where alert_triggered is True.
    """
    target_day = day or datetime.now(timezone.utc).date().isoformat()
    records = _read_all()

    day_records = [
        r for r in records
        if str(r.get("timestamp", "")).startswith(target_day)
    ]

    total_calls = len(day_records)
    total_cost = sum(r.get("cost_usd", 0.0) for r in day_records)
    fallback_count = sum(1 for r in day_records if r.get("fallback_used", False))
    alert_count = sum(1 for r in day_records if r.get("alert_triggered", False))

    model_dist: Dict[str, int] = defaultdict(int)
    for r in day_records:
        model_dist[r.get("model_selected", "unknown")] += 1

    fallback_rate = (fallback_count / total_calls * 100) if total_calls else 0.0

    return {
        "date": target_day,
        "total_calls": total_calls,
        "total_cost_usd": round(total_cost, 6),
        "fallback_count": fallback_count,
        "fallback_rate_pct": round(fallback_rate, 1),
        "model_distribution": dict(model_dist),
        "alert_triggered_count": alert_count,
    }
