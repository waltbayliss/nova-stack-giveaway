"""
Notion writer for the OpenRouter Optimizer.

Writes every completed routing decision to the `🤖 OpenRouter Usage`
database in Walt's Nova HQ Notion workspace.

Design constraints:
- Never blocks the optimizer pipeline. All public functions are safe to
  call from a background thread — they catch all exceptions internally.
- Auto-creates the Notion DB on first run, stores the ID back to .env so
  subsequent calls skip the search entirely.
- Notion unavailability is a non-fatal degraded state. The local JSONL log
  is the source of truth; Notion is the queryable dashboard view.

Environment variables required:
    NOTION_TOKEN           — Notion integration token
    NOTION_NOVA_HQ_PAGE_ID — Parent page where the DB lives (or will be created)
    NOTION_USAGE_DB_ID     — Populated automatically on first successful DB
                             lookup/creation; set manually to skip auto-search

Public API:
    write_row(log_entry)         → bool (True = success)
    get_daily_summary(date_str)  → dict
"""
from __future__ import annotations

import os
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from .config import get

# ---------------------------------------------------------------------------
# Notion API constants
# ---------------------------------------------------------------------------

_API_BASE = "https://api.notion.com/v1"
_API_VERSION = "2022-06-28"
_DB_TITLE = "🤖 OpenRouter Usage"
_REQUEST_TIMEOUT = 10  # seconds

# .env file lives two levels up from this file (repo root)
_ENV_FILE = Path(__file__).parent.parent / ".env"

# Pricing for savings-vs-opus calculation (per 1K tokens)
_OPUS_COST_IN = 0.015
_OPUS_COST_OUT = 0.075

# Thread-safe DB ID cache (populated once per process lifetime)
_db_id_lock = threading.Lock()
_db_id_cache: Optional[str] = None


# ---------------------------------------------------------------------------
# Internal helpers — HTTP
# ---------------------------------------------------------------------------

def _token() -> Optional[str]:
    return get("NOTION_TOKEN")


def _headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {_token()}",
        "Notion-Version": _API_VERSION,
        "Content-Type": "application/json",
    }


def _get(path: str, **kwargs: Any) -> requests.Response:
    return requests.get(
        f"{_API_BASE}{path}",
        headers=_headers(),
        timeout=_REQUEST_TIMEOUT,
        **kwargs,
    )


def _post(path: str, payload: Dict[str, Any]) -> requests.Response:
    return requests.post(
        f"{_API_BASE}{path}",
        headers=_headers(),
        json=payload,
        timeout=_REQUEST_TIMEOUT,
    )


def _patch(path: str, payload: Dict[str, Any]) -> requests.Response:
    return requests.patch(
        f"{_API_BASE}{path}",
        headers=_headers(),
        json=payload,
        timeout=_REQUEST_TIMEOUT,
    )


# ---------------------------------------------------------------------------
# Internal helpers — .env persistence
# ---------------------------------------------------------------------------

def _update_env_file(key: str, value: str) -> None:
    """
    Write or update a key=value pair in the project's .env file.

    Safe to call when .env does not yet exist — it will be created.
    Also sets the value in the current process environment immediately so
    subsequent calls in the same process see the updated value.
    """
    os.environ[key] = value  # update in-process immediately

    if _ENV_FILE.exists():
        content = _ENV_FILE.read_text(encoding="utf-8")
        pattern = re.compile(rf"^{re.escape(key)}=.*$", re.MULTILINE)
        if pattern.search(content):
            # Replace existing line
            new_content = pattern.sub(f"{key}={value}", content)
        else:
            # Append new key
            new_content = content.rstrip("\n") + f"\n{key}={value}\n"
    else:
        new_content = f"{key}={value}\n"

    _ENV_FILE.write_text(new_content, encoding="utf-8")


# ---------------------------------------------------------------------------
# Internal helpers — DB discovery and creation
# ---------------------------------------------------------------------------

def _search_for_db() -> Optional[str]:
    """
    Search the Notion workspace for a database titled _DB_TITLE.

    Returns the database ID if found, None otherwise.
    Searches up to the first 100 matches — sufficient for a personal workspace.
    """
    resp = _post("/search", {
        "query": _DB_TITLE,
        "filter": {"value": "database", "property": "object"},
        "page_size": 20,
    })
    if resp.status_code != 200:
        return None

    for result in resp.json().get("results", []):
        title_parts = result.get("title", [])
        flat_title = "".join(
            part.get("plain_text", "") for part in title_parts
        )
        if flat_title.strip() == _DB_TITLE:
            return result["id"]

    return None


def _create_db(parent_page_id: str) -> str:
    """
    Create the `🤖 OpenRouter Usage` database under the given parent page.

    Returns the new database ID.
    Raises requests.HTTPError on failure (caller handles).
    """
    payload: Dict[str, Any] = {
        "parent": {"type": "page_id", "page_id": parent_page_id},
        "title": [{"type": "text", "text": {"content": _DB_TITLE}}],
        "properties": {
            # Notion requires exactly one title property
            "Name": {"title": {}},
            "Date": {"date": {}},
            "Agent Name": {"rich_text": {}},
            "Model Used": {"select": {}},
            "Provider": {"select": {}},
            "Tokens In": {"number": {"format": "number"}},
            "Tokens Out": {"number": {"format": "number"}},
            "Cost USD": {"number": {"format": "dollar"}},
            "Latency ms": {"number": {"format": "number"}},
            "Complexity Score": {"number": {"format": "number"}},
            "Fallback Used": {"checkbox": {}},
            "Notes": {"rich_text": {}},
        },
    }
    resp = _post("/databases", payload)
    resp.raise_for_status()
    return resp.json()["id"]


def _ensure_db() -> Optional[str]:
    """
    Return the Notion database ID, initialising it if needed.

    Resolution order:
        1. In-process cache (fastest path after first call)
        2. NOTION_USAGE_DB_ID env var (set by prior session or manually)
        3. Notion search by title
        4. Create new DB under NOTION_NOVA_HQ_PAGE_ID

    Stores the resolved ID in .env and the in-process cache.
    Returns None if resolution fails (caller should treat as degraded).
    """
    global _db_id_cache

    with _db_id_lock:
        if _db_id_cache:
            return _db_id_cache

        # Check env var first (avoids a network call on every cold start)
        env_id = (get("NOTION_USAGE_DB_ID") or "").strip()
        if env_id:
            _db_id_cache = env_id
            return _db_id_cache

        # No token = nothing we can do
        if not _token():
            return None

        # Try to find an existing DB
        db_id = _search_for_db()

        if db_id is None:
            # Create one under the Nova HQ page
            parent_id = (get("NOTION_NOVA_HQ_PAGE_ID") or "").strip()
            if not parent_id:
                return None  # can't create without a parent page
            try:
                db_id = _create_db(parent_id)
            except Exception:
                return None

        # Persist so we don't search again
        try:
            _update_env_file("NOTION_USAGE_DB_ID", db_id)
        except Exception:
            pass  # .env update is best-effort

        _db_id_cache = db_id
        return _db_id_cache


# ---------------------------------------------------------------------------
# Internal helpers — property builders
# ---------------------------------------------------------------------------

def _rich_text(value: str) -> List[Dict[str, Any]]:
    return [{"text": {"content": str(value)[:2000]}}]


def _build_page_properties(entry: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a log_entry dict (logger.py schema) into Notion page properties.
    """
    timestamp_str: str = entry.get("timestamp", datetime.now(timezone.utc).isoformat())
    agent_name: str = entry.get("agent_name", "unknown")

    # Build a human-readable Name from agent + timestamp (truncated to minute)
    ts_short = timestamp_str[:16].replace("T", " ")
    name_str = f"{agent_name} / {ts_short}"

    return {
        "Name": {
            "title": _rich_text(name_str),
        },
        "Date": {
            "date": {"start": timestamp_str},
        },
        "Agent Name": {
            "rich_text": _rich_text(agent_name),
        },
        "Model Used": {
            "select": {"name": str(entry.get("model_selected", "unknown"))[:100]},
        },
        "Provider": {
            "select": {"name": str(entry.get("provider", "unknown"))[:100]},
        },
        "Tokens In": {
            "number": int(entry.get("tokens_in", 0)),
        },
        "Tokens Out": {
            "number": int(entry.get("tokens_out", 0)),
        },
        "Cost USD": {
            "number": round(float(entry.get("cost_usd", 0.0)), 6),
        },
        "Latency ms": {
            "number": int(entry.get("latency_ms", 0)),
        },
        "Complexity Score": {
            "number": int(entry.get("task_complexity", 0)),
        },
        "Fallback Used": {
            "checkbox": bool(entry.get("fallback_used", False)),
        },
        "Notes": {
            "rich_text": _rich_text(entry.get("notes", "") or ""),
        },
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def write_row(log_entry: Dict[str, Any]) -> bool:
    """
    Write a completed routing decision as a new row in the Notion DB.

    Safe to call from a background thread — catches all exceptions and
    returns False on any failure (caller logs and continues).

    Args:
        log_entry: A dict matching the logger.py schema. The key fields used
                   are: timestamp, agent_name, model_selected, provider,
                   tokens_in, tokens_out, cost_usd, latency_ms,
                   task_complexity, fallback_used, notes.

    Returns:
        True if the row was created successfully, False otherwise.
    """
    try:
        db_id = _ensure_db()
        if not db_id:
            return False

        properties = _build_page_properties(log_entry)
        resp = _post("/pages", {
            "parent": {"database_id": db_id},
            "properties": properties,
        })
        return resp.status_code == 200
    except Exception:
        return False


def get_daily_summary(date_str: Optional[str] = None) -> Dict[str, Any]:
    """
    Query the Notion DB for all rows on a given UTC date and return totals.

    Handles Notion API pagination transparently — fetches all pages for the
    given date regardless of how many rows exist.

    Args:
        date_str: ISO date string "YYYY-MM-DD". Defaults to today (UTC).

    Returns:
        Dict with:
            date (str):                  The queried date.
            total_calls (int):           Number of rows found.
            total_cost_usd (float):      Sum of Cost USD across all rows.
            total_tokens_in (int):       Sum of Tokens In.
            total_tokens_out (int):      Sum of Tokens Out.
            model_breakdown (dict):      {model_name: call_count}.
            savings_vs_opus_usd (float): Cost saved vs routing everything
                                         through Claude Opus at the same
                                         token volumes.
            source (str):                "notion" | "error"
            error (str | None):          Error message if query failed.
    """
    target_date = date_str or datetime.now(timezone.utc).date().isoformat()
    empty_result: Dict[str, Any] = {
        "date": target_date,
        "total_calls": 0,
        "total_cost_usd": 0.0,
        "total_tokens_in": 0,
        "total_tokens_out": 0,
        "model_breakdown": {},
        "savings_vs_opus_usd": 0.0,
        "source": "error",
        "error": None,
    }

    try:
        db_id = _ensure_db()
        if not db_id:
            empty_result["error"] = "Could not resolve Notion DB ID"
            return empty_result

        # Query with date filter — Notion date filter: on_or_after + before
        # gives us the full calendar day in UTC
        next_day_parts = target_date.split("-")
        # Increment the day by one for the upper bound
        from datetime import date, timedelta
        d = date.fromisoformat(target_date) + timedelta(days=1)
        next_day = d.isoformat()

        filter_payload = {
            "and": [
                {
                    "property": "Date",
                    "date": {"on_or_after": target_date},
                },
                {
                    "property": "Date",
                    "date": {"before": next_day},
                },
            ]
        }

        # Paginate through all results
        rows: List[Dict[str, Any]] = []
        cursor: Optional[str] = None
        while True:
            body: Dict[str, Any] = {"filter": filter_payload, "page_size": 100}
            if cursor:
                body["start_cursor"] = cursor

            resp = _post(f"/databases/{db_id}/query", body)
            if resp.status_code != 200:
                empty_result["error"] = f"Notion query failed: HTTP {resp.status_code}"
                return empty_result

            data = resp.json()
            rows.extend(data.get("results", []))
            if data.get("has_more") and data.get("next_cursor"):
                cursor = data["next_cursor"]
            else:
                break

        # Aggregate
        total_cost = 0.0
        total_tokens_in = 0
        total_tokens_out = 0
        model_breakdown: Dict[str, int] = {}
        opus_cost_equivalent = 0.0

        for row in rows:
            props = row.get("properties", {})

            cost = (props.get("Cost USD") or {}).get("number") or 0.0
            tok_in = int((props.get("Tokens In") or {}).get("number") or 0)
            tok_out = int((props.get("Tokens Out") or {}).get("number") or 0)

            model_select = (props.get("Model Used") or {}).get("select") or {}
            model_name = model_select.get("name", "unknown")

            total_cost += cost
            total_tokens_in += tok_in
            total_tokens_out += tok_out
            model_breakdown[model_name] = model_breakdown.get(model_name, 0) + 1

            # What would this call have cost on Opus?
            opus_equiv = (
                (tok_in / 1000 * _OPUS_COST_IN)
                + (tok_out / 1000 * _OPUS_COST_OUT)
            )
            opus_cost_equivalent += opus_equiv

        savings = max(0.0, opus_cost_equivalent - total_cost)

        return {
            "date": target_date,
            "total_calls": len(rows),
            "total_cost_usd": round(total_cost, 6),
            "total_tokens_in": total_tokens_in,
            "total_tokens_out": total_tokens_out,
            "model_breakdown": model_breakdown,
            "savings_vs_opus_usd": round(savings, 6),
            "source": "notion",
            "error": None,
        }

    except Exception as exc:
        empty_result["error"] = str(exc)
        return empty_result
