"""
Self-optimizing memory for the OpenRouter Optimizer.

Records human or Nova quality feedback on completed calls and uses the
accumulated history to suggest model routing adjustments. The system learns
which models actually perform well on which task types and complexity levels
— not just which models are theoretically capable.

Storage: ~/.nova/optimizer_memory.json
Format: {"outcomes": [...], "meta": {"last_updated": "...", "total_records": N}}

Quality score scale (used by record_outcome):
    1 — Unusable: wrong, incomplete, or required full retry
    2 — Poor: significant rework needed before the output was useful
    3 — Acceptable: usable but not ideal, minor follow-up needed
    4 — Good: only minor tweaks required
    5 — Excellent: no follow-up required, output was used as-is

Routing adjustment logic:
    Adjustment is calculated per (task_type, complexity) bucket.
    Minimum 10 outcome samples are required before any adjustment is applied.

    Upward adjustment (+1):  model retry rate > 20%  OR  avg quality < 3.0
    Downward adjustment (-1): avg quality >= 4.5 AND retry rate < 5%
                              AND complexity > 1 (never downgrade tier-1 tasks)
    No adjustment (0):       insufficient data, or metrics within acceptable range

Public API:
    record_outcome(call_id, quality_score, retried, notes)  → None
    get_routing_adjustment(task_type, complexity)            → dict
    get_learning_report()                                    → str
    get_recent_quality_avg(window)                          → float | None
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .config import get
from . import logger as _logger

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_DEFAULT_MEMORY_PATH = Path.home() / ".nova" / "optimizer_memory.json"
MEMORY_FILE = Path(get("OPTIMIZER_MEMORY_PATH") or str(_DEFAULT_MEMORY_PATH))

# Minimum outcome samples before an adjustment is made
MIN_SAMPLES = 10

# Thresholds that trigger routing adjustments
_RETRY_RATE_BUMP_UP = 0.20       # retry rate > 20% → bump score up
_QUALITY_BUMP_UP = 3.0           # avg quality < 3.0 → bump score up
_QUALITY_BUMP_DOWN = 4.5         # avg quality >= 4.5 → consider bump down
_RETRY_RATE_BUMP_DOWN = 0.05     # retry rate < 5% (alongside high quality) → bump down


# ---------------------------------------------------------------------------
# File I/O
# ---------------------------------------------------------------------------

def _ensure_file() -> None:
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not MEMORY_FILE.exists():
        MEMORY_FILE.write_text(
            json.dumps({"outcomes": [], "meta": {"total_records": 0}}),
            encoding="utf-8",
        )


def _read() -> Dict[str, Any]:
    _ensure_file()
    try:
        return json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"outcomes": [], "meta": {"total_records": 0}}


def _write(data: Dict[str, Any]) -> None:
    _ensure_file()
    data.setdefault("meta", {})["last_updated"] = datetime.now(timezone.utc).isoformat()
    data["meta"]["total_records"] = len(data.get("outcomes", []))
    MEMORY_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Outcome record construction
# ---------------------------------------------------------------------------

def _lookup_call(call_id: str) -> Optional[Dict[str, Any]]:
    """
    Find a routing decision in the local JSONL log by call_id.
    Returns the log entry dict, or None if not found.
    """
    all_records = _logger._read_all()
    for record in all_records:
        if record.get("call_id") == call_id:
            return record
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def record_outcome(
    call_id: str,
    quality_score: int,
    retried: bool,
    notes: str = "",
) -> None:
    """
    Record a quality outcome for a completed routing decision.

    Walt or Nova can call this to teach the system. The call_id links back to
    the original routing decision so the model, task_type, and complexity are
    retrieved automatically from the local JSONL log.

    Args:
        call_id:       UUID returned by optimize() for this routing decision.
        quality_score: Integer 1–5 (see module docstring for scale).
        retried:       True if the output was unsatisfactory and the task was
                       retried (either with the same or a different model).
        notes:         Optional free-text explanation for the quality rating.
                       Stored for future review via get_learning_report().
    """
    quality_score = max(1, min(5, int(quality_score)))

    # Retrieve routing context from the JSONL log
    call_record = _lookup_call(call_id)
    if call_record is None:
        # If the call isn't in the log (e.g. test mode), record with minimal context
        call_record = {}

    outcome: Dict[str, Any] = {
        "call_id": call_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "model": call_record.get("model_selected", "unknown"),
        "provider": call_record.get("provider", "unknown"),
        "task_type": call_record.get("task_type") or "unknown",
        "complexity": int(call_record.get("task_complexity", 0)),
        "quality_score": quality_score,
        "retried": bool(retried),
        "notes": str(notes)[:500],
    }

    data = _read()
    data.setdefault("outcomes", []).append(outcome)
    _write(data)


def get_routing_adjustment(
    task_type: Optional[str],
    complexity: int,
) -> Dict[str, Any]:
    """
    Return a routing score adjustment based on accumulated outcome history
    for a given (task_type, complexity) bucket.

    The adjustment is applied as a ±1 bump to the complexity score before
    model selection, effectively upgrading or downgrading the model tier.

    Args:
        task_type:  Task type string (e.g. "analysis", "code", "lookup").
                    If None or "unknown", no adjustment is returned.
        complexity: Base complexity score (1–5) before adjustment.

    Returns:
        Dict with:
            adjust (int):         -1, 0, or +1 score adjustment.
            reason (str):         Human-readable rationale.
            sample_count (int):   Number of outcomes in this bucket.
            confidence (float):   0.0–1.0; reaches 1.0 at 2× MIN_SAMPLES.
            model_stats (dict):   Per-model stats for transparency.
    """
    null_result: Dict[str, Any] = {
        "adjust": 0,
        "reason": "No adjustment",
        "sample_count": 0,
        "confidence": 0.0,
        "model_stats": {},
    }

    if not task_type or task_type == "unknown":
        null_result["reason"] = "No task_type provided — skipping memory lookup"
        return null_result

    data = _read()
    outcomes = data.get("outcomes", [])

    # Filter to this specific bucket
    relevant = [
        o for o in outcomes
        if o.get("task_type") == task_type
        and o.get("complexity") == complexity
    ]

    sample_count = len(relevant)
    if sample_count < MIN_SAMPLES:
        null_result["reason"] = (
            f"Insufficient data for {task_type}/complexity={complexity} "
            f"({sample_count}/{MIN_SAMPLES} samples)"
        )
        null_result["sample_count"] = sample_count
        return null_result

    # Per-model aggregation
    model_stats: Dict[str, Dict[str, Any]] = defaultdict(
        lambda: {"scores": [], "retries": 0, "total": 0}
    )
    for o in relevant:
        m = o.get("model", "unknown")
        model_stats[m]["scores"].append(o.get("quality_score", 3))
        if o.get("retried"):
            model_stats[m]["retries"] += 1
        model_stats[m]["total"] += 1

    # Compute summary stats per model
    summary: Dict[str, Dict[str, float]] = {}
    for model, s in model_stats.items():
        avg_q = sum(s["scores"]) / len(s["scores"])
        retry_rate = s["retries"] / s["total"]
        summary[model] = {
            "avg_quality": round(avg_q, 2),
            "retry_rate": round(retry_rate, 3),
            "sample_count": s["total"],
        }

    # Overall bucket stats (weighted average across models)
    all_scores = [o.get("quality_score", 3) for o in relevant]
    all_retried = [o.get("retried", False) for o in relevant]
    overall_quality = sum(all_scores) / len(all_scores)
    overall_retry = sum(all_retried) / len(all_retried)

    confidence = min(1.0, sample_count / (MIN_SAMPLES * 2))

    # Determine adjustment
    if overall_retry > _RETRY_RATE_BUMP_UP or overall_quality < _QUALITY_BUMP_UP:
        reason = (
            f"Poor performance on {task_type}/complexity={complexity}: "
            f"avg quality={overall_quality:.1f}, "
            f"retry rate={overall_retry:.0%} — upgrading model tier"
        )
        return {
            "adjust": +1,
            "reason": reason,
            "sample_count": sample_count,
            "confidence": confidence,
            "model_stats": summary,
        }

    if (
        overall_quality >= _QUALITY_BUMP_DOWN
        and overall_retry < _RETRY_RATE_BUMP_DOWN
        and complexity > 1
    ):
        reason = (
            f"Excellent performance on {task_type}/complexity={complexity}: "
            f"avg quality={overall_quality:.1f}, "
            f"retry rate={overall_retry:.0%} — downgrading model tier to save cost"
        )
        return {
            "adjust": -1,
            "reason": reason,
            "sample_count": sample_count,
            "confidence": confidence,
            "model_stats": summary,
        }

    return {
        "adjust": 0,
        "reason": (
            f"Metrics within acceptable range for {task_type}/complexity={complexity}: "
            f"avg quality={overall_quality:.1f}, retry rate={overall_retry:.0%}"
        ),
        "sample_count": sample_count,
        "confidence": confidence,
        "model_stats": summary,
    }


def get_recent_quality_avg(window: int = 20) -> Optional[float]:
    """
    Return the average quality score across the most recent N outcomes.

    Used by alerter.py to detect quality degradation trends.

    Args:
        window: Number of most recent outcomes to average.

    Returns:
        Average quality score (1.0–5.0), or None if no outcomes recorded yet.
    """
    data = _read()
    outcomes = data.get("outcomes", [])
    if not outcomes:
        return None
    recent = outcomes[-window:]
    scores = [o.get("quality_score", 3) for o in recent]
    return round(sum(scores) / len(scores), 2)


def _bucket_key(task_type: str, complexity: int) -> str:
    return f"{task_type}/complexity={complexity}"


def get_learning_report() -> str:
    """
    Generate a human-readable summary of everything the system has learned,
    formatted for Telegram delivery via Nova.

    Groups outcomes by (task_type, complexity) bucket and reports per-model
    performance within each bucket. Highlights buckets with active adjustments.

    Returns:
        A Telegram-ready plain-text string (~1500 chars max, respects Telegram
        message length limits).
    """
    data = _read()
    outcomes = data.get("outcomes", [])
    meta = data.get("meta", {})

    if not outcomes:
        return (
            "📊 *Optimizer Learning Report*\n\n"
            "No outcome data recorded yet.\n"
            "Call `record_outcome()` after reviewing agent outputs to start teaching the system."
        )

    total = meta.get("total_records", len(outcomes))
    last_updated = meta.get("last_updated", "unknown")[:10]

    # Aggregate: bucket → model → stats
    bucket_data: Dict[str, Dict[str, Any]] = defaultdict(
        lambda: defaultdict(lambda: {"scores": [], "retries": 0, "total": 0})
    )
    for o in outcomes:
        tt = o.get("task_type") or "unknown"
        cx = int(o.get("complexity", 0))
        model = o.get("model", "unknown").split("/")[-1]  # short name
        key = _bucket_key(tt, cx)
        bucket_data[key][model]["scores"].append(o.get("quality_score", 3))
        if o.get("retried"):
            bucket_data[key][model]["retries"] += 1
        bucket_data[key][model]["total"] += 1

    lines: List[str] = [
        "📊 *Optimizer Learning Report*",
        f"Total outcomes: {total} | Last updated: {last_updated}",
        "",
    ]

    for bucket_key in sorted(bucket_data.keys()):
        models = bucket_data[bucket_key]
        bucket_total = sum(m["total"] for m in models.values())
        lines.append(f"*{bucket_key}* ({bucket_total} samples)")

        for model_name, stats in sorted(models.items(), key=lambda x: -x[1]["total"]):
            scores = stats["scores"]
            avg_q = sum(scores) / len(scores)
            retry_r = stats["retries"] / stats["total"]
            retry_pct = f"{retry_r:.0%}"

            # Indicator emoji
            if avg_q < 3.0 or retry_r > 0.20:
                flag = "🔴"
            elif avg_q >= 4.5 and retry_r < 0.05:
                flag = "🟢"
            else:
                flag = "🟡"

            lines.append(
                f"  {flag} {model_name}: "
                f"quality={avg_q:.1f}/5 | "
                f"retries={retry_pct} | "
                f"n={stats['total']}"
            )
        lines.append("")

    # Trim to ~1400 chars to stay well within Telegram limits
    report = "\n".join(lines)
    if len(report) > 1400:
        report = report[:1380] + "\n…(truncated)"

    return report
