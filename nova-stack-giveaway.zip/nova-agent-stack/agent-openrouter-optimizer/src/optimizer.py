"""
OpenRouter Optimizer — main public interface.

Nova calls optimize() before every agent dispatch. The function is
intentionally synchronous, fast, and side-effect-minimal (only I/O is
the log append). It never raises — all exceptions are caught and returned
as structured error data so Nova's pipeline cannot be interrupted.

Public API:
    optimize(task)                             → RoutingResult dict
    log_completion(call_id, out, ms)           → None
    record_outcome(call_id, score, retried, notes) → None
    get_daily_summary(day)                     → stats dict
"""
from __future__ import annotations

import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests

from .config import get
from . import alerter as _alerter
from . import logger as _logger
from . import notion_writer as _notion
from . import optimizer_memory as _memory
from . import router as _router
from . import scorer as _scorer

# ---------------------------------------------------------------------------
# Configuration (all read via config.get → master .env → agent .env → default)
# ---------------------------------------------------------------------------

_OLLAMA_BASE_URL = get("OLLAMA_BASE_URL", "http://localhost:11434")
_OLLAMA_TIMEOUT_S = int(get("OLLAMA_TIMEOUT_MS", "3000")) / 1000

_THRESHOLDS: Dict[str, float] = {
    "cost_daily_usd":        float(get("COST_ALERT_DAILY_USD", "5.00")),
    "cost_single_usd":       float(get("COST_ALERT_SINGLE_CALL_USD", "0.50")),
    "fallback_rate_pct":     float(get("FALLBACK_ALERT_RATE_PERCENT", "30")),
    "min_quality_score":     float(get("MIN_QUALITY_SCORE_ALERT", "2.5")),
    "ollama_failure_streak": 3.0,
}

_OLLAMA_FAILURE_THRESHOLD = 3

# ---------------------------------------------------------------------------
# In-process state
# ---------------------------------------------------------------------------

_ollama_consecutive_failures: int = 0

# Registry of in-flight calls keyed by call_id. Holds the log entry dict so
# log_completion() can pass the full record to Notion without re-reading the
# JSONL file. Entries are removed after log_completion() to bound memory.
_call_registry: Dict[str, Dict[str, Any]] = {}
_registry_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _check_ollama() -> bool:
    """
    GET /api/tags from the local Ollama instance with a short timeout.

    Returns True if Ollama responds with HTTP 200, False for any other
    outcome (connection refused, timeout, unexpected status).
    """
    try:
        resp = requests.get(
            f"{_OLLAMA_BASE_URL}/api/tags",
            timeout=_OLLAMA_TIMEOUT_S,
        )
        return resp.status_code == 200
    except (requests.ConnectionError, requests.Timeout):
        return False
    except Exception:
        return False


def _emit_alerts(alerts: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Print each alert with the [NOVA-ALERT] prefix and return the most severe
    one (critical > warn) for inclusion in the optimize() return value.

    Nova's bridge process intercepts [NOVA-ALERT] lines on stdout and
    surfaces them to Walt via Telegram or dashboard.
    """
    if not alerts:
        return None

    for alert in alerts:
        print(
            f"[NOVA-ALERT] {alert['level'].upper()} {alert['metric']}: "
            f"{alert['message']}",
            flush=True,
        )

    # Return the first critical alert, or the first warning
    critical = [a for a in alerts if a["level"] == "critical"]
    return critical[0] if critical else alerts[0]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def optimize(task: Dict[str, Any]) -> Dict[str, Any]:
    """
    Score a task, select the right model, check alerts, log the decision,
    and return the routing result. This is the only function Nova needs to
    call before dispatching a task to a downstream agent.

    Args:
        task: Dict with the following keys:
            content (str):           Natural language task description.
            agent_name (str):        Calling agent identifier (e.g. "research-agent").
            task_type (str | None):  Optional hint — "code" | "prose" |
                                     "analysis" | "lookup".
            context_tokens (int):    Estimated input token count. Derived from
                                     content length if absent.
            min_model_tier (int):    Nova-specified minimum complexity tier (1–5).
                                     Optional; defaults to 1 (no override).

    Returns:
        Dict with:
            model (str):               Model identifier (e.g. "anthropic/claude-sonnet-4-6").
            provider (str):            "ollama" or "openrouter".
            complexity_score (int):    Base score assigned by the scorer (1–5).
            effective_score (int):     Score after memory adjustment.
            memory_adjust (int):       Adjustment applied (-1, 0, or +1).
            rationale (str):           Human-readable explanation of the score.
            estimated_cost_usd (float): Pre-call cost estimate.
            fallback (bool):           True if the primary model was unavailable.
            fallback_reason (str|None): Reason the fallback was triggered.
            alert (dict|None):         Most severe alert object, or None.
            call_id (str):             UUID for post-execution log_completion() call.
    """
    global _ollama_consecutive_failures

    agent_name: str = task.get("agent_name", "unknown")
    context_tokens: int = int(task.get("context_tokens") or 500)

    # --- Step 1: Score complexity -----------------------------------------
    score_result = _scorer.score(task)
    complexity_score: int = score_result["score"]
    rationale: str = score_result["rationale"]

    # --- Step 2: Ollama health check (only for low-tier tasks) -----------
    ollama_available = True
    if complexity_score <= 2:
        ollama_available = _check_ollama()
        if ollama_available:
            _ollama_consecutive_failures = 0
        else:
            _ollama_consecutive_failures += 1

    # --- Step 3: Route to model (includes memory adjustment) -------------
    routing = _router.route(
        score=complexity_score,
        ollama_available=ollama_available,
        task_type=task.get("task_type"),
        context_tokens=context_tokens,
    )

    model: str = routing["model"]
    provider: str = routing["provider"]
    estimated_cost: float = routing["estimated_cost_usd"]
    fallback: bool = routing["fallback"]
    fallback_reason: Optional[str] = routing.get("fallback_reason")
    effective_score: int = routing["effective_score"]
    memory_adjust: int = routing["memory_adjust"]

    # --- Step 4: Check alerts --------------------------------------------
    stats = _logger.get_stats()
    alerts = _alerter.check_alerts(
        stats=stats,
        thresholds=_THRESHOLDS,
        context={
            "current_call_cost": estimated_cost,
            "agent_name": agent_name,
            "model": model,
            "ollama_failure_streak": _ollama_consecutive_failures,
        },
    )
    top_alert = _emit_alerts(alerts)

    # --- Step 5: Log the routing decision --------------------------------
    call_id = str(uuid.uuid4())
    log_entry: Dict[str, Any] = {
        "call_id": call_id,
        "agent_name": agent_name,
        "task_type": task.get("task_type"),
        "task_complexity": complexity_score,
        "model_selected": model,
        "provider": provider,
        "tokens_in": context_tokens,
        "tokens_out": 0,
        "cost_usd": estimated_cost,
        "latency_ms": 0,
        "fallback_used": fallback,
        "fallback_reason": fallback_reason,
        "alert_triggered": top_alert is not None,
        "notes": rationale,
    }
    _logger.write(log_entry)

    # Cache for log_completion() Notion write
    with _registry_lock:
        _call_registry[call_id] = log_entry.copy()

    return {
        "model": model,
        "provider": provider,
        "complexity_score": complexity_score,
        "effective_score": effective_score,
        "memory_adjust": memory_adjust,
        "rationale": rationale,
        "estimated_cost_usd": estimated_cost,
        "fallback": fallback,
        "fallback_reason": fallback_reason,
        "alert": top_alert,
        "call_id": call_id,
    }


def log_completion(call_id: str, tokens_out: int, latency_ms: int) -> None:
    """
    Update a routing decision log entry with post-execution actuals and
    fire an async Notion write in a background daemon thread.

    The Notion write runs in a daemon thread so it adds zero latency to
    Nova's pipeline. If Notion is unreachable the failure is silently
    swallowed — the local JSONL log is always the authoritative record.

    Args:
        call_id:    UUID returned by optimize() for this routing decision.
        tokens_out: Actual output token count reported by the model API.
        latency_ms: Total end-to-end latency from route request to final response.
    """
    updates = {"tokens_out": tokens_out, "latency_ms": latency_ms}
    _logger.update(call_id, updates)

    with _registry_lock:
        cached = _call_registry.pop(call_id, None)

    if cached is not None:
        notion_entry = {**cached, **updates}
        thread = threading.Thread(
            target=_notion.write_row,
            args=(notion_entry,),
            daemon=True,
            name=f"notion-write-{call_id[:8]}",
        )
        thread.start()


def record_outcome(
    call_id: str,
    quality_score: int,
    retried: bool = False,
    notes: str = "",
) -> None:
    """
    Record a quality outcome for a completed routing decision.

    Walt or Nova can call this to teach the self-optimizing memory system.
    Over time, poor-performing model/task combinations are automatically
    routed to higher-tier models.

    Args:
        call_id:       UUID returned by optimize() for this routing decision.
        quality_score: Integer 1–5 (1=unusable, 5=excellent).
        retried:       True if the output required a retry.
        notes:         Optional free-text explanation (stored for review).
    """
    _memory.record_outcome(call_id, quality_score, retried, notes)


def get_daily_summary(day: Optional[str] = None) -> Dict[str, Any]:
    """
    Return a summary of routing decisions for a given UTC day.

    Args:
        day: ISO date string "YYYY-MM-DD". Defaults to today (UTC).

    Returns:
        Dict from logger.get_stats() — see that function for full schema.
    """
    return _logger.get_stats(day=day)
