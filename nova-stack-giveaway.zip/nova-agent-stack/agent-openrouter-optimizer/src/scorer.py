"""
Complexity scorer for the OpenRouter Optimizer.

Pure heuristics — no API calls, no I/O. Designed to be fast enough to
run inline on every Nova dispatch without adding perceptible latency.

Score reference:
    1 — Trivial:   format, lookup, echo, fill-in-the-blank
    2 — Simple:    single-step summarise, classify, extract, transform
    3 — Medium:    multi-step reasoning, draft creation, structured output
    4 — Moderate:  analysis with multiple considerations, long context, tool use
    5 — Complex:   deep reasoning, architecture, long documents, code generation
"""
from __future__ import annotations

from typing import Any, Dict, Optional

# ---------------------------------------------------------------------------
# Agent-level constraints
# ---------------------------------------------------------------------------

# Agents that always need a minimum model tier
AGENT_MINIMUM_SCORE: Dict[str, int] = {
    "agent-strategist": 4,
    "agent-coder": 4,
    "research-agent": 3,
}

# Agents that are capped at a maximum tier (lightweight by design)
AGENT_MAXIMUM_SCORE: Dict[str, int] = {
    "agent-summariser": 3,
}

# ---------------------------------------------------------------------------
# Keyword groups — checked highest-score first to avoid false downgrades
# ---------------------------------------------------------------------------

# Indicators of high complexity (score 4)
HIGH_KEYWORDS = {
    "architect", "architecture", "design", "reason", "evaluate",
    "assess", "strategise", "strategize", "complex", "implement",
    "refactor", "debug", "code", "generate", "build", "develop",
    "integrate", "optimise", "optimize", "reconstruct", "engineer",
}

# Indicators of medium-high complexity (score 3)
MEDIUM_KEYWORDS = {
    "draft", "write", "analyse", "analyze", "explain", "review",
    "research", "investigate", "compare", "synthesise", "synthesize",
    "plan", "propose", "recommend", "outline", "compose",
}

# Indicators of medium-low complexity (score 2)
MEDIUM_LOW_KEYWORDS = {
    "summarise", "summarize", "classify", "list", "categorise",
    "categorize", "translate", "transcribe", "structure", "organise",
    "organize",
}

# Indicators of low complexity (score 1)
LOW_KEYWORDS = {
    "format", "convert", "extract", "lookup", "find", "fetch",
    "get", "retrieve", "echo", "repeat", "fill", "template",
    "replace", "rename", "count",
}

# Task-type hints that bump the score up
HIGH_TASK_TYPES = {"code"}
MEDIUM_TASK_TYPES = {"analysis"}
LOW_TASK_TYPES = {"lookup"}

# ---------------------------------------------------------------------------
# Context-length thresholds (token estimates)
# ---------------------------------------------------------------------------

_CHARS_PER_TOKEN = 4
_LONG_TOKEN_THRESHOLD = 4_000   # → minimum score 3
_VERY_LONG_TOKEN_THRESHOLD = 8_000  # → minimum score 4


def _estimate_tokens(text: str) -> int:
    """Rough token estimate derived from character count."""
    return max(1, len(text) // _CHARS_PER_TOKEN)


def _base_score_from_keywords(description: str, task_type: Optional[str]) -> int:
    """
    Derive a base score (1–4) from keyword and task-type analysis.

    Checks from highest to lowest priority so that a single high-signal
    word (e.g. "implement") takes precedence over co-occurring low-signal
    words (e.g. "get").
    """
    text = (description + " " + (task_type or "")).lower()
    words = set(text.split())

    # Task-type overrides first
    if task_type in HIGH_TASK_TYPES:
        return 4
    if task_type in LOW_TASK_TYPES:
        return 1

    # Keyword cascade
    if words & HIGH_KEYWORDS:
        return 4
    if task_type in MEDIUM_TASK_TYPES:
        return 3
    if words & MEDIUM_KEYWORDS:
        return 3
    if words & MEDIUM_LOW_KEYWORDS:
        return 2
    if words & LOW_KEYWORDS:
        return 1

    # No signal found — default to medium so unknown tasks aren't under-served
    return 3


def score(task: Dict[str, Any]) -> Dict[str, Any]:
    """
    Score the complexity of a task using rule-based heuristics.

    Args:
        task: Dict with the following keys:
            content (str):           Natural language task description.
            agent_name (str):        Calling agent identifier.
            task_type (str | None):  Optional hint — "code" | "prose" |
                                     "analysis" | "lookup".
            context_tokens (int):    Known input token count (optional).
                                     Estimated from content length if absent.
            min_model_tier (int):    Nova-specified minimum score override
                                     (optional, default 1).

    Returns:
        Dict with:
            score (int):      Final complexity score, 1–5.
            rationale (str):  Human-readable explanation of every adjustment.
    """
    content: str = task.get("content", "")
    agent_name: str = task.get("agent_name", "")
    task_type: Optional[str] = task.get("task_type")
    context_tokens: int = task.get("context_tokens") or _estimate_tokens(content)
    min_model_tier: int = int(task.get("min_model_tier") or 1)

    reasons: list = []

    # 1. Keyword / task-type base score
    base = _base_score_from_keywords(content, task_type)
    reasons.append(f"keyword heuristic → {base}")

    # 2. Context length adjustment
    if context_tokens >= _VERY_LONG_TOKEN_THRESHOLD:
        if base < 4:
            base = 4
            reasons.append(f"very long context ({context_tokens} tokens) → raised to 4")
    elif context_tokens >= _LONG_TOKEN_THRESHOLD:
        if base < 3:
            base = 3
            reasons.append(f"long context ({context_tokens} tokens) → raised to 3")

    # 3. Agent minimum floor
    agent_min = AGENT_MINIMUM_SCORE.get(agent_name, 1)
    if agent_min > base:
        base = agent_min
        reasons.append(f"agent floor for '{agent_name}' → raised to {agent_min}")

    # 4. Agent maximum ceiling
    agent_max = AGENT_MAXIMUM_SCORE.get(agent_name, 5)
    if base > agent_max:
        base = agent_max
        reasons.append(f"agent ceiling for '{agent_name}' → capped at {agent_max}")

    # 5. Nova explicit override
    if min_model_tier > base:
        base = min_model_tier
        reasons.append(f"Nova min_model_tier override → raised to {min_model_tier}")

    final_score = max(1, min(5, base))
    return {
        "score": final_score,
        "rationale": "; ".join(reasons),
    }
