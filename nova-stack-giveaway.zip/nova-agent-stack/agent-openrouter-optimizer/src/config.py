"""
Centralised environment configuration loader — Nova Agent Standard.

This module defines the standard env loading pattern for all Nova agents.
It loads two .env files in order (last writer wins on conflicts):

    1. my-ai-team/.env        Master shared secrets — Anthropic API key,
                               Notion token, GitHub PAT, Telegram tokens, etc.
                               Managed centrally; never duplicated per-agent.

    2. <agent-root>/.env      Agent-specific config — model settings, alert
                               thresholds, agent-scoped API keys, feature flags.

Resolution priority (highest → lowest):
    OS environment (set before process start)
    Agent-specific .env
    Master .env
    Default argument passed to get()

Usage in any src/ module:
    from .config import get

    BASE_URL = get("OLLAMA_BASE_URL", "http://localhost:11434")
    TIMEOUT  = int(get("OLLAMA_TIMEOUT_MS", "3000"))

Side effect: resolved values are also written to os.environ (only where the
key is not already set) so that third-party libraries reading os.environ
directly (requests, notion SDK, etc.) see the correct values.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Optional

# ---------------------------------------------------------------------------
# Path resolution (relative to this file's location)
# ---------------------------------------------------------------------------

_SRC_DIR = Path(__file__).parent                    # .../agent-openrouter-optimizer/src/
_AGENT_DIR = _SRC_DIR.parent                        # .../agent-openrouter-optimizer/
_MASTER_ENV = _AGENT_DIR.parent / ".env"            # .../my-ai-team/.env
_LOCAL_ENV = _AGENT_DIR / ".env"                    # .../agent-openrouter-optimizer/.env

# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _parse_env_file(path: Path) -> Dict[str, str]:
    """
    Parse a .env file into a dict.

    Rules:
    - Lines starting with # are comments and are ignored.
    - Blank lines are ignored.
    - Values may be single- or double-quoted (quotes are stripped).
    - Inline comments (# after a space) are stripped from values.
    - Keys with no = separator are ignored.
    """
    result: Dict[str, str] = {}
    if not path.exists():
        return result

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue

        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()

        # Strip inline comments (must be preceded by a space)
        if " #" in value:
            value = value[: value.index(" #")].strip()

        # Strip surrounding quotes
        if (
            len(value) >= 2
            and value[0] == value[-1]
            and value[0] in ('"', "'")
        ):
            value = value[1:-1]

        if key:
            result[key] = value

    return result


# ---------------------------------------------------------------------------
# Load and merge
# ---------------------------------------------------------------------------

_config: Dict[str, str] = {}
_loaded: bool = False


def _load() -> None:
    global _config, _loaded
    if _loaded:
        return

    # 1. Master shared secrets
    master = _parse_env_file(_MASTER_ENV)
    # 2. Agent-specific config (overrides master on conflict)
    local = _parse_env_file(_LOCAL_ENV)
    merged = {**master, **local}

    # 3. Write to os.environ — only where the key isn't already set by the OS.
    #    This preserves true OS/shell environment variables at highest priority.
    for key, value in merged.items():
        if key not in os.environ:
            os.environ[key] = value

    # 4. Build the config dict: OS env wins (it may have overrides from merged)
    _config = {**merged, **dict(os.environ)}
    _loaded = True


# Run on import — all modules that do `from .config import get` trigger this.
_load()


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def get(key: str, default: Optional[str] = None) -> Optional[str]:
    """
    Retrieve a configuration value by key.

    Args:
        key:     Environment variable name (e.g. "OLLAMA_BASE_URL").
        default: Fallback value if the key is absent from all sources.

    Returns:
        The resolved string value, or default if not found.
    """
    return _config.get(key, default)


def require(key: str) -> str:
    """
    Retrieve a required configuration value.

    Args:
        key: Environment variable name.

    Returns:
        The resolved string value.

    Raises:
        KeyError: If the key is absent from all sources.
    """
    value = _config.get(key)
    if value is None:
        raise KeyError(
            f"Required config key '{key}' not found in os.environ, "
            f"{_LOCAL_ENV.name}, or {_MASTER_ENV.name}"
        )
    return value


def all_vars() -> Dict[str, str]:
    """
    Return a copy of all resolved configuration variables.
    Useful for debugging — do not log this in production (contains secrets).
    """
    return dict(_config)
