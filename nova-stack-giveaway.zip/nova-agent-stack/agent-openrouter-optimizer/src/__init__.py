"""
agent-openrouter-optimizer — public interface.

Nova imports this package and calls optimize() before every agent dispatch,
log_completion() after, and record_outcome() to teach the system.

    from src import optimize, log_completion, record_outcome, get_daily_summary
    from src.optimizer_memory import get_learning_report
    from src.alerter import format_for_nova

Quick example:
    result = optimize({
        "content": "Research competitors in the CRM space",
        "agent_name": "research-agent",
        "task_type": "analysis",
        "context_tokens": 800,
    })
    # result["model"]          → "anthropic/claude-haiku-4-5-20251001"
    # result["memory_adjust"]  → 0  (or ±1 once learning data exists)
    # result["call_id"]        → "a3f1..."

    # After agent execution:
    log_completion(result["call_id"], tokens_out=420, latency_ms=1840)

    # Walt or Nova rates the output:
    record_outcome(result["call_id"], quality_score=4, retried=False,
                   notes="Good summary, slight hallucination on date")
"""
from .optimizer import (
    get_daily_summary,
    log_completion,
    optimize,
    record_outcome,
)

__all__ = ["optimize", "log_completion", "record_outcome", "get_daily_summary"]
