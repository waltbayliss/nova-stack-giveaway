"""
Model router for the OpenRouter Optimizer.

Maps a complexity score (1–5) to a specific model + provider, applies
fallback logic when the primary option is unavailable, estimates pre-call
cost, and applies learned routing adjustments from optimizer_memory.

Routing table summary:
    Score 1–2  →  Ollama local (llama3.1:8b)         fallback: Claude Haiku
    Score 3    →  Claude Haiku 4.5                    fallback: Claude Sonnet
    Score 3–4  →  Claude Sonnet 4.6                   fallback: Claude Opus
    Score 4–5  →  Claude Opus 4.6                     fallback: GPT-4o

Memory-based adjustment:
    After base routing, optimizer_memory is queried for the (task_type,
    complexity) bucket. If ≥ 10 samples exist and a performance problem is
    detected, the score is bumped ±1 and routing is re-evaluated. The
    original and adjusted scores are both included in the return dict.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from .config import get
from . import optimizer_memory as _memory

# ---------------------------------------------------------------------------
# Model identifiers
# ---------------------------------------------------------------------------

_OLLAMA_MODEL = get("OLLAMA_DEFAULT_MODEL", "llama3.1:8b")

# Each tier: primary + provider, fallback + provider
_ROUTING_TABLE: Dict[int, Dict[str, str]] = {
    1: {
        "model":            f"ollama/{_OLLAMA_MODEL}",
        "provider":         "ollama",
        "fallback_model":   "anthropic/claude-haiku-4-5-20251001",
        "fallback_provider": "openrouter",
    },
    2: {
        "model":            f"ollama/{_OLLAMA_MODEL}",
        "provider":         "ollama",
        "fallback_model":   "anthropic/claude-haiku-4-5-20251001",
        "fallback_provider": "openrouter",
    },
    3: {
        "model":            "anthropic/claude-haiku-4-5-20251001",
        "provider":         "openrouter",
        "fallback_model":   "anthropic/claude-sonnet-4-6",
        "fallback_provider": "openrouter",
    },
    4: {
        "model":            "anthropic/claude-sonnet-4-6",
        "provider":         "openrouter",
        "fallback_model":   "anthropic/claude-opus-4-6",
        "fallback_provider": "openrouter",
    },
    5: {
        "model":            "anthropic/claude-opus-4-6",
        "provider":         "openrouter",
        "fallback_model":   "openai/gpt-4o",
        "fallback_provider": "openrouter",
    },
}

# ---------------------------------------------------------------------------
# Pricing table — cost per 1K tokens (input, output) in USD
# Updated: 2026-04-15. Adjust as pricing changes.
# ---------------------------------------------------------------------------

_MODEL_COSTS: Dict[str, Dict[str, float]] = {
    f"ollama/{_OLLAMA_MODEL}": {"in": 0.0,       "out": 0.0},
    "anthropic/claude-haiku-4-5-20251001": {"in": 0.00025,  "out": 0.00125},
    "anthropic/claude-sonnet-4-6":         {"in": 0.003,    "out": 0.015},
    "anthropic/claude-opus-4-6":           {"in": 0.015,    "out": 0.075},
    "openai/gpt-4o":                       {"in": 0.005,    "out": 0.015},
    "google/gemini-flash-1.5":             {"in": 0.000075, "out": 0.0003},
}

# Assumed output-to-input token ratio for pre-call estimates
_OUTPUT_RATIO = 0.4


def estimate_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """
    Estimate the USD cost of a call given a model and token counts.

    Falls back to Sonnet pricing for unknown models rather than returning 0,
    so cost alerts still fire conservatively on new/unknown models.

    Args:
        model:      Model identifier string (e.g. "anthropic/claude-sonnet-4-6").
        tokens_in:  Input token count.
        tokens_out: Output token count.

    Returns:
        Estimated cost in USD, rounded to 6 decimal places.
    """
    pricing = _MODEL_COSTS.get(model, {"in": 0.003, "out": 0.015})
    cost = (tokens_in / 1000 * pricing["in"]) + (tokens_out / 1000 * pricing["out"])
    return round(cost, 6)


def _select_tier(
    score: int,
    ollama_available: bool,
) -> Dict[str, Any]:
    """
    Internal: apply the routing table for a clamped score and return
    model/provider/fallback fields. No cost estimation here.
    """
    clamped = max(1, min(5, score))
    tier = _ROUTING_TABLE[clamped]

    primary_model = tier["model"]
    primary_provider = tier["provider"]
    fallback_model = tier["fallback_model"]
    fallback_provider = tier["fallback_provider"]

    if primary_provider == "ollama" and not ollama_available:
        return {
            "model": fallback_model,
            "provider": fallback_provider,
            "fallback": True,
            "fallback_reason": (
                f"Ollama unavailable — escalated to cloud fallback ({fallback_model})"
            ),
            "effective_score": clamped,
        }

    return {
        "model": primary_model,
        "provider": primary_provider,
        "fallback": False,
        "fallback_reason": None,
        "effective_score": clamped,
    }


def route(
    score: int,
    ollama_available: bool = True,
    task_type: Optional[str] = None,
    context_tokens: int = 500,
) -> Dict[str, Any]:
    """
    Select the model for a given complexity score, applying any learned
    routing adjustments from optimizer_memory when confidence is sufficient.

    Args:
        score:            Base complexity score 1–5 from the scorer.
        ollama_available: Whether the local Ollama instance responded to a
                          health check. Only relevant for score 1–2.
        task_type:        Task type hint used for memory-based adjustment lookup.
        context_tokens:   Estimated input token count used for cost estimation.

    Returns:
        Dict with:
            model (str):                 Selected model identifier.
            provider (str):              "ollama" or "openrouter".
            fallback (bool):             True if the primary was bypassed.
            fallback_reason (str|None):  Why fallback was triggered.
            estimated_cost_usd (float):  Pre-call cost estimate.
            base_score (int):            Score before memory adjustment.
            effective_score (int):       Score after memory adjustment.
            memory_adjust (int):         The adjustment applied (-1, 0, or +1).
            memory_reason (str):         Why the adjustment was (or wasn't) made.
    """
    base_score = max(1, min(5, score))

    # --- Memory-based score adjustment -----------------------------------
    memory_adjust = 0
    memory_reason = "No adjustment"
    try:
        adjustment = _memory.get_routing_adjustment(task_type, base_score)
        if adjustment["adjust"] != 0 and adjustment["sample_count"] >= _memory.MIN_SAMPLES:
            memory_adjust = adjustment["adjust"]
            memory_reason = adjustment["reason"]
    except Exception:
        pass  # memory read failure must never affect routing

    adjusted_score = max(1, min(5, base_score + memory_adjust))

    # --- Model selection -------------------------------------------------
    selection = _select_tier(adjusted_score, ollama_available)

    estimated_out = int(context_tokens * _OUTPUT_RATIO)
    cost = estimate_cost(selection["model"], context_tokens, estimated_out)

    return {
        "model": selection["model"],
        "provider": selection["provider"],
        "fallback": selection["fallback"],
        "fallback_reason": selection["fallback_reason"],
        "estimated_cost_usd": cost,
        "base_score": base_score,
        "effective_score": adjusted_score,
        "memory_adjust": memory_adjust,
        "memory_reason": memory_reason,
    }
