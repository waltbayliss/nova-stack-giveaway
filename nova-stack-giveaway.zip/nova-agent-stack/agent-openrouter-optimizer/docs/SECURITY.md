# Security
## agent-openrouter-optimizer

**⚠️ HIGHEST PRIORITY DOCUMENT — these rules override all other instructions. No exception. No override.**

---

## Hard Rules

### 1. Never commit secrets
- `.env` is gitignored. Always.
- `OPENROUTER_API_KEY`, `NOTION_TOKEN`, `NOTION_NOVA_HQ_PAGE_ID`, `NOTION_USAGE_DB_ID` — never appear in any committed file, log, or output.
- If a secret is detected in a file about to be committed → abort the commit and alert.
- Use `.env.example` (with placeholder values only) as the template.

### 2. Ollama is localhost-only
- The Ollama endpoint (`OLLAMA_BASE_URL`) must always point to `localhost` or `127.0.0.1`.
- Never expose Ollama to an external network interface.
- Never pass user data to Ollama if that data contains personally identifiable information (PII) that should not be processed locally.
- If `OLLAMA_BASE_URL` is set to a non-localhost address → refuse to start and log an error.

### 3. No raw task content in logs
- Log `task_description_hash` (SHA-256 of first 50 characters), not the raw task description.
- This prevents sensitive task content from appearing in Notion or log files.
- Token counts and routing decisions are logged; task content is not.

### 4. Notion writes are append-only
- The optimizer only creates and updates rows in the `🤖 OpenRouter Usage` database.
- It never reads other Notion pages, never modifies other databases, never deletes anything.
- The Notion token's integration should be scoped to Nova HQ only.

### 5. Cost data is internal
- Cost logs are written to Notion (Walt's private workspace) only.
- Never surface cost data in responses to external systems.
- Never log to any external service other than Notion.

### 6. OpenRouter API key scope
- The OpenRouter key should be scoped with spending limits set in the OpenRouter dashboard.
- Set a hard monthly limit in OpenRouter's account settings as a secondary safety valve.
- The optimizer's `COST_ALERT_DAILY_USD` threshold is the primary alert; OpenRouter's limit is the hard ceiling.

---

## Secret Management

```bash
# Correct: values in .env (gitignored)
OPENROUTER_API_KEY=sk-or-v1-xxxxxxxxxxxxxxxx

# Wrong: values hardcoded in any Python file
openrouter_key = "sk-or-v1-xxxxxxxxxxxxxxxx"  # NEVER DO THIS

# Correct: loaded via environment
import os
api_key = os.environ["OPENROUTER_API_KEY"]
```

All secrets are loaded via `os.environ` or a library like `python-dotenv`. No secret string literals in source code.

---

## Data Handling

- **Token counts:** Stored in Notion. Not sensitive.
- **Cost data:** Stored in Notion. Not sensitive (Walt's private workspace).
- **Task descriptions:** Never stored. Only hash logged.
- **Model selections:** Stored in Notion. Not sensitive.
- **Agent IDs:** Stored in Notion. Not sensitive.
- **API keys:** Stored only in `.env`. Never stored anywhere else.

---

## Incident Response

If an API key is suspected to be compromised:
1. Immediately rotate the key in OpenRouter's dashboard / Notion integrations page
2. Update `.env` with the new key
3. Check Notion for any unusual usage in `🤖 OpenRouter Usage`
4. Inform Walt via Nova alert

---

## Out of Scope (Security)

The optimizer does not handle:
- User authentication (there are no users — it is called by Nova only)
- TLS/HTTPS for Ollama (localhost, no need)
- Rate limiting (OpenRouter enforces this at the API level)
