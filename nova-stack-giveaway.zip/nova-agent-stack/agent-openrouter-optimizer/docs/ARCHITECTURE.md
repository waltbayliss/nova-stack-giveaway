# Architecture
## agent-openrouter-optimizer

**Version:** 1.0  
**Date:** 2026-04-15

---

## System Overview

The OpenRouter Optimizer is a middleware layer. It does not execute tasks — it routes them. Every agent in the Nova ecosystem is model-agnostic at the point of task definition. Before any task is handed off to an agent, Nova passes the task descriptor to the optimizer. The optimizer returns a routing decision. Nova injects the model selection into the agent's execution context.

```
┌─────────────────────────────────────────────────────────────────┐
│                         NOVA (Orchestrator)                      │
│                                                                   │
│  User intent → Nova analyses → Nova dispatches task              │
└──────────────────────────┬──────────────────────────────────────┘
                           │  task_description, agent_id,
                           │  context_tokens, task_type
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                   OPENROUTER OPTIMIZER                           │
│                                                                   │
│  1. Complexity Scorer    → score: 1-5                            │
│  2. Model Router         → model selection + provider            │
│  3. Availability Check   → Ollama ping / OpenRouter health       │
│  4. Fallback Handler     → escalate if primary unavailable       │
│  5. Cost Estimator       → pre-call USD estimate                 │
│  6. Logger               → write to Notion + local log           │
│  7. Alert Checker        → check thresholds, surface if breached │
└──────────────────────────┬──────────────────────────────────────┘
                           │  RoutingResult
                           │  { model, provider, score, reason,
                           │    estimated_cost, fallback, alert }
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    DOWNSTREAM AGENT                              │
│                                                                   │
│  Receives model-injected execution context from Nova             │
│  Executes task using the assigned model                          │
│  Returns result to Nova                                          │
└──────────────────────────┬──────────────────────────────────────┘
                           │  tokens_out, latency_ms
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│              OPTIMIZER (post-execution logging)                  │
│                                                                   │
│  optimizer.log_completion() → update Notion row with actuals     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Complexity Scoring Logic

The complexity scorer analyses the task description using a rules-based heuristic, optionally augmented by a lightweight local model call (never a cloud call for scoring itself — that would be wasteful).

**Scoring heuristics:**

1. **Token count** — High context = higher score. Threshold: >4000 tokens → minimum score 3.
2. **Task type keywords:**
   - "format", "convert", "extract", "lookup" → score lean toward 1–2
   - "summarise", "classify", "list" → score lean toward 2–3
   - "draft", "write", "analyse", "explain" → score lean toward 3–4
   - "architect", "design", "reason", "evaluate" → score lean toward 4–5
   - "code", "implement", "debug", "refactor" → score lean toward 4–5
3. **Agent identity** — certain agents carry a minimum tier:
   - `agent-strategist` → minimum score 4
   - `agent-coder` → minimum score 4
   - `agent-summariser` → maximum score 3
4. **Explicit override** — Nova can pass `min_model_tier` to force a minimum score.

Final score = max(heuristic_score, agent_minimum, explicit_override)

---

## Model Priority Chain

```
Score 1-2: Ollama local
  └─ Primary: gemma3:4b (or configured OLLAMA_DEFAULT_MODEL)
  └─ Timeout: OLLAMA_TIMEOUT_MS (default 3000ms)
  └─ Fallback → Claude Haiku (OpenRouter)

Score 3: Claude Haiku / Gemini Flash
  └─ Primary: anthropic/claude-haiku-4-5 via OpenRouter
  └─ Alternative: google/gemini-flash-1.5 (lower cost option)
  └─ Fallback → Claude Sonnet

Score 3-4: Claude Sonnet
  └─ Primary: anthropic/claude-sonnet-4-6 via OpenRouter
  └─ Fallback → Claude Opus

Score 4-5: Claude Opus / GPT-4o
  └─ Primary: anthropic/claude-opus-4-6 via OpenRouter
  └─ Alternative: openai/gpt-4o (for tasks where OpenAI excels)
  └─ No fallback (highest tier)
```

---

## Fallback Logic

```python
def route_with_fallback(task, primary_model, primary_provider):
    if primary_provider == "ollama":
        available = ping_ollama()  # timeout: OLLAMA_TIMEOUT_MS
        if not available:
            log_fallback(reason="Ollama unavailable")
            increment_ollama_failure_count()
            if get_ollama_failure_count() >= 3:
                trigger_alert("OLLAMA_DOWN")
            return route_to_cloud_fallback(task)
    
    if primary_provider == "openrouter":
        try:
            return call_openrouter(task, primary_model)
        except OpenRouterError as e:
            log_fallback(reason=str(e))
            return call_openrouter(task, next_tier_model(primary_model))
    
    return RoutingResult(model=primary_model, provider=primary_provider, fallback=False)
```

---

## Logging Schema

Every call generates a log entry written to two destinations: Notion (primary, queryable) and local file (backup, optional).

**Log Entry Object:**
```json
{
  "call_id": "uuid",
  "timestamp": "2026-04-15T10:23:44Z",
  "agent_id": "agent-summariser",
  "task_description_hash": "sha256_first_50_chars",
  "complexity_score": 3,
  "model_selected": "anthropic/claude-haiku-4-5",
  "provider": "openrouter",
  "routing_reason": "Medium complexity summarisation; Ollama available but score 3 routes to Haiku",
  "tokens_in": 1200,
  "tokens_out": 350,
  "cost_usd": 0.00078,
  "latency_ms": 1240,
  "fallback": false,
  "fallback_reason": null,
  "alert_triggered": false
}
```

---

## Notion Integration

**Target:** Nova HQ workspace, `🤖 OpenRouter Usage` database.

**Write sequence:**
1. On routing decision → write pre-call row with estimated cost (tokens_out = 0, latency_ms = 0)
2. On `log_completion()` call → update row with actual tokens_out and latency_ms
3. On first run → check if DB exists via Notion search; create if not; store DB ID in `.env`

**Notion write uses the official Notion API** via `NOTION_TOKEN`. Writes are non-blocking — if Notion is unavailable, log locally and retry on next run. Never let a failed Notion write interrupt a routing decision.

---

## Ollama Integration

- Endpoint: `OLLAMA_BASE_URL` (default `http://localhost:11434`)
- Health check: `GET /api/tags` — returns available models
- Model call: `POST /api/generate` or OpenAI-compatible `/v1/chat/completions`
- Timeout: configured by `OLLAMA_TIMEOUT_MS`
- **Localhost-only**: Ollama is never exposed externally. The optimizer only calls it from the same machine.

---

## OpenRouter Integration

- Base URL: `https://openrouter.ai/api/v1`
- Auth: `Authorization: Bearer $OPENROUTER_API_KEY`
- Interface: OpenAI-compatible `/chat/completions`
- Model strings used:
  - `anthropic/claude-haiku-4-5-20251001`
  - `anthropic/claude-sonnet-4-6`
  - `anthropic/claude-opus-4-6`
  - `openai/gpt-4o`
  - `google/gemini-flash-1.5`

---

## Directory Structure

```
agent-openrouter-optimizer/
├── CLAUDE.md              ← boot sequence + operating rules
├── README.md              ← public entry point
├── agent-memory.md        ← cross-session learnings
├── .env.example           ← required secrets template
├── .env                   ← (gitignored) real secrets
├── .gitignore
├── docs/
│   ├── PRD.md
│   ├── ARCHITECTURE.md
│   ├── SOUL.md
│   ├── SECURITY.md
│   ├── ROADMAP.md
│   ├── DECISIONS.md
│   └── SPRINT_LOG.md
├── skills/
│   └── model-routing.md   ← core routing skill spec
├── src/                   ← (Phase 1 implementation)
│   ├── optimizer.py
│   ├── scorer.py
│   ├── router.py
│   ├── logger.py
│   ├── notion_writer.py
│   └── ollama_client.py
└── wiki/
    ├── Raw/
    ├── Wiki/
    ├── Output/
    └── Master/
        └── master-context.md
```
