# Product Requirements Document
## agent-openrouter-optimizer

**Version:** 1.0  
**Date:** 2026-04-15  
**Status:** Active

---

## Overview

The OpenRouter Optimizer is a middleware agent that sits between Nova (the orchestrator) and all downstream agents in the Nova ecosystem. Its role is to intercept every task dispatch, analyse the intent and complexity of the task, select the most cost-effective model that can deliver the required quality, and inject that model selection before execution. Agents in the Nova ecosystem are model-agnostic — they declare what they need to do, not which model should do it. The optimizer decides.

---

## Target User

**Primary user:** Walt Bayliss, sole operator of the Nova agent ecosystem.  
**Secondary user:** Nova (the orchestrator AI), which calls the optimizer programmatically before every agent dispatch.

The core problem being solved: As the Nova ecosystem scales to more agents and more tasks, running every call through Claude Opus or GPT-4o becomes prohibitively expensive. But routing everything to the cheapest model sacrifices quality on tasks that require it. The optimizer exists to make this decision precisely and automatically — delivering quality where needed, cost savings everywhere else.

---

## Core Features (MVP)

### 1. Complexity Scoring Engine
Analyse incoming task descriptions and classify them on a 1–5 scale:

| Score | Label | Characteristics |
|-------|-------|-----------------|
| 1 | Trivial | Formatting, lookup, echo, fill-in-the-blank |
| 2 | Simple | Single-step summarise, classify, extract, transform |
| 3 | Medium | Multi-step reasoning, draft creation, structured output |
| 4 | Moderately Complex | Analysis with multiple considerations, long context, tool use |
| 5 | Complex | Deep reasoning, architectural decisions, long documents, code generation |

Scoring inputs: task description text, estimated context token count, task type category, agent identity.

### 2. Model Routing Engine
Map complexity score to the optimal model from the priority chain:

| Complexity | Primary Model | Provider | Fallback |
|------------|--------------|----------|----------|
| 1–2 | Ollama local (gemma3:4b or equivalent) | Local | Claude Haiku |
| 3 | Claude Haiku / Gemini Flash | OpenRouter | Claude Sonnet |
| 3–4 | Claude Sonnet | OpenRouter | Claude Opus |
| 4–5 | Claude Opus / GPT-4o | OpenRouter | — |

Routing also considers: task type (code vs prose vs analysis), context window requirements, agent-specific overrides (certain agents may require minimum model tier).

### 3. Call Logging
Every routed call is logged with:
- Timestamp (ISO 8601)
- Agent ID
- Model selected
- Complexity score
- Routing reason (human-readable string)
- Tokens in (estimated)
- Tokens out (estimated)
- Cost USD (calculated at time of routing using current model pricing)
- Latency ms (measured from route request to model response)
- Fallback flag (boolean: was the primary model unavailable?)
- Fallback reason (if applicable)

### 4. Fallback Logic
If the primary model is unavailable:
- Ollama unavailable (timeout > `OLLAMA_TIMEOUT_MS`) → escalate to Haiku/Flash immediately
- OpenRouter API error → retry once, then escalate one tier
- Log every fallback with reason
- After 3 consecutive Ollama failures → trigger ALERT to Nova

### 5. Notion Dashboard Writes
After each call, write a row to the `🤖 OpenRouter Usage` Notion database in Nova HQ.

**Database Schema:**

| Field | Type | Description |
|-------|------|-------------|
| Date | Date | Call timestamp |
| Agent Name | Text | Calling agent ID |
| Model Used | Select | Model that executed the call |
| Tokens In | Number | Input token count |
| Tokens Out | Number | Output token count |
| Cost USD | Number | Calculated cost |
| Latency ms | Number | Response latency |
| Complexity Score | Number | Assigned score (1–5) |
| Notes | Text | Routing reason, fallback notes |

On first run, if the database does not exist: create it under the `NOTION_NOVA_HQ_PAGE_ID` page and store the resulting DB ID in `.env` as `NOTION_USAGE_DB_ID`.

### 6. Alert System
Alert conditions that trigger a structured alert to Nova:

| Condition | Threshold | Alert Message |
|-----------|-----------|---------------|
| Daily cost spike | > $5.00/day | "Daily spend has exceeded $5.00 — review usage" |
| Single expensive call | > $0.50/call | "Single call cost $X.XX — [agent] used [model]" |
| Ollama repeated failure | 3+ consecutive | "Ollama appears to be down — all tasks routing to cloud" |
| High fallback rate | > 30% in 1 hour | "Fallback rate is X% — check Ollama health" |

Alerts are returned as structured objects to Nova. Nova is responsible for surfacing them to Walt.

---

## API Interface

### `optimizer.route(task)` → `RoutingResult`

**Input:**
```python
{
  "task_description": str,     # Natural language task description
  "agent_id": str,             # Calling agent identifier
  "context_tokens": int,       # Estimated input token count
  "task_type": str,            # Optional: "code" | "prose" | "analysis" | "lookup"
  "min_model_tier": int        # Optional: minimum complexity tier override (1-5)
}
```

**Output:**
```python
{
  "model": str,                 # Model identifier string
  "provider": str,              # "ollama" | "openrouter"
  "complexity_score": int,      # Assigned score 1-5
  "routing_reason": str,        # Human-readable explanation
  "estimated_cost_usd": float,  # Pre-call cost estimate
  "fallback": bool,             # Whether fallback was triggered
  "alert": dict | None          # Alert object if threshold breached
}
```

### `optimizer.log_completion(call_id, tokens_out, latency_ms)` → `None`
Called after agent execution completes to record final token counts and latency.

### `optimizer.get_daily_summary()` → `DailySummary`
Returns today's spend, model distribution, and savings vs baseline.

---

## Out of Scope (MVP)
- Learning/self-optimization (Phase 3)
- UI or dashboard beyond Notion writes
- Multi-user support
- Rate limiting or request queuing
