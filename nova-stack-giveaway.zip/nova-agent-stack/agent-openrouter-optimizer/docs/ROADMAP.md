# Roadmap
## agent-openrouter-optimizer

**Updated:** 2026-04-15

---

## Phase 1 — Core Routing Middleware
**Target:** Fully functional routing, logging, and fallback

### Goal
Nova can call the optimizer before every task dispatch and receive a reliable model selection with cost estimate. All calls are logged to Notion. Fallbacks work silently.

### Deliverables
- [ ] `src/scorer.py` — complexity scoring engine (heuristic-based)
- [ ] `src/router.py` — model routing logic (priority chain)
- [ ] `src/ollama_client.py` — Ollama health check + call wrapper
- [ ] `src/notion_writer.py` — Notion DB create + row write + row update
- [ ] `src/logger.py` — structured logging (Notion + optional local file)
- [ ] `src/optimizer.py` — main interface: `route()`, `log_completion()`, `get_daily_summary()`
- [ ] `.gitignore` — exclude `.env`, `__pycache__`, logs
- [ ] `requirements.txt` — pinned dependencies
- [ ] Unit tests for scorer and router
- [ ] Integration test: end-to-end route call with Ollama mock

### Definition of Done
- Nova can call `optimizer.route(task)` and receive a valid `RoutingResult`
- All 5 complexity levels route to the correct model tier
- Ollama fallback works: kill Ollama → call still succeeds via Haiku
- Notion `🤖 OpenRouter Usage` DB is populated with real rows
- Alert fires when daily cost threshold is breached (test with low threshold)

---

## Phase 2 — Notion Dashboard
**Target:** Cost visibility, savings tracking, trend reporting

### Goal
Walt can look at the Nova HQ Notion workspace and see, at a glance: what was spent today, this week, this month; which agents are most expensive; savings vs "always Opus" baseline; latency trends by model.

### Deliverables
- [ ] Daily rollup view in Notion (grouped by agent, by model)
- [ ] Weekly summary page (auto-written every Monday)
- [ ] "Savings vs baseline" calculation: what it would have cost if every call used Claude Opus
- [ ] Latency trend chart (Notion chart or external simple dashboard)
- [ ] Spend alert history log
- [ ] Nova daily briefing integration: optimizer summary included in Walt's morning update

### Definition of Done
- Walt receives a morning summary from Nova that includes yesterday's optimizer stats
- The Notion dashboard shows spend by agent for the past 7 days
- Savings vs Opus baseline is calculated and displayed

---

## Phase 3 — Self-Optimizing Router
**Target:** Router learns from outcomes and improves routing decisions over time

### Goal
The optimizer tracks not just which model was used, but whether the output was acceptable (based on downstream agent success/retry rates). Over time, it adjusts routing heuristics based on observed quality outcomes.

### Deliverables
- [ ] Outcome tracking: Nova signals whether an agent's output was accepted or retried
- [ ] Per-agent, per-task-type routing history in `agent-memory.md`
- [ ] Heuristic tuning: if score-3 tasks consistently need retry from Haiku, auto-elevate to Sonnet
- [ ] A/B testing mode: occasionally route a score-2 task to Haiku to test quality vs Ollama
- [ ] Monthly routing report: how heuristics changed, what was learned

### Definition of Done
- Routing decisions demonstrably improve over a 30-day window
- `agent-memory.md` contains actionable routing learnings
- Quality-adjusted cost-per-task is trending down

---

## Future Considerations
- Multi-workspace support (if Nova expands beyond Walt's workspace)
- Real-time dashboard (beyond Notion — e.g., a local web UI)
- Model benchmarking: automated quality scoring for routing calibration
- Budget forecasting: predict monthly spend based on task patterns
