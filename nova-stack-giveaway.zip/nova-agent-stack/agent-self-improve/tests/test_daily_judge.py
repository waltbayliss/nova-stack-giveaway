"""
Tests for daily_judge.py — adversarial judge logic, ensemble scoring, SHA chain.
"""

import hashlib
import json
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Make src importable
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from daily_judge import (
    _clamp_scores,
    _deterministic_check,
    _verify_sha_chain,
    JUDGE_MODELS,
)


# ---------------------------------------------------------------------------
# Adversarial judge model selection
# ---------------------------------------------------------------------------

def test_claude_agent_gets_gemini_judge():
    """Claude agents must receive a Gemini judge — never Claude."""
    judge = JUDGE_MODELS.get("claude", "")
    assert "gemini" in judge.lower(), f"Expected Gemini judge for Claude agents, got: {judge}"


def test_gemini_agent_gets_claude_judge():
    """Gemini agents must receive a Claude judge."""
    judge = JUDGE_MODELS.get("gemini", "")
    assert "claude" in judge.lower(), f"Expected Claude judge for Gemini agents, got: {judge}"


def test_openai_agent_gets_claude_judge():
    """OpenAI agents must receive a Claude judge."""
    judge = JUDGE_MODELS.get("openai", "")
    assert "claude" in judge.lower(), f"Expected Claude judge for OpenAI agents, got: {judge}"


def test_judge_model_family_differs_from_agent_family():
    """For all model families, judge family must differ from agent family."""
    for agent_family, judge_model in JUDGE_MODELS.items():
        if agent_family == "mixed":
            continue
        assert agent_family not in judge_model.lower(), (
            f"Judge model '{judge_model}' contains agent family '{agent_family}' — echo chamber!"
        )


# ---------------------------------------------------------------------------
# Score clamping
# ---------------------------------------------------------------------------

def test_score_clamping_above_10():
    breakdown = {"voice_match": {"score": 15.0, "reasoning": "too high"}}
    clamped = _clamp_scores(breakdown)
    assert clamped["voice_match"]["score"] == 10.0


def test_score_clamping_below_0():
    breakdown = {"hook_quality": {"score": -3.0, "reasoning": "negative"}}
    clamped = _clamp_scores(breakdown)
    assert clamped["hook_quality"]["score"] == 0.0


def test_score_in_range_not_modified():
    breakdown = {"structure": {"score": 7.5, "reasoning": "good"}}
    clamped = _clamp_scores(breakdown)
    assert clamped["structure"]["score"] == 7.5


def test_reasoning_text_preserved_after_clamp():
    breakdown = {"specificity": {"score": 12.0, "reasoning": "very specific"}}
    clamped = _clamp_scores(breakdown)
    assert clamped["specificity"]["reasoning"] == "very specific"


# ---------------------------------------------------------------------------
# SHA chain verification
# ---------------------------------------------------------------------------

def _make_chain(n: int) -> list:
    """Build a valid SHA chain of n entries."""
    lines = []
    prev_hash = "genesis"
    for i in range(n):
        entry = {"run_id": str(i), "prev_hash": prev_hash}
        line = json.dumps(entry, separators=(",", ":"))
        lines.append(line)
        prev_hash = hashlib.sha256(line.encode()).hexdigest()
    return lines


def test_valid_sha_chain_passes():
    lines = _make_chain(5)
    assert _verify_sha_chain(lines) is True


def test_tampered_entry_breaks_chain():
    lines = _make_chain(5)
    # Tamper entry 2 — modifies its content without updating entry 3's prev_hash
    entry = json.loads(lines[2])
    entry["extra"] = "TAMPERED"
    lines[2] = json.dumps(entry, separators=(",", ":"))
    assert _verify_sha_chain(lines) is False


def test_empty_chain_passes():
    assert _verify_sha_chain([]) is True


def test_single_entry_chain_passes():
    lines = _make_chain(1)
    assert _verify_sha_chain(lines) is True


# ---------------------------------------------------------------------------
# Deterministic pre-checks
# ---------------------------------------------------------------------------

def test_valid_entry_passes_deterministic_check():
    entry = {
        "timestamp": "2026-06-15T10:00:00Z",
        "agent_name": "test-agent",
        "run_id": "abc-123",
        "output_summary": "Posted 1 LinkedIn post",
        "status": "success",
        "prev_hash": "genesis",
    }
    assert _deterministic_check(entry) is True


def test_missing_output_summary_fails():
    entry = {
        "timestamp": "2026-06-15T10:00:00Z",
        "agent_name": "test-agent",
        "run_id": "abc-123",
        "output_summary": "",
        "status": "success",
        "prev_hash": "genesis",
    }
    assert _deterministic_check(entry) is False


def test_missing_required_field_fails():
    entry = {
        "timestamp": "2026-06-15T10:00:00Z",
        "agent_name": "test-agent",
        # run_id missing
        "output_summary": "some output",
        "status": "success",
        "prev_hash": "genesis",
    }
    assert _deterministic_check(entry) is False
