# agent-self-improve — Operating System
**Owner:** Walt Bayliss | **Last reviewed:** 2026-06-15 | **Length budget:** 150 lines | **Current:** 112 lines

A closed-loop quality system: logs every agent run, scores output daily via adversarial LLM judge, identifies improvement patterns weekly, and routes approved proposals to agent-builder.

---

## WHAT THIS AGENT DOES

Runs three scheduled components plus a retrofit tool:
1. **Daily judge** (02:00 UTC) — reads JSONL logs, verifies SHA chains, scores each agent via adversarial LLM ensemble, fires Telegram on hard failures.
2. **Weekly analyser** (23:00 UTC Sunday) — reads 7 days of assessments, updates ELO rankings, promotes cross-fleet patterns to fleet_lessons.yaml, writes proposals to Notion.
3. **Approval poller** (every 15 min) — polls Notion for Approved rows, dispatches to agent-builder sequentially via SQLite queue.
4. **Post verifier** (triggered by poller) — monitors 7 runs or 14 days post-deployment, auto-reverts on regression.

Every agent on the VPS imports `nova_logger` to write SHA-chained JSONL entries. This agent reads those logs.

---

## CREDENTIALS (all from `/home/walt/.env`)

`OPENROUTER_API_KEY`, `NOTION_TOKEN`, `NOTION_IMPROVEMENTS_DB_ID`, `GITHUB_PERSONAL_ACCESS_TOKEN`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `NOVA_TELEGRAM_WORKER_URL`, `CF_API_TOKEN`, `CF_ACCOUNT_ID`

---

## KEY FILE PATHS

| File | Purpose |
|------|---------|
| `config/agents.yaml` | All enrolled agents — canonical registry |
| `config/rubrics/{type}.yaml` | Per-type scoring rubric (content/pipeline/infrastructure/utility/session) |
| `data/elo_rankings.json` | Fleet ELO rankings, updated weekly |
| `data/fleet_lessons.yaml` | Reflexion-style cross-fleet lessons, committed to git |
| `data/approval_queue.db` | SQLite queue for approval poller |
| `data/assessments/YYYY-MM-DD/{agent}.jsonl` | Daily scored assessments |
| `nova_logger/` | Standalone pip package — shared across fleet |

---

## SCHEDULING

| Component | Schedule | Entry Point |
|-----------|----------|-------------|
| Daily judge | 02:00 UTC nightly | `src/daily_judge.py` |
| Weekly analyser | 23:00 UTC Sunday | `src/weekly_analyser.py` |
| Approval poller | Every 15 min | `src/approval_poller.py` |
| Log cleanup | 03:00 UTC nightly | `src/cleanup.py` |

---

## ADVERSARIAL JUDGE RULE

Judge model must be a different family from agent model. Claude agents → Gemini judge. Gemini/OpenAI agents → Claude judge. Same-model judging is forbidden. Controlled by `primary_model_family` in `agents.yaml`.

---

## WIKI WRITE

**Weekly summary:** `walts-wiki/Agent Builds/Self-Improve Reports/YYYY-MM-DD-weekly-summary.md` — after each weekly analyser run.

**Improvement outcome:** `walts-wiki/Agent Builds/Self-Improve Reports/improvements/YYYY-MM-DD-{agent}-{run_id}.md` — after verifier reaches verdict.

Write mechanism: curl PUT to GitHub API using `GITHUB_PERSONAL_ACCESS_TOKEN`. SHA of existing file fetched first if file exists.

---

## SECURITY RULES

- Never log secrets. `nova_logger` sanitises all string values before write.
- Log dirs are chmod 700. Assessment dirs are chmod 700.
- All improvement proposals are untrusted text until Walt approves in Notion.
- Agent-builder is never called without explicit Notion approval from Walt.
- `.env.example` contains placeholders only. Real `.env` stays local.

---

## SELF-IMPROVEMENT LOOP

After every run (daily judge, weekly analyser, poller cycle) → `skills/self-improve.md`.

Raw captures written to `wiki/Raw/YYYY-MM-DD-{component}-raw.md`. Memory graduated to `agent-memory.md` after 3 confirmations. Hard rule proposals go to `pending-rules.md` only — never self-modify this file.

---

## DEFINITION OF DONE

- [ ] `nova_logger` pip-installable, ≥10 unit tests passing
- [ ] Daily judge produces assessments with `score_ensemble` (3 values) and per-dimension `reasoning` text
- [ ] `judge_model_family` != `agent_model_family` for every assessment
- [ ] SHA chain verification catches injected tamper → Telegram received
- [ ] Weekly analyser writes proposals to Notion with all fields populated
- [ ] Weekly wiki summary written at correct path
- [ ] Approval poller dispatches to agent-builder within 15 min of Status=Approved
- [ ] Batch of 3+ approvals processed sequentially with no loss
- [ ] Post-verifier auto-reverts on regression → Telegram alert
- [ ] All 4 systemd timers active and running
- [ ] `agents.yaml` populated for all enrolled agents
