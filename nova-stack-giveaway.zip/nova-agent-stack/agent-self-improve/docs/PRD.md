# agent-self-improve — Product Requirements Document

**Version:** 2.0 (Reviewed)
**Date:** 2026-06-15
**Author:** Nova (via PRD Builder interview with Walt Bayliss)
**Reviewed by:** agent-prd-reviewer
**Status:** Active — source of truth for this build

---

This file is the canonical reviewed PRD. Full text lives at:
`/home/walt/agents/nova-assistant/pending-builds/agent-self-improve-reviewed.md`

Key sections reproduced here for agent-local reference:

## Purpose

Closed-loop quality system for Walt's AI agent fleet. Logs every agent run, scores output daily via adversarial LLM judge, identifies improvement patterns weekly, routes approved proposals to agent-builder. Makes the fleet continuously smarter without Walt having to notice problems first.

## Seven Components

1. `nova_logger/` — standalone pip package, SHA-chained JSONL writer, secret sanitiser
2. `src/daily_judge.py` — deterministic pre-checks + 3-run ensemble adversarial LLM scoring
3. `src/weekly_analyser.py` — ELO rankings, Reflexion lessons, Notion proposals
4. `src/approval_poller.py` — 15-min Notion poll, SQLite queue, sequential agent-builder dispatch
5. `src/post_verifier.py` — 7-run / 14-day monitoring, auto-revert on regression
6. `tools/retrofit.py` — one-time fleet enrolment
7. `tools/scaffold_update.py` — patch agent-builder template

## Adversarial Judge

Judge model must be different family from agent model. `primary_model_family` in `agents.yaml` drives selection:
- claude agents → `google/gemini-flash-1.5`
- gemini / openai agents → `anthropic/claude-haiku-4-5`

## Scoring

- 0.0–10.0 scale, clamped
- 5-dimension score_breakdown with per-dimension reasoning text
- 3-run ensemble at temperature=0, scores averaged
- 6-category failure_category enum

## Scheduling

| Component | Schedule | Unit |
|-----------|----------|------|
| Daily judge | 02:00 UTC nightly | agent-self-improve-daily.timer |
| Weekly analyser | 23:00 UTC Sunday | agent-self-improve-weekly.timer |
| Approval poller | Every 15 min | agent-self-improve-poller.timer |
| Log cleanup | 03:00 UTC nightly | agent-self-improve-cleanup.timer |

## MyDPA Packaging Boundaries (v1 must not foreclose v2)

- `agents.yaml` supports `namespace` field (default: `walt`)
- Rubric definitions are client-configurable YAML files
- Notion DB IDs are environment variables
- `nova_logger` accepts `namespace` parameter at init time
- SQLite DB path is configurable

## Full PRD

See `/home/walt/agents/nova-assistant/pending-builds/agent-self-improve-reviewed.md` for complete 705-line reviewed PRD including all data models, edge cases, security rules, and agent-builder interface contract.
