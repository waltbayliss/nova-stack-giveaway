# agent-self-improve — Architecture

**Version:** 1.0 | **Date:** 2026-06-15

---

## System Overview

```
Fleet agents (nova_logger installed)
  │
  ▼ write SHA-chained JSONL
{agent}/logs/YYYY-MM-DD.jsonl
  │
  ▼ 02:00 UTC nightly
daily_judge.py
  ├── SHA chain verification
  ├── Deterministic pre-checks (gate-agent duality)
  ├── asyncio.gather() → 3-run ensemble per agent (adversarial judge)
  └── data/assessments/YYYY-MM-DD/{agent}.jsonl
         │
         ▼ 23:00 UTC Sunday
         weekly_analyser.py
           ├── 7-day assessment aggregation
           ├── ELO ranking update (K=32)
           ├── fleet_lessons.yaml promotion (Reflexion)
           ├── Notion Agent Improvements DB proposals
           ├── Telegram weekly summary
           └── Walt's Wiki weekly summary report
                 │
                 ▼ Walt reviews, sets Status=Approved in Notion
                 approval_poller.py (every 15 min)
                   ├── SQLite queue (approval_queue.db)
                   ├── Sequential dispatch to agent-builder CLI
                   └── Notion status updates
                         │
                         ▼ agent-builder deploys change
                         post_verifier.py
                           ├── 7-run or 14-day monitoring window
                           ├── Score comparison vs baseline
                           ├── Auto-revert on regression (git revert + push)
                           └── Walt's Wiki improvement outcome report
```

---

## Components

### nova_logger (pip package)

**Location:** `nova_logger/`
**Install:** `pip install -e /home/walt/agents/agent-self-improve/nova_logger`
**Public API:**

```python
from nova_logger import NovaLogger

logger = NovaLogger(
    agent_name="agent-social-poster",
    log_dir="/home/walt/agents/agent-social-poster/logs",
    namespace="walt"       # MyDPA multi-tenant field
)

logger.log(
    trigger="systemd-timer",
    input_summary="...",
    decisions=["..."],
    output_summary="...",
    output_artifacts=[],
    errors=[],
    failure_category=None,
    model_used="claude-haiku-4-5",
    cost_usd=0.0018,
    duration_seconds=14.2,
    status="success",
    hard_failure=False
)
```

**Non-fatal contract:** All exceptions caught internally. Agent continues. Logger writes to stderr.

**SHA chain:** Each entry's `prev_hash` = SHA-256 of previous entry text. First entry in a new file uses SHA-256 of last entry from prior file, or `"genesis"`.

**Write contract:** Atomic temp-file + rename. One JSON object per line.

**Secret sanitisation patterns:** `sk-`, `Bearer `, `token=`, `password=`, any value >40 chars with no spaces → `[REDACTED]`.

---

### daily_judge.py

**Trigger:** `agent-self-improve-daily.timer` at 02:00 UTC
**Input:** `{log_path}/YYYY-MM-DD.jsonl` for each agent in `config/agents.yaml`
**Output:** `data/assessments/YYYY-MM-DD/{agent_name}.jsonl`

**Algorithm:**
1. Load `config/agents.yaml` → enrolled agents list
2. For each agent: read today's JSONL log
3. Verify SHA chain → quarantine on failure, Telegram alert, skip
4. For each log entry: deterministic pre-checks
   - `exit_code == 0` present
   - `output_summary` non-empty
   - Required fields present
   - Failed entries: `hard_failure=true`, `failure_category="incomplete_task"`, skip LLM
5. `asyncio.gather()` → all agents scored in parallel
6. Per-agent: 3 LLM calls at temperature=0 via OpenRouter (adversarial family)
7. Scores clamped to [0,10], averaged, all 3 stored in `score_ensemble`
8. Assessment written with per-dimension reasoning text
9. Hard failures → immediate Telegram alert (not queued for weekly)

**Adversarial model selection:**

```python
JUDGE_MODELS = {
    "claude": "google/gemini-flash-1.5",
    "gemini": "anthropic/claude-haiku-4-5",
    "openai": "anthropic/claude-haiku-4-5",
    "mixed":  "google/gemini-flash-1.5",
}
```

**Cloudflare exception:** `agent-daily-brief` has `log_path: cf-kv:agent-daily-brief` in `agents.yaml`. Daily judge reads from CF KV store instead of local file. Key pattern: `log:{date}:{run_id}`.

**Session agent window:** Agents of type `session` use rolling 7-day window instead of today's logs.

---

### weekly_analyser.py

**Trigger:** `agent-self-improve-weekly.timer` at 23:00 UTC Sunday
**Input:** `data/assessments/` (7 days)
**Output:** Notion proposals, `data/elo_rankings.json`, `data/fleet_lessons.yaml`, Walt's Wiki

**Algorithm:**
1. Load all assessment JSONL from past 7 days
2. Group by `failure_category` and rubric dimension
3. Apply proposal triggers (see Section 7 of PRD)
4. ELO update: K=32, head-to-head comparison vs fleet average
5. Cross-fleet pattern check: same `failure_category` in 3+ agents → promote to `fleet_lessons.yaml`
6. Write proposals to Notion (400ms sleep between writes)
7. Deduplication: check existing rows for same `agent_name` + `failing_dimension` + ISO week
8. Batch cap: >15 proposals → queue remainder to next week (Critical always included)
9. Write weekly summary to Walt's Wiki via curl
10. Send Telegram summary

---

### approval_poller.py

**Trigger:** `agent-self-improve-poller.timer` every 15 min
**Input:** Notion Agent Improvements DB
**State:** `data/approval_queue.db` (SQLite)

**Algorithm:**
1. Poll Notion for `Status = Approved` rows
2. Insert new approved rows into SQLite queue (UNIQUE on `notion_page_id`)
3. Process queue sequentially (one at a time):
   a. Check `systemctl is-active agent-builder.service` — if inactive: mark `builder_unavailable`, Telegram, skip
   b. Write proposal JSON to `/tmp/proposal_{page_id}.json`
   c. Invoke agent-builder CLI
   d. On success (exit 0): read commit SHA from stdout, update Notion to `Deployed`
   e. On failure: retry up to 3×, then mark `Failed`, Telegram alert, continue to next
4. Update Notion: `Status`, `Date Deployed`, `Builder Commit SHA`

---

### post_verifier.py

**Trigger:** Called by approval_poller after each successful deployment
**Monitoring window:** 7 actual logged runs OR 14 calendar days

**Algorithm:**
1. Load pre-deployment baseline (last 7 assessments before deployment)
2. Insufficient baseline (<5 runs): log `insufficient_baseline`, skip regression check
3. Poll `data/assessments/` for new runs attributed to this agent
4. On reaching 7 runs or 14 days:
   a. Calculate post-deployment average
   b. Compare to baseline
   c. Improvement (post > pre): Notion → `Verified`, Telegram, Wiki outcome report
   d. Regression (post < pre - 0.5): git revert, push, Notion → `Reverted`, Telegram, Wiki report
   e. Git revert failure: Notion → `Revert Failed`, Telegram with manual instructions + SHA

**Revert mechanics:**
```bash
git revert {builder_commit_sha} --no-edit
git push origin main
```
Uses `GITHUB_PERSONAL_ACCESS_TOKEN`.

---

### cleanup.py

**Trigger:** `agent-self-improve-cleanup.timer` at 03:00 UTC nightly
**Action:** Delete `data/assessments/` files older than 30 days. Quarantined files (`.quarantine` suffix) are exempt from deletion.

---

## Data Flow

### Log entry (written by nova_logger in host agent)
```
{agent}/logs/YYYY-MM-DD.jsonl
  └── one JSON object per line
  └── SHA-chained via prev_hash field
  └── atomic write (temp + rename)
```

### Assessment (written by daily_judge)
```
data/assessments/YYYY-MM-DD/{agent_name}.jsonl
  └── score, score_ensemble[3], score_breakdown{5 dims}
  └── failure_category, hard_failure, integrity_error
  └── judge_model, judge_model_family, agent_model_family
```

### Approval queue (SQLite)
```
data/approval_queue.db
  └── approval_queue table
  └── fleet_elo_history table
```

---

## Wiki Write Specification

### Weekly Summary
- **Trigger:** After each weekly analyser run (Sunday 23:00 UTC)
- **Path:** `walts-wiki/Agent Builds/Self-Improve Reports/YYYY-MM-DD-weekly-summary.md`
- **Content:** Fleet score table, proposal counts by severity, cross-fleet patterns, integrity errors
- **Mechanism:** curl PUT to GitHub API, SHA fetched first if file exists

### Improvement Outcome
- **Trigger:** Post-verifier reaches verdict (Verified / Reverted / Revert Failed)
- **Path:** `walts-wiki/Agent Builds/Self-Improve Reports/improvements/YYYY-MM-DD-{agent}-{run_id}.md`
- **Content:** Agent, proposal, score before/after, verdict, commit SHAs, evidence run IDs
- **Mechanism:** curl PUT to GitHub API, `_v2` suffix on conflict

---

## DB Schema

### Notion Agent Improvements DB

Fields required (set `NOTION_IMPROVEMENTS_DB_ID` in `.env`):

| Field | Type |
|-------|------|
| Upgrade Title | Title |
| Agent Name | Select |
| Agent Purpose | Text |
| Proposed Upgrade | Text |
| Severity | Select: Critical / Bug / Improvement |
| Evidence | Text |
| Failing Dimension | Select |
| Failure Category | Select |
| Expected Impact | Text |
| Status | Select: Pending Review / Approved / Building / Deployed / Verified / Reverted / Revert Failed / Rejected / Failed |
| Score Before | Number |
| Score After | Number |
| Weekly Batch | Text |
| Date Proposed | Date |
| Date Approved | Date |
| Date Deployed | Date |
| Builder Commit SHA | Text |

---

## Security Architecture

- All credentials from `/home/walt/.env`. Never hardcoded.
- `nova_logger` sanitises all string values before write.
- Log dirs chmod 700, owned by `walt`.
- Assessment dirs chmod 700.
- Notion proposals never contain credential values.
- Builder dispatch is VPS-local — no external webhook surface.
- SHA-chain verification gates all scoring.
- All LLM proposals are untrusted until Walt explicitly approves in Notion.
- `fleet_lessons.yaml` committed to git — fully auditable.
