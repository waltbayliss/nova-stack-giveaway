# agent-self-improve — Roadmap

**Last updated:** 2026-06-15

---

## v1.0 — Current Build (MVP)

- [x] `nova_logger` pip package with SHA-chaining, sanitiser, non-fatal contract
- [x] Daily judge: deterministic pre-checks + 3-run adversarial LLM ensemble
- [x] asyncio.gather() for parallel fleet scoring
- [x] SHA chain integrity verification + quarantine path
- [x] Weekly analyser: ELO rankings (K=32), Reflexion lessons, Notion proposals
- [x] 5-dimension score_breakdown with per-dimension reasoning text
- [x] 6-category failure_category taxonomy
- [x] Approval poller: SQLite queue, sequential agent-builder dispatch
- [x] Post-improvement verifier: auto-revert on regression
- [x] Walt's Wiki write: weekly summary + improvement outcome reports
- [x] Retrofit script: fleet enrolment with dry-run mode
- [x] Scaffold update: agent-builder template patching
- [x] 4 systemd timers (daily, weekly, poller, cleanup)
- [x] 30-day log retention with quarantine exemption
- [x] Cloudflare KV special handler for agent-daily-brief
- [x] MyDPA packaging boundaries: namespace field, configurable rubrics, env-var DB IDs

---

## v1.1 — Near Term (Post-Deployment Hardening)

- [ ] Staging test harness: inject controlled failure entries to test all alert paths without real agent degradation
- [ ] Score trending visualisation: generate a simple Markdown table chart in weekly wiki summary
- [ ] ELO history graph: write weekly ELO movement to wiki summary as ASCII table
- [ ] `nova_logger` v1.1: add `token_count` field for LLM cost tracking
- [ ] Per-agent rubric override: allow `agents.yaml` to specify a custom rubric YAML path (overrides type default)
- [ ] Retry queue for failed Notion writes (currently on next weekly run only)

---

## v1.2 — Medium Term

- [ ] Manual re-score command: `python3 src/daily_judge.py --agent agent-social-poster --date 2026-06-15`
- [ ] Score history export: `python3 src/export_scores.py --agent all --format csv`
- [ ] `nova_logger` batch write: buffer and flush on exit for high-frequency agents (50+ runs/day)
- [ ] Assessment deduplication: prevent double-scoring if daily judge runs twice (idempotent write)
- [ ] Cross-week trend detection: weekly analyser looks at 4-week rolling window, not just 7 days

---

## v2.0 — MyDPA Commercial Packaging

**Prerequisite:** All MyDPA packaging boundaries from Section 14 of the PRD are enforced from v1. v2 is config-only, not a code rewrite.

- [ ] Namespace management UI (Notion-based client config)
- [ ] Per-client `agents.yaml` and rubric YAML
- [ ] Per-client Notion workspace and DB IDs
- [ ] Per-client Telegram credentials
- [ ] Multi-tenant deployment guide
- [ ] `nova_logger` PyPI package (public, versioned release)

---

## Out of Scope (Permanent)

- Public dashboard or web UI
- Slack notification channel
- Automated A/B testing of improvements before full deployment
- Automated unit test generation in improvement proposals
- External reporting or public leaderboard
- Manual per-agent score overrides (Walt can reject proposals in Notion instead)
