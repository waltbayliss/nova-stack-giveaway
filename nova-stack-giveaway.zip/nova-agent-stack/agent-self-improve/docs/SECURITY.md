# agent-self-improve — Security

**HIGHEST PRIORITY. These rules override everything else.**

---

## Hard Rules

1. **Never hardcode credentials.** All secrets sourced from `/home/walt/.env`. Zero exceptions. No fallback to environment defaults that contain real values.

2. **nova_logger sanitises before writing.** All string values passed through sanitiser before JSONL write. Patterns redacted: `sk-`, `Bearer `, `token=`, `password=`, any value >40 chars with no spaces → `[REDACTED]`. No secrets in log files under any circumstances.

3. **Log directories chmod 700.** `{agent}/logs/` dirs are created with `chmod 700` at retrofit time. `data/assessments/` is chmod 700. Owned by `walt`. No world-readable run logs.

4. **Proposals are untrusted text until Walt approves.** LLM-generated improvement proposals are written to Notion only. Agent-builder is called only after Walt sets `Status = Approved` in Notion. The system never writes agent code directly. This is a security boundary, not just a workflow preference.

5. **Builder dispatch is VPS-local only.** The approval poller invokes agent-builder via local CLI. There is no external webhook or HTTP endpoint that could trigger agent-builder. No spoofable surface.

6. **SHA-chain verification gates all scoring.** Daily judge verifies the SHA chain before processing any log file. A broken chain → file quarantined (`.quarantine` suffix), Telegram alert, agent skipped for today. Tampered logs are never scored.

7. **Quarantined files are never deleted.** The cleanup timer (30-day retention) explicitly exempts `.quarantine` files. Quarantined logs are preserved for manual review.

8. **Approval poller verifies Notion workspace before acting.** The poller confirms the page belongs to the expected Notion workspace before processing any approval. Prevents acting on spoofed page IDs.

9. **Git revert uses token auth only.** `GITHUB_PERSONAL_ACCESS_TOKEN` used for all git operations. Never SSH keys or other methods. Token is read-only from `.env`.

10. **fleet_lessons.yaml is committed to git.** Changes to this file are auditable via git history. The weekly analyser never silently overwrites lessons — it appends only, with `occurrence_count` increments.

11. **`.env.example` placeholders only.** No real values. No partial values. No "fill in the X part" examples that reveal structure.

12. **`logs/` and `data/assessments/` excluded from all git commits.** Both directories in `.gitignore`. Run logs and assessments are runtime data — never committed to GitHub.

---

## What This Agent Can Access

- `/home/walt/.env` (read-only)
- `{agent}/logs/` directories on VPS (read)
- `data/` directory in own folder (read/write)
- `config/agents.yaml` and `config/rubrics/` (read)
- Notion Agent Improvements DB (read approval status, write proposals and status updates)
- GitHub API via curl (read agent PRDs, push git reverts to agent repos)
- OpenRouter API (LLM scoring calls)
- Telegram via `NOVA_TELEGRAM_WORKER_URL` (write alerts)
- Cloudflare KV (read `agent-daily-brief` logs)

## What This Agent Cannot Access

- Walt's personal data
- Payment systems or financial APIs
- Production infrastructure beyond VPS file system
- Any agent's credentials (only reads run logs)
- Notion databases other than Agent Improvements DB
- Public internet endpoints (other than APIs listed above)

---

## Threat Model

| Threat | Mitigation |
|--------|-----------|
| Malicious log injection (poisoned JSONL) | SHA chain verification; malformed lines skipped per-line not per-file |
| LLM proposes harmful code change | Human-in-the-loop gate: Walt must approve in Notion before any dispatch |
| Secret leaks via run logs | nova_logger sanitiser runs on all string values before write |
| Replay attack (stale approval) | SQLite queue uses `notion_page_id` as UNIQUE key; duplicate dispatch prevented |
| Revert causes worse regression | Post-verifier monitors after every deployment, including reverts |
| Log file tampering | SHA chain integrity check; quarantine on failure |
| OpenRouter returns adversarial score | Scores clamped to [0,10]; ensemble of 3 reduces single-call manipulation |
| Notion API credentials exposed | Token in `.env` only; never in proposals or log files |
