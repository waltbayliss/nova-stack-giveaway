"""
retrofit.py — One-time tool to add nova_logger to all existing agents on the VPS.

Usage:
    python3 tools/retrofit.py --dry-run    # preview changes, no writes
    python3 tools/retrofit.py --execute    # apply changes

Actions per agent:
1. Identify main entrypoint from agent's CLAUDE.md
2. Add nova_logger import block to entrypoint
3. Create {agent}/logs/ directory, chmod 700
4. Add logs/ to {agent}/.gitignore
5. Write agents.yaml entry
6. Push .gitignore change to agent's GitHub repo

Runs sequentially. Continues on individual agent failures.
Final report lists all failures.
"""

import argparse
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

BASE_DIR = Path("/home/walt/agents/agent-self-improve")
AGENTS_ROOT = Path("/home/walt/agents")
AGENTS_YAML = BASE_DIR / "config" / "agents.yaml"

NOVA_LOGGER_IMPORT_BLOCK = (
    "# nova_logger — fleet run logging (installed via: pip install -e /home/walt/agents/agent-self-improve/nova_logger)\n"
    "try:\n"
    "    from nova_logger import NovaLogger as _NovaLogger\n"
    "    _nova_logger = _NovaLogger(\n"
    "        agent_name=\"{agent_name}\",\n"
    "        log_dir=\"/home/walt/agents/{agent_name}/logs\",\n"
    "    )\n"
    "except Exception as _nova_logger_exc:\n"
    "    import sys as _sys\n"
    "    print(f\"[nova_logger] WARNING: failed to initialise: {_nova_logger_exc}\", file=_sys.stderr)\n"
    "    _nova_logger = None\n"
)


def _load_env() -> Dict[str, str]:
    env_path = Path("/home/walt/.env")
    env: Dict[str, str] = {}
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    return env


def _load_agents_yaml() -> Dict[str, Any]:
    if AGENTS_YAML.exists():
        with open(AGENTS_YAML) as fh:
            return yaml.safe_load(fh) or {"agents": []}
    return {"agents": []}


def _save_agents_yaml(data: Dict[str, Any]) -> None:
    with open(AGENTS_YAML, "w") as fh:
        yaml.dump(data, fh, default_flow_style=False, allow_unicode=True)


def _find_entrypoint(agent_dir: Path) -> Optional[Path]:
    """Find main entrypoint by reading CLAUDE.md."""
    claude_md = agent_dir / "CLAUDE.md"
    if not claude_md.exists():
        return None

    content = claude_md.read_text(encoding="utf-8", errors="ignore")

    # Look for explicit entrypoint declarations
    patterns = [
        r"(?:entrypoint|entry point|main entry)[:\s]+`?([^\s`]+\.py)`?",
        r"(?:run|execute|invoke)[:\s]+`python3?\s+([^\s`]+\.py)`",
        r"ExecStart=.*?python[^\s]*\s+([^\s]+\.py)",
    ]
    for pattern in patterns:
        m = re.search(pattern, content, re.IGNORECASE)
        if m:
            ep = agent_dir / m.group(1)
            if ep.exists():
                return ep

    # Fallback: look for common entrypoints
    for candidate in ["src/main.py", "src/runner.py", "src/agent.py", "main.py"]:
        p = agent_dir / candidate
        if p.exists():
            return p

    # Fallback: first .py in src/
    src = agent_dir / "src"
    if src.exists():
        pys = sorted(src.glob("*.py"))
        if pys:
            return pys[0]

    return None


def _detect_model_family(agent_dir: Path) -> str:
    """Detect primary_model_family from CLAUDE.md or requirements."""
    claude_md = agent_dir / "CLAUDE.md"
    if claude_md.exists():
        content = claude_md.read_text(encoding="utf-8", errors="ignore").lower()
        if "gemini" in content and "claude" not in content:
            return "gemini"
        if "gpt" in content or "openai" in content:
            return "openai"
    return "claude"  # Default


def _has_nova_logger(entrypoint: Path) -> bool:
    """Check if nova_logger is already imported in this file."""
    content = entrypoint.read_text(encoding="utf-8", errors="ignore")
    return "nova_logger" in content or "NovaLogger" in content


def _insert_nova_logger_import(entrypoint: Path, agent_name: str, dry_run: bool) -> bool:
    """Insert nova_logger import block after the first group of imports."""
    content = entrypoint.read_text(encoding="utf-8", errors="ignore")
    block = NOVA_LOGGER_IMPORT_BLOCK.format(agent_name=agent_name)

    # Find insertion point: after the last top-level import statement
    lines = content.splitlines(keepends=True)
    insert_after = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("import ") or stripped.startswith("from "):
            insert_after = i + 1
        elif stripped and not stripped.startswith("#") and not stripped.startswith('"""') and insert_after > 0:
            break

    if insert_after == 0:
        # No imports found — insert at top after any shebang/docstring
        for i, line in enumerate(lines):
            if not line.startswith("#") and not line.startswith('"""') and line.strip():
                insert_after = i
                break

    new_lines = lines[:insert_after] + ["\n", block, "\n"] + lines[insert_after:]
    new_content = "".join(new_lines)

    if dry_run:
        print(f"    [DRY RUN] Would insert nova_logger import block at line {insert_after + 1}")
        return True

    entrypoint.write_text(new_content, encoding="utf-8")
    return True


def _ensure_logs_dir(agent_dir: Path, dry_run: bool) -> str:
    """Create logs/ directory with chmod 700. Returns absolute path."""
    logs_dir = agent_dir / "logs"
    if dry_run:
        print(f"    [DRY RUN] Would create {logs_dir} (chmod 700)")
        return str(logs_dir)
    logs_dir.mkdir(exist_ok=True)
    os.chmod(logs_dir, 0o700)
    return str(logs_dir)


def _add_logs_to_gitignore(agent_dir: Path, dry_run: bool) -> None:
    """Add logs/ to .gitignore if not already present."""
    gitignore = agent_dir / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8", errors="ignore")
        if "logs/" in content:
            return
        new_content = content.rstrip() + "\n\n# Agent run logs (nova_logger)\nlogs/\n*.jsonl\n"
    else:
        new_content = "# Agent run logs (nova_logger)\nlogs/\n*.jsonl\n"

    if dry_run:
        print(f"    [DRY RUN] Would update {gitignore} to include logs/")
        return
    gitignore.write_text(new_content, encoding="utf-8")


def _push_gitignore(agent_dir: Path, agent_name: str, env: Dict[str, str], dry_run: bool) -> bool:
    """Push .gitignore update to agent's GitHub repo via curl."""
    token = env.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    if not token:
        print(f"    WARNING: No GITHUB_PERSONAL_ACCESS_TOKEN — skipping .gitignore push for {agent_name}")
        return False

    gitignore = agent_dir / ".gitignore"
    if not gitignore.exists():
        return False

    if dry_run:
        print(f"    [DRY RUN] Would push .gitignore to waltbayliss/{agent_name}")
        return True

    import base64
    content_b64 = base64.b64encode(gitignore.read_bytes()).decode("ascii")
    repo = f"waltbayliss/{agent_name}"

    # Get current SHA
    import json
    check_result = subprocess.run(
        ["curl", "-s", "-H", f"Authorization: token {token}",
         f"https://api.github.com/repos/{repo}/contents/.gitignore"],
        capture_output=True, text=True, timeout=15,
    )
    try:
        check_data = json.loads(check_result.stdout)
        current_sha = check_data.get("sha", "")
    except Exception:
        current_sha = ""

    payload: Dict[str, Any] = {
        "message": "chore: add logs/ to .gitignore (nova_logger retrofit)",
        "content": content_b64,
    }
    if current_sha:
        payload["sha"] = current_sha

    push_result = subprocess.run(
        ["curl", "-s", "-X", "PUT",
         "-H", f"Authorization: token {token}",
         "-H", "Content-Type: application/json",
         "-d", json.dumps(payload),
         f"https://api.github.com/repos/{repo}/contents/.gitignore"],
        capture_output=True, text=True, timeout=15,
    )
    if '"sha"' in push_result.stdout:
        print(f"    Pushed .gitignore to {repo}")
        return True
    else:
        print(f"    WARNING: .gitignore push may have failed for {repo}: {push_result.stdout[:100]}")
        return False


def _retrofit_agent(
    agent_dir: Path,
    existing_yaml_entries: Dict[str, Dict[str, Any]],
    env: Dict[str, str],
    dry_run: bool,
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Retrofit a single agent. Returns (success, error_message, yaml_entry).
    """
    agent_name = agent_dir.name

    print(f"\n  {agent_name}:")

    # Skip non-agent directories
    if not (agent_dir / "CLAUDE.md").exists():
        return False, "No CLAUDE.md found — not an agent directory", {}

    # Skip agent-self-improve itself (already has nova_logger)
    if agent_name == "agent-self-improve":
        print("    Skipping self (agent-self-improve)")
        return True, "", {}

    # Check if already enrolled
    if agent_name in existing_yaml_entries and existing_yaml_entries[agent_name].get("enrolled_date"):
        print(f"    Already enrolled ({existing_yaml_entries[agent_name]['enrolled_date']}) — skipping")
        return True, "", existing_yaml_entries.get(agent_name, {})

    entrypoint = _find_entrypoint(agent_dir)
    if not entrypoint:
        return False, "Could not identify main entrypoint", {}

    print(f"    Entrypoint: {entrypoint.relative_to(agent_dir)}")

    # Check if nova_logger already present
    if _has_nova_logger(entrypoint):
        print("    nova_logger already imported — skipping import insert")
    else:
        if not _insert_nova_logger_import(entrypoint, agent_name, dry_run):
            return False, "Failed to insert nova_logger import", {}
        print(f"    Import block {'would be' if dry_run else 'inserted'}")

    # Create logs/ dir
    log_path = _ensure_logs_dir(agent_dir, dry_run)

    # Update .gitignore
    _add_logs_to_gitignore(agent_dir, dry_run)
    print(f"    .gitignore {'would be' if dry_run else ''} updated")

    # Push .gitignore
    _push_gitignore(agent_dir, agent_name, env, dry_run)

    # Build agents.yaml entry
    model_family = _detect_model_family(agent_dir)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    agent_entry = {
        "name": agent_name,
        "type": "session",  # Default — Walt should review and correct
        "repo": f"waltbayliss/{agent_name}",
        "log_path": log_path,
        "prd_path": f"Walt's Wiki/Agent Builds/{agent_name}.md",
        "enrolled_date": today if not dry_run else "",
        "primary_model_family": model_family,
        "namespace": "walt",
    }

    print(f"    agents.yaml entry {'would be' if dry_run else ''} written (model_family: {model_family})")
    return True, "", agent_entry


def main() -> None:
    parser = argparse.ArgumentParser(description="Retrofit nova_logger to all VPS agents")
    parser.add_argument("--dry-run", action="store_true", help="Preview changes without writing")
    parser.add_argument("--execute", action="store_true", help="Apply changes")
    parser.add_argument("--agent", help="Retrofit a specific agent only")
    args = parser.parse_args()

    if not args.dry_run and not args.execute:
        print("ERROR: specify --dry-run or --execute")
        sys.exit(1)

    dry_run = args.dry_run
    mode = "DRY RUN" if dry_run else "EXECUTE"
    print(f"\nnova_logger Retrofit Tool — Mode: {mode}")
    print("=" * 50)

    env = _load_env()
    agents_data = _load_agents_yaml()
    existing_entries: Dict[str, Dict[str, Any]] = {
        a["name"]: a for a in agents_data.get("agents", [])
    }

    # Find all agent directories
    agent_dirs = sorted([
        d for d in AGENTS_ROOT.iterdir()
        if d.is_dir() and d.name.startswith("agent-") and d.name != "agent-self-improve"
    ])

    if args.agent:
        agent_dirs = [d for d in agent_dirs if d.name == args.agent]
        if not agent_dirs:
            print(f"ERROR: Agent '{args.agent}' not found in {AGENTS_ROOT}")
            sys.exit(1)

    print(f"Found {len(agent_dirs)} agent directories to process\n")

    successes: List[str] = []
    failures: List[Tuple[str, str]] = []
    new_entries: List[Dict[str, Any]] = []

    for agent_dir in agent_dirs:
        success, error, entry = _retrofit_agent(agent_dir, existing_entries, env, dry_run)
        if success:
            successes.append(agent_dir.name)
            if entry:
                new_entries.append(entry)
        else:
            failures.append((agent_dir.name, error))
            print(f"    FAILED: {error}")

    # Update agents.yaml
    if not dry_run and new_entries:
        existing_names = {a["name"] for a in agents_data.get("agents", [])}
        for entry in new_entries:
            if entry.get("name") and entry["name"] not in existing_names:
                agents_data["agents"].append(entry)
                existing_names.add(entry["name"])
            elif entry.get("name"):
                # Update enrolled_date in existing entry
                for a in agents_data["agents"]:
                    if a["name"] == entry["name"]:
                        a["enrolled_date"] = entry["enrolled_date"]
                        a["log_path"] = entry["log_path"]
                        break
        _save_agents_yaml(agents_data)
        print(f"\nUpdated agents.yaml with {len(new_entries)} entries")

    # Final report
    print("\n" + "=" * 50)
    print(f"RETROFIT COMPLETE ({mode})")
    print(f"  Succeeded: {len(successes)}")
    print(f"  Failed:    {len(failures)}")

    if failures:
        print("\nFailed agents (manual action required):")
        for name, reason in failures:
            print(f"  - {name}: {reason}")

    success_rate = len(successes) / (len(successes) + len(failures)) * 100 if (successes or failures) else 0
    print(f"\nSuccess rate: {success_rate:.0f}%")
    if success_rate < 95:
        print("WARNING: Success rate below 95% target — review failures above")


if __name__ == "__main__":
    main()
