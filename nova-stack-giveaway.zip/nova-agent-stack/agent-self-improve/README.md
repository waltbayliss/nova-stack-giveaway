# agent-self-improve

Closed-loop quality system for Walt's AI agent fleet. Logs every agent run, scores output daily via adversarial LLM judge, identifies improvement patterns weekly, and routes approved proposals to agent-builder — making the entire agent stack continuously smarter without requiring Walt to notice problems first.

## What It Does

1. **`nova_logger`** — standalone Python pip package installed fleet-wide. Every agent imports this to write SHA-chained JSONL run logs.
2. **Daily judge** (02:00 UTC) — reads logs, verifies SHA chains, runs 3-run adversarial LLM ensemble scoring, fires Telegram on hard failures.
3. **Weekly analyser** (23:00 UTC Sunday) — reads 7 days of assessments, updates ELO rankings, promotes cross-fleet patterns to `fleet_lessons.yaml`, writes proposals to Notion Agent Improvements DB.
4. **Approval poller** (every 15 min) — polls Notion for Approved rows, dispatches to agent-builder via SQLite queue, updates Notion on completion.
5. **Post verifier** — monitors 7 runs or 14 days post-deployment, auto-reverts on regression.

## Structure

```
agent-self-improve/
├── nova_logger/          # Pip package — install fleet-wide
├── src/
│   ├── daily_judge.py
│   ├── weekly_analyser.py
│   ├── approval_poller.py
│   ├── post_verifier.py
│   └── cleanup.py
├── tools/
│   ├── retrofit.py       # One-time: add nova_logger to all existing agents
│   └── scaffold_update.py # Patch agent-builder template
├── config/
│   ├── agents.yaml       # All enrolled agents
│   └── rubrics/          # Per-type scoring rubrics (YAML)
├── data/                 # Runtime data (not committed except fleet_lessons.yaml)
├── systemd/              # Timer and service units
└── tests/                # Test suite
```

## Quick Start

```bash
# Install nova_logger fleet-wide
pip install -e /home/walt/agents/agent-self-improve/nova_logger

# Retrofit all existing agents (dry run first)
python3 tools/retrofit.py --dry-run
python3 tools/retrofit.py --execute

# Update agent-builder scaffold
python3 tools/scaffold_update.py

# Install systemd timers
sudo cp systemd/*.timer systemd/*.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now agent-self-improve-daily.timer
sudo systemctl enable --now agent-self-improve-weekly.timer
sudo systemctl enable --now agent-self-improve-poller.timer
sudo systemctl enable --now agent-self-improve-cleanup.timer
```

## Agent Registry

`config/agents.yaml` is the single source of truth for all enrolled agents. Fields per entry:
- `name` — agent folder name
- `type` — `content | pipeline | infrastructure | utility | session`
- `repo` — GitHub repo path
- `log_path` — absolute path to logs dir (set at retrofit time)
- `prd_path` — wiki path to agent's PRD
- `enrolled_date` — ISO date
- `primary_model_family` — `claude | gemini | openai` (drives adversarial judge selection)
- `namespace` — defaults to `walt` (MyDPA multi-tenant field)

## Adversarial Judge

The scoring judge must always be a different model family from the agent being scored:
- Claude agents → `google/gemini-flash-1.5`
- Gemini/OpenAI agents → `anthropic/claude-haiku-4-5`

Same-model judging is forbidden — it creates an echo chamber where the model approves its own output.

## Credentials Required

All sourced from `/home/walt/.env`:

```
OPENROUTER_API_KEY
NOTION_TOKEN
NOTION_IMPROVEMENTS_DB_ID
GITHUB_PERSONAL_ACCESS_TOKEN
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
NOVA_TELEGRAM_WORKER_URL
CF_API_TOKEN
CF_ACCOUNT_ID
```

## Running Tests

```bash
cd /home/walt/agents/agent-self-improve
pip install -e nova_logger
pip install -r requirements.txt
python3 -m pytest tests/ -v
```
