"""
weekly_analyser.py — Sunday night analysis of 7 days of assessments.

Schedule: 23:00 UTC Sunday via agent-self-improve-weekly.timer

Algorithm:
1. Read 7 days of assessment JSONL from data/assessments/
2. Group by failure_category and rubric dimension
3. Apply proposal triggers (thresholds from PRD Section 7)
4. Update ELO rankings (K=32)
5. Check fleet_lessons.yaml for cross-fleet pattern promotion (Reflexion)
6. Write proposals to Notion Agent Improvements DB (400ms rate limit)
7. Deduplicate: same agent + dimension + ISO week = update existing row
8. Batch cap: >15 proposals queued to next week (Critical always included)
9. Write weekly summary to Walt's Wiki via curl
10. Send Telegram summary
"""

import asyncio
import json
import logging
import math
import os
import sys
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx
import yaml

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

BASE_DIR = Path("/home/walt/agents/agent-self-improve")
DATA_DIR = BASE_DIR / "data"
ASSESSMENTS_DIR = DATA_DIR / "assessments"
ELO_FILE = DATA_DIR / "elo_rankings.json"
LESSONS_FILE = DATA_DIR / "fleet_lessons.yaml"
CONFIG_DIR = BASE_DIR / "config"
AGENTS_YAML = CONFIG_DIR / "agents.yaml"

INITIAL_ELO = 1200.0
ELO_K = 32
MAX_PROPOSALS_PER_WEEK = 15

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [weekly_analyser] %(levelname)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("weekly_analyser")


# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------

def _load_env() -> Dict[str, str]:
    env_path = Path("/home/walt/.env")
    env: Dict[str, str] = {}
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    for key in ["NOTION_TOKEN", "NOTION_IMPROVEMENTS_DB_ID", "GITHUB_PERSONAL_ACCESS_TOKEN",
                "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "NOVA_TELEGRAM_WORKER_URL"]:
        if key in os.environ:
            env[key] = os.environ[key]
    return env


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------

async def _send_telegram(env: Dict[str, str], message: str) -> None:
    worker_url = env.get("NOVA_TELEGRAM_WORKER_URL", "")
    if not worker_url:
        log.warning("NOVA_TELEGRAM_WORKER_URL not set — skipping Telegram")
        return
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(worker_url, json={"message": message})
    except Exception as exc:
        log.warning("Telegram failed: %s", exc)


# ---------------------------------------------------------------------------
# Assessment loading
# ---------------------------------------------------------------------------

def _load_assessments(days: int = 7) -> List[Dict[str, Any]]:
    """Load all assessment JSONL entries from the past N days."""
    today = datetime.now(timezone.utc)
    assessments: List[Dict[str, Any]] = []
    for i in range(days):
        date_str = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        date_dir = ASSESSMENTS_DIR / date_str
        if not date_dir.exists():
            continue
        for f in date_dir.glob("*.jsonl"):
            for line in f.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    entry["_file_date"] = date_str
                    assessments.append(entry)
                except json.JSONDecodeError:
                    log.warning("Malformed assessment line in %s", f)
    return assessments


# ---------------------------------------------------------------------------
# ELO ranking
# ---------------------------------------------------------------------------

def _load_elo() -> Dict[str, float]:
    """Load existing ELO rankings or return empty dict."""
    if ELO_FILE.exists():
        try:
            data = json.loads(ELO_FILE.read_text())
            return {r["agent_name"]: r["elo"] for r in data.get("rankings", [])}
        except Exception:
            log.warning("ELO file corrupt — rebuilding from scratch")
    return {}


def _elo_expected(rating_a: float, rating_b: float) -> float:
    return 1.0 / (1.0 + math.pow(10, (rating_b - rating_a) / 400.0))


def _update_elo(elo: Dict[str, float], agent_scores: Dict[str, float]) -> Dict[str, float]:
    """
    Update ELO rankings using K=32. Each agent plays against the fleet average.
    Score > fleet average = win (1.0), score < fleet average = loss (0.0).
    """
    if not agent_scores:
        return elo

    fleet_avg = sum(agent_scores.values()) / len(agent_scores)

    for agent_name, score in agent_scores.items():
        current_elo = elo.get(agent_name, INITIAL_ELO)
        # Normalise score to [0,1] for ELO comparison against fleet average
        normalised_score = score / 10.0
        normalised_avg = fleet_avg / 10.0
        expected = _elo_expected(current_elo, INITIAL_ELO)
        # Win = 1.0 if above average, 0.0 if below
        actual = 1.0 if normalised_score >= normalised_avg else 0.0
        elo[agent_name] = round(current_elo + ELO_K * (actual - expected), 1)

    return elo


def _save_elo(elo: Dict[str, float], agent_scores: Dict[str, float], trends: Dict[str, str]) -> None:
    """Write ELO rankings to data/elo_rankings.json."""
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    rankings = sorted(
        [
            {
                "agent_name": name,
                "elo": rating,
                "7d_avg_score": round(agent_scores.get(name, 0.0), 2),
                "trend": trends.get(name, "stable"),
            }
            for name, rating in elo.items()
        ],
        key=lambda x: x["elo"],
        reverse=True,
    )
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ELO_FILE.write_text(
        json.dumps({"last_updated": today, "rankings": rankings}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    log.info("ELO rankings written: %d agents", len(rankings))


# ---------------------------------------------------------------------------
# Fleet lessons (Reflexion)
# ---------------------------------------------------------------------------

def _load_lessons() -> Dict[str, Any]:
    if LESSONS_FILE.exists():
        try:
            return yaml.safe_load(LESSONS_FILE.read_text()) or {"lessons": []}
        except Exception:
            log.warning("fleet_lessons.yaml corrupt — starting fresh for this run")
    return {"lessons": []}


def _save_lessons(data: Dict[str, Any]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LESSONS_FILE.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True),
        encoding="utf-8",
    )


def _promote_cross_fleet_patterns(
    assessments: List[Dict[str, Any]],
    lessons_data: Dict[str, Any],
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """
    Promote patterns to fleet_lessons.yaml when failure_category appears in 3+ agents.
    Returns updated lessons_data and list of newly promoted lessons.
    """
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # Group by failure_category
    category_agents: Dict[str, set] = {}
    for a in assessments:
        fc = a.get("failure_category")
        if fc and fc != "null" and not a.get("no_data") and not a.get("hard_failure") is False:
            # Only count actual failures
            if a.get("score", 10.0) < 7.0:
                category_agents.setdefault(fc, set()).add(a["agent_name"])

    existing_lessons = lessons_data.get("lessons", [])
    existing_patterns = {l["pattern"]: l for l in existing_lessons}
    new_promotions = []

    for category, agents in category_agents.items():
        if len(agents) < 3:
            continue
        pattern_key = f"{category} below 7.0"
        if pattern_key in existing_patterns:
            # Increment occurrence count
            existing_patterns[pattern_key]["occurrence_count"] += 1
            existing_patterns[pattern_key]["affected_agents"] = list(
                set(existing_patterns[pattern_key].get("affected_agents", [])) | agents
            )
        else:
            lesson_id = f"lesson-{len(existing_lessons) + len(new_promotions) + 1:03d}"
            new_lesson = {
                "id": lesson_id,
                "pattern": pattern_key,
                "category": category,
                "affected_agents": list(agents),
                "first_seen": today,
                "occurrence_count": 1,
                "recommendation": (
                    f"Cross-fleet pattern detected: {category} failures in {len(agents)} agents "
                    f"({', '.join(sorted(agents))}). Review prompt and tooling for this failure category."
                ),
                "promoted_at": today,
            }
            existing_lessons.append(new_lesson)
            new_promotions.append(new_lesson)
            log.info("Promoted cross-fleet lesson: %s", pattern_key)

    lessons_data["lessons"] = existing_lessons
    return lessons_data, new_promotions


# ---------------------------------------------------------------------------
# Proposal generation
# ---------------------------------------------------------------------------

def _compute_trends(agent_scores_by_day: Dict[str, List[float]]) -> Dict[str, str]:
    """Compute trend direction per agent: stable | improving | declining."""
    trends: Dict[str, str] = {}
    for agent, scores in agent_scores_by_day.items():
        if len(scores) < 3:
            trends[agent] = "stable"
            continue
        first_half = sum(scores[: len(scores) // 2]) / (len(scores) // 2)
        second_half = sum(scores[len(scores) // 2 :]) / (len(scores) - len(scores) // 2)
        diff = second_half - first_half
        if diff > 0.5:
            trends[agent] = "improving"
        elif diff < -0.5:
            trends[agent] = "declining"
        else:
            trends[agent] = "stable"
    return trends


def _generate_proposals(
    assessments: List[Dict[str, Any]],
    agent_scores_by_day: Dict[str, List[float]],
    trends: Dict[str, str],
    elo_before: Dict[str, float],
    elo_after: Dict[str, float],
) -> List[Dict[str, Any]]:
    """Generate structured proposals based on PRD Section 7 triggers."""
    today = datetime.now(timezone.utc)
    iso_week = today.strftime("%Y-W%V")
    proposals: List[Dict[str, Any]] = []

    # Group assessments by agent
    by_agent: Dict[str, List[Dict[str, Any]]] = {}
    for a in assessments:
        by_agent.setdefault(a["agent_name"], []).append(a)

    for agent_name, agent_assessments in by_agent.items():
        scores = [a["score"] for a in agent_assessments if not a.get("no_data")]
        if not scores:
            continue

        avg_score = sum(scores) / len(scores)
        trend = trends.get(agent_name, "stable")
        elo_delta = elo_after.get(agent_name, INITIAL_ELO) - elo_before.get(agent_name, INITIAL_ELO)

        # Find dominant failing dimension
        dim_scores: Dict[str, List[float]] = {}
        for a in agent_assessments:
            for dim, info in a.get("score_breakdown", {}).items():
                dim_scores.setdefault(dim, []).append(info.get("score", 10.0))
        failing_dim = None
        failing_dim_avg = 10.0
        for dim, dim_sc in dim_scores.items():
            avg_d = sum(dim_sc) / len(dim_sc)
            if avg_d < failing_dim_avg:
                failing_dim_avg = avg_d
                failing_dim = dim

        failure_categories = [a.get("failure_category") for a in agent_assessments if a.get("failure_category")]
        dominant_category = max(set(failure_categories), key=failure_categories.count) if failure_categories else "n/a"

        # Hard failure → Critical
        hard_failures = [a for a in agent_assessments if a.get("hard_failure")]
        if hard_failures:
            proposals.append({
                "severity": "Critical",
                "agent_name": agent_name,
                "failing_dimension": failing_dim or "completion_rate",
                "failure_category": dominant_category,
                "score_before": round(avg_score, 2),
                "evidence": f"Hard failure on {len(hard_failures)} day(s) in week {iso_week}. "
                            f"Run IDs: {', '.join(a.get('run_count', '') and str(a.get('run_id', '')) for a in hard_failures[:3])}",
                "proposed_upgrade": (
                    f"Investigate hard failure in {agent_name}. "
                    f"Review src/ entrypoint for unhandled exceptions. "
                    f"Add recovery logic for the {dominant_category} failure pattern."
                ),
                "expected_impact": "Eliminate hard failures — restore reliable operation",
                "iso_week": iso_week,
            })

        # Persistent low score → Bug
        elif len(scores) >= 4 and sum(1 for s in scores if s < 6.0) >= 4:
            proposals.append({
                "severity": "Bug",
                "agent_name": agent_name,
                "failing_dimension": failing_dim or "output_quality",
                "failure_category": dominant_category,
                "score_before": round(avg_score, 2),
                "evidence": f"Score < 6.0 on {sum(1 for s in scores if s < 6.0)}/7 days. "
                            f"7-day average: {avg_score:.2f}. Week: {iso_week}.",
                "proposed_upgrade": (
                    f"In {agent_name}: address persistent low {failing_dim} scores "
                    f"(avg {failing_dim_avg:.1f}/10). "
                    f"Review and improve the relevant prompt section or output validation."
                ),
                "expected_impact": f"Estimated score lift from {avg_score:.1f} to 7.0+ based on {failing_dim} gap",
                "iso_week": iso_week,
            })

        # Declining trend → Improvement
        elif trend == "declining" and len(scores) >= 3:
            score_list = agent_scores_by_day.get(agent_name, scores)
            drop = (score_list[0] if score_list else avg_score) - (score_list[-1] if score_list else avg_score)
            if abs(drop) >= 1.5:
                proposals.append({
                    "severity": "Improvement",
                    "agent_name": agent_name,
                    "failing_dimension": failing_dim or "task_completion",
                    "failure_category": dominant_category,
                    "score_before": round(avg_score, 2),
                    "evidence": f"Score dropped {abs(drop):.1f} points over 7-day window. "
                                f"Trend: declining. Week: {iso_week}.",
                    "proposed_upgrade": (
                        f"Investigate declining trend in {agent_name}. "
                        f"Primary dimension at risk: {failing_dim}. "
                        f"Review recent changes or data drift affecting outputs."
                    ),
                    "expected_impact": "Reverse declining trend — stabilise score above 7.0",
                    "iso_week": iso_week,
                })

        # Quality below threshold with identifiable gap → Improvement
        elif 6.0 <= avg_score <= 7.0 and failing_dim and failing_dim_avg < 6.5:
            proposals.append({
                "severity": "Improvement",
                "agent_name": agent_name,
                "failing_dimension": failing_dim,
                "failure_category": dominant_category,
                "score_before": round(avg_score, 2),
                "evidence": f"Average score {avg_score:.2f} with {failing_dim} averaging {failing_dim_avg:.1f}. Week: {iso_week}.",
                "proposed_upgrade": (
                    f"In {agent_name}: improve {failing_dim} dimension. "
                    f"Current average: {failing_dim_avg:.1f}/10. "
                    f"Review rubric guidance for {failing_dim} and update relevant prompts."
                ),
                "expected_impact": f"Target {failing_dim} score 7.5+ — overall lift to ~7.5",
                "iso_week": iso_week,
            })

        # ELO relative decline → Improvement
        elif elo_delta < -50:
            proposals.append({
                "severity": "Improvement",
                "agent_name": agent_name,
                "failing_dimension": failing_dim or "task_completion",
                "failure_category": "n/a",
                "score_before": round(avg_score, 2),
                "evidence": f"ELO dropped {abs(elo_delta):.0f} points this week despite score {avg_score:.2f}. "
                            f"Fleet is improving faster than this agent. Week: {iso_week}.",
                "proposed_upgrade": (
                    f"In {agent_name}: relative performance declining vs fleet. "
                    f"Identify dimensions where other agents improved and apply similar improvements."
                ),
                "expected_impact": "Restore ELO position relative to improving fleet",
                "iso_week": iso_week,
            })

    return proposals


# ---------------------------------------------------------------------------
# Notion write
# ---------------------------------------------------------------------------

async def _write_proposal_to_notion(
    client: httpx.AsyncClient,
    notion_token: str,
    db_id: str,
    proposal: Dict[str, Any],
) -> Optional[str]:
    """Write a single proposal to Notion. Returns page_id or None on failure."""
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    title = f"{proposal['severity']}: Improve {proposal['failing_dimension']} in {proposal['agent_name']}"

    properties = {
        "Upgrade Title": {"title": [{"text": {"content": title[:100]}}]},
        "Agent Name": {"select": {"name": proposal["agent_name"]}},
        "Proposed Upgrade": {"rich_text": [{"text": {"content": proposal["proposed_upgrade"][:2000]}}]},
        "Severity": {"select": {"name": proposal["severity"]}},
        "Evidence": {"rich_text": [{"text": {"content": proposal["evidence"][:2000]}}]},
        "Failing Dimension": {"select": {"name": proposal["failing_dimension"] or "n/a"}},
        "Failure Category": {"select": {"name": proposal["failure_category"] or "n/a"}},
        "Expected Impact": {"rich_text": [{"text": {"content": proposal["expected_impact"][:1000]}}]},
        "Status": {"select": {"name": "Pending Review"}},
        "Score Before": {"number": proposal.get("score_before", 0.0)},
        "Weekly Batch": {"rich_text": [{"text": {"content": proposal.get("iso_week", today)}}]},
        "Date Proposed": {"date": {"start": today}},
    }

    try:
        response = await client.post(
            "https://api.notion.com/v1/pages",
            headers={
                "Authorization": f"Bearer {notion_token}",
                "Notion-Version": "2022-06-28",
                "Content-Type": "application/json",
            },
            json={"parent": {"database_id": db_id}, "properties": properties},
            timeout=20,
        )
        if response.status_code == 200:
            return response.json().get("id")
        else:
            log.warning("Notion write failed: %d %s", response.status_code, response.text[:200])
            return None
    except Exception as exc:
        log.warning("Notion write exception: %s", exc)
        return None


async def _check_existing_notion_proposal(
    client: httpx.AsyncClient,
    notion_token: str,
    db_id: str,
    agent_name: str,
    failing_dim: str,
    iso_week: str,
) -> Optional[str]:
    """Check if a proposal already exists for agent + dimension + week. Returns page_id or None."""
    try:
        response = await client.post(
            f"https://api.notion.com/v1/databases/{db_id}/query",
            headers={
                "Authorization": f"Bearer {notion_token}",
                "Notion-Version": "2022-06-28",
                "Content-Type": "application/json",
            },
            json={
                "filter": {
                    "and": [
                        {"property": "Agent Name", "select": {"equals": agent_name}},
                        {"property": "Failing Dimension", "select": {"equals": failing_dim}},
                        {"property": "Weekly Batch", "rich_text": {"contains": iso_week}},
                    ]
                }
            },
            timeout=20,
        )
        if response.status_code == 200:
            results = response.json().get("results", [])
            if results:
                return results[0]["id"]
    except Exception as exc:
        log.warning("Notion dedup check failed: %s", exc)
    return None


# ---------------------------------------------------------------------------
# Wiki write
# ---------------------------------------------------------------------------

async def _write_wiki_summary(
    env: Dict[str, str],
    date_str: str,
    window_start: str,
    assessments: List[Dict[str, Any]],
    proposals: List[Dict[str, Any]],
    new_lessons: List[Dict[str, Any]],
    elo_rankings: List[Dict[str, Any]],
) -> None:
    """Write weekly summary to Walt's Wiki via GitHub API."""
    token = env.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    if not token:
        log.warning("No GITHUB_PERSONAL_ACCESS_TOKEN — skipping wiki write")
        return

    # Build fleet score table
    by_agent: Dict[str, List[float]] = {}
    for a in assessments:
        if not a.get("no_data"):
            by_agent.setdefault(a["agent_name"], []).append(a.get("score", 0.0))

    elo_map = {r["agent_name"]: r for r in elo_rankings}
    score_rows = []
    for agent_name, scores in sorted(by_agent.items()):
        avg = sum(scores) / len(scores)
        elo_info = elo_map.get(agent_name, {})
        score_rows.append(
            f"| {agent_name} | {avg:.2f} | {elo_info.get('trend', 'stable')} | {elo_info.get('elo', 'N/A')} |"
        )

    severity_counts = {"Critical": 0, "Bug": 0, "Improvement": 0}
    for p in proposals:
        severity_counts[p.get("severity", "Improvement")] += 1

    critical_proposals = [p for p in proposals if p.get("severity") == "Critical"]
    critical_text = "\n".join(
        f"- **{p['agent_name']}**: {p['proposed_upgrade'][:100]}" for p in critical_proposals
    ) or "None"

    lessons_text = "\n".join(
        f"- **{l['pattern']}** ({', '.join(l.get('affected_agents', [])[:3])}): {l['recommendation'][:150]}"
        for l in new_lessons
    ) or "None this week"

    integrity_errors = [a for a in assessments if a.get("integrity_error")]
    integrity_text = "\n".join(
        f"- {a['agent_name']}: log quarantined on {a.get('assessment_date', '?')}"
        for a in integrity_errors
    ) or "None"

    content = (
        f"# Fleet Self-Improvement Weekly Summary\n\n"
        f"**Analysis window:** {window_start} to {date_str}\n"
        f"**Generated:** {date_str} 23:00 UTC\n\n"
        f"## Fleet Score Summary\n\n"
        f"| Agent | 7-Day Avg Score | Trend | ELO |\n"
        f"|-------|----------------|-------|-----|\n"
        + "\n".join(score_rows)
        + f"\n\n## Proposals Generated\n\n"
        f"| Severity | Count |\n"
        f"|----------|-------|\n"
        f"| Critical | {severity_counts['Critical']} |\n"
        f"| Bug | {severity_counts['Bug']} |\n"
        f"| Improvement | {severity_counts['Improvement']} |\n\n"
        f"## Critical Proposals\n\n{critical_text}\n\n"
        f"## Cross-Fleet Patterns Promoted\n\n{lessons_text}\n\n"
        f"## Log Integrity Issues\n\n{integrity_text}\n"
    )

    wiki_path = f"Agent Builds/Self-Improve Reports/{date_str}-weekly-summary.md"
    import base64
    content_b64 = base64.b64encode(content.encode("utf-8")).decode("ascii")

    async with httpx.AsyncClient(timeout=20) as client:
        # Check if file exists (get SHA)
        check = await client.get(
            f"https://api.github.com/repos/waltbayliss/walts-wiki/contents/{wiki_path}",
            headers={"Authorization": f"token {token}"},
        )
        payload: Dict[str, Any] = {
            "message": f"agent-self-improve: weekly summary {date_str}",
            "content": content_b64,
        }
        if check.status_code == 200:
            payload["sha"] = check.json().get("sha", "")

        resp = await client.put(
            f"https://api.github.com/repos/waltbayliss/walts-wiki/contents/{wiki_path}",
            headers={
                "Authorization": f"token {token}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
        if resp.status_code in (200, 201):
            log.info("Wiki summary written: %s", wiki_path)
        else:
            log.warning("Wiki write failed: %d %s", resp.status_code, resp.text[:200])


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

async def main() -> None:
    env = _load_env()
    today = datetime.now(timezone.utc)
    today_str = today.strftime("%Y-%m-%d")
    window_start = (today - timedelta(days=6)).strftime("%Y-%m-%d")

    log.info("Weekly analyser starting — window: %s to %s", window_start, today_str)

    assessments = _load_assessments(days=7)
    log.info("Loaded %d assessment entries", len(assessments))

    # Per-agent daily scores
    agent_scores_by_day: Dict[str, List[float]] = {}
    for a in assessments:
        if not a.get("no_data") and not a.get("integrity_error"):
            agent_scores_by_day.setdefault(a["agent_name"], []).append(a.get("score", 0.0))

    agent_scores: Dict[str, float] = {
        name: sum(scores) / len(scores)
        for name, scores in agent_scores_by_day.items()
        if scores
    }
    trends = _compute_trends(agent_scores_by_day)

    # ELO update
    elo_before = _load_elo()
    elo_after = _update_elo(dict(elo_before), agent_scores)
    _save_elo(elo_after, agent_scores, trends)

    elo_after_list = sorted(
        [
            {"agent_name": n, "elo": r, "trend": trends.get(n, "stable"), "7d_avg_score": agent_scores.get(n, 0.0)}
            for n, r in elo_after.items()
        ],
        key=lambda x: x["elo"],
        reverse=True,
    )

    # Fleet lessons (Reflexion)
    lessons_data = _load_lessons()
    lessons_data, new_lessons = _promote_cross_fleet_patterns(assessments, lessons_data)
    if new_lessons:
        _save_lessons(lessons_data)

    # Generate proposals
    proposals = _generate_proposals(assessments, agent_scores_by_day, trends, elo_before, elo_after)
    log.info("Generated %d proposals", len(proposals))

    # Batch cap: >15 proposals → queue Critical first, then Bug, then Improvement
    if len(proposals) > MAX_PROPOSALS_PER_WEEK:
        critical = [p for p in proposals if p["severity"] == "Critical"]
        others = [p for p in proposals if p["severity"] != "Critical"]
        proposals = (critical + others)[:MAX_PROPOSALS_PER_WEEK]
        log.info("Batch cap applied — writing %d proposals (remainder queued next week)", len(proposals))

    # Write to Notion
    notion_token = env.get("NOTION_TOKEN", "")
    db_id = env.get("NOTION_IMPROVEMENTS_DB_ID", "")
    written = 0
    if notion_token and db_id and proposals:
        async with httpx.AsyncClient() as client:
            for proposal in proposals:
                # Deduplication check
                existing_id = await _check_existing_notion_proposal(
                    client, notion_token, db_id,
                    proposal["agent_name"], proposal.get("failing_dimension", "n/a"), proposal.get("iso_week", "")
                )
                if existing_id:
                    log.info("Duplicate proposal skipped: %s / %s", proposal["agent_name"], proposal.get("failing_dimension"))
                    continue

                page_id = await _write_proposal_to_notion(client, notion_token, db_id, proposal)
                if page_id:
                    written += 1
                    log.info("Notion proposal written: %s", page_id)
                # Rate limit: 400ms between writes
                await asyncio.sleep(0.4)

    # Wiki summary
    await _write_wiki_summary(env, today_str, window_start, assessments, proposals, new_lessons, elo_after_list)

    # Telegram summary
    if written > 0:
        notion_link = f"https://notion.so/{db_id.replace('-', '')}"
        msg = f"{written} improvement proposals ready for review: {notion_link}"
    else:
        msg = "All agents healthy this week. No proposals generated."
    await _send_telegram(env, msg)

    log.info("Weekly analyser complete — %d proposals written to Notion", written)


if __name__ == "__main__":
    asyncio.run(main())
