"""
approval_poller.py — Poll Notion for approved proposals and dispatch to agent-builder.

Schedule: Every 15 minutes via agent-self-improve-poller.timer

Algorithm:
1. Poll Notion Agent Improvements DB for Status=Approved rows
2. Insert new approved rows into SQLite queue (UNIQUE on notion_page_id)
3. Process queue sequentially:
   a. Check systemctl is-active agent-builder.service
   b. Write proposal JSON to /tmp/proposal_{page_id}.json
   c. Invoke agent-builder CLI
   d. On success (exit 0): read commit SHA, update Notion to Deployed
   e. On failure: retry up to 3x, then mark Failed, alert Walt
4. All Notion status updates performed after each dispatch
"""

import asyncio
import json
import logging
import os
import sqlite3
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx

BASE_DIR = Path("/home/walt/agents/agent-self-improve")
DATA_DIR = BASE_DIR / "data"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [approval_poller] %(levelname)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("approval_poller")

AGENT_BUILDER_SCRIPT = "/home/walt/agents/agent-builder/src/builder.py"
MAX_RETRIES = 3


# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------

def _load_env() -> Dict[str, str]:
    env_path = Path("/home/walt/.env")
    env: Dict[str, str] = {}
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    for key in ["NOTION_TOKEN", "NOTION_IMPROVEMENTS_DB_ID", "NOVA_TELEGRAM_WORKER_URL"]:
        if key in os.environ:
            env[key] = os.environ[key]
    return env


# ---------------------------------------------------------------------------
# SQLite queue
# ---------------------------------------------------------------------------

def _db_path(env: Dict[str, str]) -> str:
    """Configurable SQLite path — supports MyDPA multi-tenant."""
    return env.get("APPROVAL_QUEUE_DB_PATH", str(DATA_DIR / "approval_queue.db"))


def _init_db(db_path: str) -> sqlite3.Connection:
    """Initialise SQLite database and return connection."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS approval_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notion_page_id TEXT UNIQUE NOT NULL,
            agent_name TEXT NOT NULL,
            agent_repo TEXT NOT NULL,
            proposal_summary TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            dispatched_at TEXT,
            completed_at TEXT,
            builder_commit_sha TEXT,
            retry_count INTEGER DEFAULT 0,
            error_log TEXT
        );
        CREATE TABLE IF NOT EXISTS fleet_elo_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            week_date TEXT NOT NULL,
            agent_name TEXT NOT NULL,
            elo_before REAL NOT NULL,
            elo_after REAL NOT NULL,
            weekly_avg_score REAL NOT NULL
        );
    """)
    conn.commit()
    return conn


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------

async def _send_telegram(env: Dict[str, str], message: str) -> None:
    worker_url = env.get("NOVA_TELEGRAM_WORKER_URL", "")
    if not worker_url:
        return
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(worker_url, json={"message": message})
    except Exception as exc:
        log.warning("Telegram failed: %s", exc)


# ---------------------------------------------------------------------------
# Notion API
# ---------------------------------------------------------------------------

async def _poll_notion_approved(env: Dict[str, str]) -> List[Dict[str, Any]]:
    """Poll Notion for rows with Status=Approved."""
    token = env.get("NOTION_TOKEN", "")
    db_id = env.get("NOTION_IMPROVEMENTS_DB_ID", "")
    if not token or not db_id:
        log.warning("Notion credentials not set — skipping poll")
        return []

    try:
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.post(
                f"https://api.notion.com/v1/databases/{db_id}/query",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Notion-Version": "2022-06-28",
                    "Content-Type": "application/json",
                },
                json={
                    "filter": {
                        "property": "Status",
                        "select": {"equals": "Approved"},
                    }
                },
            )
            if response.status_code == 200:
                return response.json().get("results", [])
            else:
                log.warning("Notion poll failed: %d", response.status_code)
                return []
    except Exception as exc:
        log.warning("Notion poll exception: %s", exc)
        return []


def _extract_proposal_from_notion_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """Extract proposal fields from a Notion page result."""
    props = row.get("properties", {})

    def _text(prop: str) -> str:
        items = props.get(prop, {}).get("rich_text", [])
        return " ".join(i.get("text", {}).get("content", "") for i in items)

    def _title(prop: str) -> str:
        items = props.get(prop, {}).get("title", [])
        return " ".join(i.get("text", {}).get("content", "") for i in items)

    def _select(prop: str) -> str:
        sel = props.get(prop, {}).get("select")
        return sel.get("name", "") if sel else ""

    return {
        "notion_page_id": row["id"],
        "agent_name": _select("Agent Name"),
        "agent_repo": f"waltbayliss/{_select('Agent Name')}",
        "proposal_summary": _title("Upgrade Title"),
        "proposed_upgrade": _text("Proposed Upgrade"),
        "failing_dimension": _select("Failing Dimension"),
        "failure_category": _select("Failure Category"),
        "evidence": _text("Evidence"),
        "expected_impact": _text("Expected Impact"),
    }


async def _update_notion_status(
    env: Dict[str, str],
    page_id: str,
    status: str,
    extra_props: Optional[Dict[str, Any]] = None,
) -> None:
    """Update Notion page status and optional extra properties."""
    token = env.get("NOTION_TOKEN", "")
    if not token:
        return

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    properties: Dict[str, Any] = {
        "Status": {"select": {"name": status}},
    }
    if status == "Building":
        properties["Date Deployed"] = {"date": {"start": today}}
    if extra_props:
        properties.update(extra_props)

    try:
        async with httpx.AsyncClient(timeout=20) as client:
            await client.patch(
                f"https://api.notion.com/v1/pages/{page_id}",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Notion-Version": "2022-06-28",
                    "Content-Type": "application/json",
                },
                json={"properties": properties},
            )
    except Exception as exc:
        log.warning("Notion status update failed: %s", exc)


# ---------------------------------------------------------------------------
# agent-builder health check
# ---------------------------------------------------------------------------

def _is_agent_builder_active() -> bool:
    """Check if agent-builder systemd service is active."""
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "agent-builder.service"],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() == "active"
    except Exception:
        # systemctl not available (dev environment) — assume active
        return True


# ---------------------------------------------------------------------------
# Dispatch to agent-builder
# ---------------------------------------------------------------------------

def _write_proposal_json(proposal: Dict[str, Any]) -> str:
    """Write proposal JSON to a temp file. Returns file path."""
    page_id = proposal["notion_page_id"]
    tmp_path = f"/tmp/proposal_{page_id}.json"
    payload = {
        "notion_page_id": page_id,
        "agent_name": proposal["agent_name"],
        "agent_repo": proposal["agent_repo"],
        "proposed_upgrade": proposal.get("proposed_upgrade", ""),
        "target_files": [],
        "target_functions": [],
        "rationale": proposal.get("evidence", ""),
        "evidence_run_ids": [],
    }
    with open(tmp_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    return tmp_path


def _dispatch_to_builder(proposal: Dict[str, Any]) -> Optional[str]:
    """
    Invoke agent-builder CLI. Returns commit SHA on success, None on failure.
    Per PRD Section 13 interface contract.
    """
    proposal_file = _write_proposal_json(proposal)
    cmd = [
        "python3", AGENT_BUILDER_SCRIPT,
        "--mode", "improve",
        "--agent", proposal["agent_name"],
        "--proposal-file", proposal_file,
        "--repo", proposal["agent_repo"],
    ]
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=300,
        )
        if result.returncode == 0:
            # Commit SHA is the last line of stdout
            stdout_lines = [l.strip() for l in result.stdout.splitlines() if l.strip()]
            sha = stdout_lines[-1] if stdout_lines else ""
            log.info("agent-builder succeeded — SHA: %s", sha)
            return sha
        else:
            log.warning("agent-builder failed: %s", result.stderr[:500])
            return None
    except subprocess.TimeoutExpired:
        log.warning("agent-builder timed out for %s", proposal["agent_name"])
        return None
    except Exception as exc:
        log.warning("agent-builder dispatch error: %s", exc)
        return None
    finally:
        try:
            os.unlink(proposal_file)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Queue processing
# ---------------------------------------------------------------------------

async def _process_queue(conn: sqlite3.Connection, env: Dict[str, str]) -> None:
    """Process all pending items in the approval queue sequentially."""
    pending = conn.execute(
        "SELECT * FROM approval_queue WHERE status IN ('pending', 'builder_unavailable') ORDER BY id ASC"
    ).fetchall()

    log.info("Queue: %d pending items", len(pending))

    for row in pending:
        page_id = row["notion_page_id"]
        agent_name = row["agent_name"]
        retry_count = row["retry_count"]

        if retry_count >= MAX_RETRIES:
            log.warning("Max retries exceeded for %s — marking failed", page_id)
            conn.execute(
                "UPDATE approval_queue SET status='failed' WHERE notion_page_id=?", (page_id,)
            )
            conn.commit()
            await _send_telegram(env, f"Proposal dispatch failed after {MAX_RETRIES} retries: {agent_name}. Manual review required.")
            continue

        # Pre-dispatch health check
        if not _is_agent_builder_active():
            log.warning("agent-builder service inactive — deferring %s", page_id)
            conn.execute(
                "UPDATE approval_queue SET status='builder_unavailable' WHERE notion_page_id=?",
                (page_id,),
            )
            conn.commit()
            await _send_telegram(env, f"agent-builder service inactive. Proposal for {agent_name} deferred to next poll cycle.")
            continue

        # Update status to dispatching
        now = datetime.now(timezone.utc).isoformat()
        conn.execute(
            "UPDATE approval_queue SET status='dispatched', dispatched_at=? WHERE notion_page_id=?",
            (now, page_id),
        )
        conn.commit()
        await _update_notion_status(env, page_id, "Building")

        # Build proposal dict from queue row
        proposal = {
            "notion_page_id": page_id,
            "agent_name": agent_name,
            "agent_repo": row["agent_repo"],
            "proposed_upgrade": row["proposal_summary"],
            "evidence": "",
        }

        commit_sha = _dispatch_to_builder(proposal)

        if commit_sha is not None:
            completed = datetime.now(timezone.utc).isoformat()
            conn.execute(
                "UPDATE approval_queue SET status='deployed', completed_at=?, builder_commit_sha=? WHERE notion_page_id=?",
                (completed, commit_sha, page_id),
            )
            conn.commit()
            await _update_notion_status(
                env, page_id, "Deployed",
                extra_props={
                    "Builder Commit SHA": {"rich_text": [{"text": {"content": commit_sha}}]},
                    "Date Deployed": {"date": {"start": datetime.now(timezone.utc).strftime("%Y-%m-%d")}},
                },
            )
            log.info("Deployed: %s — SHA: %s", agent_name, commit_sha)

            # Trigger post-verifier
            _trigger_post_verifier(page_id, agent_name, row["agent_repo"], commit_sha)
        else:
            new_retry = retry_count + 1
            error_note = f"Dispatch failed at {datetime.now(timezone.utc).isoformat()}"
            conn.execute(
                "UPDATE approval_queue SET status='pending', retry_count=?, error_log=? WHERE notion_page_id=?",
                (new_retry, error_note, page_id),
            )
            conn.commit()
            log.warning("Dispatch failed for %s (retry %d/%d)", agent_name, new_retry, MAX_RETRIES)


def _trigger_post_verifier(page_id: str, agent_name: str, agent_repo: str, commit_sha: str) -> None:
    """Launch post_verifier as a background subprocess."""
    verifier_script = BASE_DIR / "src" / "post_verifier.py"
    cmd = [
        "python3", str(verifier_script),
        "--page-id", page_id,
        "--agent", agent_name,
        "--repo", agent_repo,
        "--sha", commit_sha,
    ]
    try:
        subprocess.Popen(cmd, start_new_session=True)
        log.info("Post-verifier launched for %s (SHA: %s)", agent_name, commit_sha)
    except Exception as exc:
        log.warning("Could not launch post-verifier: %s", exc)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main() -> None:
    env = _load_env()
    db_path = _db_path(env)
    conn = _init_db(db_path)

    log.info("Approval poller starting")

    # Poll Notion for newly approved rows
    approved_rows = await _poll_notion_approved(env)
    log.info("Notion poll: %d Approved rows found", len(approved_rows))

    inserted = 0
    for row in approved_rows:
        proposal = _extract_proposal_from_notion_row(row)
        if not proposal["agent_name"]:
            continue
        try:
            conn.execute(
                "INSERT OR IGNORE INTO approval_queue (notion_page_id, agent_name, agent_repo, proposal_summary) "
                "VALUES (?, ?, ?, ?)",
                (
                    proposal["notion_page_id"],
                    proposal["agent_name"],
                    proposal["agent_repo"],
                    proposal["proposal_summary"],
                ),
            )
            if conn.execute("SELECT changes()").fetchone()[0]:
                inserted += 1
        except sqlite3.IntegrityError:
            pass  # Already in queue
    conn.commit()

    if inserted:
        log.info("Inserted %d new proposals into queue", inserted)

    # Process queue
    await _process_queue(conn, env)

    conn.close()
    log.info("Approval poller complete")


if __name__ == "__main__":
    asyncio.run(main())
