"""
post_verifier.py — Monitor runs after a deployment and auto-revert on regression.

Triggered by approval_poller after each successful agent-builder dispatch.

Monitoring window: 7 actual logged runs OR 14 calendar days (whichever comes first).
Insufficient baseline guard: if pre-deployment baseline < 5 scored runs, skip regression check.
Auto-revert: git revert {sha} --no-edit, then push via GITHUB_PERSONAL_ACCESS_TOKEN.
"""

import argparse
import asyncio
import base64
import json
import logging
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx

BASE_DIR = Path("/home/walt/agents/agent-self-improve")
DATA_DIR = BASE_DIR / "data"
ASSESSMENTS_DIR = DATA_DIR / "assessments"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [post_verifier] %(levelname)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("post_verifier")

MIN_BASELINE_RUNS = 5
MONITORING_RUNS = 7
MONITORING_DAYS = 14
REGRESSION_THRESHOLD = 0.5  # post avg must be < pre avg - 0.5 to trigger revert


# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------

def _load_env() -> Dict[str, str]:
    env_path = Path("/home/walt/.env")
    env: Dict[str, str] = {}
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    for key in ["GITHUB_PERSONAL_ACCESS_TOKEN", "NOTION_TOKEN", "NOVA_TELEGRAM_WORKER_URL"]:
        if key in os.environ:
            env[key] = os.environ[key]
    return env


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------

async def _send_telegram(env: Dict[str, str], message: str) -> None:
    worker_url = env.get("NOVA_TELEGRAM_WORKER_URL", "")
    if not worker_url:
        return
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(worker_url, json={"message": message})
    except Exception as exc:
        log.warning("Telegram failed: %s", exc)


# ---------------------------------------------------------------------------
# Assessment loading
# ---------------------------------------------------------------------------

def _load_agent_assessments(agent_name: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
    """Load assessment entries for a specific agent between two dates."""
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")
    entries: List[Dict[str, Any]] = []
    current = start
    while current <= end:
        date_str = current.strftime("%Y-%m-%d")
        assessment_file = ASSESSMENTS_DIR / date_str / f"{agent_name}.jsonl"
        if assessment_file.exists():
            for line in assessment_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    if not entry.get("no_data") and not entry.get("integrity_error"):
                        entries.append(entry)
                except json.JSONDecodeError:
                    pass
        current += timedelta(days=1)
    return entries


# ---------------------------------------------------------------------------
# Notion status update
# ---------------------------------------------------------------------------

async def _update_notion_status(
    env: Dict[str, str],
    page_id: str,
    status: str,
    extra_props: Optional[Dict[str, Any]] = None,
) -> None:
    token = env.get("NOTION_TOKEN", "")
    if not token:
        return
    properties: Dict[str, Any] = {"Status": {"select": {"name": status}}}
    if extra_props:
        properties.update(extra_props)
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            await client.patch(
                f"https://api.notion.com/v1/pages/{page_id}",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Notion-Version": "2022-06-28",
                    "Content-Type": "application/json",
                },
                json={"properties": properties},
            )
    except Exception as exc:
        log.warning("Notion update failed: %s", exc)


# ---------------------------------------------------------------------------
# Git revert
# ---------------------------------------------------------------------------

def _git_revert(agent_repo: str, commit_sha: str, env: Dict[str, str]) -> Optional[str]:
    """
    Clone the agent repo, revert the specified commit, push, return revert SHA.
    Returns None on failure (caller handles alert + Notion Revert Failed).
    """
    token = env.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    if not token:
        log.error("No GITHUB_PERSONAL_ACCESS_TOKEN — cannot revert")
        return None

    clone_url = f"https://{token}@github.com/{agent_repo}.git"
    with tempfile.TemporaryDirectory() as tmpdir:
        try:
            subprocess.run(
                ["git", "clone", "--depth", "50", clone_url, tmpdir],
                check=True, capture_output=True, timeout=60,
            )
            subprocess.run(
                ["git", "revert", commit_sha, "--no-edit"],
                check=True, capture_output=True, timeout=30, cwd=tmpdir,
            )
            # Get the revert commit SHA
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                check=True, capture_output=True, text=True, cwd=tmpdir,
            )
            revert_sha = result.stdout.strip()

            subprocess.run(
                ["git", "push", "origin", "main"],
                check=True, capture_output=True, timeout=60, cwd=tmpdir,
            )
            log.info("Git revert successful — revert SHA: %s", revert_sha)
            return revert_sha

        except subprocess.CalledProcessError as exc:
            log.error("Git revert failed: %s", exc.stderr.decode() if exc.stderr else str(exc))
            return None


# ---------------------------------------------------------------------------
# Wiki outcome write
# ---------------------------------------------------------------------------

async def _write_wiki_outcome(
    env: Dict[str, str],
    agent_name: str,
    page_id: str,
    proposal_summary: str,
    score_before: float,
    score_after: float,
    verdict: str,
    deploy_sha: str,
    revert_sha: Optional[str],
    run_count: int,
    run_id: str,
) -> None:
    """Write improvement outcome report to Walt's Wiki."""
    token = env.get("GITHUB_PERSONAL_ACCESS_TOKEN", "")
    if not token:
        log.warning("No GITHUB_PERSONAL_ACCESS_TOKEN — skipping wiki outcome write")
        return

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    wiki_path = f"Agent Builds/Self-Improve Reports/improvements/{today}-{agent_name}-{run_id[:8]}.md"

    content = (
        f"# Improvement Outcome: {agent_name}\n\n"
        f"**Date:** {today}\n"
        f"**Notion Page ID:** {page_id}\n"
        f"**Verdict:** {verdict}\n\n"
        f"## Proposal\n\n{proposal_summary}\n\n"
        f"## Scores\n\n"
        f"| Metric | Value |\n"
        f"|--------|-------|\n"
        f"| Score Before (7-day avg) | {score_before:.2f} |\n"
        f"| Score After ({run_count} runs) | {score_after:.2f} |\n"
        f"| Change | {score_after - score_before:+.2f} |\n\n"
        f"## Commits\n\n"
        f"- Deployment SHA: `{deploy_sha}`\n"
    )
    if revert_sha:
        content += f"- Revert SHA: `{revert_sha}`\n"

    content_b64 = base64.b64encode(content.encode("utf-8")).decode("ascii")
    async with httpx.AsyncClient(timeout=20) as client:
        check = await client.get(
            f"https://api.github.com/repos/waltbayliss/walts-wiki/contents/{wiki_path}",
            headers={"Authorization": f"token {token}"},
        )
        payload: Dict[str, Any] = {
            "message": f"agent-self-improve: outcome {agent_name} {verdict}",
            "content": content_b64,
        }
        if check.status_code == 200:
            # File exists — use _v2 suffix
            wiki_path = wiki_path.replace(".md", "_v2.md")
            payload.pop("sha", None)

        await client.put(
            f"https://api.github.com/repos/waltbayliss/walts-wiki/contents/{wiki_path}",
            headers={
                "Authorization": f"token {token}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
    log.info("Wiki outcome written: %s", wiki_path)


# ---------------------------------------------------------------------------
# Main verification loop
# ---------------------------------------------------------------------------

async def verify(
    page_id: str,
    agent_name: str,
    agent_repo: str,
    deploy_sha: str,
) -> None:
    env = _load_env()
    today = datetime.now(timezone.utc)
    deploy_date = today.strftime("%Y-%m-%d")
    window_end = (today + timedelta(days=MONITORING_DAYS)).strftime("%Y-%m-%d")

    log.info("Post-verifier: %s deploy SHA %s", agent_name, deploy_sha)

    # Load pre-deployment baseline (assessments before today)
    pre_start = (today - timedelta(days=14)).strftime("%Y-%m-%d")
    pre_end = (today - timedelta(days=1)).strftime("%Y-%m-%d")
    baseline = _load_agent_assessments(agent_name, pre_start, pre_end)

    if len(baseline) < MIN_BASELINE_RUNS:
        log.info(
            "%s: insufficient baseline (%d runs, need %d) — skipping regression check",
            agent_name, len(baseline), MIN_BASELINE_RUNS,
        )
        return

    baseline_avg = sum(a.get("score", 0.0) for a in baseline) / len(baseline)
    log.info("%s: baseline avg %.2f (%d runs)", agent_name, baseline_avg, len(baseline))

    # Poll for post-deployment runs
    import time
    poll_interval = 3600  # Check hourly
    deadline = today + timedelta(days=MONITORING_DAYS)
    post_runs: List[Dict[str, Any]] = []

    while len(post_runs) < MONITORING_RUNS and datetime.now(timezone.utc) < deadline:
        post_runs = _load_agent_assessments(agent_name, deploy_date, window_end)
        if len(post_runs) >= MONITORING_RUNS:
            break
        log.info("%s: %d/%d post-deployment runs collected — sleeping 1h", agent_name, len(post_runs), MONITORING_RUNS)
        await asyncio.sleep(poll_interval)

    if not post_runs:
        log.info("%s: no post-deployment runs within window — no verdict", agent_name)
        return

    post_avg = sum(a.get("score", 0.0) for a in post_runs) / len(post_runs)
    log.info("%s: post-deployment avg %.2f (%d runs)", agent_name, post_avg, len(post_runs))
    run_id = str(post_runs[0].get("run_id", "unknown")) if post_runs else "unknown"

    if post_avg >= baseline_avg - REGRESSION_THRESHOLD:
        # Improvement or stable — verify
        verdict = "Verified"
        await _update_notion_status(
            env, page_id, "Verified",
            extra_props={"Score After": {"number": round(post_avg, 2)}},
        )
        await _send_telegram(
            env,
            f"agent-{agent_name} improved: {baseline_avg:.1f} to {post_avg:.1f} ({len(post_runs)} run avg). Commit: {deploy_sha}",
        )
        log.info("%s: VERIFIED — %.2f -> %.2f", agent_name, baseline_avg, post_avg)
        await _write_wiki_outcome(
            env, agent_name, page_id, "",
            baseline_avg, post_avg, verdict, deploy_sha, None, len(post_runs), run_id,
        )
    else:
        # Regression detected — revert
        log.warning("%s: REGRESSION detected — %.2f -> %.2f — reverting", agent_name, baseline_avg, post_avg)
        revert_sha = _git_revert(agent_repo, deploy_sha, env)

        if revert_sha:
            verdict = "Reverted"
            await _update_notion_status(
                env, page_id, "Reverted",
                extra_props={"Score After": {"number": round(post_avg, 2)}},
            )
            await _send_telegram(
                env,
                f"Regression detected in {agent_name}: {baseline_avg:.1f} to {post_avg:.1f}. "
                f"Reverted commit {deploy_sha}. Revert SHA: {revert_sha}",
            )
        else:
            verdict = "Revert Failed"
            await _update_notion_status(env, page_id, "Revert Failed")
            await _send_telegram(
                env,
                f"REVERT FAILED for {agent_name}. Score regressed {baseline_avg:.1f} to {post_avg:.1f}. "
                f"Manual revert required: git revert {deploy_sha} in repo {agent_repo}. "
                f"Notion page: {page_id}",
            )

        await _write_wiki_outcome(
            env, agent_name, page_id, "",
            baseline_avg, post_avg, verdict, deploy_sha, revert_sha, len(post_runs), run_id,
        )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Post-improvement verifier")
    parser.add_argument("--page-id", required=True, help="Notion page ID")
    parser.add_argument("--agent", required=True, help="Agent name")
    parser.add_argument("--repo", required=True, help="GitHub repo (waltbayliss/agent-name)")
    parser.add_argument("--sha", required=True, help="Builder commit SHA")
    args = parser.parse_args()

    asyncio.run(verify(args.page_id, args.agent, args.repo, args.sha))


if __name__ == "__main__":
    main()
