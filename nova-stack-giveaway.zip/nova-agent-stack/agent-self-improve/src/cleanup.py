"""
cleanup.py — 30-day log retention for assessment files.

Schedule: 03:00 UTC nightly via agent-self-improve-cleanup.timer

Deletes assessment JSONL files older than 30 days.
Quarantined files (.quarantine suffix) are NEVER deleted.
"""

import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE_DIR = Path("/home/walt/agents/agent-self-improve")
DATA_DIR = BASE_DIR / "data"
ASSESSMENTS_DIR = DATA_DIR / "assessments"
RETENTION_DAYS = 30

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [cleanup] %(levelname)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("cleanup")


def main() -> None:
    cutoff = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
    cutoff_str = cutoff.strftime("%Y-%m-%d")

    if not ASSESSMENTS_DIR.exists():
        log.info("No assessments directory found — nothing to clean")
        return

    deleted = 0
    skipped_quarantine = 0

    for date_dir in sorted(ASSESSMENTS_DIR.iterdir()):
        if not date_dir.is_dir():
            continue
        dir_name = date_dir.name
        # Only process directories named YYYY-MM-DD
        if len(dir_name) != 10 or dir_name > cutoff_str:
            continue

        for f in date_dir.iterdir():
            if f.suffix == ".quarantine" or ".quarantine" in f.name:
                skipped_quarantine += 1
                continue
            if f.is_file():
                f.unlink()
                deleted += 1
                log.debug("Deleted: %s", f)

        # Remove empty date directories
        try:
            remaining = list(date_dir.iterdir())
            if not remaining:
                date_dir.rmdir()
                log.debug("Removed empty dir: %s", date_dir)
        except Exception as exc:
            log.warning("Could not remove dir %s: %s", date_dir, exc)

    log.info(
        "Cleanup complete — deleted: %d files, preserved: %d quarantined files",
        deleted, skipped_quarantine,
    )


if __name__ == "__main__":
    main()
