"""
daily_judge.py — Daily LLM scoring of all enrolled agent runs.

Schedule: 02:00 UTC nightly via agent-self-improve-daily.timer

Algorithm:
1. Load config/agents.yaml
2. For each agent: read today's JSONL log (local file or CF KV)
3. Verify SHA chain — quarantine on failure, Telegram alert, skip
4. Deterministic pre-checks per entry (gate-agent duality)
5. asyncio.gather() — all agents scored in parallel
6. Per-agent: 3-run ensemble via OpenRouter (adversarial judge family)
7. Scores clamped [0,10], averaged, all 3 stored in score_ensemble
8. Write assessment JSONL with per-dimension reasoning text
9. Immediate Telegram alert on hard_failure or integrity_error
"""

import asyncio
import hashlib
import json
import logging
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
import yaml

# ---------------------------------------------------------------------------
# Paths and configuration
# ---------------------------------------------------------------------------

BASE_DIR = Path("/home/walt/agents/agent-self-improve")
CONFIG_DIR = BASE_DIR / "config"
DATA_DIR = BASE_DIR / "data"
ASSESSMENTS_DIR = DATA_DIR / "assessments"
AGENTS_YAML = CONFIG_DIR / "agents.yaml"
RUBRICS_DIR = CONFIG_DIR / "rubrics"

# Adversarial judge model selection — must be different family from agent model
JUDGE_MODELS: Dict[str, str] = {
    "claude": "google/gemini-flash-1.5",
    "gemini": "anthropic/claude-haiku-4-5",
    "openai": "anthropic/claude-haiku-4-5",
    "mixed": "google/gemini-flash-1.5",
}

REQUIRED_LOG_FIELDS = {"timestamp", "agent_name", "run_id", "output_summary", "status", "prev_hash"}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [daily_judge] %(levelname)s %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger("daily_judge")


# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------

def _load_env() -> Dict[str, str]:
    """Load required env vars from /home/walt/.env."""
    env_path = Path("/home/walt/.env")
    env: Dict[str, str] = {}
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()
    # Override with process environment
    for key in ["OPENROUTER_API_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
                "NOVA_TELEGRAM_WORKER_URL", "CF_API_TOKEN", "CF_ACCOUNT_ID"]:
        if key in os.environ:
            env[key] = os.environ[key]
    return env


# ---------------------------------------------------------------------------
# Telegram alert
# ---------------------------------------------------------------------------

async def _send_telegram(env: Dict[str, str], message: str) -> None:
    """Send a Telegram alert via NOVA_TELEGRAM_WORKER_URL."""
    worker_url = env.get("NOVA_TELEGRAM_WORKER_URL", "")
    if not worker_url:
        log.warning("NOVA_TELEGRAM_WORKER_URL not set — skipping Telegram alert")
        return
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(worker_url, json={"message": message})
    except Exception as exc:
        log.warning("Telegram alert failed: %s", exc)


# ---------------------------------------------------------------------------
# Agent config loading
# ---------------------------------------------------------------------------

def _load_agents() -> List[Dict[str, Any]]:
    """Load enrolled agents from config/agents.yaml."""
    with open(AGENTS_YAML, "r") as fh:
        data = yaml.safe_load(fh)
    return data.get("agents", [])


def _load_rubric(agent_type: str) -> Dict[str, Any]:
    """Load rubric YAML for a given agent type."""
    rubric_path = RUBRICS_DIR / f"{agent_type}.yaml"
    if not rubric_path.exists():
        log.warning("No rubric found for type '%s' — using session rubric as fallback", agent_type)
        rubric_path = RUBRICS_DIR / "session.yaml"
    with open(rubric_path, "r") as fh:
        return yaml.safe_load(fh)


# ---------------------------------------------------------------------------
# Log reading
# ---------------------------------------------------------------------------

def _read_log_entries(agent: Dict[str, Any], date_str: str) -> List[Dict[str, Any]]:
    """
    Read JSONL log entries for an agent on a given date.
    Returns list of parsed entry dicts. Skips malformed lines.
    """
    log_path = agent.get("log_path", "")

    if log_path.startswith("cf-kv:"):
        # Cloudflare KV handler — not implemented in this stub
        log.info("CF KV handler not yet implemented for %s — returning empty", agent["name"])
        return []

    log_file = Path(log_path) / f"{date_str}.jsonl"
    if not log_file.exists():
        return []

    entries = []
    for i, line in enumerate(log_file.read_text(encoding="utf-8").splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            log.warning("%s: malformed JSON on line %d — skipping", agent["name"], i + 1)
    return entries


def _read_log_lines_raw(agent: Dict[str, Any], date_str: str) -> List[str]:
    """Return raw line strings for SHA chain verification."""
    log_path = agent.get("log_path", "")
    if log_path.startswith("cf-kv:"):
        return []
    log_file = Path(log_path) / f"{date_str}.jsonl"
    if not log_file.exists():
        return []
    return [l for l in log_file.read_text(encoding="utf-8").splitlines() if l.strip()]


# ---------------------------------------------------------------------------
# SHA chain verification
# ---------------------------------------------------------------------------

def _verify_sha_chain(lines: List[str]) -> bool:
    """
    Verify the SHA-256 chain across all entries.
    Returns True if chain is valid, False if integrity error detected.
    """
    if not lines:
        return True

    first = json.loads(lines[0])
    if first.get("prev_hash") != "genesis" and len(lines) > 0:
        # First entry must be genesis unless there is a prior-day link
        # We allow a non-genesis first entry (cross-day chain)
        pass

    for i in range(1, len(lines)):
        prev_line = lines[i - 1]
        current = json.loads(lines[i])
        expected_hash = hashlib.sha256(prev_line.encode("utf-8")).hexdigest()
        if current.get("prev_hash") != expected_hash:
            log.error("SHA chain broken at entry %d", i)
            return False
    return True


def _quarantine_log(agent: Dict[str, Any], date_str: str) -> None:
    """Rename corrupted log file with .quarantine suffix."""
    log_path = agent.get("log_path", "")
    if log_path.startswith("cf-kv:"):
        return
    log_file = Path(log_path) / f"{date_str}.jsonl"
    if log_file.exists():
        quarantine = log_file.with_suffix(".jsonl.quarantine")
        log_file.rename(quarantine)
        log.warning("Quarantined: %s", quarantine)


# ---------------------------------------------------------------------------
# Deterministic pre-checks
# ---------------------------------------------------------------------------

def _deterministic_check(entry: Dict[str, Any]) -> bool:
    """
    Gate-agent duality: zero-cost checks before any LLM invocation.
    Returns True if entry passes, False if it should be flagged as hard_failure.
    """
    missing = REQUIRED_LOG_FIELDS - set(entry.keys())
    if missing:
        log.warning("Entry %s missing fields: %s", entry.get("run_id", "?"), missing)
        return False
    if not entry.get("output_summary"):
        return False
    return True


# ---------------------------------------------------------------------------
# LLM scoring
# ---------------------------------------------------------------------------

async def _score_once(
    client: httpx.AsyncClient,
    openrouter_key: str,
    judge_model: str,
    agent: Dict[str, Any],
    entry: Dict[str, Any],
    rubric: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    """
    Call the judge model once and return parsed score_breakdown.
    Returns None on failure.
    """
    dimensions = rubric.get("dimensions", {})
    dimension_prompts = "\n".join(
        f"- {dim}: {info.get('description', '')}. {info.get('guidance_text', '')}"
        for dim, info in dimensions.items()
    )

    prompt = (
        f"You are an adversarial quality judge for an AI agent fleet. "
        f"Your job is to critically evaluate the following agent run output and score it.\n\n"
        f"Agent: {agent['name']} (type: {agent.get('type', 'unknown')})\n"
        f"Trigger: {entry.get('trigger', 'unknown')}\n"
        f"Input: {entry.get('input_summary', '')}\n"
        f"Output: {entry.get('output_summary', '')}\n"
        f"Status: {entry.get('status', 'unknown')}\n"
        f"Decisions: {json.dumps(entry.get('decisions', []))}\n"
        f"Errors: {json.dumps(entry.get('errors', []))}\n\n"
        f"Score each of the following dimensions from 0.0 to 10.0. "
        f"Be adversarial — look for flaws, gaps, and missed opportunities.\n\n"
        f"{dimension_prompts}\n\n"
        f"Return ONLY a JSON object in this exact format (no markdown, no explanation outside JSON):\n"
        f"{{\n"
        + ",\n".join(
            f'  "{dim}": {{"score": <0.0-10.0>, "reasoning": "<one sentence explanation>"}}'
            for dim in dimensions
        )
        + f"\n}}"
    )

    try:
        response = await client.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {openrouter_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": judge_model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0,
                "max_tokens": 512,
            },
            timeout=30,
        )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"].strip()
        # Strip markdown code fences if present
        if content.startswith("```"):
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        return json.loads(content)
    except Exception as exc:
        log.warning("Judge call failed for %s: %s", agent["name"], exc)
        return None


def _clamp_scores(score_breakdown: Dict[str, Any]) -> Dict[str, Any]:
    """Clamp all scores in a score_breakdown to [0, 10]. Log warnings for out-of-range."""
    clamped = {}
    for dim, info in score_breakdown.items():
        raw = info.get("score", 0)
        if raw < 0 or raw > 10:
            log.warning("Score out of range for dimension %s: %s — clamping", dim, raw)
        clamped[dim] = {
            "score": max(0.0, min(10.0, float(raw))),
            "reasoning": info.get("reasoning", ""),
        }
    return clamped


async def _score_entry_ensemble(
    client: httpx.AsyncClient,
    openrouter_key: str,
    judge_model: str,
    agent: Dict[str, Any],
    entry: Dict[str, Any],
    rubric: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Run 3 parallel judge calls, average scores, return assessment dict.
    """
    results = await asyncio.gather(
        _score_once(client, openrouter_key, judge_model, agent, entry, rubric),
        _score_once(client, openrouter_key, judge_model, agent, entry, rubric),
        _score_once(client, openrouter_key, judge_model, agent, entry, rubric),
    )

    valid = [r for r in results if r is not None]
    if not valid:
        return {
            "score": 0.0,
            "score_ensemble": [],
            "score_breakdown": {},
            "findings": ["All 3 judge calls failed — scoring unavailable"],
            "hard_failure": True,
            "failure_category": "incomplete_task",
        }

    # Average scores per dimension across valid results
    dimensions = list(valid[0].keys())
    averaged_breakdown: Dict[str, Any] = {}
    for dim in dimensions:
        scores = [_clamp_scores(r).get(dim, {}).get("score", 0.0) for r in valid if dim in r]
        avg_score = sum(scores) / len(scores) if scores else 0.0
        # Use reasoning from first valid result
        reasoning = valid[0].get(dim, {}).get("reasoning", "")
        averaged_breakdown[dim] = {"score": round(avg_score, 2), "reasoning": reasoning}

    dim_scores = [v["score"] for v in averaged_breakdown.values()]
    overall = round(sum(dim_scores) / len(dim_scores), 2) if dim_scores else 0.0

    # Individual run scores (average of all dimensions per run)
    ensemble = []
    for r in valid:
        clamped = _clamp_scores(r)
        run_scores = [v["score"] for v in clamped.values()]
        ensemble.append(round(sum(run_scores) / len(run_scores), 2) if run_scores else 0.0)

    findings = [
        f"{dim}: {info['reasoning']}"
        for dim, info in averaged_breakdown.items()
        if info["score"] < 7.0
    ]

    return {
        "score": overall,
        "score_ensemble": ensemble,
        "score_breakdown": averaged_breakdown,
        "findings": findings,
        "hard_failure": False,
        "failure_category": None,
    }


# ---------------------------------------------------------------------------
# Per-agent scoring
# ---------------------------------------------------------------------------

async def _score_agent(
    agent: Dict[str, Any],
    date_str: str,
    env: Dict[str, str],
    client: httpx.AsyncClient,
) -> Dict[str, Any]:
    """Score a single agent for the given date. Returns assessment dict."""
    name = agent["name"]
    agent_type = agent.get("type", "session")
    model_family = agent.get("primary_model_family", "claude")
    judge_model = JUDGE_MODELS.get(model_family, JUDGE_MODELS["mixed"])

    # Determine log window: session agents use 7-day rolling window
    dates_to_check = [date_str]
    if agent_type == "session":
        from datetime import timedelta
        base = datetime.strptime(date_str, "%Y-%m-%d")
        dates_to_check = [(base - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]

    all_entries: List[Dict[str, Any]] = []
    all_lines: List[str] = []
    for d in dates_to_check:
        all_entries.extend(_read_log_entries(agent, d))
        all_lines.extend(_read_log_lines_raw(agent, d))

    if not all_entries:
        log.info("%s: no data for %s", name, date_str)
        return _make_no_data_assessment(agent, date_str, judge_model, model_family)

    # SHA chain verification (only for today's file if single day)
    if len(dates_to_check) == 1:
        today_lines = _read_log_lines_raw(agent, date_str)
        if today_lines and not _verify_sha_chain(today_lines):
            _quarantine_log(agent, date_str)
            msg = f"Log integrity failure: {name} {date_str} log. File quarantined. Manual review required."
            await _send_telegram(env, msg)
            return _make_integrity_error_assessment(agent, date_str, judge_model, model_family)

    rubric = _load_rubric(agent_type)
    openrouter_key = env.get("OPENROUTER_API_KEY", "")

    # Score each entry
    assessments = []
    for entry in all_entries:
        if not _deterministic_check(entry):
            assessment = {
                "run_id": entry.get("run_id", str(uuid.uuid4())),
                "deterministic_pass": False,
                "score": 0.0,
                "score_ensemble": [],
                "score_breakdown": {},
                "findings": ["Failed deterministic pre-check"],
                "failure_category": "incomplete_task",
                "hard_failure": True,
            }
        else:
            scored = await _score_entry_ensemble(client, openrouter_key, judge_model, agent, entry, rubric)
            assessment = {
                "run_id": entry.get("run_id", str(uuid.uuid4())),
                "deterministic_pass": True,
                **scored,
            }

        if assessment.get("hard_failure"):
            msg = (
                f"Hard failure: {name} — {entry.get('output_summary', 'empty output')[:100]}. "
                f"Run ID: {assessment['run_id']}"
            )
            await _send_telegram(env, msg)

        assessments.append(assessment)

    # Daily aggregate: average score across all entries
    valid_scores = [a["score"] for a in assessments if a["score"] > 0]
    day_score = round(sum(valid_scores) / len(valid_scores), 2) if valid_scores else 0.0
    any_hard_failure = any(a.get("hard_failure") for a in assessments)

    # Write assessment file
    assessment_date_dir = ASSESSMENTS_DIR / date_str
    assessment_date_dir.mkdir(parents=True, exist_ok=True)
    os.chmod(assessment_date_dir, 0o700)

    assessment_file = assessment_date_dir / f"{name}.jsonl"
    final_assessment = {
        "assessment_date": date_str,
        "agent_name": name,
        "agent_type": agent_type,
        "run_count": len(assessments),
        "score": day_score,
        "score_ensemble": assessments[0]["score_ensemble"] if assessments else [],
        "score_breakdown": assessments[0].get("score_breakdown", {}),
        "failure_category": assessments[0].get("failure_category"),
        "findings": [f for a in assessments for f in a.get("findings", [])],
        "hard_failure": any_hard_failure,
        "integrity_error": False,
        "judge_model": judge_model,
        "judge_model_family": "gemini" if "gemini" in judge_model else "claude",
        "agent_model_family": model_family,
        "no_data": False,
        "insufficient_baseline": False,
    }

    with open(assessment_file, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(final_assessment, ensure_ascii=False) + "\n")
    os.chmod(assessment_file, 0o700)

    log.info("%s: scored %.2f (judge: %s)", name, day_score, judge_model)
    return final_assessment


def _make_no_data_assessment(agent: Dict[str, Any], date_str: str, judge_model: str, model_family: str) -> Dict[str, Any]:
    result = {
        "assessment_date": date_str,
        "agent_name": agent["name"],
        "agent_type": agent.get("type", "session"),
        "run_count": 0,
        "score": 0.0,
        "score_ensemble": [],
        "score_breakdown": {},
        "failure_category": None,
        "findings": [],
        "hard_failure": False,
        "integrity_error": False,
        "judge_model": judge_model,
        "judge_model_family": "gemini" if "gemini" in judge_model else "claude",
        "agent_model_family": model_family,
        "no_data": True,
        "insufficient_baseline": False,
    }
    assessment_date_dir = ASSESSMENTS_DIR / date_str
    assessment_date_dir.mkdir(parents=True, exist_ok=True)
    assessment_file = assessment_date_dir / f"{agent['name']}.jsonl"
    with open(assessment_file, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(result, ensure_ascii=False) + "\n")
    return result


def _make_integrity_error_assessment(agent: Dict[str, Any], date_str: str, judge_model: str, model_family: str) -> Dict[str, Any]:
    result = {
        "assessment_date": date_str,
        "agent_name": agent["name"],
        "agent_type": agent.get("type", "session"),
        "run_count": 0,
        "score": 0.0,
        "score_ensemble": [],
        "score_breakdown": {},
        "failure_category": None,
        "findings": ["Log integrity error — file quarantined"],
        "hard_failure": False,
        "integrity_error": True,
        "judge_model": judge_model,
        "judge_model_family": "gemini" if "gemini" in judge_model else "claude",
        "agent_model_family": model_family,
        "no_data": False,
        "insufficient_baseline": False,
    }
    assessment_date_dir = ASSESSMENTS_DIR / date_str
    assessment_date_dir.mkdir(parents=True, exist_ok=True)
    assessment_file = assessment_date_dir / f"{agent['name']}.jsonl"
    with open(assessment_file, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(result, ensure_ascii=False) + "\n")
    return result


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

async def main() -> None:
    env = _load_env()
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    agents = _load_agents()
    log.info("Daily judge starting — date: %s, agents: %d", date_str, len(agents))

    ASSESSMENTS_DIR.mkdir(parents=True, exist_ok=True)

    async with httpx.AsyncClient() as client:
        tasks = [_score_agent(agent, date_str, env, client) for agent in agents]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    for agent, result in zip(agents, results):
        if isinstance(result, Exception):
            log.error("Error scoring %s: %s", agent["name"], result)

    scored = sum(1 for r in results if not isinstance(r, Exception) and not r.get("no_data"))
    log.info("Daily judge complete — %d/%d agents scored", scored, len(agents))


if __name__ == "__main__":
    asyncio.run(main())
