"""
Secret sanitiser for nova_logger.

Redacts values matching known secret patterns before they are written to JSONL logs.
Redacted placeholder: [REDACTED]

Patterns redacted:
- Strings starting with "sk-"
- Strings starting with "Bearer "
- Strings containing "token="
- Strings containing "password="
- Any string longer than 40 characters containing no spaces
"""

import re
from typing import Any

# Patterns that indicate a string is a secret
_SECRET_PATTERNS = [
    re.compile(r"sk-"),
    re.compile(r"Bearer "),
    re.compile(r"token=", re.IGNORECASE),
    re.compile(r"password=", re.IGNORECASE),
]

_REDACTED = "[REDACTED]"
_LONG_NO_SPACE_MIN_LEN = 40


def _is_secret_string(value: str) -> bool:
    """Return True if the string value looks like a secret."""
    for pattern in _SECRET_PATTERNS:
        if pattern.search(value):
            return True
    # Long value with no spaces is likely a token or key
    if len(value) > _LONG_NO_SPACE_MIN_LEN and " " not in value:
        return True
    return False


def sanitise(value: Any) -> Any:
    """
    Recursively sanitise a value before it is written to a log entry.

    - Strings: check against secret patterns; redact if matched.
    - Dicts: sanitise all values recursively.
    - Lists: sanitise all elements recursively.
    - Other types (int, float, bool, None): returned unchanged.
    """
    if isinstance(value, str):
        if _is_secret_string(value):
            return _REDACTED
        return value
    if isinstance(value, dict):
        return {k: sanitise(v) for k, v in value.items()}
    if isinstance(value, list):
        return [sanitise(item) for item in value]
    # int, float, bool, None — safe as-is
    return value
