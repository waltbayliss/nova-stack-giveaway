"""
nova_logger — Shared run logging library for Walt's AI agent fleet.

SHA-chained JSONL writer with secret sanitisation and non-fatal contract.
Every agent on the VPS imports this package to record structured run data.

Install: pip install -e /home/walt/agents/agent-self-improve/nova_logger
Usage:
    from nova_logger import NovaLogger
    logger = NovaLogger(agent_name="agent-social-poster",
                        log_dir="/home/walt/agents/agent-social-poster/logs")
    logger.log(trigger="systemd-timer", input_summary="...", ...)
"""

from nova_logger.logger import NovaLogger
from nova_logger.sanitiser import sanitise

__version__ = "1.0.0"
__all__ = ["NovaLogger", "sanitise"]
