"""
NovaLogger — core logging class for agent-self-improve fleet logging.

Non-fatal contract: all exceptions are caught internally. The host agent
continues regardless of logger errors. Exceptions are written to stderr only.

SHA-chain: each entry's prev_hash = SHA-256 of previous entry text.
First entry in a new daily file uses SHA-256 of last entry from prior file,
or the string "genesis" if no prior file exists.

Write contract: atomic temp-file + rename to prevent partial writes.
"""

import hashlib
import json
import os
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from nova_logger.sanitiser import sanitise


class NovaLogger:
    """
    Shared run logging library for Walt's AI agent fleet.

    Parameters
    ----------
    agent_name : str
        Name of the calling agent (e.g. "agent-social-poster").
    log_dir : str | Path
        Directory where YYYY-MM-DD.jsonl files are written.
        Created (chmod 700) if it does not exist.
    agent_version : str, optional
        Git SHA or version string for the calling agent. Defaults to "unknown".
    namespace : str, optional
        MyDPA multi-tenant namespace. Defaults to "walt".
    """

    def __init__(
        self,
        agent_name: str,
        log_dir: str | Path,
        agent_version: str = "unknown",
        namespace: str = "walt",
    ) -> None:
        self.agent_name = agent_name
        self.log_dir = Path(log_dir)
        self.agent_version = agent_version
        self.namespace = namespace
        try:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            # chmod 700 — owner read/write/execute only
            os.chmod(self.log_dir, 0o700)
        except Exception as exc:
            print(f"[nova_logger] WARNING: could not create log_dir {self.log_dir}: {exc}", file=sys.stderr)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log(
        self,
        trigger: str,
        input_summary: str,
        output_summary: str,
        status: str,
        decisions: Optional[List[str]] = None,
        output_artifacts: Optional[List[Dict[str, Any]]] = None,
        errors: Optional[List[str]] = None,
        failure_category: Optional[str] = None,
        model_used: Optional[str] = None,
        cost_usd: Optional[float] = None,
        duration_seconds: Optional[float] = None,
        hard_failure: bool = False,
        extra: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """
        Write a structured run entry to today's JSONL log file.

        Returns the run_id string on success, or None if logging failed
        (the host agent must continue regardless).

        Parameters
        ----------
        trigger : str
            How this run was initiated (e.g. "systemd-timer", "nova-routing", "cli").
        input_summary : str
            Brief description of what the agent received / was asked to do.
        output_summary : str
            Brief description of what was produced or delivered.
        status : str
            "success" | "partial_success" | "failure" | "skipped"
        decisions : list of str, optional
            Key decisions made during the run (for auditability).
        output_artifacts : list of dict, optional
            Structured references to produced artefacts (type, id, url, etc).
        errors : list of str, optional
            Error messages encountered (sanitised before write).
        failure_category : str, optional
            One of: tool_misuse | context_loss | hallucinated_action |
            incomplete_task | incorrect_reasoning | format_error | None
        model_used : str, optional
            Model identifier used for LLM calls in this run.
        cost_usd : float, optional
            Estimated LLM cost for this run in USD.
        duration_seconds : float, optional
            Wall-clock run duration.
        hard_failure : bool
            True if this run represents a hard failure requiring immediate alert.
        extra : dict, optional
            Additional agent-specific fields (sanitised before write).
        """
        try:
            run_id = str(uuid.uuid4())
            timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

            log_file = self.log_dir / f"{today}.jsonl"
            prev_hash = self._compute_prev_hash(log_file)

            entry: Dict[str, Any] = {
                "timestamp": timestamp,
                "agent_name": self.agent_name,
                "agent_version": self.agent_version,
                "namespace": self.namespace,
                "run_id": run_id,
                "trigger": trigger,
                "input_summary": sanitise(input_summary),
                "decisions": sanitise(decisions or []),
                "output_summary": sanitise(output_summary),
                "output_artifacts": sanitise(output_artifacts or []),
                "errors": sanitise(errors or []),
                "failure_category": failure_category,
                "model_used": model_used,
                "cost_usd": cost_usd,
                "duration_seconds": duration_seconds,
                "status": status,
                "hard_failure": hard_failure,
                "prev_hash": prev_hash,
            }

            if extra:
                entry["extra"] = sanitise(extra)

            self._atomic_append(log_file, entry)
            return run_id

        except Exception as exc:
            print(f"[nova_logger] ERROR: failed to write log entry: {exc}", file=sys.stderr)
            return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _compute_prev_hash(self, today_log: Path) -> str:
        """
        Compute the prev_hash for a new log entry.

        If today's file already has entries: SHA-256 of the last entry line.
        If today's file is empty/missing: SHA-256 of last line from yesterday's file.
        If no prior file exists at all: return "genesis".
        """
        try:
            if today_log.exists() and today_log.stat().st_size > 0:
                last_line = self._read_last_line(today_log)
                if last_line:
                    return hashlib.sha256(last_line.encode("utf-8")).hexdigest()

            # No entries today — look for yesterday's file
            prior = self._find_prior_log(today_log)
            if prior:
                last_line = self._read_last_line(prior)
                if last_line:
                    return hashlib.sha256(last_line.encode("utf-8")).hexdigest()

            return "genesis"
        except Exception as exc:
            print(f"[nova_logger] WARNING: could not compute prev_hash: {exc}", file=sys.stderr)
            return "genesis"

    def _read_last_line(self, path: Path) -> Optional[str]:
        """Return the last non-empty line from a file, or None."""
        try:
            with open(path, "r", encoding="utf-8") as fh:
                lines = [line.strip() for line in fh if line.strip()]
            return lines[-1] if lines else None
        except Exception:
            return None

    def _find_prior_log(self, today_log: Path) -> Optional[Path]:
        """Find the most recent JSONL file before today in the same directory."""
        today_name = today_log.name
        try:
            all_logs = sorted(
                [f for f in self.log_dir.glob("????-??-??.jsonl") if f.name != today_name]
            )
            return all_logs[-1] if all_logs else None
        except Exception:
            return None

    def _atomic_append(self, log_file: Path, entry: Dict[str, Any]) -> None:
        """
        Append a JSON entry to the log file atomically.

        Strategy: write to a temp file in the same directory, then use
        os.open + write to append (read existing + new line, write all).
        Simpler and safer: write entry to temp, then append temp content to log.
        """
        line = json.dumps(entry, ensure_ascii=False, separators=(",", ":")) + "\n"
        line_bytes = line.encode("utf-8")

        # Write to temp file first
        tmp_fd, tmp_path = tempfile.mkstemp(
            dir=self.log_dir,
            prefix=".tmp_nova_",
            suffix=".jsonl"
        )
        try:
            os.write(tmp_fd, line_bytes)
            os.fsync(tmp_fd)
        finally:
            os.close(tmp_fd)

        # Append temp file content to the real log file
        try:
            with open(log_file, "ab") as dest, open(tmp_path, "rb") as src:
                dest.write(src.read())
                dest.flush()
                os.fsync(dest.fileno())
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
