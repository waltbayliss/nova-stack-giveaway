# agent-code-reviewer — Roadmap

**Version:** 1.0
**Date:** 2026-04-18

---

## Current State (v1.0)

- 5-dimension review checklist (structure, security, CLAUDE.md, functionality, docs)
- Two-pass cap with Nova escalation
- GitHub MCP write-back to target DECISIONS.md
- Nova report after every pass

---

## Near Term

- [ ] **Skill file: review-checklist.md** — extract the 5-dimension checklist into a dedicated skills/ file
- [ ] **Notion integration** — log every pass to a Notion "Agent Reviews" database
- [ ] **agent-memory.md calibration** — log recurring failure patterns to agent-memory.md

---

## Medium Term

- [ ] **Thin agent upgrade reviews** — extend review to cover legacy thin agents as they get upgraded
- [ ] **Security scan depth** — integrate with agent-security for lightweight credential scan in Dimension 2
- [ ] **Review history dashboard** — Notion view of all reviewed agents, pass counts, verdicts

---

## Long Term

- [ ] **Automated trigger** — n8n workflow fires review automatically on agent-builder repo push
- [ ] **Review diff** — on Pass 2, show only what changed since Pass 1
