# agent-code-reviewer — Product Requirements Document

**Version:** 1.0
**Date:** 2026-04-18
**Owner:** Walt Bayliss
**Status:** Active

---

## Overview

agent-code-reviewer is the quality gate of Walt's AI agent team. Every agent built or upgraded by agent-builder passes through this agent before being declared done. It reviews new builds across 5 structured dimensions, writes findings back to the agent's own DECISIONS.md, and reports a verdict to Nova.

It does not build. It does not operate agents. It inspects — and it catches what agent-builder missed.

---

## Target User

**Nova** — who routes every completed build here automatically.
**Walt** — who can invoke it directly ("review [agent-name]").

---

## Core Problem

Agent-builder can produce incomplete or subtly broken builds — missing files, placeholder docs, exposed structure, misaligned specs. Without a structured review pass, these agents go live with quality debt that compounds over time.

agent-code-reviewer exists to break that cycle. No agent ships without passing review.

---

## Feature Set

### Feature 1: 5-Dimension Structured Review
Every review covers:
1. Nova Standard Structure — all required files and folders present
2. Security — no credentials, SECURITY.md enforced, boot sequence wired
3. CLAUDE.md Quality — identity, triggers, hard rules, boot sequence complete
4. Functionality Alignment — PRD matches CLAUDE.md, skills exist, integrations wired
5. Documentation Quality — docs are real, not placeholders

### Feature 2: Two-Pass Cap
- Pass 1 → findings → agent-builder fixes → Pass 2
- Pass 2 → sign-off or escalate to Nova
- No Pass 3. Escalation means Nova decides what happens next.

### Feature 3: DECISIONS.md Write-Back
Every review finding is appended to the reviewed agent's `docs/DECISIONS.md` via GitHub MCP. Review that isn't recorded didn't happen.

### Feature 4: Nova Report
After every pass, agent-code-reviewer reports to Nova: verdict, required fixes, recommended items. Nova tracks pass count and routes accordingly.

### Feature 5: Notion Record (optional)
If a Notion "Agent Reviews" database is available, log each pass there for searchable history.

---

## Out of Scope
- agent-code-reviewer does not fix bugs — it identifies them
- It does not build missing files — it flags them
- It does not review code logic in detail — it reviews structure, security, and alignment
- It does not run tests — it inspects documents and structure
