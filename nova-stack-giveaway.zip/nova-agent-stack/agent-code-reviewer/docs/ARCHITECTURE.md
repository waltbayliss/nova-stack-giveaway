# agent-code-reviewer — Architecture

**Version:** 1.0
**Date:** 2026-04-18

---

## System Overview

agent-code-reviewer is a pure Claude Code agent — no server, no cron, no Cloudflare Worker. It is invoked by Nova (or Walt directly) inside a Claude Code session in the `agent-code-reviewer/` directory.

```
Nova / Walt
  │
  ▼
agent-code-reviewer (Claude Code session)
  │
  ├── GitHub MCP → reads target agent repo (waltbayliss/agent-[name])
  ├── GitHub MCP → appends findings to target agent's docs/DECISIONS.md
  └── (optional) Notion MCP → logs pass to Agent Reviews DB
```

---

## Runtime

- **Interface:** Claude Code (local), invoked from `my-ai-team/agent-code-reviewer/`
- **Trigger:** Nova routing phrase: "Review [agent-name] — Pass [N]. Repo: waltbayliss/[agent-name]"
- **No persistent process** — session-based, invoked per review

---

## Repository Structure

```
agent-code-reviewer/
├── CLAUDE.md
├── README.md
├── agent-memory.md
├── .env.example
├── docs/
│   ├── PRD.md
│   ├── ARCHITECTURE.md
│   ├── SOUL.md
│   ├── SECURITY.md
│   ├── ROADMAP.md
│   ├── DECISIONS.md
│   └── SPRINT_LOG.md
├── skills/
│   └── review-checklist.md
└── wiki/
    ├── Raw/
    ├── Wiki/
    ├── Output/
    └── Master/
        └── master-context.md
```

---

## Integrations

| Service | Purpose | How |
|---------|---------|-----|
| GitHub MCP | Read target agent repo files | `mcp__github__get_file_contents` |
| GitHub MCP | Write findings to target DECISIONS.md | `mcp__github__create_or_update_file` |
| Notion MCP | Log review pass (optional) | `notion-create-pages` or `notion-update-page` |

---

## Review Flow

```
1. Nova triggers: "Review [agent-name] — Pass N"
2. Reviewer reads target agent's GitHub repo (CLAUDE.md, docs/, skills/, wiki/ structure)
3. Runs 5-dimension checklist
4. Compiles findings report
5. Appends findings to target agent's docs/DECISIONS.md on GitHub
6. Reports verdict + required fixes to Nova
7. (optional) Logs pass to Notion
```

---

## Architectural Principles

1. **Read-only on itself** — the reviewer never modifies its own files during a review session
2. **Append-only on target** — findings are appended to DECISIONS.md, never overwrite
3. **Stateless per session** — no carry-forward state between sessions
4. **No execution** — reviewer identifies, it does not fix
