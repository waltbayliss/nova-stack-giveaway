---
name: review-standard
description: Standard code review for a Nova agent. Five dimensions, two-pass cap, dual write to GitHub + Notion. Use for all routine post-build reviews.
---

# Skill: review-standard

## Trigger
Called by Nova after agent-builder signals build complete, or on Walt's on-demand request.

## Input
- `agent_name` — the agent to review (e.g. `agent-content-suggestor`)
- `repo` — GitHub repo (e.g. `waltbayliss/agent-content-suggestor`)
- `pass_number` — 1 or 2

## Steps

1. **Read the agent repo** — CLAUDE.md, all docs/, all skills/, agent-memory.md, src/ if present
2. **Check pass count** — query Notion for existing review entries matching agent_name. If already 2 passes, refuse and report to Nova.
3. **Assess across 5 dimensions:**
   - Completeness: all 8 docs present? Nova standard structure followed?
   - Clarity: are prompts and boot sequences unambiguous?
   - Efficiency: any redundant logic, token waste, or unnecessary API calls?
   - Features: what's obviously missing that would add real value?
   - Best practices: security rules loaded first? env var hygiene? error handling?
4. **Implement safe fixes** — missing docs, typos, incomplete prompts. Commit directly.
5. **Write findings to DECISIONS.md** — append review block (see format in CLAUDE.md)
6. **Write Notion log entry** — Agent Pipeline DB, title: `[agent-name] — Review Pass N`
7. **Report to Nova** — what was found, what was fixed, what was flagged for builder

## Output
```
Review Pass N complete — [agent-name]
Fixed: [list]
Flagged for builder: [list]
Notion logged. DECISIONS.md updated.
[Pass 1: sending back to builder | Pass 2: agent signed off]
```
