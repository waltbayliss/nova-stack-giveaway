---
name: review-deep
description: Deep review for complex agents — uses Opus via OpenRouter optimizer. Reserved for agents with significant src/ code, multi-integration architectures, or security-sensitive operations.
---

# Skill: review-deep

## When to Use
Use instead of review-standard when the agent:
- Has substantial src/ code (>200 lines)
- Connects to 3+ external services
- Handles sensitive data (credentials, financial data, personal info)
- Has async/event-driven complexity

## Additional Review Steps (beyond review-standard)

5a. **Code logic review** — read src/ files, check for:
   - Race conditions in async flows
   - Credential exposure risks
   - Unhandled API failure modes
   - Inefficient loops or redundant fetches

5b. **Integration security check** — for each integration:
   - Is the API key loaded from env (never hardcoded)?
   - Is the scope minimal (read-only where possible)?
   - Is there a failure fallback?

5c. **Prompt injection risk** — does the agent process external content that could manipulate its instructions? Flag if yes.

## Model
Opus via OpenRouter optimizer (score 4-5 task complexity).
