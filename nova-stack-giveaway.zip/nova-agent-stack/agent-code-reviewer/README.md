# agent-code-reviewer

Nova-standard quality gate. Reviews every agent built by agent-builder across 5 dimensions: completeness, clarity, efficiency, features, and best practices. 2-pass cap. Findings written to GitHub DECISIONS.md + Notion.

---

## How It's Triggered

**Automatic:** agent-builder signals build complete → Nova routes to code-reviewer automatically.

**On-demand:** Tell Nova — _"review agent-[name]"_ → Nova triggers this agent.

---

## What It Reviews

1. Completeness — all 8 docs + Nova standard structure present?
2. Clarity — prompts and instructions unambiguous?
3. Efficiency — token waste, redundant logic?
4. Features — what's missing that would add real value?
5. Best practices — security, error handling, env var hygiene

---

## Output

- Appends findings to agent's `docs/DECISIONS.md` on GitHub
- Writes log entry to Notion Agent Pipeline DB
- Reports to Nova: what was found, what was fixed, what was flagged

---

## Two-Pass Cap

```
Builder builds → Reviewer Pass 1 → Builder fixes → Reviewer Pass 2 → DONE
```

No agent gets more than 2 review passes. After pass 2, agent is signed off.

---

## Repo

`waltbayliss/agent-code-reviewer` — private
